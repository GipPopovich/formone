(function(){
  'use strict';
  function protectStudioForm(form){
    if (!form || form.__feospSafetyBound) return;
    form.__feospSafetyBound = true;
    form.addEventListener('submit', function(){
      var honey = form.querySelector('input[name="fone_honey"]');
      if (honey && honey.value) {
        honey.value = '';
      }
    }, true);
  }
  function scan(){
    document.querySelectorAll('.feosp-widget-wrap form.fone-front-form').forEach(protectStudioForm);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scan);
  } else {
    scan();
  }
  document.addEventListener('elementor/popup/show', scan);
})();
