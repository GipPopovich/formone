<?php
/**
 * Plugin Name: Form One Elementor Studio Pro
 * Plugin URI:  https://neetly.eu/formone/
 * Description: Add-on Pro per costruire, sincronizzare e stilizzare form Form One direttamente da Elementor: step, libreria campi ampia, impostazioni avanzate e controlli design live.
 * Version:     1.0.5
 * Author:      Luigi Coppola
 * Author URI:  https://neetly.eu/formone/
 * Text Domain: form-one-elementor-studio-pro
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License:     GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('FEOSP_VERSION', '1.0.5');
define('FEOSP_FILE', __FILE__);
define('FEOSP_DIR', plugin_dir_path(__FILE__));
define('FEOSP_URL', plugin_dir_url(__FILE__));
define('FEOSP_BASENAME', plugin_basename(__FILE__));

function feosp_form_one_ready() {
    return defined('FONE_VERSION')
        && function_exists('fone_get_all_forms')
        && function_exists('fone_get_form')
        && function_exists('fone_save_form')
        && function_exists('fone_create_form');
}

function feosp_elementor_ready() {
    return did_action('elementor/loaded') || class_exists('\\Elementor\\Plugin') || class_exists('\\Elementor\\Widget_Base');
}

add_action('plugins_loaded', function () {
    load_plugin_textdomain('form-one-elementor-studio-pro', false, dirname(FEOSP_BASENAME) . '/languages');
}, 1);

add_action('wp_enqueue_scripts', 'feosp_register_assets');
add_action('elementor/frontend/after_register_styles', 'feosp_register_assets');
add_action('elementor/editor/after_enqueue_styles', function () {
    feosp_register_assets();
    wp_enqueue_style('feosp-editor');
});

function feosp_register_assets() {
    wp_register_style('feosp-frontend', FEOSP_URL . 'assets/studio-pro-frontend.css', [], FEOSP_VERSION);
    wp_register_style('feosp-editor', FEOSP_URL . 'assets/studio-pro-editor.css', [], FEOSP_VERSION);
}

add_action('elementor/elements/categories_registered', 'feosp_register_category', 20);
add_action('elementor/widgets/register', 'feosp_register_widgets', 20);
add_action('elementor/widgets/widgets_registered', 'feosp_register_widgets_legacy', 20);

function feosp_register_category($elements_manager) {
    if (!method_exists($elements_manager, 'add_category')) {
        return;
    }
    $elements_manager->add_category('form-one-studio', [
        'title' => __('Form One Studio', 'form-one-elementor-studio-pro'),
        'icon'  => 'fa fa-layer-group',
    ]);
}

function feosp_load_widget_files() {
    if (!class_exists('\\Elementor\\Widget_Base')) {
        return false;
    }
    require_once FEOSP_DIR . 'includes/class-feosp-sync.php';
    require_once FEOSP_DIR . 'includes/class-feosp-widget-studio-pro.php';
    return class_exists('FEOSP_Widget_Studio_Pro');
}

function feosp_register_widgets($widgets_manager) {
    if (!feosp_load_widget_files()) {
        return;
    }
    $widget = new FEOSP_Widget_Studio_Pro();
    if (method_exists($widgets_manager, 'register')) {
        $widgets_manager->register($widget);
    } elseif (method_exists($widgets_manager, 'register_widget_type')) {
        $widgets_manager->register_widget_type($widget);
    }
}

function feosp_register_widgets_legacy() {
    if (!class_exists('\\Elementor\\Plugin') || !isset(\Elementor\Plugin::$instance->widgets_manager)) {
        return;
    }
    feosp_register_widgets(\Elementor\Plugin::$instance->widgets_manager);
}



/**
 * Studio Pro 1.0.2 — protezione anti falso spam.
 *
 * Alcuni browser/password manager/temi possono valorizzare automaticamente
 * il campo honeypot off-screen di Form One (`fone_honey`). Quando questo accade,
 * il core Form One blocca il submit come spam PRIMA di arrivare all'invio email.
 *
 * Per i form creati e gestiti dallo Studio Pro neutralizziamo questo falso positivo
 * molto presto, prima degli handler Form One. Il frontend resta protetto da nonce,
 * rate limit, validazione, sanitizzazione e dal normale motore Form One.
 */
add_action('init', 'feosp_clear_false_honeypot_for_managed_forms', 0);
function feosp_clear_false_honeypot_for_managed_forms() {
    if (empty($_POST['fone_form_submit']) || empty($_POST['fone_form_id'])) {
        return;
    }

    $form_id = absint(wp_unslash($_POST['fone_form_id']));
    if (!$form_id || !feosp_is_managed_form_id($form_id)) {
        return;
    }

    if (isset($_POST['fone_honey']) && $_POST['fone_honey'] !== '') {
        $_POST['fone_honey'] = '';
        if (function_exists('error_log')) {
            error_log('[Form One Elementor Studio Pro] Honeypot non vuoto azzerato per form Studio #' . $form_id . ' per evitare falso positivo spam.');
        }
    }
}

function feosp_is_managed_form_id($form_id) {
    $form_id = absint($form_id);
    if (!$form_id) {
        return false;
    }

    if (!class_exists('FEOSP_Sync') && file_exists(FEOSP_DIR . 'includes/class-feosp-sync.php')) {
        require_once FEOSP_DIR . 'includes/class-feosp-sync.php';
    }
    if (class_exists('FEOSP_Sync') && method_exists('FEOSP_Sync', 'is_managed_form_id')) {
        return FEOSP_Sync::is_managed_form_id($form_id);
    }

    $map = get_option('feosp_managed_forms', []);
    if (is_array($map)) {
        foreach ($map as $id) {
            if (absint($id) === $form_id) {
                return true;
            }
        }
    }

    if (function_exists('fone_get_form')) {
        $form = fone_get_form($form_id);
        if (!empty($form['settings']['feosp_managed'])) {
            return true;
        }
    }

    return false;
}

add_action('wp_enqueue_scripts', 'feosp_enqueue_frontend_safety_script', 30);
function feosp_enqueue_frontend_safety_script() {
    wp_register_script('feosp-frontend-safety', FEOSP_URL . 'assets/studio-pro-frontend.js', [], FEOSP_VERSION, true);
    wp_enqueue_script('feosp-frontend-safety');
}


/**
 * Studio Pro 1.0.4 — handler submit anticipato per form gestiti dallo Studio.
 *
 * Motivo: il core Form One normalmente processa il POST dentro lo shortcode.
 * Se Elementor non riesce a recuperare l'ID del form nel render frontend,
 * il shortcode non viene eseguito e quindi non nasce nessun invio.
 * Qui intercettiamo SOLO i form marcati come gestiti dallo Studio Pro e
 * lasciamo comunque lavorare il motore Form One: validazione, entry, email,
 * registrazione, login, webhook e messaggi restano quelli del core.
 */
add_action('template_redirect', 'feosp_handle_managed_submission_early', 1);
function feosp_handle_managed_submission_early() {
    static $done = false;
    if ($done) {
        return;
    }
    if (empty($_POST['fone_form_submit']) || empty($_POST['fone_form_id']) || empty($_POST['fone_form_nonce'])) {
        return;
    }

    $form_id = absint(wp_unslash($_POST['fone_form_id']));
    if (!$form_id || !feosp_is_managed_form_id($form_id)) {
        return;
    }
    if (!function_exists('fone_get_form') || !function_exists('fone_handle_submission')) {
        return;
    }

    $form = fone_get_form($form_id);
    if (empty($form) || empty($form['schema']) || !is_array($form['schema'])) {
        return;
    }

    $done = true;
    $result = fone_handle_submission($form['schema'], $form_id);

    $base_url = wp_get_referer();
    if (!$base_url) {
        $base_url = get_permalink();
    }
    if (!$base_url) {
        $base_url = home_url('/');
    }

    $flash_qkey = 'fone_flash_' . $form_id;
    $done_qkey  = 'fone_done_' . $form_id;
    $success_qkey = 'fone_success_' . $form_id;

    if (!empty($result['success'])) {
        $success_key = wp_generate_uuid4();
        set_transient('fone_success_' . $success_key, [
            'values' => !empty($result['values']) ? $result['values'] : [],
            'schema' => $form['schema'],
            'form_id' => $form_id,
        ], 5 * MINUTE_IN_SECONDS);

        $redirect = remove_query_arg([$flash_qkey, $done_qkey, $success_qkey], $base_url);
        $redirect = add_query_arg([
            $done_qkey => '1',
            $success_qkey => $success_key,
        ], $redirect);
        wp_safe_redirect($redirect);
        exit;
    }

    $key = wp_generate_uuid4();
    set_transient('fone_flash_' . $key, [
        'errors' => !empty($result['errors']) ? $result['errors'] : ['global' => __('Invio non completato. Controlla i campi e riprova.', 'form-one-elementor-studio-pro')],
        'values' => !empty($result['values']) ? $result['values'] : [],
    ], 5 * MINUTE_IN_SECONDS);

    $redirect = remove_query_arg([$flash_qkey, $done_qkey, $success_qkey], $base_url);
    $redirect = add_query_arg($flash_qkey, $key, $redirect);
    wp_safe_redirect($redirect);
    exit;
}

add_action('admin_menu', function () {
    if (!current_user_can('manage_options')) {
        return;
    }
    add_submenu_page(
        'fone-forms',
        __('Elementor Studio Pro', 'form-one-elementor-studio-pro'),
        __('Elementor Studio Pro', 'form-one-elementor-studio-pro'),
        'manage_options',
        'feosp-studio-pro',
        'feosp_admin_page'
    );
}, 99);

function feosp_admin_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $form_one_ok = feosp_form_one_ready();
    $elementor_ok = feosp_elementor_ready();
    ?>
    <div class="wrap">
        <h1>Form One Elementor Studio Pro</h1>
        <p><strong>Versione:</strong> <?php echo esc_html(FEOSP_VERSION); ?></p>
        <table class="widefat striped" style="max-width:860px">
            <tbody>
                <tr><td><strong>Stato add-on</strong></td><td>✅ attivo</td></tr>
                <tr><td><strong>Form One</strong></td><td><?php echo $form_one_ok ? '✅ rilevato' : '❌ non rilevato'; ?></td></tr>
                <tr><td><strong>Elementor</strong></td><td><?php echo $elementor_ok ? '✅ rilevato' : '❌ non rilevato'; ?></td></tr>
                <tr><td><strong>Nome widget</strong></td><td>Form One Elementor Studio Pro</td></tr>
                <tr><td><strong>Categoria Elementor</strong></td><td>Form One Studio</td></tr>
                <tr><td><strong>Modalità</strong></td><td>Usa form esistente / Studio Pro con sync nel backend Form One</td></tr>
            </tbody>
        </table>
        <p style="margin-top:20px">Per usarlo: apri Elementor e cerca <strong>Form One Elementor Studio Pro</strong>, <strong>studio</strong> oppure <strong>form one</strong>.</p>
        <p>Nota: i form creati dallo Studio Pro vengono salvati nel database Form One e restano modificabili anche dal backend Form One.</p>
    </div>
    <?php
}

add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    $screen_id = $screen ? (string) $screen->id : '';
    if ($screen_id && strpos($screen_id, 'plugins') === false && strpos($screen_id, 'form') === false && strpos($screen_id, 'feosp') === false) {
        return;
    }
    $missing = [];
    if (!feosp_form_one_ready()) {
        $missing[] = 'Form One 1.0.0+';
    }
    if (!feosp_elementor_ready()) {
        $missing[] = 'Elementor';
    }
    if (!$missing) {
        return;
    }
    echo '<div class="notice notice-warning"><p><strong>Form One Elementor Studio Pro</strong>: per funzionare richiede questi plugin attivi: ' . esc_html(implode(', ', $missing)) . '.</p></div>';
});

add_filter('plugin_action_links_' . FEOSP_BASENAME, function ($links) {
    $links[] = '<a href="' . esc_url(admin_url('admin.php?page=feosp-studio-pro')) . '">' . esc_html__('Stato Studio Pro', 'form-one-elementor-studio-pro') . '</a>';
    return $links;
});

register_uninstall_hook(__FILE__, 'feosp_uninstall');
function feosp_uninstall() {
    delete_option('feosp_managed_forms');
}
