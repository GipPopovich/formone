=== Form One Elementor Studio Pro ===
Contributors: Luigi Coppola
Tags: form one, elementor, forms, lead generation, multistep
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.5
License: GPLv2 or later

Form One Elementor Studio Pro porta dentro Elementor un pannello avanzato per creare, sincronizzare e stilizzare form Form One.

== Description ==

Form One Elementor Studio Pro è un add-on separato per Form One.
Permette di usare form esistenti oppure creare form da Elementor con step, campi, impostazioni email, registrazione/login e controlli stile live.

Il motore resta Form One: submit, registrazione, login, email, token e backend restano gestiti dal plugin principale.

== Installation ==

1. Installa e attiva Form One.
2. Installa e attiva Elementor.
3. Installa e attiva Form One Elementor Studio Pro.
4. Apri Elementor e cerca "Form One Elementor Studio Pro".

== Changelog ==

= 1.0.5 =
* Aggiunti controlli hover separati per submit e continua.
* Rafforzati i selector Elementor live per pulsanti, campi, opzioni e messaggi.
* Aggiunti controlli hover campo, hover opzioni, colore cursore testo, padding/radius messaggi.


= 1.0.4 =
* Hotfix critico email + messaggio successo: rimosso flag interno non gestito dal core che bloccava il flusso. Aggiunti fallback robusti per email admin, oggetto email e messaggio di successo: se l'utente lascia vuoti i campi nel widget Elementor, il sistema usa valori predefiniti sensati invece di mandare valori vuoti al core.
* Email utente di conferma ora ATTIVA di default (era spenta): chi compila il form riceve sempre la mail di ricevuta.
* Hover dei pulsanti ora visibili: aggiunte regole :hover, :active, :focus-visible per submit, continue, profile, whatsapp e link sotto al form. Anche gli input al passaggio del cursore mostrano un bordo più scuro.
* Stato disabled (in attesa) per submit/continue: cursore "wait" e leggero grayscale per chiarire che il click è già stato processato.
* Focus accessibile da tastiera con outline visibile.

= 1.0.2 =
* Template Registrazione utenti abilita automaticamente la registrazione Form One.
* Template Login utenti abilita automaticamente il login Form One.
* CSS Elementor rafforzati per pulsanti, colori, progress bar, focus, campi e messaggi con selettori più forti.
* Aggiunti controlli stile separati per submit, continua/step e larghezza pulsanti.

= 1.0.0 =
* Prima versione Pro.
* Widget Form One Elementor Studio Pro.
* Modalità form esistente e Studio Pro.
* Step configurabili.
* Libreria campi ampia e leggibile.
* Molti controlli stile live in Elementor.
* Sync sicura nel database Form One.


= 1.0.2 =
* Fix falso positivo spam/honeypot per form creati da Elementor Studio Pro.
* Aggiunta protezione JS frontend che svuota il campo honeypot prima del submit nei form Studio.
* Aggiunta segnalazione errore se wp_mail fallisce sui form Studio Pro.
