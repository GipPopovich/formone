<?php
/**
 * Widget Elementor Pro: Form One Elementor Studio Pro.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (class_exists('\\Elementor\\Widget_Base') && !class_exists('FEOSP_Widget_Studio_Pro')) {
    class FEOSP_Widget_Studio_Pro extends \Elementor\Widget_Base {
        public function get_name() {
            return 'form_one_elementor_studio_pro';
        }

        public function get_title() {
            return __('Form One Elementor Studio Pro', 'form-one-elementor-studio-pro');
        }

        public function get_icon() {
            return 'eicon-form-horizontal';
        }

        public function get_categories() {
            return ['form-one-studio', 'general'];
        }

        public function get_keywords() {
            return ['form one', 'studio pro', 'form', 'elementor', 'step', 'multistep', 'registrazione', 'login', 'lead'];
        }

        public function get_style_depends() {
            return ['feosp-frontend'];
        }

        protected function register_controls() {
            $this->register_content_controls();
            $this->register_step_controls();
            $this->register_field_controls();
            $this->register_submit_controls();
            $this->register_account_controls();
            $this->register_advanced_controls();
            $this->register_style_controls();
        }

        private function form_options() {
            $options = ['' => __('— Seleziona un form —', 'form-one-elementor-studio-pro')];
            if (!function_exists('fone_get_all_forms')) {
                return $options;
            }
            foreach ((array) fone_get_all_forms() as $form) {
                if (empty($form['id'])) {
                    continue;
                }
                $label = !empty($form['form_name']) ? (string) $form['form_name'] : sprintf(__('Form #%d', 'form-one-elementor-studio-pro'), (int) $form['id']);
                if (!empty($form['is_registration'])) {
                    $label .= ' — ' . __('Registrazione', 'form-one-elementor-studio-pro');
                }
                if (!empty($form['is_login'])) {
                    $label .= ' — ' . __('Login', 'form-one-elementor-studio-pro');
                }
                $options[(int) $form['id']] = $label;
            }
            return $options;
        }

        private function register_content_controls() {
            $this->start_controls_section('feosp_main_section', [
                'label' => __('Studio Pro', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]);

            $this->add_control('mode', [
                'label'   => __('Modalità', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'studio',
                'options' => [
                    'existing' => __('Usa form esistente Form One', 'form-one-elementor-studio-pro'),
                    'studio'   => __('Studio Pro: crea/gestisci da Elementor', 'form-one-elementor-studio-pro'),
                ],
            ]);

            $this->add_control('existing_form_id', [
                'label'       => __('Form esistente', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => '',
                'options'     => $this->form_options(),
                'label_block' => true,
                'condition'   => ['mode' => 'existing'],
            ]);

            $this->add_control('studio_notice', [
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => __('Studio Pro salva il form dentro Form One. Il form resta modificabile anche dal backend Form One. La sincronizzazione avviene solo in editor/preview admin, mai sul frontend pubblico.', 'form-one-elementor-studio-pro'),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                'condition'       => ['mode' => 'studio'],
            ]);

            $this->add_control('studio_form_name', [
                'label'       => __('Nome form nel backend Form One', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => __('Form One Elementor Studio Pro', 'form-one-elementor-studio-pro'),
                'label_block' => true,
                'condition'   => ['mode' => 'studio'],
            ]);

            $this->add_control('preset_mode', [
                'label'   => __('Origine campi', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'manual',
                'options' => [
                    'manual'   => __('Uso i campi manuali qui sotto', 'form-one-elementor-studio-pro'),
                    'template' => __('Uso un template pronto', 'form-one-elementor-studio-pro'),
                ],
                'condition' => ['mode' => 'studio'],
            ]);

            $this->add_control('studio_template', [
                'label'   => __('Template pronto', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'contact',
                'options' => [
                    'contact'      => __('Contatto', 'form-one-elementor-studio-pro'),
                    'quote'        => __('Richiesta preventivo', 'form-one-elementor-studio-pro'),
                    'lead'         => __('Lead magnet', 'form-one-elementor-studio-pro'),
                    'registration' => __('Registrazione utenti', 'form-one-elementor-studio-pro'),
                    'login'        => __('Login utenti', 'form-one-elementor-studio-pro'),
                    'booking'      => __('Prenotazione appuntamento', 'form-one-elementor-studio-pro'),
                    'survey'       => __('Survey / feedback', 'form-one-elementor-studio-pro'),
                ],
                'condition' => ['mode' => 'studio', 'preset_mode' => 'template'],
            ]);

            $this->add_control('registration_template_notice', [
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => __('Questo template abilita automaticamente la registrazione Form One e salva il form come form di registrazione anche nel backend. Email, username e password vengono mappati sui campi WordPress.', 'form-one-elementor-studio-pro'),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-success',
                'condition'       => ['mode' => 'studio', 'preset_mode' => 'template', 'studio_template' => 'registration'],
            ]);

            $this->add_control('login_template_notice', [
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => __('Questo template abilita automaticamente il login Form One. Il submit viene gestito dal core Form One, non dallo Studio Pro.', 'form-one-elementor-studio-pro'),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-success',
                'condition'       => ['mode' => 'studio', 'preset_mode' => 'template', 'studio_template' => 'login'],
            ]);

            $this->add_control('studio_title', [
                'label'       => __('Titolo form', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => __('Iniziamo', 'form-one-elementor-studio-pro'),
                'label_block' => true,
                'condition'   => ['mode' => 'studio'],
            ]);

            $this->add_control('studio_subtitle', [
                'label'       => __('Sottotitolo form', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => __('Compila il percorso guidato: pochi passaggi, più ordine, meno attrito.', 'form-one-elementor-studio-pro'),
                'rows'        => 2,
                'condition'   => ['mode' => 'studio'],
            ]);

            $this->end_controls_section();
        }

        private function register_step_controls() {
            $this->start_controls_section('feosp_steps_section', [
                'label'     => __('Step del form', 'form-one-elementor-studio-pro'),
                'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => ['mode' => 'studio'],
            ]);

            $this->add_control('show_step_headings', [
                'label'        => __('Mostra titoli step nel form', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ]);

            $step = new \Elementor\Repeater();
            $step->add_control('step_title', [
                'label'       => __('Titolo step', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => __('Nuovo step', 'form-one-elementor-studio-pro'),
                'label_block' => true,
            ]);
            $step->add_control('step_subtitle', [
                'label' => __('Sottotitolo step', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::TEXTAREA,
                'rows'  => 2,
            ]);
            $step->add_control('step_layout', [
                'label'   => __('Layout campi nello step', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '1col',
                'options' => [
                    '1col' => __('Una colonna', 'form-one-elementor-studio-pro'),
                    '2col' => __('Due colonne', 'form-one-elementor-studio-pro'),
                ],
            ]);

            $this->add_control('studio_steps', [
                'label'       => __('Lista step', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $step->get_controls(),
                'title_field' => '{{{ step_title }}}',
                'default'     => [
                    ['step_title' => 'I tuoi dati', 'step_subtitle' => 'Partiamo dalle informazioni principali.', 'step_layout' => '2col'],
                    ['step_title' => 'Dettagli', 'step_subtitle' => 'Aggiungi quello che serve.', 'step_layout' => '1col'],
                    ['step_title' => 'Conferma', 'step_subtitle' => 'Ultimo passaggio prima dell’invio.', 'step_layout' => '1col'],
                ],
            ]);

            $this->add_control('step_help', [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw'  => __('Nei singoli campi scegli il numero step: 1, 2, 3 ecc. Gli step creati qui servono anche per i titoli visibili e il layout nel backend Form One.', 'form-one-elementor-studio-pro'),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]);

            $this->end_controls_section();
        }

        private function register_field_controls() {
            $this->start_controls_section('feosp_fields_section', [
                'label'     => __('Libreria campi', 'form-one-elementor-studio-pro'),
                'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => ['mode' => 'studio', 'preset_mode' => 'manual'],
            ]);

            $repeater = new \Elementor\Repeater();
            $repeater->add_control('field_type', [
                'label'   => __('Tipo campo', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::SELECT2,
                'default' => 'text',
                'options' => FEOSP_Sync::field_type_options(),
                'label_block' => true,
            ]);
            $repeater->add_control('field_label', [
                'label'       => __('Etichetta', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => __('Campo', 'form-one-elementor-studio-pro'),
                'label_block' => true,
            ]);
            $repeater->add_control('field_slug', [
                'label'       => __('Slug / nome tecnico', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'description' => __('Lascia vuoto per generarlo automaticamente. Esempi: name, email, phone, privacy.', 'form-one-elementor-studio-pro'),
            ]);
            $repeater->add_control('field_placeholder', [
                'label'       => __('Placeholder', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'label_block' => true,
            ]);
            $repeater->add_control('field_help', [
                'label' => __('Testo aiuto / microcopy', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::TEXTAREA,
                'rows'  => 2,
            ]);
            $repeater->add_control('field_required', [
                'label'        => __('Obbligatorio', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $repeater->add_control('field_step', [
                'label'   => __('Numero step', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 20,
                'step'    => 1,
                'default' => 1,
            ]);
            $repeater->add_control('field_width', [
                'label'   => __('Larghezza', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'full',
                'options' => [
                    'full'       => __('100%', 'form-one-elementor-studio-pro'),
                    'half'       => __('50%', 'form-one-elementor-studio-pro'),
                    'third'      => __('33%', 'form-one-elementor-studio-pro'),
                    'two-thirds' => __('66%', 'form-one-elementor-studio-pro'),
                ],
            ]);
            $repeater->add_control('field_options', [
                'label'       => __('Opzioni', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'description' => __('Una opzione per riga. Usato da select, radio, checkbox, prodotto, fasce orarie.', 'form-one-elementor-studio-pro'),
            ]);
            $repeater->add_control('field_default', [
                'label' => __('Valore default', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]);
            $repeater->add_control('wp_field', [
                'label'   => __('Mappa WordPress', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __('Nessuna / meta utente', 'form-one-elementor-studio-pro'),
                    'first_name' => __('Nome WP', 'form-one-elementor-studio-pro'),
                    'last_name' => __('Cognome WP', 'form-one-elementor-studio-pro'),
                    'display_name' => __('Nome visualizzato WP', 'form-one-elementor-studio-pro'),
                    'user_login' => __('Username WP', 'form-one-elementor-studio-pro'),
                    'user_email' => __('Email WP', 'form-one-elementor-studio-pro'),
                    'user_pass' => __('Password WP', 'form-one-elementor-studio-pro'),
                ],
            ]);
            $repeater->add_control('meta_key', [
                'label' => __('Meta key utente', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'description' => __('Opzionale: salva questo campo come meta utente con questa chiave.', 'form-one-elementor-studio-pro'),
            ]);
            $repeater->add_control('email_confirm', [
                'label'        => __('Richiedi conferma email', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $repeater->add_control('max_chars', [
                'label' => __('Max caratteri textarea', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::NUMBER,
                'min'   => 0,
                'max'   => 5000,
                'step'  => 10,
                'default' => 0,
            ]);
            $repeater->add_control('opt_min', [
                'label' => __('Min', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]);
            $repeater->add_control('opt_max', [
                'label' => __('Max', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]);
            $repeater->add_control('opt_step', [
                'label' => __('Step numerico', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => '1',
            ]);
            $repeater->add_control('accept_types', [
                'label' => __('MIME accettati upload', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => '',
            ]);
            $repeater->add_control('max_size_mb', [
                'label' => __('Max MB upload', 'form-one-elementor-studio-pro'),
                'type'  => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
                'default' => 10,
            ]);

            $this->add_control('studio_fields', [
                'label'       => __('Campi del form', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ field_label }}} — {{{ field_type }}}',
                'default'     => [
                    ['field_type'=>'first_name','field_label'=>'Nome','field_slug'=>'first_name','field_step'=>1,'field_width'=>'half','field_required'=>'yes','wp_field'=>'first_name'],
                    ['field_type'=>'email','field_label'=>'Email','field_slug'=>'email','field_step'=>1,'field_width'=>'half','field_required'=>'yes','wp_field'=>'user_email'],
                    ['field_type'=>'tel','field_label'=>'Telefono','field_slug'=>'phone','field_step'=>1,'field_width'=>'half'],
                    ['field_type'=>'select','field_label'=>'Tipo richiesta','field_slug'=>'request_type','field_step'=>2,'field_width'=>'full','field_options'=>'Informazioni\nPreventivo\nCollaborazione\nAltro'],
                    ['field_type'=>'textarea','field_label'=>'Messaggio','field_slug'=>'message','field_step'=>2,'field_width'=>'full','field_required'=>'yes'],
                    ['field_type'=>'privacy','field_label'=>'Privacy','field_slug'=>'privacy','field_step'=>3,'field_width'=>'full','field_required'=>'yes'],
                    ['field_type'=>'submit','field_label'=>'Invia richiesta','field_slug'=>'submit','field_step'=>3,'field_width'=>'full'],
                ],
            ]);

            $this->end_controls_section();
        }

        private function register_submit_controls() {
            $this->start_controls_section('feosp_submit_section', [
                'label'     => __('Invio / Email', 'form-one-elementor-studio-pro'),
                'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => ['mode' => 'studio'],
            ]);
            $this->add_control('success_message', [
                'label'   => __('Messaggio successo', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'rows'    => 3,
                'default' => __('Messaggio inviato con successo. Ti risponderemo al più presto!', 'form-one-elementor-studio-pro'),
            ]);
            $this->add_control('submit_button_text', [
                'label'   => __('Testo pulsante invio', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => __('Invia', 'form-one-elementor-studio-pro'),
            ]);
            $this->add_control('admin_email', [
                'label'       => __('Email amministratore', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => get_option('admin_email'),
                'label_block' => true,
            ]);
            $this->add_control('admin_email_subject', [
                'label'       => __('Oggetto email admin', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '[Form One] Nuovo invio',
                'label_block' => true,
            ]);
            $this->add_control('user_email_enabled', [
                'label'        => __('Email conferma utente', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ]);
            $this->add_control('user_email_subject', [
                'label'       => __('Oggetto email utente', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => 'Abbiamo ricevuto il tuo messaggio',
                'label_block' => true,
                'condition'   => ['user_email_enabled' => 'yes'],
            ]);
            $this->end_controls_section();
        }

        private function register_account_controls() {
            $this->start_controls_section('feosp_account_section', [
                'label'     => __('Registrazione / Login', 'form-one-elementor-studio-pro'),
                'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => ['mode' => 'studio'],
            ]);
            $this->add_control('account_auto_notice', [
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => __('Nota: se usi il template pronto Registrazione utenti o Login utenti, lo Studio Pro abilita automaticamente il relativo flusso nel motore Form One. Questi interruttori servono soprattutto per i form manuali.', 'form-one-elementor-studio-pro'),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]);

            $this->add_control('enable_registration', [
                'label'        => __('Abilita registrazione utenti', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $this->add_control('registration_role', [
                'label'   => __('Ruolo nuovo utente', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'subscriber',
                'options' => [
                    'subscriber' => 'Subscriber',
                    'contributor' => 'Contributor',
                    'author' => 'Author',
                    'customer' => 'Customer',
                ],
                'condition' => ['enable_registration' => 'yes'],
            ]);
            $this->add_control('registration_autologin', [
                'label'        => __('Auto-login dopo registrazione', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => ['enable_registration' => 'yes'],
            ]);
            $this->add_control('registration_send_wp_email', [
                'label'        => __('Email WordPress registrazione', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => ['enable_registration' => 'yes'],
            ]);
            $this->add_control('registration_redirect', [
                'label'       => __('Redirect dopo registrazione', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'label_block' => true,
                'condition'   => ['enable_registration' => 'yes'],
            ]);
            $this->add_control('enable_login', [
                'label'        => __('Abilita login utenti', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $this->add_control('profile_url', [
                'label'       => __('URL area personale', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'label_block' => true,
            ]);
            $this->add_control('auto_redirect_profile', [
                'label'        => __('Redirect automatico al profilo', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $this->add_control('auto_redirect_delay', [
                'label'      => __('Secondi redirect', 'form-one-elementor-studio-pro'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'range'      => ['px' => ['min' => 3, 'max' => 30]],
                'default'    => ['size' => 8],
                'condition'  => ['auto_redirect_profile' => 'yes'],
            ]);
            $this->end_controls_section();
        }

        private function register_advanced_controls() {
            $this->start_controls_section('feosp_features_section', [
                'label'     => __('Azioni / Funzioni avanzate', 'form-one-elementor-studio-pro'),
                'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => ['mode' => 'studio'],
            ]);
            $this->add_control('whatsapp_enabled', [
                'label'        => __('Mostra WhatsApp dopo invio', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $this->add_control('whatsapp_number', [
                'label'       => __('Numero WhatsApp', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'label_block' => true,
                'condition'   => ['whatsapp_enabled' => 'yes'],
            ]);
            $this->add_control('whatsapp_message', [
                'label'     => __('Messaggio WhatsApp', 'form-one-elementor-studio-pro'),
                'type'      => \Elementor\Controls_Manager::TEXTAREA,
                'default'   => 'Ciao, ho appena inviato il form.',
                'condition' => ['whatsapp_enabled' => 'yes'],
            ]);
            $this->add_control('webhook_enabled', [
                'label'        => __('Invia webhook', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $this->add_control('webhook_url', [
                'label'       => __('URL webhook', 'form-one-elementor-studio-pro'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'label_block' => true,
                'condition'   => ['webhook_enabled' => 'yes'],
            ]);
            $this->add_control('first_yes_enabled', [
                'label'        => __('First Yes Mode', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $this->add_control('first_yes_button_label', [
                'label'     => __('Testo primo pulsante', 'form-one-elementor-studio-pro'),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'default'   => 'Inizia',
                'condition' => ['first_yes_enabled' => 'yes'],
            ]);
            $this->add_control('first_yes_hint', [
                'label'     => __('Hint First Yes', 'form-one-elementor-studio-pro'),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'default'   => 'Ti guidiamo un passo alla volta.',
                'condition' => ['first_yes_enabled' => 'yes'],
            ]);
            $this->add_control('resume_later_enabled', [
                'label'        => __('Resume Later', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $this->add_control('resume_later_ttl_days', [
                'label'      => __('Giorni salvataggio', 'form-one-elementor-studio-pro'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'range'      => ['px' => ['min' => 1, 'max' => 90]],
                'default'    => ['size' => 7],
                'condition'  => ['resume_later_enabled' => 'yes'],
            ]);
            $this->add_control('microcopy_assistant', [
                'label'        => __('Microcopy Assistant', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
            ]);
            $this->add_control('reveal_animation', [
                'label'   => __('Animazione reveal', 'form-one-elementor-studio-pro'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'from-top',
                'options' => [
                    'none' => __('Nessuna', 'form-one-elementor-studio-pro'),
                    'from-top' => __('Dall’alto', 'form-one-elementor-studio-pro'),
                    'fade' => __('Fade', 'form-one-elementor-studio-pro'),
                ],
            ]);
            $this->end_controls_section();
        }

        private function register_style_controls() {
            $this->start_controls_section('feosp_style_container', [
                'label' => __('Stile contenitore', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]);
            $this->add_responsive_control('wrapper_max_width', [
                'label' => __('Larghezza massima', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px','%'],
                'range' => ['px' => ['min' => 240, 'max' => 1400], '%' => ['min' => 20, 'max' => 100]],
                'default' => ['size' => 760, 'unit' => 'px'],
                'selectors' => ['{{WRAPPER}} .feosp-widget-wrap' => 'max-width: {{SIZE}}{{UNIT}};'],
            ]);
            $this->add_responsive_control('wrapper_align', [
                'label' => __('Allineamento', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    '0 auto 0 0' => ['title' => __('Sinistra', 'form-one-elementor-studio-pro'), 'icon' => 'eicon-text-align-left'],
                    '0 auto' => ['title' => __('Centro', 'form-one-elementor-studio-pro'), 'icon' => 'eicon-text-align-center'],
                    '0 0 0 auto' => ['title' => __('Destra', 'form-one-elementor-studio-pro'), 'icon' => 'eicon-text-align-right'],
                ],
                'default' => '0 auto',
                'selectors' => ['{{WRAPPER}} .feosp-widget-wrap' => 'margin: {{VALUE}};'],
            ]);
            $this->add_responsive_control('container_padding', [
                'label' => __('Padding esterno', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px','em','%'],
                'selectors' => ['{{WRAPPER}} .feosp-widget-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Background::get_type(), [
                'name' => 'container_background',
                'selector' => '{{WRAPPER}} .feosp-widget-wrap',
            ]);
            $this->add_group_control(\Elementor\Group_Control_Border::get_type(), [
                'name' => 'container_border',
                'selector' => '{{WRAPPER}} .feosp-widget-wrap',
            ]);
            $this->add_responsive_control('container_radius', [
                'label' => __('Border radius contenitore', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors' => ['{{WRAPPER}} .feosp-widget-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Box_Shadow::get_type(), [
                'name' => 'container_shadow',
                'selector' => '{{WRAPPER}} .feosp-widget-wrap',
            ]);
            $this->end_controls_section();

            $this->start_controls_section('feosp_style_form', [
                'label' => __('Stile form', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]);
            $this->add_control('accent_color', [
                'label' => __('Colore accento Form One', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2563eb',
                'selectors' => ['{{WRAPPER}} .fone-wrap' => '--fone-accent: {{VALUE}} !important;'],
            ]);
            $this->add_control('progress_color', [
                'label' => __('Colore progress / selezioni', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2563eb',
                'selectors' => [
                    '{{WRAPPER}} .fone-progress-bar > span' => 'background: {{VALUE}} !important;',
                    '{{WRAPPER}} .fone-progress-fill' => 'background: {{VALUE}} !important;',
                    '{{WRAPPER}} .fone-nps button.is-selected' => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important; color: #fff !important;',
                    '{{WRAPPER}} .fone-rating .is-selected, {{WRAPPER}} .fone-rating button.is-selected' => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important; color: #fff !important;',
                ],
            ]);
            $this->add_responsive_control('form_padding', [
                'label' => __('Padding form', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px','em','%'],
                'selectors' => ['{{WRAPPER}} .fone-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Background::get_type(), [
                'name' => 'form_background',
                'selector' => '{{WRAPPER}} .fone-wrap',
            ]);
            $this->add_group_control(\Elementor\Group_Control_Border::get_type(), [
                'name' => 'form_border',
                'selector' => '{{WRAPPER}} .fone-wrap',
            ]);
            $this->add_responsive_control('field_radius', [
                'label' => __('Radius campi/Form One', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 60]],
                'default' => ['size' => 14],
                'selectors' => ['{{WRAPPER}} .fone-wrap' => '--fone-radius: {{SIZE}}px; border-radius: {{SIZE}}px;'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Box_Shadow::get_type(), [
                'name' => 'form_shadow',
                'selector' => '{{WRAPPER}} .fone-wrap',
            ]);
            $this->end_controls_section();

            $this->start_controls_section('feosp_style_titles', [
                'label' => __('Titolo e sottotitolo', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]);
            $this->add_control('title_color', [
                'label' => __('Colore titolo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-form-title' => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .fone-form-title',
            ]);
            $this->add_control('subtitle_color', [
                'label' => __('Colore sottotitolo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-form-subtitle' => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
                'name' => 'subtitle_typography',
                'selector' => '{{WRAPPER}} .fone-form-subtitle',
            ]);
            $this->add_responsive_control('title_align', [
                'label' => __('Allineamento testo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => ['title' => __('Sinistra', 'form-one-elementor-studio-pro'), 'icon' => 'eicon-text-align-left'],
                    'center' => ['title' => __('Centro', 'form-one-elementor-studio-pro'), 'icon' => 'eicon-text-align-center'],
                    'right' => ['title' => __('Destra', 'form-one-elementor-studio-pro'), 'icon' => 'eicon-text-align-right'],
                ],
                'selectors' => ['{{WRAPPER}} .fone-form-header' => 'text-align: {{VALUE}};'],
            ]);
            $this->end_controls_section();

            $this->start_controls_section('feosp_style_steps', [
                'label' => __('Step / sezioni', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]);
            $this->add_responsive_control('step_gap', [
                'label' => __('Distanza step', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 80]],
                'selectors' => ['{{WRAPPER}} .fone-step-card' => 'margin-bottom: {{SIZE}}px;'],
            ]);
            $this->add_control('step_heading_color', [
                'label' => __('Colore titolo step', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-section-divider strong' => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
                'name' => 'step_heading_typography',
                'selector' => '{{WRAPPER}} .fone-section-divider strong',
            ]);
            $this->add_control('step_box_background', [
                'label' => __('Sfondo titolo step', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-section-divider' => 'background: {{VALUE}} !important;'],
            ]);
            $this->add_responsive_control('step_box_padding', [
                'label' => __('Padding titolo step', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => ['{{WRAPPER}} .fone-section-divider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]);
            $this->end_controls_section();

            $this->start_controls_section('feosp_style_labels', [
                'label' => __('Label e testi aiuto', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]);
            $this->add_control('label_color', [
                'label' => __('Colore label', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-field label, {{WRAPPER}} .fone-avatar-label' => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
                'name' => 'label_typography',
                'selector' => '{{WRAPPER}} .fone-field label, {{WRAPPER}} .fone-avatar-label',
            ]);
            $this->add_responsive_control('label_spacing', [
                'label' => __('Spazio sotto label', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 40]],
                'selectors' => ['{{WRAPPER}} .fone-field label' => 'margin-bottom: {{SIZE}}px;'],
            ]);
            $this->add_control('help_color', [
                'label' => __('Colore microcopy', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-help, {{WRAPPER}} .fone-section-divider small' => 'color: {{VALUE}} !important;'],
            ]);
            $this->end_controls_section();

            $this->start_controls_section('feosp_style_fields', [
                'label' => __('Campi', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]);
            $field_selector = '{{WRAPPER}} .fone-field input:not([type="checkbox"]):not([type="radio"]), {{WRAPPER}} .fone-field select, {{WRAPPER}} .fone-field textarea';
            $this->add_responsive_control('fields_padding', [
                'label' => __('Padding campi', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [$field_selector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]);
            $this->add_control('fields_bg', [
                'label' => __('Sfondo campi', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$field_selector => 'background-color: {{VALUE}} !important;'],
            ]);
            $this->add_control('fields_color', [
                'label' => __('Colore testo campi', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$field_selector => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_control('placeholder_color', [
                'label' => __('Colore placeholder', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .fone-field input::placeholder' => 'color: {{VALUE}} !important;',
                    '{{WRAPPER}} .fone-field textarea::placeholder' => 'color: {{VALUE}} !important;',
                ],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Border::get_type(), [
                'name' => 'fields_border',
                'selector' => $field_selector,
            ]);
            $this->add_responsive_control('fields_radius', [
                'label' => __('Radius campi', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors' => [$field_selector => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]);
            $this->add_control('fields_focus_border', [
                'label' => __('Bordo focus', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$field_selector . ':focus' => 'border-color: {{VALUE}} !important; outline-color: {{VALUE}} !important; box-shadow: 0 0 0 4px color-mix(in srgb, {{VALUE}} 18%, transparent) !important;'],
            ]);
            $this->add_control('fields_hover_bg', [
                'label' => __('Sfondo hover campo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$field_selector . ':hover' => 'background-color: {{VALUE}} !important;'],
            ]);
            $this->add_control('fields_hover_border', [
                'label' => __('Bordo hover campo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$field_selector . ':hover' => 'border-color: {{VALUE}} !important;'],
            ]);
            $this->add_control('fields_caret_color', [
                'label' => __('Colore cursore testo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$field_selector => 'caret-color: {{VALUE}} !important;'],
            ]);
            $this->add_responsive_control('field_gap', [
                'label' => __('Spazio tra campi', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 80]],
                'selectors' => ['{{WRAPPER}} .fone-step-grid' => 'gap: {{SIZE}}px;'],
            ]);
            $this->end_controls_section();

            $this->start_controls_section('feosp_style_choices', [
                'label' => __('Checkbox / radio / scale', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]);
            $this->add_control('choice_bg', [
                'label' => __('Sfondo opzioni', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-choice-row' => 'background: {{VALUE}} !important;'],
            ]);
            $this->add_control('choice_color', [
                'label' => __('Colore testo opzioni', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-choice-row' => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_control('choice_hover_bg', [
                'label' => __('Sfondo hover opzioni', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-choice-row:hover' => 'background: {{VALUE}} !important;'],
            ]);
            $this->add_control('choice_hover_color', [
                'label' => __('Testo hover opzioni', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-choice-row:hover' => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_control('choice_checked_accent', [
                'label' => __('Colore spunta / selezione', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-choice-row input:checked' => 'accent-color: {{VALUE}} !important;'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Border::get_type(), [
                'name' => 'choice_border',
                'selector' => '{{WRAPPER}} .fone-choice-row',
            ]);
            $this->add_responsive_control('choice_radius', [
                'label' => __('Radius opzioni', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 40]],
                'selectors' => ['{{WRAPPER}} .fone-choice-row' => 'border-radius: {{SIZE}}px;'],
            ]);
            $this->end_controls_section();

            $this->start_controls_section('feosp_style_buttons', [
                'label' => __('Pulsanti', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]);
            $button_selector = '{{WRAPPER}} .feosp-widget-wrap .fone-submit-btn, {{WRAPPER}} .feosp-widget-wrap .fone-continue-btn, {{WRAPPER}} .feosp-widget-wrap .fone-profile-btn, {{WRAPPER}} .feosp-widget-wrap .fone-whatsapp-btn';
            $submit_selector = '{{WRAPPER}} .feosp-widget-wrap .fone-submit-btn';
            $continue_selector = '{{WRAPPER}} .feosp-widget-wrap .fone-continue-btn';
            $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
                'name' => 'button_typography',
                'selector' => $button_selector,
            ]);
            $this->add_responsive_control('button_padding', [
                'label' => __('Padding pulsanti', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [$button_selector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;'],
            ]);
            $this->add_control('button_bg', [
                'label' => __('Sfondo pulsanti', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$button_selector => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important;'],
            ]);
            $this->add_control('button_color', [
                'label' => __('Testo pulsanti', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$button_selector => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_control('button_hover_bg', [
                'label' => __('Hover sfondo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$button_selector . ':hover' => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important; filter: none !important;'],
            ]);
            $this->add_control('button_hover_color', [
                'label' => __('Hover testo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$button_selector . ':hover' => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_control('submit_bg', [
                'label' => __('Solo submit: sfondo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$submit_selector => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important;'],
            ]);
            $this->add_control('submit_color', [
                'label' => __('Solo submit: testo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$submit_selector => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_control('submit_hover_bg', [
                'label' => __('Solo submit: hover sfondo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    $submit_selector . ':hover:not([disabled])' => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important; filter: none !important;',
                    $submit_selector . ':focus-visible' => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important; filter: none !important;',
                ],
            ]);
            $this->add_control('submit_hover_color', [
                'label' => __('Solo submit: hover testo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    $submit_selector . ':hover:not([disabled])' => 'color: {{VALUE}} !important;',
                    $submit_selector . ':focus-visible' => 'color: {{VALUE}} !important;',
                ],
            ]);
            $this->add_control('continue_bg', [
                'label' => __('Solo continua: sfondo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$continue_selector => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important;'],
            ]);
            $this->add_control('continue_color', [
                'label' => __('Solo continua: testo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [$continue_selector => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_control('continue_hover_bg', [
                'label' => __('Solo continua: hover sfondo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    $continue_selector . ':hover:not([disabled])' => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important; filter: none !important;',
                    $continue_selector . ':focus-visible' => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important; filter: none !important;',
                ],
            ]);
            $this->add_control('continue_hover_color', [
                'label' => __('Solo continua: hover testo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    $continue_selector . ':hover:not([disabled])' => 'color: {{VALUE}} !important;',
                    $continue_selector . ':focus-visible' => 'color: {{VALUE}} !important;',
                ],
            ]);
            $this->add_control('button_full_width', [
                'label'        => __('Pulsanti a larghezza piena', 'form-one-elementor-studio-pro'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => '',
                'selectors'    => [$button_selector => 'width: 100% !important;'],
            ]);
            $this->add_responsive_control('button_radius', [
                'label' => __('Radius pulsanti', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 60]],
                'selectors' => [$button_selector => 'border-radius: {{SIZE}}px !important;'],
            ]);
            $this->add_group_control(\Elementor\Group_Control_Box_Shadow::get_type(), [
                'name' => 'button_shadow',
                'selector' => $button_selector,
            ]);
            $this->end_controls_section();

            $this->start_controls_section('feosp_style_messages', [
                'label' => __('Messaggi successo / errore', 'form-one-elementor-studio-pro'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]);
            $this->add_control('success_bg', [
                'label' => __('Sfondo successo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-success-box' => 'background: {{VALUE}} !important;'],
            ]);
            $this->add_control('success_color', [
                'label' => __('Testo successo', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-success-box' => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_control('error_bg', [
                'label' => __('Sfondo errore', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-global-error, {{WRAPPER}} .fone-field-error' => 'background: {{VALUE}} !important;'],
            ]);
            $this->add_control('error_color', [
                'label' => __('Testo errore', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .fone-global-error, {{WRAPPER}} .fone-field-error' => 'color: {{VALUE}} !important;'],
            ]);
            $this->add_responsive_control('message_padding', [
                'label' => __('Padding messaggi', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px','em'],
                'selectors' => ['{{WRAPPER}} .fone-success-box, {{WRAPPER}} .fone-global-error, {{WRAPPER}} .fone-field-error' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;'],
            ]);
            $this->add_responsive_control('message_radius', [
                'label' => __('Radius messaggi', 'form-one-elementor-studio-pro'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 50]],
                'selectors' => ['{{WRAPPER}} .fone-success-box, {{WRAPPER}} .fone-global-error, {{WRAPPER}} .fone-field-error' => 'border-radius: {{SIZE}}px !important;'],
            ]);
            $this->end_controls_section();
        }

        protected function render() {
            $settings = $this->get_settings_for_display();
            echo '<div class="feosp-widget-wrap">';

            if (!function_exists('do_shortcode')) {
                echo '<div class="feosp-alert">WordPress non pronto.</div></div>';
                return;
            }
            if (!feosp_form_one_ready()) {
                echo '<div class="feosp-alert">Form One non è attivo o non è compatibile.</div></div>';
                return;
            }

            $mode = isset($settings['mode']) ? $settings['mode'] : 'studio';
            $form_id = 0;
            if ($mode === 'existing') {
                $form_id = !empty($settings['existing_form_id']) ? absint($settings['existing_form_id']) : 0;
            } else {
                $form_id = FEOSP_Sync::sync_form($settings, $this->get_id(), get_the_ID());
            }

            if (!$form_id) {
                echo '<div class="feosp-alert">Seleziona o crea un form Form One.</div></div>';
                return;
            }

            $preview = '0';
            if (class_exists('\\Elementor\\Plugin') && isset(\Elementor\Plugin::$instance->editor) && method_exists(\Elementor\Plugin::$instance->editor, 'is_edit_mode') && \Elementor\Plugin::$instance->editor->is_edit_mode()) {
                $preview = '1';
            }
            echo do_shortcode('[form_one id="' . absint($form_id) . '" preview="' . esc_attr($preview) . '"]');
            echo '</div>';
        }
    }
}
