<?php
/**
 * Sync sicura tra Elementor Studio Pro e database Form One.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('FEOSP_Sync')) {
    class FEOSP_Sync {
        public static function field_type_options() {
            return [
                'text' => '— BASE — 📝 Testo breve',
                'textarea' => '— BASE — 💬 Testo lungo / messaggio',
                'email' => '— BASE — 📧 Email',
                'tel' => '— BASE — 📱 Telefono',
                'number' => '— BASE — 🔢 Numero',
                'url' => '— BASE — 🌐 URL / sito web',
                'hidden' => '— BASE — 👁️ Campo nascosto',
                'html' => '— BASE — 🧩 HTML libero',
                'divider' => '— BASE — ➖ Separatore / linea',
                'section_title' => '— BASE — 🏷️ Titolo sezione',

                'first_name' => '— UTENTE — 👤 Nome',
                'last_name' => '— UTENTE — 👤 Cognome',
                'full_name' => '— UTENTE — 👥 Nome completo',
                'username' => '— UTENTE — 🆔 Username',
                'password' => '— UTENTE — 🔐 Password',
                'password_confirm' => '— UTENTE — 🔐 Conferma password',
                'avatar' => '— UTENTE — 🖼️ Avatar / foto profilo',
                'bio' => '— UTENTE — ✍️ Biografia breve',
                'user_role_text' => '— UTENTE — 🧑‍💼 Ruolo / professione',
                'company' => '— UTENTE — 🏢 Azienda',
                'job_title' => '— UTENTE — 💼 Qualifica / mansione',

                'address' => '— ANAGRAFICA — 📍 Indirizzo',
                'city' => '— ANAGRAFICA — 🏙️ Città',
                'province' => '— ANAGRAFICA — 🗺️ Provincia',
                'zip' => '— ANAGRAFICA — 📮 CAP',
                'region' => '— ANAGRAFICA — 🗺️ Regione',
                'country' => '— ANAGRAFICA — 🌍 Paese',
                'birthdate' => '— ANAGRAFICA — 🎂 Data di nascita',
                'gender' => '— ANAGRAFICA — ⚧ Sesso / genere',
                'tax_code' => '— ANAGRAFICA — 🧾 Codice fiscale',
                'vat_number' => '— ANAGRAFICA — 🧾 Partita IVA',

                'select' => '— SCELTE — ⬇️ Menu a tendina',
                'radio' => '— SCELTE — 🔘 Radio button',
                'checkbox' => '— SCELTE — ☑️ Checkbox multiple',
                'consent' => '— SCELTE — ✅ Consenso semplice',
                'privacy' => '— SCELTE — 🔒 Consenso privacy',
                'marketing_consent' => '— SCELTE — 📣 Consenso marketing',
                'terms' => '— SCELTE — 📜 Accettazione termini',
                'yes_no' => '— SCELTE — ✅ Sì / No',
                'scale' => '— SCELTE — 📊 Scala numerica',
                'image_choice' => '— SCELTE — 🖼️ Scelta immagini (testuale)',

                'date' => '— DATE — 📅 Data',
                'time' => '— DATE — 🕒 Ora',
                'datetime' => '— DATE — 📆 Data e ora',
                'time_slot' => '— DATE — ⏱️ Fascia oraria',
                'appointment_date' => '— DATE — 📌 Calendario appuntamento',

                'file' => '— AVANZATI — 📎 Upload file',
                'rating' => '— AVANZATI — ⭐ Valutazione a stelle',
                'nps' => '— AVANZATI — 📈 NPS',
                'range' => '— AVANZATI — 🎚️ Slider numerico',
                'color' => '— AVANZATI — 🎨 Colore',
                'whatsapp' => '— AVANZATI — 🟢 WhatsApp',
                'amount' => '— AVANZATI — 💶 Importo',
                'quantity' => '— AVANZATI — 🔢 Quantità',
                'product_choice' => '— AVANZATI — 🛒 Scelta prodotto/servizio',
                'coupon' => '— AVANZATI — 🎟️ Codice coupon',
                'source_url' => '— TRACKING — 🔗 URL sorgente',
                'utm_source' => '— TRACKING — 📡 UTM source',
                'utm_campaign' => '— TRACKING — 📣 UTM campaign',
                'submit' => '— AZIONE — 🚀 Pulsante invio',
            ];
        }

        public static function is_safe_sync_context() {
            if (!current_user_can('manage_options')) {
                return false;
            }
            if (is_admin()) {
                return true;
            }
            if (class_exists('\\Elementor\\Plugin') && isset(\Elementor\Plugin::$instance)) {
                $plugin = \Elementor\Plugin::$instance;
                if (isset($plugin->editor) && method_exists($plugin->editor, 'is_edit_mode') && $plugin->editor->is_edit_mode()) {
                    return true;
                }
                if (isset($plugin->preview) && method_exists($plugin->preview, 'is_preview_mode') && $plugin->preview->is_preview_mode()) {
                    return true;
                }
            }
            return false;
        }

        public static function sync_form(array $settings, $widget_id = '', $post_id = 0) {
            if (!function_exists('fone_create_form') || !function_exists('fone_save_form')) {
                return 0;
            }

            // Sul frontend NON creiamo e NON aggiorniamo form.
            // Recuperiamo solo un ID già sincronizzato in editor/admin.
            if (!self::is_safe_sync_context()) {
                return self::get_managed_form_id($widget_id, $post_id);
            }

            $key = self::managed_key($widget_id, $post_id);
            $form_id = self::get_managed_form_id($widget_id, $post_id);
            $form_name = self::clean_text($settings['studio_form_name'] ?? 'Form One Elementor Studio Pro');
            if ($form_name === '') {
                $form_name = 'Form One Elementor Studio Pro';
            }

            if (!$form_id || !function_exists('fone_get_form') || !fone_get_form($form_id)) {
                $form_id = (int) fone_create_form($form_name);
                self::save_managed_form_id($key, $form_id, $widget_id, $post_id);
            }
            if (!$form_id) {
                return 0;
            }

            $schema = self::build_schema($settings, $key);
            $form_settings = self::build_settings($settings);
            $layouts = self::build_layouts($settings, $schema);
            $custom_css = self::build_custom_css($settings);

            $saved = fone_save_form($form_id, [
                'form_name' => $form_name,
                'schema' => $schema,
                'settings' => $form_settings,
                'layouts' => $layouts,
                'custom_css' => $custom_css,
                'is_registration' => !empty($form_settings['enable_registration']) ? 1 : 0,
                'is_login' => !empty($form_settings['enable_login']) ? 1 : 0,
            ]);

            // Anche se fone_save_form restituisce false perché i dati non cambiano,
            // l'ID resta valido. Salviamo comunque tutte le chiavi di risoluzione.
            self::save_managed_form_id($key, $form_id, $widget_id, $post_id);

            // Marcatori utili per debug e riconoscimento lato core/admin.
            update_post_meta(absint($post_id), '_feosp_has_studio_form', 1);

            return $form_id;
        }

        public static function managed_key($widget_id, $post_id = 0) {
            $post_id = $post_id ? absint($post_id) : absint(get_the_ID());
            return sanitize_key('post_' . $post_id . '_widget_' . (string) $widget_id);
        }

        private static function widget_key($widget_id) {
            return sanitize_key('widget_' . (string) $widget_id);
        }

        public static function get_managed_form_id($widget_id, $post_id = 0) {
            $map = get_option('feosp_managed_forms', []);
            if (!is_array($map) || !$map) {
                return 0;
            }

            $strict_key = self::managed_key($widget_id, $post_id);
            if (!empty($map[$strict_key])) {
                $id = absint($map[$strict_key]);
                if ($id && self::form_exists($id)) {
                    return $id;
                }
            }

            // Fallback fondamentale: Elementor può cambiare contesto tra editor,
            // preview, template e frontend. La chiave widget-only evita che il
            // form creato nello Studio diventi invisibile sul frontend.
            $widget_key = self::widget_key($widget_id);
            if (!empty($map[$widget_key])) {
                $id = absint($map[$widget_key]);
                if ($id && self::form_exists($id)) {
                    return $id;
                }
            }

            // Fallback ulteriore: cerca qualsiasi chiave che finisca con lo stesso widget.
            $needle = '_widget_' . sanitize_key((string) $widget_id);
            foreach ($map as $key => $id) {
                $id = absint($id);
                if (!$id) {
                    continue;
                }
                if (substr((string) $key, -strlen($needle)) === $needle && self::form_exists($id)) {
                    return $id;
                }
            }

            // Ultimo fallback in POST: se l'HTML già renderizzato invia un ID Form One
            // marcato come gestito dallo Studio, lo usiamo per non perdere il submit.
            if (!empty($_POST['fone_form_submit']) && !empty($_POST['fone_form_id'])) {
                $posted_id = absint(wp_unslash($_POST['fone_form_id']));
                if ($posted_id && self::is_managed_form_id($posted_id) && self::form_exists($posted_id)) {
                    return $posted_id;
                }
            }

            return 0;
        }

        public static function is_managed_form_id($form_id) {
            $form_id = absint($form_id);
            if (!$form_id) {
                return false;
            }
            $map = get_option('feosp_managed_forms', []);
            if (is_array($map) && $map) {
                foreach ($map as $id) {
                    if (absint($id) === $form_id) {
                        return true;
                    }
                }
            }
            $form = self::form_exists($form_id) ? fone_get_form($form_id) : null;
            return !empty($form['settings']['feosp_managed']);
        }

        private static function form_exists($form_id) {
            return function_exists('fone_get_form') && $form_id && (bool) fone_get_form(absint($form_id));
        }

        private static function save_managed_form_id($key, $form_id, $widget_id = '', $post_id = 0) {
            $form_id = absint($form_id);
            if (!$form_id) {
                return;
            }
            $map = get_option('feosp_managed_forms', []);
            if (!is_array($map)) {
                $map = [];
            }
            $map[sanitize_key($key)] = $form_id;
            if ($widget_id !== '') {
                $map[self::widget_key($widget_id)] = $form_id;
            }
            if ($post_id) {
                $map[self::managed_key($widget_id, $post_id)] = $form_id;
            }
            update_option('feosp_managed_forms', $map, false);
        }

        public static function build_settings(array $settings) {
            $defaults = function_exists('fone_default_settings') ? fone_default_settings() : [];
            $out = is_array($defaults) ? $defaults : [];

            $preset_mode = sanitize_key($settings['preset_mode'] ?? 'manual');
            $template    = sanitize_key($settings['studio_template'] ?? 'contact');
            $is_template_registration = ($preset_mode === 'template' && $template === 'registration');
            $is_template_login        = ($preset_mode === 'template' && $template === 'login');

            $out['form_title'] = self::clean_text($settings['studio_title'] ?? '');
            $out['form_subtitle'] = sanitize_textarea_field($settings['studio_subtitle'] ?? '');

            // Studio Pro 1.0.3: fallback robusti.
            // sanitize_*('') ritorna '' (non null), quindi `?? default` non basta.
            // Se l'utente lascia vuoti i campi nel widget Elementor, dobbiamo
            // forzare i fallback altrimenti il core Form One non manda email
            // e non mostra messaggio di successo.
            $success_message = sanitize_textarea_field($settings['success_message'] ?? '');
            $out['success_message'] = ($success_message !== '')
                ? $success_message
                : 'Messaggio inviato con successo.';

            $out['accent_color'] = self::clean_color($settings['accent_color'] ?? '#2563eb');
            $out['border_radius'] = self::slider_size($settings['field_radius'] ?? null, 14);
            $out['reveal_animation'] = sanitize_key($settings['reveal_animation'] ?? 'from-top');

            // Email admin: se vuota o non valida, fallback ad admin_email del sito.
            $admin_email_raw = sanitize_email($settings['admin_email'] ?? '');
            $out['admin_email'] = is_email($admin_email_raw)
                ? $admin_email_raw
                : sanitize_email(get_option('admin_email'));

            $admin_subj = self::clean_text($settings['admin_email_subject'] ?? '');
            $out['admin_email_subject'] = ($admin_subj !== '')
                ? $admin_subj
                : '[Form One] Nuovo invio';

            // Email utente: di default ATTIVA per non sorprendere chi non
            // sa di doverla accendere a mano. L'utente può sempre disattivarla.
            $user_email_raw = $settings['user_email_enabled'] ?? 'yes';
            $out['user_email_enabled'] = self::is_yes($user_email_raw) ? 1 : 0;

            $user_subj = self::clean_text($settings['user_email_subject'] ?? '');
            $out['user_email_subject'] = ($user_subj !== '')
                ? $user_subj
                : 'Abbiamo ricevuto il tuo messaggio';

            $manual_registration = self::is_yes($settings['enable_registration'] ?? '');
            $manual_login        = self::is_yes($settings['enable_login'] ?? '');

            // Regola Pro 1.0.1:
            // se il template scelto è Registrazione/Login, il flag Form One viene acceso automaticamente.
            // Così Elementor non crea più un form che sembra registrazione ma viene trattato come form normale.
            $out['enable_registration'] = ($is_template_registration || ($manual_registration && !$is_template_login)) ? 1 : 0;
            $out['registration_role'] = sanitize_key($settings['registration_role'] ?? 'subscriber');
            $out['registration_autologin'] = self::is_yes($settings['registration_autologin'] ?? 'yes') ? 1 : 0;
            $out['registration_send_wp_email'] = self::is_yes($settings['registration_send_wp_email'] ?? 'yes') ? 1 : 0;
            $out['registration_redirect'] = esc_url_raw($settings['registration_redirect'] ?? '');

            $out['enable_login'] = ($is_template_login || ($manual_login && empty($out['enable_registration']))) ? 1 : 0;
            $out['profile_url'] = esc_url_raw($settings['profile_url'] ?? '');
            $out['auto_redirect_profile'] = self::is_yes($settings['auto_redirect_profile'] ?? '') ? 1 : 0;
            $out['auto_redirect_delay'] = self::slider_size($settings['auto_redirect_delay'] ?? null, 8);

            $out['whatsapp_enabled'] = self::is_yes($settings['whatsapp_enabled'] ?? '') ? 1 : 0;
            $out['whatsapp_number'] = preg_replace('/[^0-9+]/', '', (string) ($settings['whatsapp_number'] ?? ''));
            $out['whatsapp_message'] = sanitize_textarea_field($settings['whatsapp_message'] ?? 'Ciao, ho appena inviato il form.');
            $out['webhook_enabled'] = self::is_yes($settings['webhook_enabled'] ?? '') ? 1 : 0;
            $out['webhook_url'] = esc_url_raw($settings['webhook_url'] ?? '');
            $out['first_yes_enabled'] = self::is_yes($settings['first_yes_enabled'] ?? '') ? 1 : 0;
            $out['first_yes_button_label'] = self::clean_text($settings['first_yes_button_label'] ?? 'Inizia');
            $out['first_yes_hint'] = self::clean_text($settings['first_yes_hint'] ?? 'Ti guidiamo un passo alla volta.');
            $out['resume_later_enabled'] = self::is_yes($settings['resume_later_enabled'] ?? '') ? 1 : 0;
            $out['resume_later_ttl_days'] = self::slider_size($settings['resume_later_ttl_days'] ?? null, 7);
            $out['microcopy_assistant'] = self::is_yes($settings['microcopy_assistant'] ?? '') ? 1 : 0;
            $out['feosp_managed'] = 1;

            // Studio Pro 1.0.3: rimosso 'require_email_success' che non era gestito
            // dal core Form One e poteva causare comportamenti imprevisti del messaggio
            // di successo. Adesso il flusso normale del core manda l'email e mostra
            // il messaggio in maniera coerente con il resto di Form One.

            return $out;
        }

        public static function build_schema(array $settings, $key) {
            $mode = sanitize_key($settings['preset_mode'] ?? 'manual');
            $template = sanitize_key($settings['studio_template'] ?? 'contact');
            $raw_fields = [];

            if ($mode === 'template') {
                $raw_fields = self::template_fields($template);
            } elseif (!empty($settings['studio_fields']) && is_array($settings['studio_fields'])) {
                $raw_fields = $settings['studio_fields'];
            }
            if (!$raw_fields) {
                $raw_fields = self::template_fields('contact');
            }

            $fields = [];
            $seen = [];
            $show_step_headings = self::is_yes($settings['show_step_headings'] ?? 'yes');
            $steps = self::normalized_steps($settings);

            if ($show_step_headings) {
                foreach ($steps as $num => $step) {
                    if (!empty($step['title'])) {
                        $fields[] = self::normalize_field([
                            'field_type' => 'section_title',
                            'field_label' => $step['title'],
                            'field_help' => $step['subtitle'],
                            'field_slug' => 'step_' . $num . '_title',
                            'field_step' => $num,
                            'field_width' => 'full',
                        ], $key, count($fields) + 1, $seen);
                    }
                }
            }

            foreach ($raw_fields as $item) {
                $field = self::normalize_field((array) $item, $key, count($fields) + 1, $seen);
                if ($field) {
                    $fields[] = $field;
                }
            }

            if (!self::has_submit($fields)) {
                $fields[] = self::normalize_field([
                    'field_type' => 'submit',
                    'field_label' => self::clean_text($settings['submit_button_text'] ?? 'Invia'),
                    'field_slug' => 'submit',
                    'field_step' => self::max_step($fields),
                    'field_width' => 'full',
                ], $key, count($fields) + 1, $seen);
            }

            return array_values(array_filter($fields));
        }

        private static function normalize_field(array $item, $key, $index, array &$seen) {
            $kind = sanitize_key($item['field_type'] ?? 'text');
            $map = self::map_kind($kind);
            $type = $map['type'];
            $label = self::clean_text($item['field_label'] ?? '');
            if ($label === '') {
                $label = $map['label'];
            }
            $slug = sanitize_key($item['field_slug'] ?? '');
            if ($slug === '') {
                $slug = sanitize_key($map['slug']);
            }
            if ($slug === '') {
                $slug = 'field_' . absint($index);
            }
            $base = $slug;
            $counter = 2;
            while (isset($seen[$slug])) {
                $slug = $base . '_' . $counter++;
            }
            $seen[$slug] = true;

            $options = sanitize_textarea_field($item['field_options'] ?? '');
            if ($options === '' && !empty($map['options'])) {
                $options = $map['options'];
            }

            $default = self::clean_text($item['field_default'] ?? '');
            if ($default === '' && !empty($map['default'])) {
                $default = $map['default'];
            }

            $field = [
                'id' => 'feosp_' . substr(md5($key . '_' . $index . '_' . $slug . '_' . $kind), 0, 12),
                'type' => $type,
                'slug' => $slug,
                'label' => $label,
                'placeholder' => self::clean_text($item['field_placeholder'] ?? $map['placeholder']),
                'help' => sanitize_textarea_field($item['field_help'] ?? ''),
                'required' => self::is_yes($item['field_required'] ?? '') ? 1 : 0,
                'step' => max(1, absint($item['field_step'] ?? 1)),
                'width' => self::clean_width($item['field_width'] ?? $map['width']),
                'options' => $options,
                'default_value' => $default,
                'autocomp' => self::clean_text($map['autocomplete']),
                'wp_field' => sanitize_key($item['wp_field'] ?? $map['wp_field']),
                'meta_key' => sanitize_key($item['meta_key'] ?? ''),
                'studio_kind' => $kind,
            ];

            if ($type === 'file' || $type === 'avatar') {
                $field['accept_types'] = sanitize_text_field($item['accept_types'] ?? ($type === 'avatar' ? 'image/jpeg,image/png,image/webp' : 'application/pdf,image/jpeg,image/png,image/webp,text/plain'));
                $field['max_size_mb'] = max(1, absint($item['max_size_mb'] ?? 10));
            }
            if (in_array($type, ['number','range','rating','nps'], true)) {
                $field['opt_min'] = self::clean_text($item['opt_min'] ?? $map['min']);
                $field['opt_max'] = self::clean_text($item['opt_max'] ?? $map['max']);
                $field['opt_step'] = self::clean_text($item['opt_step'] ?? '1');
            }
            if ($type === 'textarea' && !empty($item['max_chars'])) {
                $field['max_chars'] = absint($item['max_chars']);
            }
            if ($type === 'password') {
                $field['opt_show_strength'] = 1;
            }
            if ($kind === 'email' && self::is_yes($item['email_confirm'] ?? '')) {
                $field['opt_require_confirm'] = 1;
            }
            if ($kind === 'hidden' && $field['default_value'] === '') {
                $field['default_value'] = $slug === 'source_url' ? home_url(add_query_arg(null, null)) : '';
            }

            return $field;
        }

        private static function map_kind($kind) {
            $base = [
                'type' => 'text', 'label' => 'Campo', 'slug' => $kind, 'placeholder' => '', 'width' => 'full', 'options' => '', 'default' => '', 'wp_field' => '', 'autocomplete' => 'off', 'min' => '', 'max' => ''
            ];
            $maps = [
                'text' => ['type'=>'text','label'=>'Testo breve','slug'=>'text','placeholder'=>'Scrivi qui','width'=>'half'],
                'textarea' => ['type'=>'textarea','label'=>'Messaggio','slug'=>'message','placeholder'=>'Scrivi qui','width'=>'full'],
                'email' => ['type'=>'email','label'=>'Email','slug'=>'email','placeholder'=>'nome@email.it','width'=>'half','wp_field'=>'user_email','autocomplete'=>'email'],
                'tel' => ['type'=>'tel','label'=>'Telefono','slug'=>'phone','placeholder'=>'333 1234567','width'=>'half','autocomplete'=>'tel'],
                'number' => ['type'=>'number','label'=>'Numero','slug'=>'number','placeholder'=>'0','width'=>'half'],
                'url' => ['type'=>'url','label'=>'Sito web','slug'=>'website','placeholder'=>'https://','width'=>'half','autocomplete'=>'url'],
                'hidden' => ['type'=>'hidden','label'=>'Campo nascosto','slug'=>'hidden','width'=>'full'],
                'html' => ['type'=>'html','label'=>'<strong>Blocco HTML</strong>','slug'=>'html','width'=>'full'],
                'divider' => ['type'=>'divider','label'=>'Separatore','slug'=>'divider','width'=>'full'],
                'section_title' => ['type'=>'divider','label'=>'Titolo sezione','slug'=>'section','width'=>'full'],
                'first_name' => ['type'=>'name','label'=>'Nome','slug'=>'first_name','placeholder'=>'Mario','width'=>'half','wp_field'=>'first_name','autocomplete'=>'given-name'],
                'last_name' => ['type'=>'name','label'=>'Cognome','slug'=>'last_name','placeholder'=>'Rossi','width'=>'half','wp_field'=>'last_name','autocomplete'=>'family-name'],
                'full_name' => ['type'=>'name','label'=>'Nome completo','slug'=>'display_name','placeholder'=>'Mario Rossi','width'=>'full','wp_field'=>'display_name','autocomplete'=>'name'],
                'username' => ['type'=>'text','label'=>'Username','slug'=>'username','placeholder'=>'mariorossi','width'=>'half','wp_field'=>'user_login','autocomplete'=>'username'],
                'password' => ['type'=>'password','label'=>'Password','slug'=>'password','placeholder'=>'Password','width'=>'half','wp_field'=>'user_pass','autocomplete'=>'new-password'],
                'password_confirm' => ['type'=>'password','label'=>'Conferma password','slug'=>'password_confirm','placeholder'=>'Ripeti password','width'=>'half','autocomplete'=>'new-password'],
                'avatar' => ['type'=>'avatar','label'=>'Foto profilo','slug'=>'avatar','width'=>'full'],
                'bio' => ['type'=>'textarea','label'=>'Biografia breve','slug'=>'description','placeholder'=>'Raccontati in poche righe','width'=>'full'],
                'user_role_text' => ['type'=>'text','label'=>'Ruolo / professione','slug'=>'role_text','placeholder'=>'Es. Designer','width'=>'half'],
                'company' => ['type'=>'text','label'=>'Azienda','slug'=>'company','placeholder'=>'Nome azienda','width'=>'half','autocomplete'=>'organization'],
                'job_title' => ['type'=>'text','label'=>'Qualifica / mansione','slug'=>'job_title','placeholder'=>'Es. Responsabile marketing','width'=>'half'],
                'address' => ['type'=>'text','label'=>'Indirizzo','slug'=>'address','placeholder'=>'Via e numero civico','width'=>'full','autocomplete'=>'street-address'],
                'city' => ['type'=>'text','label'=>'Città','slug'=>'city','placeholder'=>'Latina','width'=>'half','autocomplete'=>'address-level2'],
                'province' => ['type'=>'text','label'=>'Provincia','slug'=>'province','placeholder'=>'LT','width'=>'half'],
                'zip' => ['type'=>'text','label'=>'CAP','slug'=>'zip','placeholder'=>'04100','width'=>'half','autocomplete'=>'postal-code'],
                'region' => ['type'=>'text','label'=>'Regione','slug'=>'region','placeholder'=>'Lazio','width'=>'half','autocomplete'=>'address-level1'],
                'country' => ['type'=>'text','label'=>'Paese','slug'=>'country','placeholder'=>'Italia','width'=>'half','autocomplete'=>'country-name'],
                'birthdate' => ['type'=>'date','label'=>'Data di nascita','slug'=>'birthdate','width'=>'half'],
                'gender' => ['type'=>'select','label'=>'Sesso / genere','slug'=>'gender','placeholder'=>'Seleziona','width'=>'half','options'=>'Donna\nUomo\nNon specificato\nAltro'],
                'tax_code' => ['type'=>'text','label'=>'Codice fiscale','slug'=>'tax_code','placeholder'=>'RSSMRA...','width'=>'half'],
                'vat_number' => ['type'=>'text','label'=>'Partita IVA','slug'=>'vat_number','placeholder'=>'IT00000000000','width'=>'half'],
                'select' => ['type'=>'select','label'=>'Menu a tendina','slug'=>'select','placeholder'=>'Seleziona','width'=>'half','options'=>'Opzione 1\nOpzione 2\nOpzione 3'],
                'radio' => ['type'=>'radio','label'=>'Scelta singola','slug'=>'radio','width'=>'full','options'=>'Opzione 1\nOpzione 2\nOpzione 3'],
                'checkbox' => ['type'=>'checkbox','label'=>'Scelte multiple','slug'=>'checkbox','width'=>'full','options'=>'Opzione 1\nOpzione 2\nOpzione 3'],
                'consent' => ['type'=>'consent','label'=>'Acconsento','slug'=>'consent','width'=>'full','default'=>'Acconsento.'],
                'privacy' => ['type'=>'consent','label'=>'Privacy','slug'=>'privacy','width'=>'full','default'=>'Accetto il trattamento dei dati personali.'],
                'marketing_consent' => ['type'=>'consent','label'=>'Marketing','slug'=>'marketing_consent','width'=>'full','default'=>'Accetto di ricevere comunicazioni marketing.'],
                'terms' => ['type'=>'consent','label'=>'Termini e condizioni','slug'=>'terms','width'=>'full','default'=>'Accetto termini e condizioni.'],
                'yes_no' => ['type'=>'radio','label'=>'Sì / No','slug'=>'yes_no','width'=>'full','options'=>'Sì\nNo'],
                'scale' => ['type'=>'rating','label'=>'Scala numerica','slug'=>'scale','width'=>'full','min'=>'1','max'=>'5'],
                'image_choice' => ['type'=>'radio','label'=>'Scelta immagini','slug'=>'image_choice','width'=>'full','options'=>'Immagine 1\nImmagine 2\nImmagine 3'],
                'date' => ['type'=>'date','label'=>'Data','slug'=>'date','width'=>'half'],
                'time' => ['type'=>'time','label'=>'Ora','slug'=>'time','width'=>'half'],
                'datetime' => ['type'=>'text','label'=>'Data e ora','slug'=>'datetime','placeholder'=>'GG/MM/AAAA HH:MM','width'=>'half'],
                'time_slot' => ['type'=>'select','label'=>'Fascia oraria','slug'=>'time_slot','placeholder'=>'Scegli fascia','width'=>'half','options'=>'Mattina\nPomeriggio\nSera'],
                'appointment_date' => ['type'=>'date','label'=>'Data appuntamento','slug'=>'appointment_date','width'=>'half'],
                'file' => ['type'=>'file','label'=>'Carica file','slug'=>'file','width'=>'full'],
                'rating' => ['type'=>'rating','label'=>'Valutazione','slug'=>'rating','width'=>'full','min'=>'1','max'=>'5'],
                'nps' => ['type'=>'nps','label'=>'Quanto ci consiglieresti?','slug'=>'nps','width'=>'full','min'=>'0','max'=>'10'],
                'range' => ['type'=>'range','label'=>'Slider','slug'=>'range','width'=>'full','min'=>'0','max'=>'100'],
                'color' => ['type'=>'color','label'=>'Colore','slug'=>'color','width'=>'half','default'=>'#2563eb'],
                'whatsapp' => ['type'=>'whatsapp','label'=>'WhatsApp','slug'=>'whatsapp','placeholder'=>'333 1234567','width'=>'half'],
                'amount' => ['type'=>'number','label'=>'Importo','slug'=>'amount','placeholder'=>'0.00','width'=>'half','min'=>'0'],
                'quantity' => ['type'=>'number','label'=>'Quantità','slug'=>'quantity','placeholder'=>'1','width'=>'half','min'=>'1'],
                'product_choice' => ['type'=>'select','label'=>'Prodotto / servizio','slug'=>'product_choice','placeholder'=>'Scegli','width'=>'full','options'=>'Servizio 1\nServizio 2\nServizio 3'],
                'coupon' => ['type'=>'text','label'=>'Codice coupon','slug'=>'coupon','placeholder'=>'CODICE','width'=>'half'],
                'source_url' => ['type'=>'hidden','label'=>'URL sorgente','slug'=>'source_url','width'=>'full'],
                'utm_source' => ['type'=>'hidden','label'=>'UTM source','slug'=>'utm_source','width'=>'full'],
                'utm_campaign' => ['type'=>'hidden','label'=>'UTM campaign','slug'=>'utm_campaign','width'=>'full'],
                'submit' => ['type'=>'submit','label'=>'Invia','slug'=>'submit','width'=>'full'],
            ];
            return array_merge($base, $maps[$kind] ?? []);
        }

        public static function normalized_steps(array $settings) {
            $items = !empty($settings['studio_steps']) && is_array($settings['studio_steps']) ? $settings['studio_steps'] : [];
            if (!$items) {
                $items = [
                    ['step_title' => 'I tuoi dati', 'step_subtitle' => 'Partiamo dalle informazioni principali.'],
                    ['step_title' => 'Dettagli', 'step_subtitle' => 'Aggiungi quello che serve.'],
                    ['step_title' => 'Conferma', 'step_subtitle' => 'Ultimo passaggio prima dell’invio.'],
                ];
            }
            $out = [];
            $i = 1;
            foreach ($items as $item) {
                $out[$i] = [
                    'title' => self::clean_text($item['step_title'] ?? ('Step ' . $i)),
                    'subtitle' => sanitize_textarea_field($item['step_subtitle'] ?? ''),
                    'layout' => sanitize_key($item['step_layout'] ?? '1col'),
                ];
                $i++;
            }
            return $out;
        }

        public static function build_layouts(array $settings, array $schema) {
            $steps = self::normalized_steps($settings);
            $layouts = [];
            foreach ($steps as $num => $step) {
                $layouts[$num] = in_array($step['layout'], ['1col','2col'], true) ? $step['layout'] : '1col';
            }
            foreach ($schema as $field) {
                $sn = max(1, absint($field['step'] ?? 1));
                if (!isset($layouts[$sn])) {
                    $layouts[$sn] = '1col';
                }
            }
            return $layouts;
        }

        public static function template_fields($template) {
            switch ($template) {
                case 'registration':
                    return [
                        ['field_type'=>'avatar','field_label'=>'Foto profilo','field_slug'=>'avatar','field_step'=>1,'field_width'=>'full'],
                        ['field_type'=>'first_name','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'last_name','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'username','field_step'=>2,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'email','field_step'=>2,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'password','field_step'=>2,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'password_confirm','field_step'=>2,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'privacy','field_step'=>3,'field_required'=>'yes'],
                    ];
                case 'login':
                    return [
                        ['field_type'=>'email','field_label'=>'Email o username','field_slug'=>'login','field_step'=>1,'field_width'=>'full','field_required'=>'yes'],
                        ['field_type'=>'password','field_label'=>'Password','field_slug'=>'password','field_step'=>1,'field_width'=>'full','field_required'=>'yes'],
                    ];
                case 'quote':
                    return [
                        ['field_type'=>'first_name','field_label'=>'Nome','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'email','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'tel','field_step'=>1,'field_width'=>'half'],
                        ['field_type'=>'company','field_step'=>1,'field_width'=>'half'],
                        ['field_type'=>'product_choice','field_label'=>'Tipo richiesta','field_step'=>2,'field_width'=>'full','field_options'=>'Sito web\nLanding page\nPlugin WordPress\nConsulenza AI\nAltro'],
                        ['field_type'=>'textarea','field_label'=>'Raccontaci il progetto','field_step'=>2,'field_width'=>'full','field_required'=>'yes'],
                        ['field_type'=>'file','field_label'=>'Allega documento','field_step'=>3,'field_width'=>'full'],
                        ['field_type'=>'privacy','field_step'=>3,'field_required'=>'yes'],
                    ];
                case 'lead':
                    return [
                        ['field_type'=>'first_name','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'email','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'company','field_step'=>2,'field_width'=>'half'],
                        ['field_type'=>'job_title','field_step'=>2,'field_width'=>'half'],
                        ['field_type'=>'marketing_consent','field_step'=>3],
                        ['field_type'=>'privacy','field_step'=>3,'field_required'=>'yes'],
                    ];
                case 'booking':
                    return [
                        ['field_type'=>'first_name','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'email','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'tel','field_step'=>1,'field_width'=>'half'],
                        ['field_type'=>'appointment_date','field_step'=>2,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'time_slot','field_step'=>2,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'textarea','field_label'=>'Note','field_step'=>3,'field_width'=>'full'],
                        ['field_type'=>'privacy','field_step'=>3,'field_required'=>'yes'],
                    ];
                case 'survey':
                    return [
                        ['field_type'=>'rating','field_label'=>'Valutazione generale','field_step'=>1,'field_width'=>'full','field_required'=>'yes'],
                        ['field_type'=>'nps','field_label'=>'Quanto ci consiglieresti?','field_step'=>1,'field_width'=>'full'],
                        ['field_type'=>'textarea','field_label'=>'Cosa possiamo migliorare?','field_step'=>2,'field_width'=>'full'],
                        ['field_type'=>'email','field_label'=>'Email facoltativa','field_step'=>3,'field_width'=>'half'],
                        ['field_type'=>'privacy','field_step'=>3],
                    ];
                case 'contact':
                default:
                    return [
                        ['field_type'=>'first_name','field_label'=>'Nome','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'email','field_step'=>1,'field_width'=>'half','field_required'=>'yes'],
                        ['field_type'=>'tel','field_step'=>1,'field_width'=>'half'],
                        ['field_type'=>'textarea','field_label'=>'Messaggio','field_step'=>2,'field_width'=>'full','field_required'=>'yes'],
                        ['field_type'=>'privacy','field_step'=>2,'field_required'=>'yes'],
                    ];
            }
        }

        private static function build_custom_css(array $settings) {
            return '';
        }

        private static function has_submit(array $fields) {
            foreach ($fields as $f) {
                if (($f['type'] ?? '') === 'submit') {
                    return true;
                }
            }
            return false;
        }

        private static function max_step(array $fields) {
            $max = 1;
            foreach ($fields as $f) {
                $max = max($max, absint($f['step'] ?? 1));
            }
            return $max;
        }

        private static function clean_width($width) {
            $width = sanitize_key($width);
            return in_array($width, ['full','half','third','two-thirds'], true) ? $width : 'full';
        }

        private static function clean_color($color) {
            return sanitize_hex_color($color) ?: '#2563eb';
        }

        private static function is_yes($value) {
            return $value === 'yes' || $value === 1 || $value === '1' || $value === true;
        }

        private static function slider_size($value, $fallback = 0) {
            if (is_array($value) && isset($value['size'])) {
                return absint($value['size']);
            }
            return absint($value !== null && $value !== '' ? $value : $fallback);
        }

        private static function clean_text($value) {
            return sanitize_text_field((string) $value);
        }
    }
}
