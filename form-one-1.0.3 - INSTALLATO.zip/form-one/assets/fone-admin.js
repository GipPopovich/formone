
/* ===================================================================
   Form One — Admin JS
   Builder completo: libreria campi, drag&drop, step illimitati,
   pannello settings dinamico, anteprima live responsive
=================================================================== */

(function ($) {
    'use strict';

    $(document).ready(function () {
        if (!window.FONE_ADMIN || !FONE_ADMIN.builderPage) return;

        /* ---- UTILITIES ----------------------------------------- */
        function esc(str) {
            return String(str == null ? '' : str)
                .replace(/&/g, '&amp;').replace(/</g, '&lt;')
                .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
        }
        function safeStyleText(css) {
            return String(css == null ? '' : css)
                .replace(/<\/style/gi, '<\\/style')
                .replace(/<script/gi, '&lt;script')
                .replace(/<\/script/gi, '&lt;/script');
        }
        function uid() { return 'fone_' + Math.random().toString(36).slice(2, 10); }
        function getLang() { return (FONE_ADMIN.settings && FONE_ADMIN.settings.lang) || 'it'; }
        function t(key) {
            var lang = getLang();
            var s = (FONE_ADMIN.strings && FONE_ADMIN.strings[lang]) || {};
            if (s[key]) return s[key];
            var it = (FONE_ADMIN.strings && FONE_ADMIN.strings.it) || {};
            return it[key] || key;
        }

        function foneIconMarkup(iconClass, fallbackIcon) {
            iconClass = String(iconClass || '').replace(/[^a-zA-Z0-9_\- ]/g, '').trim();
            if (iconClass) {
                return '<i class="' + esc(iconClass) + '" aria-hidden="true"></i>';
            }
            return esc(fallbackIcon || '▪');
        }

        /* ---- REFS ---------------------------------------------- */
        var $schemaInput  = $('#fone_schema_json');
        var $layoutsInput = $('#fone_step_layouts_json');
        var $library      = $('#fone-field-library');
        var $librarySearch= $('#fone-library-search');
        var $canvas       = $('#fone-form-canvas');
        var $settingsPane = $('#fone-field-settings');
        var $previewInner = $('#fone-preview-inner');
        var $previewVp    = $('#fone-preview-viewport');
        var $copyBtn      = $('#fone-copy-shortcode');
        var $shortcodeInp = $('#fone-shortcode-input');
        var $langTop      = $('#fone_lang_top');
        var $langHidden   = $('#fone_lang_hidden');
        var $colorInput   = $('#fone_accent_color');
        var $colorValue   = $('.fone-color-value');
        var $addStepBtn   = $('#fone-add-step');
        var $builderLayout = $('.fone-builder-layout');
        var isModernBuilder = $builderLayout.hasClass('fone-builder-ui-modern');

        function setFieldEditingMode(isEditing) {
            if (!isModernBuilder) return;
            $builderLayout.toggleClass('fone-field-editing', !!isEditing);
        }

        function updateBuilderEditMode() {
            var f = (activeIdx !== null && schema[activeIdx]) ? schema[activeIdx] : null;
            $builderLayout.toggleClass('fone-html-admin-editing', !!(f && f.type === 'html_admin'));
        }

        /* ---- STATE --------------------------------------------- */
        var schema = [];
        var layouts = {};
        var activeIdx = null;
        var maxStep = 1;

        try { schema = JSON.parse($schemaInput.val() || '[]'); } catch(e) { schema = []; }
        if (!Array.isArray(schema)) schema = [];

        try { layouts = JSON.parse($layoutsInput.val() || '{}') || {}; } catch(e) { layouts = {}; }

        // Ricalcola maxStep da schema esistente — solo in crescita
        function recalcMaxStep() {
            var calc = 1;
            schema.forEach(function (f) {
                if (f.step && f.step > calc) calc = f.step;
            });
            if (calc > maxStep) maxStep = calc;
            if (maxStep < 1) maxStep = 1;
        }
        recalcMaxStep();

        function sync() {
            $schemaInput.val(JSON.stringify(schema));
            $layoutsInput.val(JSON.stringify(layouts));
        }

        /* ---- LIBRARY DATA -------------------------------------- */
        var library = FONE_ADMIN.library || [];
        var lang = getLang();
        var isPro = !!FONE_ADMIN.isPro;
        var licenseUrl = FONE_ADMIN.licenseUrl || '';
        var freeFieldSlugs = ['text','email','tel','textarea','select','radio','checkbox','consent','hidden','divider','file_upload','submit'];
        function isFieldLocked(item) {
            if (isPro) return false;
            if (!item) return false;
            if (parseInt(item.is_pro || 0, 10) === 1) return true;
            return freeFieldSlugs.indexOf(String(item.slug || '')) === -1;
        }

        function libItemToField(item, stepNumber) {
            var f = {
                id: uid(),
                type: item.type,
                slug: item.slug,
                label: (lang === 'en' ? item.label_en : item.label_it) || '',
                placeholder: (lang === 'en' ? item.placeholder_en : item.placeholder_it) || '',
                help: '',
                required: parseInt(item.required || 0, 10),
                step: stepNumber || 1,
                width: ['textarea','html','html_admin','submit','radio','checkbox','avatar','file','consent','divider','rating','nps'].indexOf(item.type) >= 0 ? 'full' : 'half',
                options: item.options || '',
                max_chars: item.max_chars || '',
                autocomp: item.autocomp || 'off',
                meta_key: item.meta_key || '',
                accept_types: item.accept_types || 'image/jpeg,image/png,image/webp',
                max_size_mb: item.max_size_mb || '5',
                default_value: item.default_value || '',
                opt_min: item.opt_min || '',
                opt_max: item.opt_max || '',
                opt_step: item.opt_step || ''
            };
            if (item.type === 'html' && item.default_content) f.label = item.default_content;
            if (item.type === 'html_admin') {
                f.label = 'Inserire HTML';
                f.html_content = item.default_content || '<div class="fone-html-admin-box"><strong>Titolo HTML</strong><p>Testo HTML personalizzato.</p></div>';
                f.html_css = item.default_css || '.fone-html-admin-box { padding: 16px; border-radius: 12px; background: #f8fafc; }';
            }
            return f;
        }

        /* ---- RENDER LIBRARY ------------------------------------ */
        function renderLibrary(filter) {
            $library.empty();
            filter = (filter || '').toLowerCase();

            library.forEach(function (cat) {
                var catLabel = t(cat.category);
                var matchedFields = (cat.fields || []).filter(function (f) {
                    if (!filter) return true;
                    var l = (lang === 'en' ? f.label_en : f.label_it) || '';
                    return (l + ' ' + f.slug).toLowerCase().indexOf(filter) >= 0;
                });
                if (!matchedFields.length) return;

                var $catWrap = $('<div class="fone-lib-category"></div>');
                $catWrap.append('<h4 class="fone-lib-category-title">' + esc(catLabel) + '</h4>');

                var $items = $('<div class="fone-lib-category-items"></div>');
                matchedFields.forEach(function (f) {
                    var label = (lang === 'en' ? f.label_en : f.label_it) || f.slug;
                    var locked = isFieldLocked(f);
                    var $btn = $(
                        '<button type="button" class="fone-lib-btn' + (locked ? ' is-pro-locked' : '') + '" draggable="false" ' +
                        'data-fone-lib-slug="' + esc(f.slug) + '"' + (locked ? ' data-pro-locked="1"' : '') + '>' +
                            '<span class="fone-lib-icon">' + foneIconMarkup(f.icon_class, f.icon || '') + '</span>' +
                            '<span class="fone-lib-label">' + esc(label) + '</span>' +
                            (locked ? '<span class="fone-lib-pro-badge">PRO</span>' : '') +
                        '</button>'
                    );
                    $btn.data('libItem', f);

                    // Click = aggiungi all'ultimo step, oppure mostra blocco PRO.
                    $btn.on('click', function () {
                        if (locked) {
                            if (window.confirm('Campo disponibile nella versione Pro. Vuoi aprire la pagina licenza?')) {
                                if (licenseUrl) window.location.href = licenseUrl;
                            }
                            return;
                        }
                        var field = libItemToField(f, maxStep);
                        schema.push(field);
                        activeIdx = schema.length - 1;
                        sync(); renderCanvas(); renderSettings(); renderPreview();
                    });

                    // Disabilito il drag HTML5 nativo — gestito da PointerDnD
                    $btn.attr('draggable', 'false');
                    $btn.attr('data-fone-pointer-src', 'lib');

                    $items.append($btn);
                });

                $catWrap.append($items);
                $library.append($catWrap);
            });
        }

        $librarySearch.on('input', function () { renderLibrary($(this).val()); });

        /* ---- RENDER CANVAS ------------------------------------- */
        function renderCanvas() {
            recalcMaxStep();
            $canvas.empty();

            if (schema.length === 0) {
                $canvas.append(
                    '<div class="fone-canvas-empty" data-fone-empty="1">' +
                        esc(t('drag_here')) +
                    '</div>'
                );
                attachEmptyDrop();
                return;
            }

            // Raggruppa per step
            var groups = {};
            schema.forEach(function (f, idx) {
                var st = f.step || 1;
                if (!groups[st]) groups[st] = [];
                groups[st].push({ field: f, idx: idx });
            });

            // Serie di step da 1 a maxStep (inclusi quelli vuoti, per permettere drop)
            for (var step = 1; step <= maxStep; step++) {
                var items = groups[step] || [];
                var layoutVal = layouts[step] || '1col';

                var $stepWrap = $(
                    '<div class="fone-canvas-step" data-fone-step="' + step + '">' +
                        '<div class="fone-canvas-step-header">' +
                            '<span class="fone-canvas-step-label" data-step-num="' + step + '">' + esc(t('step')) + '</span>' +
                            '<div class="fone-canvas-step-tools">' +
                                '<select class="fone-step-layout-select" data-fone-layout-for="' + step + '">' +
                                    '<option value="1col"' + (layoutVal === '1col' ? ' selected' : '') + '>' + esc(t('one_column')) + '</option>' +
                                    '<option value="2col"' + (layoutVal === '2col' ? ' selected' : '') + '>' + esc(t('two_columns')) + '</option>' +
                                '</select>' +
                                (step > 1 ?
                                    '<button type="button" class="fone-row-btn fone-row-btn-danger" data-fone-remove-step="' + step + '" title="' + esc(t('remove_step')) + '"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>'
                                    : ''
                                ) +
                            '</div>' +
                        '</div>' +
                        '<div class="fone-step-rows" data-fone-step-rows="' + step + '"></div>' +
                    '</div>'
                );

                var $rowsHost = $stepWrap.find('.fone-step-rows');

                if (items.length === 0) {
                    $rowsHost.append('<div class="fone-step-empty-drop">' + esc(t('drag_here')) + '</div>');
                } else {
                    items.forEach(function (it) {
                        $rowsHost.append(renderCanvasRow(it.field, it.idx));
                    });
                }

                $canvas.append($stepWrap);
            }

            // Bottone grande "+ Aggiungi step" in fondo
            var $addBig = $('<button type="button" class="fone-add-step-big" id="fone-add-step-big">' + esc(t('add_step')) + '</button>');
            $addBig.on('click', function () {
                maxStep++;
                layouts[maxStep] = '1col';
                sync(); renderCanvas(); renderPreview();
            });
            $canvas.append($addBig);

            bindStepEvents();
            bindRowEvents();
            attachCanvasDnd();
        }

        function renderCanvasRow(field, idx) {
            var isActive = (idx === activeIdx);
            var stepNum  = field.step || 1;

            // Icona tipo: Font Awesome se disponibile, fallback testuale se assente.
            var typeIconClasses = {
                text:'fa-solid fa-font', name:'fa-solid fa-user', email:'fa-solid fa-envelope', tel:'fa-solid fa-phone', phone:'fa-solid fa-phone',
                whatsapp:'fa-brands fa-whatsapp', number:'fa-solid fa-hashtag', url:'fa-solid fa-globe', password:'fa-solid fa-key',
                date:'fa-solid fa-calendar', textarea:'fa-solid fa-align-left', select:'fa-solid fa-list', radio:'fa-solid fa-circle-dot',
                checkbox:'fa-solid fa-square-check', avatar:'fa-solid fa-camera', html:'fa-solid fa-code', html_admin:'fa-solid fa-code',
                submit:'fa-solid fa-paper-plane', paypal_button:'fa-brands fa-paypal', hidden:'fa-solid fa-eye-slash', divider:'fa-solid fa-minus',
                consent:'fa-solid fa-shield-halved', file:'fa-solid fa-paperclip', range:'fa-solid fa-sliders', rating:'fa-solid fa-star',
                nps:'fa-solid fa-chart-simple', time:'fa-solid fa-clock', color:'fa-solid fa-palette'
            };
            var typeIcon = foneIconMarkup(field.icon_class || typeIconClasses[field.type], field.icon || '▪');

            // Bottoni cambio step (prev/next)
            var prevStepBtn = stepNum > 1
                ? '<button type="button" class="fone-row-btn" data-action="prev-step" title="Sposta allo step ' + (stepNum-1) + '"><i class="fa-solid fa-arrow-up" aria-hidden="true"></i> Step ' + (stepNum-1) + '</button>'
                : '';
            var nextStepBtn = stepNum < maxStep
                ? '<button type="button" class="fone-row-btn" data-action="next-step" title="Sposta allo step ' + (stepNum+1) + '"><i class="fa-solid fa-arrow-down" aria-hidden="true"></i> Step ' + (stepNum+1) + '</button>'
                : '';

            // Bottoni rapidi width nel canvas: attivi anche per Submit/Invia e HTML Admin.
            var isHtmlOrSub = (field.type === 'html');
            var currentWidth = field.width || ((field.type === 'submit' || field.type === 'html_admin') ? 'full' : 'half');
            var widthBadge = '';
            var widthBtns = '';
            if (!isHtmlOrSub) {
                var wIcons = { 'third': '1/3', 'half': '1/2', 'two-thirds': '2/3', 'full': 'full' };
                widthBadge = '<span class="fone-width-badge" title="Larghezza attuale">' + (wIcons[currentWidth] || '▭') + '</span>';
                widthBtns =
                    '<div class="fone-width-btns" title="Cambia larghezza (anche 1/2/3/4 da tastiera)">' +
                    '<button type="button" class="fone-width-btn' + (currentWidth === 'third' ? ' is-active' : '') + '" data-width-set="third" title="1/3 Un terzo (1)">1/3</button>' +
                    '<button type="button" class="fone-width-btn' + (currentWidth === 'half' ? ' is-active' : '') + '" data-width-set="half" title="1/2 Metà (2)">1/2</button>' +
                    '<button type="button" class="fone-width-btn' + (currentWidth === 'two-thirds' ? ' is-active' : '') + '" data-width-set="two-thirds" title="2/3 Due terzi (3)">2/3</button>' +
                    '<button type="button" class="fone-width-btn' + (currentWidth === 'full' ? ' is-active' : '') + '" data-width-set="full" title="Full Piena (4)">full</button>' +
                    '</div>';
            }

            var displayLabel = field.type === 'html_admin' ? 'Inserire HTML' : (field.label || field.slug || '');

            var $row = $(
                '<div class="fone-canvas-row' + (isActive ? ' is-active' : '') + ' fone-w-' + esc(currentWidth) + '" ' +
                     'data-idx="' + idx + '" data-fone-pointer-src="row">' +
                    // Handle drag (grip)
                    '<span class="fone-drag-handle" data-fone-handle="1" title="Trascina per spostare">⠿</span>' +
                    '<div class="fone-canvas-row-info">' +
                        '<span class="fone-canvas-row-icon">' + typeIcon + '</span>' +
                        '<span class="fone-canvas-row-label">' + esc(displayLabel) + '</span>' +
                        widthBadge +
                        '<span class="fone-canvas-row-meta fone-muted">· ' + esc(field.type) + '</span>' +
                    '</div>' +
                    '<div class="fone-canvas-row-actions">' +
                        widthBtns +
                        prevStepBtn +
                        nextStepBtn +
                        '<button type="button" class="fone-row-btn" data-action="up" title="' + esc(t('move_up')) + '">↑</button>' +
                        '<button type="button" class="fone-row-btn" data-action="down" title="' + esc(t('move_down')) + '">↓</button>' +
                        '<button type="button" class="fone-row-btn" data-action="dup" title="' + esc(t('duplicate_field')) + '">⧉</button>' +
                        '<button type="button" class="fone-row-btn fone-row-btn-danger" data-action="remove" title="' + esc(t('remove_field')) + '"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>' +
                    '</div>' +
                '</div>'
            );
            return $row;
        }

        /* ---- STEP EVENTS --------------------------------------- */
        function bindStepEvents() {
            $canvas.find('.fone-step-layout-select').off('change').on('change', function () {
                var step = parseInt($(this).data('fone-layout-for'), 10);
                layouts[step] = $(this).val();
                sync(); renderPreview();
            });
            $canvas.find('[data-fone-remove-step]').off('click').on('click', function () {
                var step = parseInt($(this).data('fone-remove-step'), 10);
                if (step <= 1) return; // Step 1 non eliminabile

                var hasFields = schema.some(function (f) { return (f.step || 1) === step; });
                var msg = hasFields
                    ? 'Rimuovere lo Step ' + step + '? I suoi campi verranno spostati allo Step ' + (step - 1) + '.'
                    : 'Rimuovere lo Step ' + step + ' (vuoto)?';
                if (!confirm(msg)) return;

                // Sposta i campi di questo step al precedente
                schema.forEach(function (f) {
                    if ((f.step || 1) === step) {
                        f.step = step - 1;
                    }
                });

                // Rinumera tutti gli step successivi (es. step 3 → 2, step 4 → 3)
                schema.forEach(function (f) {
                    if ((f.step || 1) > step) {
                        f.step = f.step - 1;
                    }
                });

                // Aggiorna layouts: elimina il layout dello step rimosso,
                // rinumera i layout degli step successivi
                var newLayouts = {};
                Object.keys(layouts).forEach(function (k) {
                    var kn = parseInt(k, 10);
                    if (kn < step) {
                        newLayouts[kn] = layouts[k];
                    } else if (kn > step) {
                        newLayouts[kn - 1] = layouts[k];
                    }
                    // kn === step → eliminato, non copiare
                });
                layouts = newLayouts;

                maxStep = Math.max(1, maxStep - 1);
                if (activeIdx !== null && activeIdx >= schema.length) activeIdx = schema.length - 1;
                if (schema.length === 0) activeIdx = null;

                sync(); renderCanvas(); renderSettings(); renderPreview();
            });
        }

        /* ---- ROW EVENTS ---------------------------------------- */
        function bindRowEvents() {
            $canvas.find('.fone-canvas-row').each(function () {
                var $row = $(this);
                var idx = parseInt($row.data('idx'), 10);

                $row.off('click').on('click', function (e) {
                    if ($(e.target).closest('[data-action],[data-width-set],.fone-drag-handle').length) return;
                    activeIdx = idx;
                    renderCanvas(); renderSettings(); renderPreview();
                });

                $row.find('[data-action]').off('click').on('click', function (e) {
                    e.stopPropagation();
                    var action = $(this).data('action');
                    if (action === 'up' && idx > 0) {
                        var tmp = schema[idx]; schema[idx] = schema[idx-1]; schema[idx-1] = tmp;
                        activeIdx = idx - 1;
                    } else if (action === 'down' && idx < schema.length - 1) {
                        var tmp2 = schema[idx]; schema[idx] = schema[idx+1]; schema[idx+1] = tmp2;
                        activeIdx = idx + 1;
                    } else if (action === 'prev-step' && (schema[idx].step || 1) > 1) {
                        schema[idx].step = (schema[idx].step || 1) - 1;
                        activeIdx = idx;
                    } else if (action === 'next-step' && (schema[idx].step || 1) < maxStep) {
                        schema[idx].step = (schema[idx].step || 1) + 1;
                        activeIdx = idx;
                    } else if (action === 'dup') {
                        var clone = $.extend({}, schema[idx], { id: uid() });
                        schema.splice(idx + 1, 0, clone);
                        activeIdx = idx + 1;
                    } else if (action === 'remove') {
                        schema.splice(idx, 1);
                        if (activeIdx !== null && activeIdx >= schema.length) activeIdx = schema.length - 1;
                        if (schema.length === 0) activeIdx = null;
                    }
                    sync(); renderCanvas(); renderSettings(); renderPreview();
                });

                // Bottoni rapidi cambio width
                $row.find('[data-width-set]').off('click').on('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var newWidth = String($(this).data('width-set') || '');
                    if (!schema[idx] || ['third','half','two-thirds','full'].indexOf(newWidth) === -1) return;
                    schema[idx].width = newWidth;
                    activeIdx = idx;
                    sync(); renderCanvas(); renderSettings(); renderPreview();
                });
            });
        }

        /* ---- DRAG & DROP CANVAS -------------------------------- */
        function attachEmptyDrop() {
            var $e = $canvas.find('[data-fone-empty]');
            $e.on('dragover', function (ev) { ev.preventDefault(); $(this).css('background','#eef2ff'); });
            $e.on('dragleave', function () { $(this).css('background',''); });
            $e.on('drop', function (ev) {
                ev.preventDefault();
                var slug = ev.originalEvent.dataTransfer.getData('text/fone-lib-slug');
                if (!slug) return;
                var item = findLibItemBySlug(slug);
                if (item) {
                    schema.push(libItemToField(item, 1));
                    activeIdx = schema.length - 1;
                    sync(); renderCanvas(); renderSettings(); renderPreview();
                }
            });
        }

        function findLibItemBySlug(slug) {
            for (var i = 0; i < library.length; i++) {
                var fields = library[i].fields || [];
                for (var j = 0; j < fields.length; j++) {
                    if (fields[j].slug === slug) return fields[j];
                }
            }
            return null;
        }

        /* ---- DRAG & DROP CANVAS — versione avanzata ------------ */
        /* ──────────────────────────────────────────────────────────
           DRAG & DROP UNIFICATO (pointer events)
           Funziona su mouse, touch e penna.
           Sostituisce HTML5 drag&drop perché:
             • non funziona su touch
             • niente auto-scroll
             • cursore default brutto
             • dragenter/leave flickerano
        ────────────────────────────────────────────────────────── */
        function attachCanvasDnd() {
            // Stato drag
            var drag = null;
            // drag = {
            //   src: 'lib'|'row',
            //   slug, fromIdx,        // sorgente
            //   ghost,                 // div fluttuante
            //   startX, startY,
            //   active,                // true quando si è superata la soglia di partenza
            //   currentInsert: { stepNumber, beforeIdx } | null,
            //   rafId,                 // requestAnimationFrame per aggiornare il ghost
            //   pointerX, pointerY
            // }

            var DRAG_THRESHOLD = 5;      // px prima di considerare un vero drag
            var AUTOSCROLL_EDGE = 60;    // px dal bordo per attivare autoscroll
            var AUTOSCROLL_SPEED = 14;   // px per frame
            var lastInsertSig = '';      // signature ultimo insert per evitare DOM thrashing

            function clearInsertors() {
                document.querySelectorAll('.fone-insert-line').forEach(function(n){ n.remove(); });
                $canvas.find('.fone-canvas-step').removeClass('is-drop-target');
                lastInsertSig = '';
                if (drag) drag.currentInsert = null;
            }

            function showInsertLine(stepNumber, beforeRowEl) {
                // Signature per skip se identica all'ultima
                var sig = stepNumber + ':' + (beforeRowEl ? beforeRowEl.getAttribute('data-idx') : 'end');
                if (sig === lastInsertSig) return;
                lastInsertSig = sig;

                // Rimuovi vecchie linee, mantieni stato target
                document.querySelectorAll('.fone-insert-line').forEach(function(n){ n.remove(); });
                $canvas.find('.fone-canvas-step').removeClass('is-drop-target');
                var $stepEl = $canvas.find('[data-fone-step="' + stepNumber + '"]');
                $stepEl.addClass('is-drop-target');

                var line = document.createElement('div');
                line.className = 'fone-insert-line';
                if (beforeRowEl) {
                    beforeRowEl.parentNode.insertBefore(line, beforeRowEl);
                    drag.currentInsert = { stepNumber: stepNumber, beforeIdx: parseInt(beforeRowEl.getAttribute('data-idx'), 10) };
                } else {
                    var rowsHost = $canvas.find('[data-fone-step-rows="' + stepNumber + '"]')[0];
                    if (rowsHost) rowsHost.appendChild(line);
                    drag.currentInsert = { stepNumber: stepNumber, beforeIdx: -1 };
                }
            }

            // Trova lo step e la posizione di insert in base alle coordinate del puntatore
            function resolveInsertTarget(clientX, clientY) {
                // Cerco lo step sotto il puntatore
                var stepEls = $canvas.find('.fone-canvas-step').toArray();
                var hitStep = null;
                for (var i = 0; i < stepEls.length; i++) {
                    var rect = stepEls[i].getBoundingClientRect();
                    if (clientX >= rect.left && clientX <= rect.right &&
                        clientY >= rect.top  && clientY <= rect.bottom) {
                        hitStep = stepEls[i];
                        break;
                    }
                }
                if (!hitStep) return null;

                var stepNumber = parseInt(hitStep.getAttribute('data-fone-step'), 10);
                var rows = hitStep.querySelectorAll('.fone-canvas-row');
                if (!rows.length) {
                    return { stepNumber: stepNumber, beforeRowEl: null };
                }

                for (var r = 0; r < rows.length; r++) {
                    var rr = rows[r].getBoundingClientRect();
                    if (clientY < rr.top + rr.height / 2) {
                        return { stepNumber: stepNumber, beforeRowEl: rows[r] };
                    }
                }
                return { stepNumber: stepNumber, beforeRowEl: null };
            }

            // Auto-scroll quando il puntatore è vicino ai bordi del canvas
            function maybeAutoScroll(clientY) {
                var canvasEl = $canvas[0];
                if (!canvasEl) return;
                // Cerca il container scrollabile più vicino
                var scroller = canvasEl;
                while (scroller && scroller !== document.body) {
                    var oy = window.getComputedStyle(scroller).overflowY;
                    if ((oy === 'auto' || oy === 'scroll') && scroller.scrollHeight > scroller.clientHeight) break;
                    scroller = scroller.parentElement;
                }
                if (!scroller || scroller === document.body) {
                    // Scroll della pagina intera
                    if (clientY < AUTOSCROLL_EDGE) {
                        window.scrollBy(0, -AUTOSCROLL_SPEED);
                    } else if (clientY > window.innerHeight - AUTOSCROLL_EDGE) {
                        window.scrollBy(0, AUTOSCROLL_SPEED);
                    }
                    return;
                }
                var sr = scroller.getBoundingClientRect();
                if (clientY < sr.top + AUTOSCROLL_EDGE) {
                    scroller.scrollTop -= AUTOSCROLL_SPEED;
                } else if (clientY > sr.bottom - AUTOSCROLL_EDGE) {
                    scroller.scrollTop += AUTOSCROLL_SPEED;
                }
            }

            function makeGhost(srcEl, label) {
                var ghost = document.createElement('div');
                ghost.className = 'fone-drag-ghost';
                ghost.textContent = label || 'Campo';
                document.body.appendChild(ghost);
                return ghost;
            }

            function startDrag(opts, ev) {
                drag = {
                    src: opts.src,
                    slug: opts.slug || null,
                    fromIdx: opts.fromIdx != null ? opts.fromIdx : null,
                    sourceEl: opts.sourceEl,
                    ghost: null,
                    label: opts.label || 'Campo',
                    startX: ev.clientX,
                    startY: ev.clientY,
                    pointerX: ev.clientX,
                    pointerY: ev.clientY,
                    active: false,
                    currentInsert: null,
                    rafId: null
                };

                // Cattura il puntatore: tutti gli eventi pointer arriveranno a questo elemento
                try { opts.sourceEl.setPointerCapture(ev.pointerId); } catch(e){}
                drag.pointerId = ev.pointerId;

                document.addEventListener('pointermove', onPointerMove, true);
                document.addEventListener('pointerup',   onPointerUp,   true);
                document.addEventListener('pointercancel', onPointerUp, true);
            }

            function activateDragVisuals() {
                if (drag.active) return;
                drag.active = true;
                document.body.classList.add('fone-is-dragging');
                drag.ghost = makeGhost(drag.sourceEl, drag.label);
                if (drag.src === 'row' && drag.sourceEl) {
                    drag.sourceEl.classList.add('is-dragging');
                } else if (drag.src === 'lib' && drag.sourceEl) {
                    drag.sourceEl.classList.add('is-dragging');
                }
                // Disabilita selezione testo durante il drag
                document.body.style.userSelect = 'none';
            }

            function updateGhost() {
                if (!drag || !drag.ghost) return;
                drag.ghost.style.left = drag.pointerX + 'px';
                drag.ghost.style.top  = drag.pointerY + 'px';
            }

            function onPointerMove(ev) {
                if (!drag) return;
                drag.pointerX = ev.clientX;
                drag.pointerY = ev.clientY;

                if (!drag.active) {
                    var dx = Math.abs(ev.clientX - drag.startX);
                    var dy = Math.abs(ev.clientY - drag.startY);
                    if (dx < DRAG_THRESHOLD && dy < DRAG_THRESHOLD) return;
                    activateDragVisuals();
                }

                // Throttle via rAF
                if (!drag.rafId) {
                    drag.rafId = requestAnimationFrame(function(){
                        drag.rafId = null;
                        updateGhost();
                        var t = resolveInsertTarget(drag.pointerX, drag.pointerY);
                        if (t) {
                            showInsertLine(t.stepNumber, t.beforeRowEl);
                        } else {
                            clearInsertors();
                        }
                        maybeAutoScroll(drag.pointerY);
                    });
                }
                ev.preventDefault();
            }

            function onPointerUp(ev) {
                if (!drag) return;
                document.removeEventListener('pointermove', onPointerMove, true);
                document.removeEventListener('pointerup',   onPointerUp,   true);
                document.removeEventListener('pointercancel', onPointerUp, true);

                try { if (drag.sourceEl) drag.sourceEl.releasePointerCapture(drag.pointerId); } catch(e){}

                var wasActive = drag.active;
                var insert = drag.currentInsert;
                var src = drag.src;
                var slug = drag.slug;
                var fromIdx = drag.fromIdx;

                // Cleanup visivo
                if (drag.ghost) drag.ghost.remove();
                if (drag.sourceEl) drag.sourceEl.classList.remove('is-dragging');
                document.body.classList.remove('fone-is-dragging');
                document.body.style.userSelect = '';
                clearInsertors();
                drag = null;

                if (!wasActive) return; // era solo un click, non un drag

                if (!insert) return; // drop fuori da uno step valido

                // === Esegui l'azione ===
                if (src === 'lib' && slug) {
                    var libItem = findLibItemBySlug(slug);
                    if (!libItem) return;
                    var newField = libItemToField(libItem, insert.stepNumber);
                    if (insert.beforeIdx === -1) {
                        schema.push(newField);
                        activeIdx = schema.length - 1;
                    } else {
                        schema.splice(insert.beforeIdx, 0, newField);
                        activeIdx = insert.beforeIdx;
                    }
                    schema[activeIdx].step = insert.stepNumber;
                    sync(); renderCanvas(); renderSettings(); renderPreview();
                    return;
                }

                if (src === 'row' && fromIdx != null) {
                    if (!schema[fromIdx]) return;
                    var movedField = schema.splice(fromIdx, 1)[0];
                    movedField.step = insert.stepNumber;
                    if (insert.beforeIdx === -1 || insert.beforeIdx > schema.length) {
                        schema.push(movedField);
                        activeIdx = schema.length - 1;
                    } else {
                        var adjustedBefore = (fromIdx < insert.beforeIdx) ? insert.beforeIdx - 1 : insert.beforeIdx;
                        adjustedBefore = Math.max(0, Math.min(adjustedBefore, schema.length));
                        schema.splice(adjustedBefore, 0, movedField);
                        activeIdx = adjustedBefore;
                    }
                    sync(); renderCanvas(); renderSettings(); renderPreview();
                }
            }

            // === Bind: row del canvas (drag dall'handle ⠿ o dall'intera row) ===
            $canvas.find('.fone-canvas-row').each(function () {
                var rowEl = this;
                var idx   = parseInt(rowEl.getAttribute('data-idx'), 10);

                rowEl.removeEventListener('pointerdown', rowEl.__foneDownHandler || function(){});
                var handler = function (ev) {
                    if (ev.button !== undefined && ev.button !== 0) return; // solo tasto sinistro
                    // Ignora se il pointerdown è su un pulsante azione
                    if (ev.target.closest('[data-action],[data-width-set],button,input,select,textarea,a,[contenteditable="true"]')) return;
                    // Permetti drag solo dall'handle se vuoi maggiore controllo,
                    // o da tutta la row tranne dai pulsanti — qui consentiamo da tutta la row
                    startDrag({
                        src: 'row',
                        fromIdx: idx,
                        sourceEl: rowEl,
                        label: (schema[idx] && (schema[idx].label || schema[idx].slug)) || 'Campo'
                    }, ev);
                };
                rowEl.__foneDownHandler = handler;
                rowEl.addEventListener('pointerdown', handler);
            });

            // === Bind: bottoni libreria ===
            $library.find('[data-fone-pointer-src="lib"]').each(function(){
                var btn = this;
                btn.removeEventListener('pointerdown', btn.__foneDownHandler || function(){});
                var handler = function (ev) {
                    if (ev.button !== undefined && ev.button !== 0) return;
                    var slug = btn.getAttribute('data-fone-lib-slug') || $(btn).data('fone-lib-slug');
                    var $lab = $(btn).find('.fone-lib-label');
                    startDrag({
                        src: 'lib',
                        slug: slug,
                        sourceEl: btn,
                        label: $lab.length ? $lab.text() : slug
                    }, ev);
                };
                btn.__foneDownHandler = handler;
                btn.addEventListener('pointerdown', handler);
            });
        }

        /* ---- RENDER SETTINGS (right sidebar) ------------------- */
        function microcopyEnabled() {
            return !FONE_ADMIN.settings || FONE_ADMIN.settings.microcopy_assistant !== 0;
        }

        function microcopyGoal() {
            return (FONE_ADMIN.settings && FONE_ADMIN.settings.microcopy_goal) || 'general';
        }

        function microcopySuggestions(f) {
            var type = f.type || 'text';
            var label = f.label || '';
            var goal = microcopyGoal();
            var out = [];
            function add(title, l, p, h) { out.push({ title: title, label: l || label, placeholder: p || '', help: h || '' }); }

            if (type === 'email') {
                if (goal === 'lead_magnet') add('Lead magnet', 'Dove vuoi ricevere la risorsa?', 'nome@email.it', 'Ti invieremo qui il materiale richiesto.');
                if (goal === 'quote') add('Preventivo', 'Dove possiamo inviarti una prima risposta?', 'nome@email.it', 'Useremo questa email solo per questa richiesta.');
                if (goal === 'consulting') add('Consulenza', 'Qual è la tua email migliore?', 'nome@email.it', 'Ti scriveremo per concordare il prossimo passo.');
                add('Meno freddo', 'Dove possiamo scriverti?', 'nome@email.it', 'Useremo questa email solo per rispondere alla tua richiesta.');
            } else if (type === 'tel' || type === 'phone' || type === 'whatsapp') {
                if (goal === 'contact' || goal === 'quote') add('Ricontatto', 'Dove possiamo contattarti?', '333 1234567', 'Ti contatteremo solo per questa richiesta.');
                add('WhatsApp friendly', 'Numero WhatsApp', '333 1234567', 'Se preferisci, possiamo scriverti direttamente lì.');
                add('Più rassicurante', 'Numero di telefono', '333 1234567', 'Nessuno spam, solo ricontatto se serve.');
            } else if (type === 'textarea') {
                if (goal === 'quote') add('Preventivo', 'Raccontaci cosa ti serve', 'Esempio: mi serve un preventivo per...', 'Bastano poche righe per preparare una risposta più precisa.');
                if (goal === 'support') add('Supporto', 'Descrivi il problema', 'Scrivi cosa non funziona o cosa vuoi ottenere...', 'Più contesto inserisci, più semplice sarà aiutarti.');
                if (goal === 'application') add('Candidatura', 'Perché ti interessa?', 'Scrivi poche righe...', 'Non serve essere perfetti: ci basta capire motivazione e contesto.');
                add('Problema/necessità', 'Raccontaci cosa ti serve', 'Scrivi qui qualche dettaglio...', 'Bastano poche righe: ci aiutano a capire meglio.');
            } else if (type === 'select') {
                if (goal === 'quote') add('Bisogno', 'Che tipo di progetto ti serve?', '— Scegli una voce —', 'Partiamo da qui, poi potrai aggiungere dettagli.');
                if (goal === 'consulting') add('Consulenza', 'Su cosa vuoi lavorare?', '— Seleziona —', 'Scegli l\'area più vicina al tuo bisogno.');
                add('Scelta leggera', 'Scegli l\'opzione più vicina', '— Seleziona —', 'Non deve essere perfetta: scegli quella più simile al tuo caso.');
            } else if (type === 'radio' || type === 'checkbox') {
                add('First Yes', 'Da dove vuoi partire?', '', 'Una scelta veloce ci aiuta a guidarti nel percorso giusto.');
                add('Scelta semplice', 'Scegli una risposta', '', 'Puoi selezionare l\'opzione più vicina alla tua situazione.');
            } else if (type === 'name' || (type === 'text' && /nome|name/i.test(f.slug || label))) {
                add('Più umano', 'Come ti chiami?', 'Il tuo nome', 'Ci serve solo per risponderti meglio.');
                add('Professionale', 'Nome e cognome', 'Mario Rossi', 'Inserisci il nome che vuoi usare per questa richiesta.');
            } else if (type === 'url') {
                add('Sito/social', 'Hai già un sito o una pagina?', 'https://...', 'Inserisci un link se vuoi farci vedere da dove parti.');
            } else if (type === 'date') {
                add('Data desiderata', 'Quando ti serve?', '', 'Scegli una data indicativa, se non è ancora definitiva.');
            } else if (type === 'file') {
                add('File utile', 'Carica un file utile', '', 'Puoi allegare immagini, PDF o documenti che aiutano a capire la richiesta.');
            } else if (type === 'consent') {
                add('Consenso chiaro', 'Privacy', '', 'Acconsento al trattamento dei dati per ricevere risposta alla mia richiesta.');
            } else if (type === 'number' || type === 'range' || type === 'rating' || type === 'nps') {
                add('Scala chiara', 'Quanto è importante per te?', '', 'Scegli un valore indicativo: ci aiuta a capire la priorità.');
            } else {
                add('Più umano', label || 'La tua risposta', 'Scrivi qui...', 'Compila questo campo per proseguire.');
                add('Più leggero', label || 'Partiamo da qui', 'Risposta breve', 'Va bene anche una risposta semplice.');
            }
            return out.slice(0, 3);
        }

        function renderMicrocopyAssistant(f) {
            if (!microcopyEnabled()) return '';
            if (['html','submit','hidden','avatar'].indexOf(f.type || '') >= 0) return '';
            var suggestions = microcopySuggestions(f);
            var html = '<div class="fone-microcopy-box">' +
                '<h4 class="fone-settings-section"><i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i> Microcopy Assistant</h4>' +
                '<p class="fone-muted">Suggerimenti locali per rendere questo campo più chiaro, leggero e umano.</p>' +
                '<div class="fone-microcopy-actions">';
            suggestions.forEach(function(s, i){
                html += '<button type="button" class="fone-microcopy-apply" data-micro-index="' + i + '">' + esc(s.title) + '</button>';
            });
            html += '</div></div>';
            return html;
        }

        function renderSettings() {
            if (activeIdx === null || activeIdx >= schema.length) {
                updateBuilderEditMode();
                setFieldEditingMode(false);
                $settingsPane.html('<p class="fone-muted">' + esc(t('select_field')) + '</p>');
                return;
            }
            var f = schema[activeIdx];
            updateBuilderEditMode();
            setFieldEditingMode(true);
            var isHtmlOnly = (f.type === 'html');
            var isHtmlAdmin = (f.type === 'html_admin');
            var isSubmit = (f.type === 'submit');
            var isHtmlOrSub = isHtmlOnly || isHtmlAdmin || isSubmit;
            var isAvatar    = f.type === 'avatar';
            var hasOptions  = ['select','radio','checkbox'].indexOf(f.type) >= 0;
            var hasMaxChars = f.type === 'textarea' || (f.type === 'text');

            var html = '<div class="fone-settings-inner">';
            html += settingRow(t('field_type'),
                '<span class="fone-type-badge">' + esc(f.type) + '</span>');
            html += settingRow(t('field_id'),
                '<input class="fone-settings-input" data-key="id" value="' + esc(f.id) + '" readonly style="opacity:.5">');

            if (!isHtmlOrSub) {
                html += settingRow(t('label'),
                    '<input class="fone-settings-input" data-key="label" value="' + esc(f.label || '') + '">');
                if (!isAvatar) {
                    html += settingRow(t('placeholder'),
                        '<input class="fone-settings-input" data-key="placeholder" value="' + esc(f.placeholder || '') + '">');
                }
                html += settingRow(t('help_text'),
                    '<input class="fone-settings-input" data-key="help" value="' + esc(f.help || '') + '">');
            } else if (f.type === 'html_admin') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-puzzle-piece" aria-hidden="true"></i> HTML Admin</h4>';
                html += settingRow('HTML del blocco',
                    '<textarea class="fone-settings-input fone-settings-textarea fone-html-admin-code" data-key="html_content" spellcheck="false" placeholder="<div class=&quot;mio-box&quot;>Contenuto HTML</div>">' + esc(f.html_content || f.label || '') + '</textarea>' +
                    '<small class="fone-muted">HTML inserito dal backend. Nel canvas resta compatto; il risultato si vede nell\'anteprima in basso e nel frontend.</small>');
                html += settingRow('CSS del blocco',
                    '<textarea class="fone-settings-input fone-settings-textarea fone-html-admin-code" data-key="html_css" spellcheck="false" placeholder=".mio-box { padding: 16px; border-radius: 12px; }">' + esc(f.html_css || '') + '</textarea>' +
                    '<small class="fone-muted">CSS opzionale. Consiglio: usa classi tue per non sporcare il resto del form.</small>');
            } else if (f.type === 'html') {
                html += settingRow(t('label'),
                    '<textarea class="fone-settings-input fone-settings-textarea" data-key="label">' + esc(f.label || '') + '</textarea>');
            } else {
                html += settingRow(t('label'),
                    '<input class="fone-settings-input" data-key="label" value="' + esc(f.label || '') + '">');
            }

            if (!isHtmlOrSub) {
                html += settingRow(t('required'),
                    '<label class="fone-toggle">' +
                        '<input type="checkbox" data-key="required"' + (f.required ? ' checked' : '') + '>' +
                        '<span class="fone-toggle-track"><span class="fone-toggle-thumb"></span></span>' +
                    '</label>');
            }

            // Step selector — dinamico
            var stepOpts = '';
            for (var i = 1; i <= maxStep; i++) {
                stepOpts += '<option value="' + i + '"' + (f.step == i ? ' selected' : '') + '>Step ' + i + '</option>';
            }
            stepOpts += '<option value="__new__">' + esc(t('add_step')) + '</option>';
            html += settingRow(t('step'),
                '<select class="fone-settings-input" data-key="step">' + stepOpts + '</select>');

            if (!isHtmlOnly) {
                var selectedWidth = f.width || ((isSubmit || isHtmlAdmin) ? 'full' : 'half');
                html += settingRow(t('width'),
                    '<select class="fone-settings-input" data-key="width">' +
                        '<option value="third"' + (selectedWidth === 'third' ? ' selected' : '') + '>⅓ ' + esc(t('third')) + '</option>' +
                        '<option value="half"' + (selectedWidth === 'half' ? ' selected' : '') + '>½ ' + esc(t('half')) + '</option>' +
                        '<option value="two-thirds"' + (selectedWidth === 'two-thirds' ? ' selected' : '') + '>⅔ ' + esc(t('two_thirds')) + '</option>' +
                        '<option value="full"' + (selectedWidth === 'full' ? ' selected' : '') + '>⬛ ' + esc(t('full')) + '</option>' +
                    '</select>' +
                    '<small class="fone-muted" style="display:block;margin-top:4px;"><i class="fa-solid fa-lightbulb" aria-hidden="true"></i> Scorciatoie da tastiera (campo selezionato): <kbd>1</kbd>=⅓ <kbd>2</kbd>=½ <kbd>3</kbd>=⅔ <kbd>4</kbd>=Full</small>');
            }

            if (hasOptions) {
                html += settingRow(t('options'),
                    '<textarea class="fone-settings-input fone-settings-textarea" data-key="options">' + esc(f.options || '') + '</textarea>');
            }
            if (hasMaxChars) {
                html += settingRow(t('max_chars'),
                    '<input type="number" class="fone-settings-input" data-key="max_chars" value="' + esc(f.max_chars || '') + '" min="0" max="10000">');
            }

            if (isAvatar) {
                html += settingRow(t('accept_types'),
                    '<input class="fone-settings-input" data-key="accept_types" value="' + esc(f.accept_types || '') + '">' +
                    '<small class="fone-muted">' + esc(t('accept_types_help')) + '</small>');
                html += settingRow(t('max_size_mb'),
                    '<input type="number" class="fone-settings-input" data-key="max_size_mb" value="' + esc(f.max_size_mb || '5') + '" min="1" max="20">');
                html += settingRow(t('meta_key'),
                    '<input class="fone-settings-input" data-key="meta_key" value="' + esc(f.meta_key || 'wp_user_avatar') + '">' +
                    '<small class="fone-muted">' + esc(t('meta_key_help')) + '</small>');
            }
            html += renderMicrocopyAssistant(f);

            if (!isHtmlOrSub && !isAvatar) {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-compass" aria-hidden="true"></i> Conditional Logic Light</h4>';
                html += settingRow('Abilita condizione',
                    '<label class="fone-toggle">' +
                        '<input type="checkbox" data-key="conditional_enabled"' + (f.conditional_enabled ? ' checked' : '') + '>' +
                        '<span class="fone-toggle-track"><span class="fone-toggle-thumb"></span></span>' +
                    '</label><small class="fone-muted">Mostra o nasconde questo campo in base a una risposta precedente.</small>');

                var refs = '<option value="">— Scegli campo —</option>';
                schema.forEach(function(cf){
                    if (!cf || !cf.id || cf.id === f.id || ['html','html_admin','submit','divider','paypal_button'].indexOf(cf.type || '') >= 0) return;
                    var refVal = cf.slug || cf.id;
                    var refLabel = (cf.label || cf.slug || cf.id) + ' · ' + (cf.type || 'field');
                    refs += '<option value="' + esc(refVal) + '"' + ((f.conditional_field || '') === refVal ? ' selected' : '') + '>' + esc(refLabel) + '</option>';
                });
                html += settingRow('Campo di riferimento', '<select class="fone-settings-input" data-key="conditional_field">' + refs + '</select>');
                html += settingRow('Operatore',
                    '<select class="fone-settings-input" data-key="conditional_operator">' +
                        '<option value="is"' + ((f.conditional_operator || 'is') === 'is' ? ' selected' : '') + '>è uguale a</option>' +
                        '<option value="is_not"' + (f.conditional_operator === 'is_not' ? ' selected' : '') + '>è diverso da</option>' +
                        '<option value="contains"' + (f.conditional_operator === 'contains' ? ' selected' : '') + '>contiene</option>' +
                        '<option value="not_empty"' + (f.conditional_operator === 'not_empty' ? ' selected' : '') + '>non è vuoto</option>' +
                        '<option value="empty"' + (f.conditional_operator === 'empty' ? ' selected' : '') + '>è vuoto</option>' +
                    '</select>');
                html += settingRow('Valore', '<input class="fone-settings-input" data-key="conditional_value" value="' + esc(f.conditional_value || '') + '" placeholder="Es: Sito web">');
                html += settingRow('Azione',
                    '<select class="fone-settings-input" data-key="conditional_action">' +
                        '<option value="show"' + ((f.conditional_action || 'show') === 'show' ? ' selected' : '') + '>Mostra questo campo se la condizione è vera</option>' +
                        '<option value="hide"' + (f.conditional_action === 'hide' ? ' selected' : '') + '>Nascondi questo campo se la condizione è vera</option>' +
                    '</select>');
            }

            /* ==========================================================
               OPZIONI AVANZATE PER-TIPO DI CAMPO
            ========================================================== */
            var toggleRow = function(label, key, checked, help) {
                return settingRow(label,
                    '<label class="fone-toggle">' +
                        '<input type="checkbox" data-key="' + key + '"' + (checked ? ' checked' : '') + '>' +
                        '<span class="fone-toggle-track"><span class="fone-toggle-thumb"></span></span>' +
                    '</label>' +
                    (help ? '<small class="fone-muted">' + esc(help) + '</small>' : ''));
            };
            var inputRow = function(label, key, type, value, help, attrs) {
                attrs = attrs || '';
                return settingRow(label,
                    '<input type="' + type + '" class="fone-settings-input" data-key="' + key + '" value="' + esc(value || '') + '" ' + attrs + '>' +
                    (help ? '<small class="fone-muted">' + esc(help) + '</small>' : ''));
            };

            // === EMAIL ===
            if (f.type === 'email') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-envelope" aria-hidden="true"></i> Opzioni Email</h4>';
                html += toggleRow('Blocca email temporanee', 'opt_block_temp_email', !!f.opt_block_temp_email, 'Rifiuta mailinator, tempmail, 10minutemail, guerrillamail, ecc.');
                html += inputRow('Dominio ammesso (opzionale)', 'opt_email_domain', 'text', f.opt_email_domain, 'Es: @azienda.it (lascia vuoto per tutti)');
                html += toggleRow('Conferma email (doppio campo)', 'opt_require_confirm', !!f.opt_require_confirm, 'Chiede di reinserire l\'email per conferma');
            }

            // === PASSWORD ===
            if (f.type === 'password') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-key" aria-hidden="true"></i> Sicurezza Password</h4>';
                html += inputRow('Lunghezza minima', 'opt_min_length', 'number', f.opt_min_length || 8, 'Default: 8', 'min="4" max="64"');
                html += toggleRow('Richiedi lettera maiuscola', 'opt_require_upper', !!f.opt_require_upper);
                html += toggleRow('Richiedi lettera minuscola', 'opt_require_lower', !!f.opt_require_lower);
                html += toggleRow('Richiedi numero', 'opt_require_number', !!f.opt_require_number);
                html += toggleRow('Richiedi carattere speciale', 'opt_require_symbol', !!f.opt_require_symbol, '! @ # $ % ecc.');
                html += toggleRow('Mostra indicatore forza', 'opt_show_strength', !!f.opt_show_strength, 'Barra colorata live sotto al campo');
            }

            // === TELEFONO / WHATSAPP ===
            if (f.type === 'tel' || f.type === 'phone' || f.type === 'whatsapp') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-phone" aria-hidden="true"></i> Opzioni Telefono</h4>';
                html += settingRow('Prefisso default',
                    '<select class="fone-settings-input" data-key="default_prefix">' +
                        ['+39','+1','+44','+33','+49','+34','+41','+43','+32','+31','+351','+30','+46','+47','+45','+358','+48','+420','+36','+40','+7','+380','+90','+86','+81','+82','+91','+61','+55','+54','+52']
                            .map(function(p){ return '<option value="'+p+'"' + ((f.default_prefix||'+39')===p?' selected':'') + '>'+p+'</option>'; }).join('') +
                    '</select>');
                html += inputRow('Cifre minime', 'opt_min_digits', 'number', f.opt_min_digits || '', 'Es: 8 (lascia vuoto per libero)', 'min="0" max="20"');
                html += inputRow('Cifre massime', 'opt_max_digits', 'number', f.opt_max_digits || '', 'Es: 15 (lascia vuoto per libero)', 'min="0" max="20"');
            }

            // === NUMERO ===
            if (f.type === 'number') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-hashtag" aria-hidden="true"></i> Opzioni Numero</h4>';
                html += inputRow('Valore minimo', 'opt_min', 'number', f.opt_min, 'Lascia vuoto per nessun limite');
                html += inputRow('Valore massimo', 'opt_max', 'number', f.opt_max, 'Lascia vuoto per nessun limite');
                html += inputRow('Incremento (step)', 'opt_step', 'number', f.opt_step || 1, 'Es: 1, 0.01, 5', 'min="0" step="0.01"');
                html += toggleRow('Solo numeri interi', 'opt_integer_only', !!f.opt_integer_only);
            }

            // === URL ===
            if (f.type === 'url') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-globe" aria-hidden="true"></i> Opzioni URL</h4>';
                html += toggleRow('Richiedi HTTPS', 'opt_require_https', !!f.opt_require_https, 'Rifiuta http:// non sicuro');
                html += inputRow('Dominio richiesto', 'opt_url_domain', 'text', f.opt_url_domain, 'Es: instagram.com (lascia vuoto per tutti)');
            }

            // === DATA ===
            if (f.type === 'date') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-calendar-days" aria-hidden="true"></i> Opzioni Data</h4>';
                html += toggleRow('Solo date future', 'opt_future_only', !!f.opt_future_only, 'Rifiuta date passate');
                html += toggleRow('Solo date passate', 'opt_past_only', !!f.opt_past_only, 'Rifiuta date future');
                html += inputRow('Età minima (anni)', 'opt_min_age', 'number', f.opt_min_age, 'Utile per data di nascita. Es: 18', 'min="0" max="120"');
                html += inputRow('Età massima (anni)', 'opt_max_age', 'number', f.opt_max_age, 'Es: 99', 'min="0" max="120"');
            }

            // === TESTO / NOME / USERNAME ===
            if (f.type === 'text' || f.type === 'name') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-font" aria-hidden="true"></i> Opzioni Testo</h4>';
                html += toggleRow('Solo lettere (no numeri/simboli)', 'opt_letters_only', !!f.opt_letters_only, 'Utile per nome/cognome');
                html += toggleRow('Solo alfanumerico', 'opt_alphanum_only', !!f.opt_alphanum_only, 'Lettere + numeri, no simboli');
                html += toggleRow('No spazi', 'opt_no_spaces', !!f.opt_no_spaces, 'Utile per username');
                html += toggleRow('Forza minuscolo', 'opt_lowercase', !!f.opt_lowercase, 'Converte tutto in lowercase');
                html += toggleRow('Capitalizza prima lettera', 'opt_capitalize', !!f.opt_capitalize, 'Prima lettera maiuscola automatica');
                html += inputRow('Lunghezza minima', 'opt_min_length', 'number', f.opt_min_length, '', 'min="0" max="500"');
                html += inputRow('Lunghezza massima', 'opt_max_length', 'number', f.opt_max_length, '', 'min="0" max="500"');
            }

            // === TEXTAREA ===
            if (f.type === 'textarea') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-align-left" aria-hidden="true"></i> Opzioni Area Testo</h4>';
                html += toggleRow('Blocca link/URL', 'opt_block_links', !!f.opt_block_links, 'Rifiuta messaggi con http:// o www.');
                html += toggleRow('Blocca parolacce comuni', 'opt_block_badwords', !!f.opt_block_badwords, 'Filtro anti-spam basilare IT/EN');
            }

            // === HIDDEN / DEFAULT VALUE ===
            if (f.type === 'hidden') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-eye-slash" aria-hidden="true"></i> Campo nascosto</h4>';
                html += inputRow('Valore nascosto', 'default_value', 'text', f.default_value, 'Valore inviato senza mostrarlo all\'utente');
            }

            // === CONSENSO ===
            if (f.type === 'consent') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> Opzioni consenso</h4>';
                html += inputRow('Testo consenso', 'default_value', 'text', f.default_value || 'Acconsento al trattamento dei dati.', 'Testo mostrato accanto alla checkbox');
            }

            // === DIVIDER / SEZIONE ===
            if (f.type === 'divider') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-minus" aria-hidden="true"></i> Opzioni divider</h4>';
                html += inputRow('Sottotitolo sezione', 'help', 'text', f.help, 'Testo piccolo sotto al titolo, opzionale');
            }

            // === FILE UPLOAD ===
            if (f.type === 'file') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-paperclip" aria-hidden="true"></i> Opzioni file</h4>';
                html += inputRow('Tipi MIME ammessi', 'accept_types', 'text', f.accept_types || 'application/pdf,image/jpeg,image/png,image/webp,text/plain', 'Esempio: application/pdf,image/jpeg,image/png');
                html += inputRow('Peso massimo MB', 'max_size_mb', 'number', f.max_size_mb || 10, 'Default: 10 MB', 'min="1" max="50"');
            }

            // === RANGE / RATING / NPS ===
            if (f.type === 'range' || f.type === 'rating' || f.type === 'nps') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-sliders" aria-hidden="true"></i> Scala numerica</h4>';
                html += inputRow('Valore minimo', 'opt_min', 'number', f.opt_min || (f.type === 'nps' ? 0 : 1), '', 'step="1"');
                html += inputRow('Valore massimo', 'opt_max', 'number', f.opt_max || (f.type === 'nps' ? 10 : 5), '', 'step="1"');
                html += inputRow('Incremento', 'opt_step', 'number', f.opt_step || 1, '', 'min="0.01" step="0.01"');
                if (f.type === 'range') {
                    html += inputRow('Valore iniziale', 'default_value', 'number', f.default_value || '', 'Lascia vuoto per nessun valore iniziale');
                }
            }

            // === ORA / COLORE ===
            if (f.type === 'time') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-clock" aria-hidden="true"></i> Opzioni ora</h4>';
                html += inputRow('Ora minima', 'opt_min', 'time', f.opt_min || '', 'Opzionale');
                html += inputRow('Ora massima', 'opt_max', 'time', f.opt_max || '', 'Opzionale');
            }
            if (f.type === 'color') {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-palette" aria-hidden="true"></i> Opzioni colore</h4>';
                html += inputRow('Colore iniziale', 'default_value', 'color', f.default_value || '#2563eb', 'Valore predefinito');
            }

            // === INDIRIZZO (text con autocomp street-address o slug address) ===
            if ((f.type === 'text' && (f.autocomp === 'street-address' || (f.slug || '').indexOf('address') !== -1))) {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-location-dot" aria-hidden="true"></i> Opzioni Indirizzo</h4>';
                html += toggleRow('Link Google Maps nell\'email', 'opt_is_address', f.opt_is_address !== 0, 'Il valore diventa cliccabile → apre Maps');
            }

            // === MAPPATURA CAMPO WORDPRESS (per form di registrazione) ===
            if (!isHtmlOrSub) {
                html += '<h4 class="fone-settings-section"><i class="fa-solid fa-user-gear" aria-hidden="true"></i> Mappatura WordPress</h4>';
                var wpFieldOptions = [
                    ['', '— Nessuna mappatura —'],
                    ['user_email',   'Email utente (user_email)'],
                    ['user_login',   'Username (user_login)'],
                    ['user_pass',    'Password (user_pass)'],
                    ['first_name',   'Nome (first_name)'],
                    ['last_name',    'Cognome (last_name)'],
                    ['display_name', 'Nome visualizzato (display_name)'],
                    ['user_url',     'Sito web (user_url)'],
                    ['description',  'Biografia (description)'],
                    ['custom_meta',  'Meta personalizzato (usa il campo ID come chiave)'],
                ];
                var wpSelHtml = '<select class="fone-settings-input" data-key="wp_field">';
                wpFieldOptions.forEach(function(opt){
                    var sel = (f.wp_field || '') === opt[0] ? ' selected' : '';
                    wpSelHtml += '<option value="' + esc(opt[0]) + '"' + sel + '>' + esc(opt[1]) + '</option>';
                });
                wpSelHtml += '</select>';
                html += settingRow('Mappa a campo WP', wpSelHtml + '<small class="fone-muted">Usato solo se "Registrazione Utente" è attiva nelle Impostazioni.</small>');
            }

            html += '</div>';

            $settingsPane.html(html);

            $settingsPane.find('.fone-microcopy-apply').on('click', function () {
                var idx = parseInt($(this).attr('data-micro-index'), 10) || 0;
                var suggestions = microcopySuggestions(schema[activeIdx] || {});
                var s = suggestions[idx];
                if (!s || !schema[activeIdx]) return;
                if (s.label) schema[activeIdx].label = s.label;
                if (s.placeholder && schema[activeIdx].type !== 'radio' && schema[activeIdx].type !== 'checkbox' && schema[activeIdx].type !== 'consent') {
                    schema[activeIdx].placeholder = s.placeholder;
                }
                if (s.help) schema[activeIdx].help = s.help;
                if ((schema[activeIdx].type || '') === 'consent' && s.help) {
                    schema[activeIdx].default_value = s.help;
                }
                sync();
                renderCanvas();
                renderSettings();
                renderPreview();
            });

            $settingsPane.find('[data-key]').each(function () {
                var $el = $(this);
                var key = $el.data('key');
                if (!key || key === 'id') return;
                // checkbox → change, select → change, tutto il resto → input
                var evt = ($el.is(':checkbox') || $el.is('select')) ? 'change' : 'input';
                $el.on(evt, function () {
                    if ($el.is(':checkbox')) {
                        schema[activeIdx][key] = $el.is(':checked') ? 1 : 0;
                    } else if (key === 'step') {
                        var v = $el.val();
                        if (v === '__new__') {
                            maxStep++;
                            schema[activeIdx].step = maxStep;
                        } else {
                            schema[activeIdx].step = parseInt(v, 10) || 1;
                        }
                    } else {
                        schema[activeIdx][key] = $el.val();
                    }
                    sync();
                    renderCanvas();

                    // IMPORTANTE: non richiamare renderSettings() mentre l'utente
                    // scrive in input/textarea della barra destra. Ricostruire il
                    // pannello settings ad ogni carattere distrugge il campo attivo
                    // e fa perdere il cursore. Rigeneriamo la sidebar solo quando
                    // cambia lo step, perché l'opzione "+ Aggiungi step" deve
                    // trasformarsi nello step reale.
                    if (key === 'step') {
                        renderSettings();
                    }

                    renderPreview();
                });
            });
        }

        function settingRow(label, control) {
            return '<div class="fone-settings-row">' +
                '<label class="fone-settings-label">' + esc(label) + '</label>' +
                '<div class="fone-settings-control">' + control + '</div>' +
            '</div>';
        }

        /* ---- LIVE PREVIEW -------------------------------------- */
        /* ---- PREVIEW STATE ------------------------------------- */
        var previewStep = 1; // step attualmente visualizzato in anteprima

        function getStepKeys() {
            var groups = {};
            schema.forEach(function(f){ var s = f.step || 1; if (!groups[s]) groups[s] = true; });
            // Includi anche step vuoti (quelli in layouts)
            for (var ls = 1; ls <= maxStep; ls++) { groups[ls] = true; }
            return Object.keys(groups).map(Number).sort(function(a,b){ return a-b; });
        }

        function renderPreview() {
            var accent = ($colorInput.val() || (FONE_ADMIN.settings && FONE_ADMIN.settings.accent_color) || '#2563eb');
            var $radiusEl = $('[name="fone_border_radius"]');
            var radius = $radiusEl.length ? (parseInt($radiusEl.val(), 10) || 10) : 10;

            // Sincronizza previewStep con il campo attivo nel canvas
            if (activeIdx !== null && schema[activeIdx]) {
                previewStep = schema[activeIdx].step || 1;
            }

            // Clamp previewStep ai valori validi
            var stepKeys = getStepKeys();
            if (!stepKeys.length) stepKeys = [1];
            if (stepKeys.indexOf(previewStep) === -1) previewStep = stepKeys[0];

            // Raggruppa campi per step
            var groups = {};
            schema.forEach(function(f){
                var s = f.step || 1;
                if (!groups[s]) groups[s] = [];
                groups[s].push(f);
            });

            // ── Topbar: device + step tabs ──
            var tabsHtml = '<div id="fone-preview-step-tabs" class="fone-preview-step-tabs">';
            stepKeys.forEach(function(s){
                var cls = s === previewStep ? ' is-active' : '';
                var hasFields = groups[s] && groups[s].length > 0;
                tabsHtml += '<button type="button" class="fone-preview-step-tab' + cls + '" data-preview-step="' + s + '">' +
                    esc(t('step')) + ' ' + s +
                    (hasFields ? ' <span class="fone-preview-step-count">' + (groups[s].length) + '</span>' : '') +
                '</button>';
            });
            tabsHtml += '</div>';

            // ── Prev/Next step ──
            var curIdx   = stepKeys.indexOf(previewStep);
            var hasPrev  = curIdx > 0;
            var hasNext  = curIdx < stepKeys.length - 1;
            var prevStep = hasPrev ? stepKeys[curIdx - 1] : null;
            var nextStep = hasNext ? stepKeys[curIdx + 1] : null;

            // ── Contenuto step corrente ──
            var fields    = groups[previewStep] || [];
            var layoutVal = layouts[previewStep] || '1col';
            var gridCls   = layoutVal === '2col' ? 'fone-step-grid is-two-col' : 'fone-step-grid is-one-col';

            var stepHtml = '<div class="fone-wrap" style="' +
                '--fone-accent:' + esc(accent) + ';' +
                '--fone-radius:' + radius + 'px;' +
                'box-shadow:none;border:none;padding:0;background:transparent;">';

            stepHtml += '<div class="fone-step-card"><div class="' + gridCls + '">';

            if (fields.length === 0) {
                stepHtml += '<div class="fone-preview-empty-step" style="grid-column:1/-1;text-align:center;padding:40px 20px;color:#94a3b8;border:2px dashed #e2e8f0;border-radius:12px;">' +
                    '<i class="fa-solid fa-clipboard-list" aria-hidden="true"></i> Nessun campo in questo step.<br><small>Trascina campi dalla libreria su Step ' + previewStep + '</small>' +
                '</div>';
            } else {
                fields.forEach(function(f){ stepHtml += renderPreviewField(f); });
            }

            stepHtml += '</div>';

            // Bottone continua o invia
            var hasSubmitField = fields.some(function(f){ return f.type === 'submit'; });
            if (!hasSubmitField) {
                if (hasNext) {
                    stepHtml += '<button type="button" class="fone-continue-btn" style="pointer-events:none;">' +
                        '<i class="fa-solid fa-arrow-right" aria-hidden="true"></i> ' + esc(t('continue')) + '</button>';
                }
                // Ultimo step senza submit: mostra "Invia" fittizio
                if (!hasNext && fields.length > 0) {
                    stepHtml += '<button type="button" class="fone-submit-btn" style="pointer-events:none;margin-top:10px;">' +
                        esc(t('submit')) + '</button>';
                }
            }

            stepHtml += '</div></div>';

            // ── Nav step (prev / next) ──
            var navHtml = '<div class="fone-preview-step-nav">' +
                '<button type="button" class="fone-preview-nav-btn" data-preview-nav="prev"' + (hasPrev ? '' : ' disabled') + '>← Step ' + (prevStep || '') + '</button>' +
                '<span class="fone-preview-step-indicator">Step ' + previewStep + ' / ' + stepKeys.length + '</span>' +
                '<button type="button" class="fone-preview-nav-btn" data-preview-nav="next"' + (hasNext ? '' : ' disabled') + '>Step ' + (nextStep || '') + ' <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></button>' +
            '</div>';

            // ── Assembla tutto ──
            $previewInner.html(tabsHtml + navHtml + stepHtml);

            // Bind tab click
            $previewInner.find('.fone-preview-step-tab').off('click').on('click', function(){
                previewStep = parseInt($(this).data('preview-step'), 10);
                renderPreview();
            });

            // Bind nav prev/next
            $previewInner.find('[data-preview-nav]').off('click').on('click', function(){
                var dir = $(this).data('preview-nav');
                var keys = getStepKeys();
                var ci = keys.indexOf(previewStep);
                if (dir === 'prev' && ci > 0) { previewStep = keys[ci - 1]; renderPreview(); }
                if (dir === 'next' && ci < keys.length - 1) { previewStep = keys[ci + 1]; renderPreview(); }
            });
        }

        function renderPreviewField(f) {
            var type  = f.type || 'text';
            var label = f.label || '';
            var ph    = f.placeholder || '';
            var slug  = f.slug || '';
            var req   = f.required ? '<span class="fone-required">*</span>' : '';
            var width;
            if (f.width === 'full' || f.width === 'half' || f.width === 'third' || f.width === 'two-thirds') {
                width = f.width;
            } else {
                width = (['textarea','html','html_admin','submit','radio','checkbox','avatar','paypal_button','whatsapp','tel','phone','file','consent','divider','rating','nps'].indexOf(type) >= 0 ? 'full' : 'half');
            }

            var inner = '';

            if (type === 'html') {
                inner = '<div class="fone-html-block">' + (label || '<em>Blocco HTML</em>') + '</div>';

            } else if (type === 'html_admin') {
                var htmlAdmin = f.html_content || label || '<div class="fone-html-admin-box"><strong>HTML Admin</strong><p>Contenuto personalizzato.</p></div>';
                var cssAdmin = f.html_css || '';
                inner = (cssAdmin ? '<style>' + safeStyleText(cssAdmin) + '</style>' : '') + '<div class="fone-html-admin-block">' + htmlAdmin + '</div>';

            } else if (type === 'submit') {
                inner = '<button type="button" class="fone-submit-btn" style="pointer-events:none;">' + esc(label || t('submit')) + '</button>';

            } else if (type === 'hidden') {
                inner = '<div class="fone-hidden-preview"><i class="fa-solid fa-eye-slash" aria-hidden="true"></i> Campo nascosto: ' + esc(f.default_value || '') + '</div>';

            } else if (type === 'divider') {
                inner = '<div class="fone-section-divider-preview"><strong>' + esc(label || 'Nuova sezione') + '</strong>' + (f.help ? '<small>' + esc(f.help) + '</small>' : '') + '</div>';

            } else if (type === 'consent') {
                inner = '<label class="fone-choice-row"><input type="checkbox" disabled><span>' + esc(f.default_value || label || 'Acconsento al trattamento dei dati.') + req + '</span></label>';

            } else if (type === 'file') {
                inner = '<label>' + esc(label) + req + '</label><input type="file" disabled><small class="fone-muted">Max ' + esc(f.max_size_mb || '10') + ' MB</small>';

            } else if (type === 'range') {
                var rmin = f.opt_min || 0, rmax = f.opt_max || 100, rstep = f.opt_step || 1;
                inner = '<label>' + esc(label) + req + '</label><input type="range" min="' + esc(rmin) + '" max="' + esc(rmax) + '" step="' + esc(rstep) + '" value="' + esc(f.default_value || Math.round((Number(rmin)+Number(rmax))/2)) + '" disabled>';

            } else if (type === 'rating' || type === 'nps') {
                var mn = parseInt(f.opt_min || (type === 'nps' ? 0 : 1), 10);
                var mx = parseInt(f.opt_max || (type === 'nps' ? 10 : 5), 10);
                var labels = [];
                for (var ri=mn; ri<=mx && labels.length<15; ri++) labels.push('<label class="fone-choice-row"><input type="radio" disabled><span>' + (type === 'rating' ? '⭐ ' : '') + esc(ri) + '</span></label>');
                inner = '<label>' + esc(label) + req + '</label><div class="fone-choice-group fone-scale-group">' + labels.join('') + '</div>';

            } else if (type === 'time') {
                inner = '<label>' + esc(label) + req + '</label><input type="time" disabled>';

            } else if (type === 'color') {
                inner = '<label>' + esc(label) + req + '</label><input type="color" value="' + esc(f.default_value || '#2563eb') + '" disabled>';

            } else if (type === 'avatar') {
                inner = '<div class="fone-avatar-slot">' +
                    '<div class="fone-avatar-label">' + esc(label) + req + '</div>' +
                    '<div class="fone-avatar-preview"><div class="fone-avatar-placeholder"><i class="fa-solid fa-camera" aria-hidden="true"></i></div></div>' +
                    '<div class="fone-avatar-buttons">' +
                        '<span class="fone-avatar-btn fone-avatar-upload-btn"><span>' + esc(t('upload_photo')) + '</span></span>' +
                        '<span class="fone-avatar-btn fone-avatar-capture-btn"><span>' + esc(t('take_photo')) + '</span></span>' +
                    '</div>' +
                '</div>';

            } else if (type === 'textarea') {
                var maxc = f.max_chars ? ' maxlength="' + esc(f.max_chars) + '"' : '';
                inner = '<label>' + esc(label) + req + '</label>' +
                        '<div class="fone-textarea-wrap"><textarea placeholder="' + esc(ph) + '" disabled' + maxc + '></textarea></div>';

            } else if (type === 'select') {
                inner = '<label>' + esc(label) + req + '</label>' +
                        '<select disabled><option>' + esc(ph || '— Seleziona —') + '</option></select>';

            } else if (type === 'radio' || type === 'checkbox') {
                var opts = (f.options || '').split('\n').filter(Boolean);
                inner = '<label>' + esc(label) + req + '</label>' +
                    '<div class="fone-choice-group">' +
                    (opts.length ? opts.map(function(o){
                        return '<label class="fone-choice-row"><input type="' + type + '" disabled><span>' + esc(o.trim()) + '</span></label>';
                    }).join('') : '<label class="fone-choice-row"><input type="' + type + '" disabled><span>Opzione 1</span></label>') +
                    '</div>';

            } else if (type === 'tel' || type === 'phone' || type === 'whatsapp') {
                // Mostra con prefisso internazionale come nel frontend reale
                var prefix = f.default_prefix || '+39';
                var wrapCls = 'fone-phone-wrap' + (type === 'whatsapp' ? ' is-whatsapp' : '');
                inner = '<label>' + esc(label) + req + '</label>' +
                    '<div class="' + wrapCls + '">' +
                        '<select class="fone-phone-prefix" disabled><option>' + esc(prefix) + '</option></select>' +
                        '<input type="tel" class="fone-phone-number" placeholder="' + esc(ph || '333 1234567') + '" disabled>' +
                    '</div>';

            } else if (type === 'password') {
                inner = '<label>' + esc(label) + req + '</label>' +
                        '<div class="fone-password-wrap is-preview">' +
                            '<input type="password" class="fone-password-input" placeholder="' + esc(ph || '••••••••') + '" disabled>' +
                            '<button type="button" class="fone-password-toggle" disabled aria-label="Mostra password">' +
                                '<span class="fone-password-eye" aria-hidden="true"><i class="fa-solid fa-eye"></i></span>' +
                            '</button>' +
                        '</div>';
                if (f.opt_show_strength) {
                    inner += '<div class="fone-pw-strength">' +
                        '<div class="fone-pw-strength-bar"><div class="fone-pw-strength-fill" style="width:0"></div></div>' +
                        '<div class="fone-pw-strength-label">—</div>' +
                    '</div>';
                }

            } else if (type === 'date') {
                inner = '<label>' + esc(label) + req + '</label>' +
                        '<input type="date" disabled>';

            } else if (type === 'number') {
                var minA = f.opt_min !== undefined && f.opt_min !== '' ? ' min="' + esc(f.opt_min) + '"' : '';
                var maxA = f.opt_max !== undefined && f.opt_max !== '' ? ' max="' + esc(f.opt_max) + '"' : '';
                inner = '<label>' + esc(label) + req + '</label>' +
                        '<input type="number" placeholder="' + esc(ph) + '" disabled' + minA + maxA + '>';

            } else if (type === 'paypal_button') {
                inner = '<div class="fone-paypal-wrap">' +
                    '<p class="fone-paypal-intro">' + esc(label || 'Completa il pagamento') + '</p>' +
                    '<div style="background:#f0ad4e;color:#fff;text-align:center;padding:12px 20px;border-radius:6px;font-weight:600;font-size:14px;opacity:.7;"><i class="fa-brands fa-paypal" aria-hidden="true"></i> PayPal</div>' +
                '</div>';

            } else {
                // text, name, email, url, ecc.
                var inputType = type === 'phone' ? 'tel' : type;
                inner = '<label>' + esc(label) + req + '</label>' +
                        '<input type="' + esc(inputType) + '" placeholder="' + esc(ph) + '" disabled>';
                // Campo email con conferma
                if (type === 'email' && f.opt_require_confirm) {
                    inner += '<input type="email" placeholder="Conferma email" disabled style="margin-top:8px;">';
                }
            }

            return '<div class="fone-field fone-width-' + esc(width) + ' fone-type-' + esc(type) + ' fone-slug-' + esc(slug) + '">' + inner + '</div>';
        }

        /* ---- DEVICE SWITCHER ----------------------------------- */
        $('.fone-device-btn').on('click', function () {
            $('.fone-device-btn').removeClass('is-active');
            $(this).addClass('is-active');
            var device = $(this).data('device');
            $previewVp.attr('class', 'fone-preview-viewport is-' + device);
        });

        /* ---- TABS ---------------------------------------------- */
        function setBuilderTab(tab) {
            $('.fone-tab').removeClass('is-active');
            $('.fone-panel').removeClass('is-active');
            $('[data-fone-tab="' + tab + '"]').addClass('is-active');
            $('[data-fone-panel="' + tab + '"]').addClass('is-active');

            var expanded = ['settings', 'design', 'publish'].indexOf(tab) !== -1;
            $builderLayout.toggleClass('fone-left-expanded', expanded);
            $builderLayout.attr('data-fone-active-tab', tab);

            if (tab !== 'fields') {
                $builderLayout.removeClass('fone-html-admin-editing');
            } else {
                updateBuilderEditMode();
            }
        }

        $('.fone-tab').on('click', function () {
            setBuilderTab($(this).data('fone-tab'));
        });

        $('#fone-sidebar-compact-toggle').on('click', function () {
            setBuilderTab('fields');
        });

        $('#fone-back-to-fields').on('click', function () {
            activeIdx = null;
            setBuilderTab('fields');
            renderCanvas();
            renderSettings();
            renderPreview();
        });

        setBuilderTab('fields');

        /* ---- COPY SHORTCODE ------------------------------------ */
        $copyBtn.on('click', function () {
            $shortcodeInp.select();
            try { document.execCommand('copy'); } catch(e) {}
            var original = $copyBtn.text();
            $copyBtn.text(t('copied'));
            setTimeout(function () { $copyBtn.text(original); }, 1800);
        });

        /* ---- LANG SYNC ----------------------------------------- */
        $langTop.on('change', function () {
            $langHidden.val($(this).val());
            lang = $(this).val();
            renderLibrary($librarySearch.val());
        });

        /* ---- COLOR PREVIEW ------------------------------------- */
        $colorInput.on('input', function () {
            $colorValue.text($(this).val());
            renderPreview();
        });

        /* ---- RADIUS LIVE PREVIEW ------------------------------- */
        $('[name="fone_border_radius"]').on('input', renderPreview);

        /* ---- CUSTOM CSS LIVE IN BUILDER ------------------------ */
        var $cssEditor = $('#fone_custom_css_builder');
        var $cssStyleTag = null;
        var cssDebounce = null;

        function applyCustomCssToPreview() {
            var css = $cssEditor.length ? ($cssEditor.val() || '') : '';
            // Tutto il custom CSS viene scopato nell'anteprima, così si vede
            // esattamente come apparirà in frontend
            if (!$cssStyleTag) {
                $cssStyleTag = $('<style id="fone-custom-css-preview"></style>');
                $previewInner.prepend($cssStyleTag);
            } else if (!$.contains($previewInner[0], $cssStyleTag[0])) {
                $previewInner.prepend($cssStyleTag);
            }
            $cssStyleTag.text(css);
        }

        if ($cssEditor.length) {
            $cssEditor.on('input', function () {
                clearTimeout(cssDebounce);
                cssDebounce = setTimeout(applyCustomCssToPreview, 300);
            });
        }

        // Wrappo renderPreview per applicare SEMPRE il custom CSS dopo il render
        var _renderPreviewOriginal = renderPreview;
        renderPreview = function () {
            _renderPreviewOriginal();
            applyCustomCssToPreview();
        };

        // Reset CSS al default
        $('#fone-reset-custom-css').on('click', function () {
            if (!confirm(t('reset_css_confirm'))) return;
            if (window.FONE_ADMIN.defaultCustomCss && $cssEditor.length) {
                $cssEditor.val(window.FONE_ADMIN.defaultCustomCss);
                applyCustomCssToPreview();
            }
        });

        /* ---- ADD STEP BUTTON ----------------------------------- */
        $addStepBtn.on('click', function () {
            maxStep++;
            layouts[maxStep] = '1col';
            sync(); renderCanvas(); renderPreview();
        });

        /* ---- KEYBOARD SHORTCUTS (1/2/3/4 per width) ----------- */
        $(document).off('keydown.fone-width').on('keydown.fone-width', function (e) {
            // Ignora se l'utente sta digitando in un input/textarea/select/contenteditable
            var t = e.target;
            if (!t) return;
            var tag = (t.tagName || '').toUpperCase();
            if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || t.isContentEditable) return;
            // Solo se è attivo un campo nel canvas
            if (activeIdx === null || !schema[activeIdx]) return;
            // Ignora solo i campi HTML: Submit/Invia può essere ridimensionato.
            var fld = schema[activeIdx];
            if (fld.type === 'html') return;

            var widthMap = { '1': 'third', '2': 'half', '3': 'two-thirds', '4': 'full' };
            var newWidth = widthMap[e.key];
            if (!newWidth) return;
            e.preventDefault();
            fld.width = newWidth;
            sync(); renderCanvas(); renderSettings(); renderPreview();
        });

        /* ---- INIT ---------------------------------------------- */
        renderLibrary();
        renderCanvas();
        renderSettings();
        renderPreview();
    });
})(jQuery);
