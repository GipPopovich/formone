/* ===================================================================
   Form One — Frontend JS
   - Stealth step reveal engine (step illimitati)
   - Validazione inline per step
   - Counter caratteri textarea
   - Anteprima foto profilo autore dopo upload
   - Submit state
=================================================================== */

document.addEventListener('DOMContentLoaded', function () {

    // Password toggle GLOBALE delegato (funziona anche su form login esclusi
    // dall'init).
    document.addEventListener('click', function(e){
        var btn = e.target.closest('[data-fone-password-toggle]');
        if (!btn) return;
        e.preventDefault();
        var holder = btn.closest('.fone-password-wrap');
        var input = holder ? holder.querySelector('input[type="password"], input[type="text"]') : null;
        if (!input) return;
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        btn.setAttribute('aria-pressed', show ? 'true' : 'false');
        btn.setAttribute('aria-label', show ? 'Nascondi password' : 'Mostra password');
        var icon = btn.querySelector('.fone-password-eye');
        if (icon) icon.innerHTML = show ? '<i class="fa-solid fa-eye-slash" aria-hidden="true"></i>' : '<i class="fa-solid fa-eye" aria-hidden="true"></i>';
    });

    var wraps = document.querySelectorAll('.fone-wrap');
    if (!wraps.length) return;

    wraps.forEach(function (wrap) {
        initForm(wrap);
    });

    function initForm(wrap) {

        var revealMode   = wrap.dataset.foneReveal || wrap.dataset.mgfReveal || 'from-top';
        var stepCards    = Array.prototype.slice.call(wrap.querySelectorAll('.fone-step-card'));
        var continueBtns = wrap.querySelectorAll('.fone-continue-btn');
        var submitBtn    = wrap.querySelector('.fone-submit-btn');
        var form         = wrap.querySelector('.fone-front-form');
        var resumeEnabled = wrap.dataset.foneResume === '1';
        var formId        = wrap.dataset.foneFormId || (form ? (form.querySelector('input[name="fone_form_id"]') || {}).value : '0');
        var resumeTtlDays = Math.max(1, Math.min(30, parseInt(wrap.dataset.foneResumeTtl || '7', 10) || 7));
        var resumeKey     = 'fone_resume_' + String(formId || '0') + '_' + window.location.pathname;
        var currentStep   = 1;
        var foneSessionKey = 'fone_session_' + String(formId || '0');
        var startedTracked = false;

        function resumeStorageAvailable() {
            try {
                var testKey = '__fone_resume_test__';
                window.localStorage.setItem(testKey, '1');
                window.localStorage.removeItem(testKey);
                return true;
            } catch (e) { return false; }
        }

        var canUseResume = resumeEnabled && resumeStorageAvailable();

        function getSessionId() {
            try {
                var sid = window.localStorage.getItem(foneSessionKey);
                if (!sid) {
                    sid = 's_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2);
                    window.localStorage.setItem(foneSessionKey, sid);
                }
                return sid;
            } catch(e) {
                return 's_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2);
            }
        }

        function trackEvent(eventName, stepNumber) {
            if (!window.FONE_FRONT || !FONE_FRONT.ajaxUrl || !FONE_FRONT.nonce || !formId) return;
            var body = new URLSearchParams();
            body.append('action', 'fone_track_event');
            body.append('nonce', FONE_FRONT.nonce);
            body.append('form_id', String(formId || '0'));
            body.append('event', eventName);
            body.append('step', String(stepNumber || currentStep || 0));
            body.append('session', getSessionId());
            body.append('url', window.location.href.split('#')[0]);

            try {
                if (navigator.sendBeacon) {
                    var fd = new FormData();
                    body.forEach(function(v, k){ fd.append(k, v); });
                    navigator.sendBeacon(FONE_FRONT.ajaxUrl, fd);
                    return;
                }
            } catch(e) {}

            try {
                fetch(FONE_FRONT.ajaxUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString()
                }).catch(function(){});
            } catch(e) {}
        }

        function trackStartOnce() {
            if (startedTracked) return;
            startedTracked = true;
            trackEvent('start', currentStep);
        }

        function refreshSecurityToken() {
            if (!form || !window.FONE_FRONT || !FONE_FRONT.ajaxUrl || !formId) {
                return Promise.resolve(true); // 'true' invece di 'false' per non bloccare il flow
            }
            var nonceInput = form.querySelector('input[name="fone_form_nonce"]');
            if (!nonceInput) return Promise.resolve(true); // niente nonce da refreshare = ok

            var body = new URLSearchParams();
            body.append('action', 'fone_refresh_form_nonce');
            body.append('form_id', String(formId || '0'));

            return fetch(FONE_FRONT.ajaxUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString()
            }).then(function(resp){ return resp.json(); }).then(function(json){
                if (json && json.success && json.data && json.data.nonce) {
                    nonceInput.value = json.data.nonce;
                    return true;
                }
                return true; // anche se non riesce, lasciamo procedere il submit
            }).catch(function(){ return true; });
        }

        trackEvent('view', 1);

        function isResumeField(el) {
            if (!el || !el.name) return false;
            if (el.name === 'fone_honey' || el.name === 'fone_form_nonce' || el.name === 'fone_form_submit' || el.name === 'fone_form_id') return false;
            if (el.type === 'file' || el.type === 'password' || el.type === 'hidden' || el.type === 'submit' || el.type === 'button') return false;

            var fieldWrap = el.closest('.fone-field');
            if (fieldWrap && fieldWrap.classList.contains('fone-type-consent')) return false;

            if (/privacy|consent|gdpr|terms|termini|trattamento/i.test(el.name)) return false;
            return /^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName);
        }

        function readResumeData() {
            if (!canUseResume) return null;
            try {
                var raw = window.localStorage.getItem(resumeKey);
                if (!raw) return null;
                var data = JSON.parse(raw);
                if (!data || typeof data !== 'object') return null;
                var updated = parseInt(data.updated || 0, 10);
                if (updated && (Date.now() - updated) > resumeTtlDays * 24 * 60 * 60 * 1000) {
                    window.localStorage.removeItem(resumeKey);
                    return null;
                }
                return data;
            } catch (e) { return null; }
        }

        function writeResumeData() {
            if (!canUseResume || !form) return;
            var data = { updated: Date.now(), currentStep: currentStep || 1, fields: {} };
            form.querySelectorAll('input, select, textarea').forEach(function (el) {
                if (!isResumeField(el)) return;
                if (el.type === 'checkbox') {
                    if (el.name.slice(-2) === '[]') {
                        if (!data.fields[el.name]) data.fields[el.name] = [];
                        if (el.checked) data.fields[el.name].push(el.value);
                    } else {
                        data.fields[el.name] = el.checked ? el.value : '';
                    }
                } else if (el.type === 'radio') {
                    if (el.checked) data.fields[el.name] = el.value;
                } else {
                    data.fields[el.name] = el.value;
                }
            });
            try { window.localStorage.setItem(resumeKey, JSON.stringify(data)); } catch (e) {}
        }

        function restoreResumeData() {
            if (!canUseResume || !form) return 1;
            var data = readResumeData();
            if (!data || !data.fields) return 1;
            var highestStep = data.currentStep ? parseInt(data.currentStep, 10) : 1;
            if (!highestStep || highestStep < 1) highestStep = 1;

            form.querySelectorAll('input, select, textarea').forEach(function (el) {
                if (!isResumeField(el)) return;
                if (!(el.name in data.fields)) return;

                var saved = data.fields[el.name];
                if (el.type === 'checkbox') {
                    if (Array.isArray(saved)) el.checked = saved.indexOf(el.value) !== -1;
                    else el.checked = String(saved) !== '' && String(saved) === String(el.value);
                } else if (el.type === 'radio') {
                    el.checked = String(saved) === String(el.value);
                } else {
                    el.value = saved;
                }

                if ((Array.isArray(saved) && saved.length) || (!Array.isArray(saved) && String(saved || '') !== '')) {
                    var card = el.closest('.fone-step-card');
                    var sn = card ? parseInt(card.dataset.foneStep || '1', 10) : 1;
                    if (sn > highestStep) highestStep = sn;
                }

                try {
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                } catch(e) {}
            });

            if (highestStep > 1) {
                stepCards.forEach(function (card) {
                    var sn = parseInt(card.dataset.foneStep || '1', 10);
                    if (sn <= highestStep) {
                        card.classList.remove('is-hidden');
                        card.removeAttribute('aria-hidden');
                    }
                });
            }
            currentStep = highestStep;
            if (data.fields && Object.keys(data.fields).length) {
                showResumeNotice();
            }
            return highestStep;
        }

        function showResumeNotice() {
            if (!canUseResume || wrap.querySelector('.fone-resume-notice')) return;
            var notice = document.createElement('div');
            notice.className = 'fone-resume-notice';
            notice.innerHTML = '<span>Abbiamo ripristinato i dati salvati su questo dispositivo.</span><button type="button">Cancella dati salvati</button>';
            var target = form || wrap.firstChild;
            if (target && target.parentNode) target.parentNode.insertBefore(notice, target);
            var btn = notice.querySelector('button');
            if (btn) btn.addEventListener('click', function(){
                clearResumeData();
                form.querySelectorAll('input, select, textarea').forEach(function(el){
                    if (!isResumeField(el)) return;
                    if (el.type === 'checkbox' || el.type === 'radio') el.checked = false;
                    else el.value = '';
                    try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch(e) {}
                });
                notice.remove();
            });
        }

        function clearResumeData() {
            if (!canUseResume) return;
            try { window.localStorage.removeItem(resumeKey); } catch (e) {}
        }

        if (canUseResume && wrap.querySelector('.fone-success-box')) {
            clearResumeData();
        }
        var resumeRestoredStep = restoreResumeData();

        if (canUseResume && form) {
            form.querySelectorAll('input, select, textarea').forEach(function (el) {
                if (!isResumeField(el)) return;
                el.addEventListener('input', function(){ trackStartOnce(); writeResumeData(); });
                el.addEventListener('change', function(){ trackStartOnce(); writeResumeData(); });
            });
        }


        /* ---- CONDITIONAL LOGIC LIGHT -------------------------- */
        function getFieldValueByRef(ref) {
            if (!form || !ref) return '';
            var byName = form.querySelectorAll('[name="' + cssEscape(ref) + '"], [name="' + cssEscape(ref) + '[]"]');
            var values = [];
            byName.forEach(function(el){
                if (el.type === 'checkbox' || el.type === 'radio') {
                    if (el.checked) values.push(el.value);
                } else {
                    values.push(el.value || '');
                }
            });
            if (values.length) return values.join(' ');
            var bySlug = wrap.querySelector('.fone-slug-' + cssEscape(ref));
            if (bySlug) {
                bySlug.querySelectorAll('input,select,textarea').forEach(function(el){
                    if (el.type === 'checkbox' || el.type === 'radio') {
                        if (el.checked) values.push(el.value);
                    } else {
                        values.push(el.value || '');
                    }
                });
            }
            return values.join(' ');
        }

        function cssEscape(value) {
            if (window.CSS && CSS.escape) return CSS.escape(String(value));
            return String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
        }

        function conditionalMatch(cond) {
            var actual = getFieldValueByRef(cond.field || '').trim();
            var expected = String(cond.value || '').trim();
            switch (cond.operator || 'is') {
                case 'is_not': return actual !== expected;
                case 'contains': return expected !== '' && actual.toLowerCase().indexOf(expected.toLowerCase()) !== -1;
                case 'not_empty': return actual !== '';
                case 'empty': return actual === '';
                case 'is':
                default: return actual === expected;
            }
        }

        function applyConditionals() {
            wrap.querySelectorAll('[data-fone-conditional]').forEach(function(fieldWrap){
                var cond = null;
                try { cond = JSON.parse(fieldWrap.getAttribute('data-fone-conditional') || '{}'); } catch(e) {}
                if (!cond || !cond.field) return;
                var match = conditionalMatch(cond);
                var show = (cond.action === 'hide') ? !match : match;
                fieldWrap.classList.toggle('fone-conditional-hidden', !show);
                fieldWrap.setAttribute('aria-hidden', show ? 'false' : 'true');
                fieldWrap.querySelectorAll('input,select,textarea,button').forEach(function(el){
                    if (!show) {
                        el.setAttribute('data-fone-disabled-by-condition', '1');
                        el.disabled = true;
                    } else if (el.getAttribute('data-fone-disabled-by-condition') === '1') {
                        el.disabled = false;
                        el.removeAttribute('data-fone-disabled-by-condition');
                    }
                });
            });
        }

        if (form) {
            form.addEventListener('input', applyConditionals);
            form.addEventListener('change', applyConditionals);
            applyConditionals();
        }

        /* ---- CHARACTER COUNTER -------------------------------- */
        wrap.querySelectorAll('textarea[data-maxchars]').forEach(function (ta) {
            var maxChars = parseInt(ta.dataset.maxchars, 10);
            if (!maxChars) return;
            var counter = wrap.querySelector('.fone-char-count[data-for="' + ta.id + '"]');
            if (!counter) return;

            function update() {
                var len = ta.value.length;
                counter.textContent = len + ' / ' + maxChars;
                counter.classList.toggle('is-near-limit', len > maxChars * 0.85);
                counter.classList.toggle('is-over-limit', len >= maxChars);
            }
            ta.addEventListener('input', update);
            update();
        });

        /* ---- FILE GENERICO: controllo peso client-side ---- */
        wrap.querySelectorAll('input[data-fone-file="1"]').forEach(function (inp) {
            inp.addEventListener('change', function () {
                var file = inp.files && inp.files[0];
                if (!file) return;
                var maxSizeMb = parseInt(inp.dataset.maxSize, 10) || 10;
                if (file.size > maxSizeMb * 1024 * 1024) {
                    alert('File troppo grande. Massimo ' + maxSizeMb + ' MB.');
                    inp.value = '';
                }
            });
        });

        /* ---- RANGE: output valore live ---- */
        wrap.querySelectorAll('input[data-fone-range="1"]').forEach(function (inp) {
            var out = wrap.querySelector('output[for="' + inp.id + '"]');
            function updateRange(){ if (out) out.textContent = inp.value; }
            inp.addEventListener('input', updateRange);
            updateRange();
        });

        /* ---- PHONE / WHATSAPP: accetta solo numeri e spazi ---- */
        wrap.querySelectorAll('input[data-fone-numeric="1"]').forEach(function (inp) {
            inp.addEventListener('input', function () {
                var cleaned = this.value.replace(/[^0-9 ]/g, '');
                if (cleaned !== this.value) this.value = cleaned;
            });
            inp.addEventListener('paste', function (e) {
                e.preventDefault();
                var text = (e.clipboardData || window.clipboardData).getData('text');
                var cleaned = (text || '').replace(/[^0-9 ]/g, '').trim();
                // Inserisci il testo pulito nella posizione corrente
                var start = this.selectionStart || 0;
                var end   = this.selectionEnd   || 0;
                this.value = this.value.slice(0, start) + cleaned + this.value.slice(end);
                var pos = start + cleaned.length;
                this.setSelectionRange(pos, pos);
            });
        });

        /* ---- PASSWORD TOGGLE: mostra/nasconde password ----- */
        wrap.querySelectorAll('[data-fone-password-toggle]').forEach(function (btn) {
            var targetId = btn.getAttribute('aria-controls');
            var input = null;

            if (targetId && window.CSS && CSS.escape) {
                input = wrap.querySelector('#' + CSS.escape(targetId));
            }
            if (!input) {
                var holder = btn.closest('.fone-password-wrap');
                input = holder ? holder.querySelector('input[type="password"], input[type="text"]') : null;
            }
            if (!input) return;

            btn.addEventListener('click', function () {
                var show = input.type === 'password';
                var start = null;
                var end = null;

                try {
                    start = input.selectionStart;
                    end = input.selectionEnd;
                } catch (e) {}

                input.type = show ? 'text' : 'password';
                btn.setAttribute('aria-pressed', show ? 'true' : 'false');
                btn.setAttribute('aria-label', show ? 'Nascondi password' : 'Mostra password');

                var icon = btn.querySelector('.fone-password-eye');
                if (icon) icon.innerHTML = show ? '<i class="fa-solid fa-eye-slash" aria-hidden="true"></i>' : '<i class="fa-solid fa-eye" aria-hidden="true"></i>';

                try {
                    input.focus({ preventScroll: true });
                    if (start !== null && end !== null) {
                        input.setSelectionRange(start, end);
                    }
                } catch (e) {
                    input.focus();
                }
            });
        });

        /* ---- TRASFORMAZIONI LIVE sui campi testo ----- */
        wrap.querySelectorAll('input[data-fone-lowercase="1"]').forEach(function(inp){
            inp.addEventListener('input', function(){
                var caret = this.selectionStart;
                this.value = this.value.toLowerCase();
                try { this.setSelectionRange(caret, caret); } catch(e){}
            });
        });
        wrap.querySelectorAll('input[data-fone-capitalize="1"]').forEach(function(inp){
            inp.addEventListener('blur', function(){
                this.value = this.value.replace(/\b\p{L}/gu, function(m){ return m.toUpperCase(); });
            });
        });
        wrap.querySelectorAll('input[data-fone-letters-only="1"]').forEach(function(inp){
            inp.addEventListener('input', function(){
                var cleaned = this.value.replace(/[^\p{L}\s'’\-]/gu, '');
                if (cleaned !== this.value) this.value = cleaned;
            });
        });
        wrap.querySelectorAll('input[data-fone-alphanum="1"]').forEach(function(inp){
            inp.addEventListener('input', function(){
                var cleaned = this.value.replace(/[^\p{L}0-9\s]/gu, '');
                if (cleaned !== this.value) this.value = cleaned;
            });
        });
        wrap.querySelectorAll('input[data-fone-no-spaces="1"]').forEach(function(inp){
            inp.addEventListener('input', function(){
                var cleaned = this.value.replace(/\s+/g, '');
                if (cleaned !== this.value) this.value = cleaned;
            });
        });

        /* ---- PASSWORD STRENGTH METER ----- */
        wrap.querySelectorAll('.fone-pw-strength').forEach(function(meter){
            var targetId = meter.getAttribute('data-fone-pw-for');
            if (!targetId) return;
            var input = wrap.querySelector('#' + CSS.escape(targetId));
            if (!input) return;
            var fill  = meter.querySelector('.fone-pw-strength-fill');
            var label = meter.querySelector('.fone-pw-strength-label');

            function score(pw){
                var s = 0;
                if (!pw) return 0;
                if (pw.length >= 8)  s++;
                if (pw.length >= 12) s++;
                if (/[A-Z]/.test(pw)) s++;
                if (/[0-9]/.test(pw)) s++;
                if (/[^A-Za-z0-9]/.test(pw)) s++;
                return Math.min(s, 4);
            }
            var colors = ['#dc2626','#f97316','#eab308','#22c55e','#16a34a'];
            var labels = ['Troppo debole','Debole','Media','Forte','Fortissima'];
            input.addEventListener('input', function(){
                var s = score(this.value);
                var pct = (s/4) * 100;
                fill.style.width = pct + '%';
                fill.style.background = colors[s];
                label.textContent = this.value ? labels[s] : '—';
                label.style.color = colors[s];
            });
        });

        /* ---- AVATAR FIELD: crop/zoom + anteprima foto --------- */
        wrap.querySelectorAll('.fone-avatar-slot').forEach(function (slot) {
            var inputs = slot.querySelectorAll('.fone-avatar-input');
            var preview = slot.querySelector('.fone-avatar-preview');
            if (!inputs.length || !preview) return;

            // Input nascosto dove finisce il file CROPPATO (base64 → blob → file)
            var fieldId = slot.getAttribute('data-fone-avatar');

            inputs.forEach(function (input) {
                input.addEventListener('change', function () {
                    var file = input.files && input.files[0];
                    if (!file) return;

                    // Check size
                    var maxSizeMb = parseInt(input.dataset.maxSize, 10) || 12;
                    if (file.size > maxSizeMb * 1024 * 1024) {
                        alert('File troppo grande. Massimo ' + maxSizeMb + ' MB.');
                        input.value = '';
                        return;
                    }

                    // Apri modal di crop
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        openCropModal(e.target.result, file, input, preview, slot);
                    };
                    reader.readAsDataURL(file);
                });
            });
        });

        function openCropModal(dataUrl, originalFile, originalInput, previewEl, slot) {
            // Se Cropper.js non è caricato, fallback: anteprima senza crop
            if (typeof Cropper === 'undefined') {
                previewEl.innerHTML = '<img src="' + dataUrl + '" alt="Anteprima">';
                return;
            }

            // Costruisco il modal
            var overlay = document.createElement('div');
            overlay.className = 'fone-crop-overlay';
            overlay.innerHTML =
                '<div class="fone-crop-modal">' +
                    '<div class="fone-crop-head">' +
                        '<h3>Ritaglia la foto</h3>' +
                        '<button type="button" class="fone-crop-close" aria-label="Chiudi"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>' +
                    '</div>' +
                    '<div class="fone-crop-body">' +
                        '<div class="fone-crop-stage">' +
                            '<img class="fone-crop-img" src="' + dataUrl + '" alt="">' +
                        '</div>' +
                        '<div class="fone-crop-hint">Sposta e zooma con le maniglie. Usa la rotellina del mouse o le dita per lo zoom.</div>' +
                    '</div>' +
                    '<div class="fone-crop-foot">' +
                        '<button type="button" class="fone-crop-zoom-out" title="Zoom -">−</button>' +
                        '<button type="button" class="fone-crop-zoom-in" title="Zoom +">+</button>' +
                        '<button type="button" class="fone-crop-rotate" title="Ruota">↻</button>' +
                        '<button type="button" class="fone-crop-reset" title="Reimposta">Reset</button>' +
                        '<div style="flex:1"></div>' +
                        '<button type="button" class="fone-crop-cancel">Annulla</button>' +
                        '<button type="button" class="fone-crop-confirm">Applica</button>' +
                    '</div>' +
                '</div>';

            document.body.appendChild(overlay);

            var img = overlay.querySelector('.fone-crop-img');
            var cropper = new Cropper(img, {
                aspectRatio: 1,           // quadrato (verrà poi ritagliato a cerchio)
                viewMode: 1,
                dragMode: 'move',
                autoCropArea: 0.9,
                responsive: true,
                restore: false,
                guides: true,
                center: true,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: true,
                toggleDragModeOnDblclick: false,
                background: true
            });

            function closeModal() {
                try { cropper.destroy(); } catch(e) {}
                if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
            }

            overlay.querySelector('.fone-crop-close').addEventListener('click', closeModal);
            overlay.querySelector('.fone-crop-cancel').addEventListener('click', function(){
                // Ripulisco l'input originale se l'utente annulla
                originalInput.value = '';
                closeModal();
            });
            overlay.querySelector('.fone-crop-zoom-in').addEventListener('click', function(){ cropper.zoom(0.1); });
            overlay.querySelector('.fone-crop-zoom-out').addEventListener('click', function(){ cropper.zoom(-0.1); });
            overlay.querySelector('.fone-crop-rotate').addEventListener('click', function(){ cropper.rotate(90); });
            overlay.querySelector('.fone-crop-reset').addEventListener('click', function(){ cropper.reset(); });

            overlay.querySelector('.fone-crop-confirm').addEventListener('click', function(){
                var canvas = cropper.getCroppedCanvas({
                    width: 600,
                    height: 600,
                    imageSmoothingEnabled: true,
                    imageSmoothingQuality: 'high'
                });
                if (!canvas) { closeModal(); return; }

                canvas.toBlob(function(blob){
                    if (!blob) { closeModal(); return; }

                    // Costruisco un nuovo File dal blob croppato
                    var ext = (originalFile.name.match(/\.(\w+)$/) || [])[1] || 'jpg';
                    var newName = 'avatar-cropped-' + Date.now() + '.' + ext;
                    var newFile;
                    try {
                        newFile = new File([blob], newName, { type: blob.type, lastModified: Date.now() });
                    } catch(e) {
                        // Fallback per browser vecchi: uso Blob direttamente
                        newFile = blob;
                        newFile.name = newName;
                    }

                    // Sostituisco il file nell'input originale usando DataTransfer
                    try {
                        var dt = new DataTransfer();
                        dt.items.add(newFile);
                        originalInput.files = dt.files;
                    } catch(e) {
                        console.warn('DataTransfer non supportato, upload dell\'originale');
                    }

                    // Aggiorno anteprima
                    var reader2 = new FileReader();
                    reader2.onload = function(ev){
                        previewEl.innerHTML = '<img src="' + ev.target.result + '" alt="Anteprima">';
                    };
                    reader2.readAsDataURL(blob);

                    closeModal();
                }, originalFile.type && originalFile.type.indexOf('image/') === 0 ? originalFile.type : 'image/jpeg', 0.92);
            });
        }

        /* ---- STEALTH REVEAL ----------------------------------- */
        function revealStep(stepCard) {
            stepCard.classList.remove('is-hidden');
            stepCard.removeAttribute('aria-hidden');
            currentStep = parseInt(stepCard.dataset.foneStep || currentStep || '1', 10) || currentStep || 1;
            trackEvent('step', currentStep);
            writeResumeData();
            applyConditionals();

            // Applica classe animazione
            var animClass = 'fone-reveal-' + revealMode;
            stepCard.classList.add(animClass);

            setTimeout(function () {
                var first = stepCard.querySelector('input:not([type="hidden"]):not([type="file"]), select, textarea');
                if (first) {
                    try { first.focus({ preventScroll: true }); } catch(e) { first.focus(); }
                }

                // Scroll: lascia lo step successivo visibile sotto l'inizio viewport.
                // Offset corretto: il card viene posizionato circa 40px più in basso,
                // evitando che la parte alta venga coperta/tagliata.
                try {
                    var rect = stepCard.getBoundingClientRect();
                    var targetY = window.scrollY + rect.top - 140;
                    window.scrollTo({ top: Math.max(0, targetY), behavior: 'smooth' });
                } catch (err) {
                    stepCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }, 80);
        }

        /* ---- VALIDATE STEP ------------------------------------ */
        function validateStep(stepCard) {
            var inputs = stepCard.querySelectorAll(
                'input[required]:not([type="hidden"]), select[required], textarea[required]'
            );
            var valid = true;

            // Clear previous JS errors
            stepCard.querySelectorAll('.fone-field-error-js').forEach(function (e) { e.remove(); });
            stepCard.querySelectorAll('.has-error-js').forEach(function (el) { el.classList.remove('has-error-js'); });

            inputs.forEach(function (inp) {
                if (inp.disabled) return;
                var fieldWrap = inp.closest('.fone-field');
                if (fieldWrap && fieldWrap.classList.contains('fone-conditional-hidden')) return;
                var fieldValid = true;
                var errorMsg = 'Campo obbligatorio.';

                // Email check
                if (inp.type === 'email' && inp.value.trim() !== '') {
                    var emailRx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRx.test(inp.value.trim())) {
                        fieldValid = false;
                        errorMsg = 'Inserisci un\'email valida.';
                    }
                }
                // URL check
                else if (inp.type === 'url' && inp.value.trim() !== '') {
                    try { new URL(inp.value.trim()); }
                    catch(e) { fieldValid = false; errorMsg = 'Inserisci un URL valido.'; }
                }
                // Radio / Checkbox
                else if (inp.type === 'radio' || inp.type === 'checkbox') {
                    var name = inp.name.replace('[]', '');
                    var checked = stepCard.querySelectorAll('input[name="' + name + '"]:checked, input[name="' + name + '[]"]:checked');
                    if (checked.length === 0) fieldValid = false;
                }
                // File upload (avatar)
                else if (inp.type === 'file') {
                    var hasFile = inp.files && inp.files.length > 0;
                    // Check se c'è il gemello _capture
                    if (!hasFile) {
                        var captureSibling = stepCard.querySelector('input[name="' + inp.name + '_capture"]');
                        if (captureSibling && captureSibling.files && captureSibling.files.length > 0) {
                            hasFile = true;
                        }
                    }
                    if (!hasFile) fieldValid = false;
                }
                // Default: non vuoto
                else {
                    if (inp.value.trim() === '') fieldValid = false;
                }

                if (!fieldValid && fieldWrap && !fieldWrap.querySelector('.fone-field-error-js')) {
                    fieldWrap.classList.add('has-error-js');
                    var err = document.createElement('span');
                    err.className = 'fone-field-error fone-field-error-js';
                    err.setAttribute('role', 'alert');
                    err.textContent = errorMsg;
                    fieldWrap.appendChild(err);
                    inp.setAttribute('aria-invalid', 'true');
                    valid = false;
                }
            });

            // Password match check (se esistono entrambi i campi)
            var pwFields    = stepCard.querySelectorAll('.fone-slug-password input[type="password"]');
            var pwConfFields= stepCard.querySelectorAll('.fone-slug-password_confirm input[type="password"]');
            if (pwFields.length && pwConfFields.length) {
                var pw    = pwFields[0].value;
                var pwCon = pwConfFields[0].value;
                if (pw && pwCon && pw !== pwCon) {
                    var confWrap = pwConfFields[0].closest('.fone-field');
                    if (confWrap && !confWrap.querySelector('.fone-field-error-js')) {
                        confWrap.classList.add('has-error-js');
                        var e2 = document.createElement('span');
                        e2.className = 'fone-field-error fone-field-error-js';
                        e2.textContent = 'Le password non coincidono.';
                        confWrap.appendChild(e2);
                        valid = false;
                    }
                }
            }

            return valid;
        }

        /* ---- CONTINUE BUTTONS --------------------------------- */
        continueBtns.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var currentCard = btn.closest('.fone-step-card');
                if (!currentCard) return;

                if (!validateStep(currentCard)) {
                    var firstErr = currentCard.querySelector('.has-error-js input, .has-error-js select, .has-error-js textarea');
                    if (firstErr) firstErr.focus();
                    return;
                }

                // Trova il prossimo step nascosto
                var nextCard = null;
                for (var i = 0; i < stepCards.length; i++) {
                    if (stepCards[i].classList.contains('is-hidden')) {
                        nextCard = stepCards[i];
                        break;
                    }
                }

                if (nextCard) {
                    revealStep(nextCard);
                    btn.disabled = true;
                    btn.classList.add('is-done');
                }
            });
        });

        /* ---- SUBMIT STATE ------------------------------------- */
        if (form && submitBtn) {
            // BYPASS PER FORM LOGIN: i form di login (sia [fone_login] sia
            // builder con flag is_login) devono fare submit POST nativo per
            // permettere al server di settare i cookie di autenticazione.
            // Il JS di intercettazione causa un loop "Invio…" perché
            // requestSubmit/form.submit dopo preventDefault non sempre
            // si comporta come ci si aspetta su tutti i temi/Elementor.
            var isLoginForm = !!(
                form.querySelector('input[name="fone_login_submit"]') ||
                wrap.classList.contains('fone-login-wrap') ||
                wrap.dataset.foneIsLogin === '1' ||
                form.dataset.foneIsLogin === '1'
            );

            // FALLBACK: detection per contenuto. Un form di login tipicamente
            // ha 1 sola password e 1 sola email/text di "username", più al
            // massimo un checkbox "remember" e i campi nascosti del nonce/honeypot.
            // Se il form ha 0 textarea, 0 file, 0 select, 0 radio, e 1 sola
            // password, lo trattiamo come login.
            if (!isLoginForm) {
                var passwordInputs = form.querySelectorAll('input[type="password"]');
                var fileInputs     = form.querySelectorAll('input[type="file"]');
                var textareas      = form.querySelectorAll('textarea');
                var selects        = form.querySelectorAll('select');
                var radios         = form.querySelectorAll('input[type="radio"]');
                if (passwordInputs.length === 1 && fileInputs.length === 0 &&
                    textareas.length === 0 && selects.length === 0 && radios.length === 0) {
                    // Conto i campi text/email visibili (escludo nascosti)
                    var visibleTextish = 0;
                    form.querySelectorAll('input[type="text"], input[type="email"]').forEach(function(i){
                        if (i.offsetParent !== null) visibleTextish++;
                    });
                    if (visibleTextish <= 2) {
                        isLoginForm = true;
                    }
                }
            }

            if (isLoginForm) {
                // Solo cambio testo bottone, niente preventDefault, niente AJAX.
                form.addEventListener('submit', function () {
                    submitBtn.disabled = true;
                    submitBtn.classList.add('is-loading');
                    var loadText = submitBtn.dataset.loading || 'Accesso…';
                    submitBtn.textContent = loadText;
                    // Lascia che il browser faccia il submit nativo. Niente preventDefault.
                });
                return; // esci dalla initForm: nessun altro handler complica le cose
            }

            form.addEventListener('submit', function (e) {
                if (form.dataset.foneSubmitting === '1') {
                    return;
                }

                trackStartOnce();
                applyConditionals();
                writeResumeData();
                // Validazione last step prima del submit
                var visibleSteps = stepCards.filter(function (c) { return !c.classList.contains('is-hidden'); });
                var lastStep = visibleSteps[visibleSteps.length - 1];
                if (lastStep && !validateStep(lastStep)) {
                    e.preventDefault();
                    var firstErr = lastStep.querySelector('.has-error-js input, .has-error-js select, .has-error-js textarea');
                    if (firstErr) firstErr.focus();
                    return;
                }

                e.preventDefault();
                submitBtn.disabled = true;
                submitBtn.classList.add('is-loading');
                var loadText = submitBtn.dataset.loading || 'Invio…';
                submitBtn.textContent = loadText;

                refreshSecurityToken().then(function(){
                    form.dataset.foneSubmitting = '1';
                    if (form.requestSubmit) {
                        // requestSubmit richiamerebbe l'evento submit: uso il flag sopra.
                        form.requestSubmit();
                    } else {
                        HTMLFormElement.prototype.submit.call(form);
                    }
                });
            });
        }
    }
});

/* Account avatar change — show preview on file select */
document.addEventListener('change', function(e) {
    var inp = e.target;
    if (!inp || inp.type !== 'file' || !inp.dataset.preview) return;
    var previewId = inp.dataset.preview;
    var preview = document.getElementById(previewId);
    if (!preview) return;
    var file = inp.files && inp.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(ev) { preview.src = ev.target.result; };
    reader.readAsDataURL(file);
});
