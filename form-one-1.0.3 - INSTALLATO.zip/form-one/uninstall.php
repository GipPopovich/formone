<?php
/**
 * Form One — Uninstall handler
 * Rimuove tutte le tabelle e opzioni create dal plugin.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

// Drop tabelle custom
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}fone_forms");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}fone_entries");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}fone_insights_events");

// Opzioni da eliminare
$options = [
    'fone_form_schema', 'fone_settings', 'fone_entries', 'fone_custom_css',
    'fone_license', 'fone_db_version', 'fone_entries_migrated', 'fone_mgf_migrated',
    'fone_multiforms_migrated', 'fone_step_layouts', 'fone_elementor_managed_forms',
];
foreach ($options as $opt) {
    delete_option($opt);
    delete_site_option($opt);
}

// User meta
$wpdb->delete($wpdb->usermeta, ['meta_key' => 'fone_license_notice_snoozed'], ['%s']);

// Transient
$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_fone_%' OR option_name LIKE '_transient_timeout_fone_%'"
);
