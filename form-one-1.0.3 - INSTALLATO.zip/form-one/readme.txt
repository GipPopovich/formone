=== Form One ===
Contributors: luigicoppola
Tags: form builder, multi-step forms, lead generation, conditional logic, elementor
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.3
License: GPLv2 or later

Form One trasforma i form WordPress pesanti in percorsi guidati, più semplici da completare.

== Descrizione ==

Form One è un plugin WordPress gratuito per creare form multi-step guidati, pensati per ridurre l'attrito e aumentare il completamento dei moduli.

Puoi usarlo per contatti, preventivi, lead generation, iscrizioni, sondaggi, richieste commerciali e registrazione utenti WordPress.

La promessa è semplice: invece di mostrare tutto il form in una volta, Form One accompagna l'utente passo dopo passo.

**Funzionalità principali:**

* **Setup Wizard** — crea il primo form in pochi passaggi guidati.
* **Multi-step guidato** — dividi il modulo in passaggi più leggeri e ordinati.
* **Builder visuale drag & drop** — riordina campi e step senza scrivere codice.
* **120+ campi preconfigurati** — contatti, profilo, business, survey, upload, consenso, rating, NPS e molto altro.
* **Conditional Logic Light** — mostra o nascondi campi in base alle risposte dell'utente.
* **Conversion Insights** — views, starts, completamenti e step raggiunti con eventi tecnici anonimi.
* **Resume Later** — salva i dati nel browser dell'utente e ripristina il form senza inviare dati al server.
* **First Yes Mode** — rende il primo step più leggero e più facile da iniziare.
* **Microcopy Assistant** — suggerimenti locali per label, placeholder e help text più chiari.
* **Registrazione utenti WordPress** — crea account WordPress tramite form dedicati.
* **Area personale** — shortcode account con profilo e avatar.
* **Foto profilo** — upload avatar con crop locale, senza CDN obbligatorie.
* **Email HTML** — notifiche amministratore e utente con design pulito.
* **Webhook** — invia ogni submission a Make, Zapier, n8n o endpoint personalizzati.
* **WhatsApp after submit** — mostra un link WhatsApp dopo l'invio, quando configurato.
* **Lead Action Panel** — stato lead, note e azioni dalla pagina Invii.
* **Import / Export JSON** — sposta form e template tra siti.
* **Export CSV** — esporta invii con BOM UTF-8 compatibile con Excel.
* **Widget Elementor core** — inserisci un form esistente in Elementor in modo semplice, stabile e leggero.
* **Traduzioni IT/EN** — file lingua inclusi e pronti per Loco Translate.

== Installazione ==

1. Carica la cartella `form-one` in `/wp-content/plugins/`
2. Attiva il plugin dal menu "Plugin" di WordPress
3. Segui il Setup Wizard oppure vai su **Form One → Tutti i Form**
4. Inserisci il form in pagina con lo shortcode `[form_one id="1"]` oppure con il widget Elementor

== Screenshots ==

1. Setup Wizard iniziale con scelta dell'obiettivo del form
2. Builder visuale drag & drop con libreria campi
3. Anteprima live responsive durante la modifica
4. Form multi-step frontend con progressione guidata
5. Conversion Insights con completamenti e step raggiunti
6. Conditional Logic Light nel builder
7. Widget Elementor core per inserire un form esistente
8. Email HTML ricevuta dopo un invio
9. Form di registrazione utente con area personale

== Frequently Asked Questions ==

= Form One è solo un plugin di registrazione utenti? =

No. La registrazione utenti è una funzione importante, ma Form One nasce soprattutto per creare form WordPress guidati e più facili da completare: contatti, preventivi, lead generation, iscrizioni, richieste commerciali e molto altro.

= Form One funziona con Elementor? =

Sì. Puoi usare lo shortcode `[form_one id="1"]` oppure il widget Elementor core "Form One" per inserire un form già creato nel builder.

= Cosa fa il Resume Later? =

Salva nel browser dell'utente i campi compilati, esclusi password, file e consensi privacy. Se l'utente chiude la pagina e torna, ritrova il form parzialmente compilato. I dati restano nel suo browser e non vengono inviati al server.

= I dati di Conversion Insights sono GDPR-friendly? =

Gli Insights registrano solo eventi tecnici anonimi: vista, inizio, step raggiunto e completamento. Non vengono salvati IP, user agent o dati personali del form. Gli eventi più vecchi vengono ripuliti automaticamente.

= Form One carica librerie esterne da CDN? =

No. Il crop avatar usa un componente locale incluso nel plugin. Questo riduce dipendenze esterne obbligatorie e rende il plugin più pulito per siti in produzione.

= Posso esportare gli invii ricevuti? =

Sì. Nella pagina Invii c'è il pulsante "Esporta CSV". Il file usa BOM UTF-8 per essere più leggibile anche in Excel.

= Posso integrare Form One con Make / Zapier / n8n? =

Sì. Puoi configurare un Webhook URL globale o per singolo form. Ad ogni invio Form One invia una POST JSON con i dati del form al tuo endpoint.

= Come faccio a tradurre il plugin in altre lingue? =

Il plugin include i file `form-one.pot`, `form-one-it_IT.po` e `form-one-en_US.po` nella cartella `languages/`. Puoi usare Poedit o Loco Translate.

== Changelog ==

= 1.0.3 =
* Nuovo pannello dedicato Form One → Form di Registrazione: stessa filosofia del pannello Login, con personalizzazione di titolo, sottotitolo, colori, bordi, microcopy, redirect, ruolo predefinito, autologin, email di benvenuto, e anteprima live.
* Nuovo shortcode [fone_registration]: renderizza automaticamente il form di registrazione attivo applicando le impostazioni del pannello.
* Pulsante "Crea form di registrazione preimpostato" se l'utente non ne ha ancora uno: crea un form 3 step (dati, credenziali, privacy) usando il template registrazione-utenti.
* Risolto: dopo registrazione + autologin il form mostrava "Sei già loggato" invece del messaggio di benvenuto. Il check ora salta correttamente quando il submit è appena stato completato (parametro fone_done).
* Risolto: il redirect post-submit fallback su widget/homepage che ritornano permalink falsy. Aggiunto helper fone_current_url() con cascata permalink → referer → REQUEST_URI → home.
* Risolto: redirect post-login più robusto, stesso helper riutilizzato nel flusso login form builder.
* Pulizia: id univoci tra modalità builder modern/classic per evitare conflitti DOM teorici.

= 1.0.2 =
* Hotfix mittente email per registrazione utenti: la mail di benvenuto WordPress era l'unica che sfuggiva al branding "Form One" perché non passava dal wrapper blindato. Adesso anche quella usa i 3 strati di protezione (header esplicito + filtri WP + hook phpmailer_init) con priorità PHP_INT_MAX. Il mittente è "Form One" anche con plugin SMTP attivi.
* Upload file più capienti: il default massimo passa da 10MB a 20MB e la whitelist MIME è stata estesa per accettare anche video (mp4, webm, mov, avi, mkv), audio (mp3, wav, ogg, m4a), archivi (zip), CSV, RTF, OpenDocument (odt/ods/odp) e immagini avanzate (avif, bmp, tiff, heic). I formati pericolosi (svg, html, js, php, ecc.) restano bloccati.
* Risolto: il file caricato in registrazione ora compare correttamente nell'area personale come link cliccabile al file con il nome originale, e l'utente può sostituirlo caricandone uno nuovo.
* Risolto: l'attachment_id dei campi file viene ora salvato come intero negli user meta (prima veniva trasformato in stringa rompendo wp_get_attachment_url() in alcuni casi).
* Aggiornato il default del campo "file" nella libreria builder per riflettere la nuova whitelist estesa e il nuovo limite di 20MB.

= 1.0.1 =
* Hotfix mittente email: il nome mittente è di nuovo bloccato a "Form One" anche quando sul sito sono attivi plugin SMTP (WP Mail SMTP, FluentSMTP, Post SMTP, ecc.) che a volte sovrascrivevano il mittente con il nome del sito. Triplo strato di protezione: header esplicito + filtri WP a priorità massima + hook phpmailer_init che blinda il mittente subito prima dell'invio reale via SMTP.
* Whitelist mittente: se un filtro esterno ritorna un valore vuoto o sospetto, il sistema forza il fallback "Form One" per garantire coerenza del branding.

= 1.0.0 =
Prima release pubblica pulita di Form One, firmata Luigi Coppola.

* Builder visuale drag & drop per form WordPress guidati e multi-step.
* Libreria campi ampia, con campi standard, consenso, upload file, avatar, rating, NPS e campo HTML Admin.
* Icone professionali dei campi nel Builder tramite Font Awesome Free locale, senza CDN obbligatorie.
* Controlli larghezza campo nel builder: 1/3, 1/2, 2/3 e full, applicabili anche dal canvas.
* Frontend con griglia responsive e fallback sicuro del pulsante Invia.
* Registrazione utenti WordPress tramite form dedicati.
* Redirect dopo submit e registrazione opzionale: il comportamento standard mostra il messaggio di successo del form.
* Area personale con shortcode, profilo utente, logout e avatar con crop locale.
* Form di login dedicato tramite shortcode [fone_login] e pannello impostazioni.
* Nuova interfaccia Builder moderna opzionale: barra destra abolita, impostazioni campo nella colonna sinistra e pulsante per tornare ai campi.
* Email HTML admin/utente con supporto agli allegati caricati dai campi file.
* Conversion Insights con eventi tecnici anonimi e retention configurabile.
* Resume Later, First Yes Mode, Microcopy Assistant, conditional logic light, webhook, WhatsApp after submit, import/export JSON ed export CSV.
* Setup Wizard, widget Elementor core, traduzioni IT/EN, pagina Aiuto e strumenti admin.
* Sicurezza base: nonce, sanitizzazione/escape, prepared SQL, honeypot, rate limit, controlli upload e ruoli utente protetti.


== Hook ==

* `fone_after_submission` — action dopo un submit valido. Parametri: `$values` (array), `$schema` (array), `$form_id` (int)
* `fone_support_email` — filtra l'email mostrata nella pagina Aiuto.
* `fone_docs_url` — filtra l'URL documentazione.
* `fone_should_enqueue_front_assets` — forza il caricamento asset frontend quando serve.
* `fone_insights_retention_days` — modifica i giorni di retention degli Insights.
