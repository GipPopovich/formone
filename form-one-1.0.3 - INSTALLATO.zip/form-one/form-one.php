<?php
/*
Plugin Name: Form One
Plugin URI:  https://neetly.eu/formone/
Description: Crea form WordPress guidati, multi-step e più facili da completare. Builder visuale, setup wizard, Elementor, conditional logic, insights e registrazione utenti.
Version:     1.0.3
Author:      Luigi Coppola
Author URI:  https://neetly.eu/formone/
Text Domain: form-one
Domain Path: /languages
Requires at least: 6.0
Requires PHP: 7.4
License:     GPLv2 or later
*/

if (!defined('ABSPATH')) {
    exit;
}

/* ===============================================================
   COSTANTI
=============================================================== */

define('FONE_VERSION',    '1.0.3');
define('FONE_DB_VERSION', '2.2.0');
define('FONE_FILE',       __FILE__);
define('FONE_DIR',        plugin_dir_path(__FILE__));
define('FONE_URL',        plugin_dir_url(__FILE__));
define('FONE_BASENAME',   plugin_basename(__FILE__));

/* ===============================================================
   INCLUDES
=============================================================== */

require_once FONE_DIR . 'includes/fone-i18n.php';
require_once FONE_DIR . 'includes/fone-settings.php';
require_once FONE_DIR . 'includes/fone-core-tools.php';
require_once FONE_DIR . 'includes/fone-db.php';
require_once FONE_DIR . 'includes/fone-license.php';
require_once FONE_DIR . 'includes/fone-field-library.php';
require_once FONE_DIR . 'includes/fone-avatar.php';
require_once FONE_DIR . 'includes/fone-builder.php';
require_once FONE_DIR . 'includes/fone-render.php';
require_once FONE_DIR . 'includes/fone-submit.php';
require_once FONE_DIR . 'includes/fone-entries.php';
require_once FONE_DIR . 'includes/fone-insights.php';
require_once FONE_DIR . 'includes/fone-account.php';
require_once FONE_DIR . 'includes/fone-login.php';
require_once FONE_DIR . 'includes/fone-registration.php';
require_once FONE_DIR . 'includes/fone-wizard.php';

add_action('plugins_loaded', function () {
    if (did_action('elementor/loaded') || class_exists('\Elementor\Plugin')) {
        require_once FONE_DIR . 'includes/fone-elementor.php';
    }
}, 20);


/* ===============================================================
   BACKEND PRO REMINDER
=============================================================== */

add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) return;
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    if (strpos($page, 'fone-') !== 0) return;
    if (function_exists('fone_is_premium') && fone_is_premium()) return;
    if ($page === 'fone-settings' && isset($_GET['tab']) && sanitize_key(wp_unslash($_GET['tab'])) === 'licenza') return;
    ?>
    <div class="notice notice-info fone-pro-reminder-notice">
        <p>
            <strong>Form One PRO</strong> — la versione gratuita resta utilizzabile, ma alcune funzioni avanzate sono bloccate. 
            <a href="<?php echo esc_url(admin_url('admin.php?page=fone-settings&tab=licenza')); ?>">Inserisci il seriale o attiva la versione Pro</a>.
        </p>
    </div>
    <?php
}, 30);

/* ===============================================================
   LOAD TEXTDOMAIN
=============================================================== */

add_action('plugins_loaded', function () {
    if (function_exists('fone_migrate_from_mgf')) {
        fone_migrate_from_mgf();
    }
    load_plugin_textdomain('form-one', false, dirname(FONE_BASENAME) . '/languages');
});

/* ===============================================================
   ACTIVATION
=============================================================== */

function fone_activate() {
    fone_create_table();
    fone_migrate_from_mgf();

    // Crea il form di default se non ci sono ancora form
    global $wpdb;
    $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . fone_table_forms());
    if ($count === 0) {
        $default_form_id = fone_create_form('Form di Registrazione');
        if ($default_form_id && function_exists('fone_get_form') && function_exists('fone_save_form')) {
            $default_form = fone_get_form((int) $default_form_id);
            $settings = is_array($default_form['settings'] ?? null) ? $default_form['settings'] : fone_default_settings();
            $settings['enable_registration'] = 1;
            $settings['enable_login'] = 0;
            fone_save_form((int) $default_form_id, [
                'settings' => $settings,
                'is_registration' => 1,
                'is_login' => 0,
            ]);
        }
    }

    // Crea la pagina account /account-form-one/ sul dominio corrente
    fone_ensure_account_page();

    // Auto-fix URL salvati con vecchio dominio (es. dopo migrazione sito)
    fone_fix_domain_in_settings();

    // Inizializza le impostazioni globali di Form One se mancanti.
    if (function_exists('fone_get_global_settings')) {
        fone_get_global_settings();
    }

    /**
     * Hook interno usato dal Setup Wizard e da eventuali moduli futuri.
     * Nella 1.0.0 era registrato il listener, ma l'hook non veniva eseguito
     * durante l'attivazione: così il redirect automatico al wizard poteva non partire.
     */
    do_action('fone_after_activate');
}
register_activation_hook(__FILE__, 'fone_activate');

if (!function_exists('fone_ensure_account_page')) {
    /**
     * Crea (se non esiste) la pagina "account-form-one" sul dominio corrente.
     * La pagina contiene lo shortcode [fone_account] e si autoreplica su
     * ogni nuovo sito dove il plugin viene installato. NON eredita "neetly"
     * o altri domini precedenti — usa sempre home_url() del sito attuale.
     */
    function fone_ensure_account_page() {
        $slug = 'account-form-one';
        $existing = get_page_by_path($slug);
        if ($existing && $existing->post_status === 'publish') return (int) $existing->ID;

        $page_id = wp_insert_post([
            'post_title'   => 'Area Personale',
            'post_name'    => $slug,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '[fone_account]',
            'post_author'  => get_current_user_id() ?: 1,
        ]);
        return is_wp_error($page_id) ? 0 : (int) $page_id;
    }
}

if (!function_exists('fone_fix_domain_in_settings')) {
    /**
     * Riallinea automaticamente gli URL salvati nelle impostazioni dei form
     * al dominio attuale del sito. Evita che dopo una migrazione/clonazione
     * il plugin punti ancora al vecchio host (es. neetly.eu) invece di
     * usare quello del sito su cui gira ora.
     */
    function fone_fix_domain_in_settings() {
        global $wpdb;
        $current_host = (string) parse_url(home_url(), PHP_URL_HOST);
        if (!$current_host) return;

        $rows = $wpdb->get_results("SELECT id, settings_json FROM " . fone_table_forms(), ARRAY_A);
        if (!is_array($rows)) return;

        foreach ($rows as $row) {
            $settings = json_decode($row['settings_json'] ?? '{}', true);
            if (!is_array($settings)) continue;

            $changed = false;
            foreach (['profile_url', 'registration_redirect'] as $key) {
                if (empty($settings[$key])) continue;
                $url_host = (string) parse_url($settings[$key], PHP_URL_HOST);
                if ($url_host && strcasecmp($url_host, $current_host) !== 0) {
                    // Sostituisco l'host preservando path
                    $path = (string) parse_url($settings[$key], PHP_URL_PATH);
                    $settings[$key] = home_url($path ?: '/account-form-one/');
                    $changed = true;
                }
            }

            if ($changed) {
                $wpdb->update(
                    fone_table_forms(),
                    ['settings_json' => wp_json_encode($settings)],
                    ['id' => (int) $row['id']]
                );
            }
        }
    }
}


if (!function_exists('fone_migrate_redirect_defaults_100')) {
    /**
     * Linea 1.0.0: i vecchi default potevano puntare subito alla
     * pagina account. Per il nuovo comportamento standard disattiviamo solo i
     * redirect che sembrano provenire dal vecchio default, lasciando intatti
     * eventuali URL personalizzati scelti consapevolmente dall'amministratore.
     */
    function fone_migrate_redirect_defaults_100() {
        if (get_option('fone_redirect_defaults_migrated_100')) return;
        if (!function_exists('fone_table_forms')) return;

        global $wpdb;
        $table = fone_table_forms();
        $rows = $wpdb->get_results("SELECT id, settings_json FROM {$table}", ARRAY_A);
        if (!is_array($rows)) return;

        $default_profile = function_exists('fone_default_profile_url') ? fone_default_profile_url() : home_url('/account-form-one/');
        $default_path = (string) parse_url($default_profile, PHP_URL_PATH);

        foreach ($rows as $row) {
            $settings = json_decode($row['settings_json'] ?? '{}', true);
            if (!is_array($settings)) continue;

            $changed = false;
            $reg_redirect = isset($settings['registration_redirect']) ? trim((string) $settings['registration_redirect']) : '';
            $reg_path = $reg_redirect ? (string) parse_url($reg_redirect, PHP_URL_PATH) : '';
            $looks_like_old_default = $reg_redirect === '' || $reg_redirect === $default_profile || ($default_path && $reg_path === $default_path);

            if ($looks_like_old_default && !empty($settings['registration_redirect'])) {
                $settings['registration_redirect'] = '';
                $changed = true;
            }

            if ($looks_like_old_default && !empty($settings['auto_redirect_profile'])) {
                $settings['auto_redirect_profile'] = 0;
                $changed = true;
            }

            if ($changed) {
                $wpdb->update(
                    $table,
                    ['settings_json' => wp_json_encode($settings, JSON_UNESCAPED_UNICODE)],
                    ['id' => (int) $row['id']]
                );
            }
        }

        update_option('fone_redirect_defaults_migrated_100', '1', false);
    }
}
add_action('admin_init', 'fone_migrate_redirect_defaults_100', 6);

if (!function_exists('fone_migrate_from_mgf')) {
    function fone_migrate_from_mgf() {
        if (get_option('fone_mgf_migrated')) return;
        $map = [
            'mgf_form_schema' => 'fone_form_schema',
            'mgf_settings'    => 'fone_settings',
            'mgf_entries'     => 'fone_entries',
            'mgf_custom_css'  => 'fone_custom_css',
            'mgf_license'     => 'fone_license',
        ];
        foreach ($map as $old => $new) {
            $v = get_option($old, null);
            if ($v === null || $v === false) continue;
            if (get_option($new, null) !== null && get_option($new, null) !== false) continue;
            update_option($new, $v);
        }
        update_option('fone_mgf_migrated', '1');
    }
}

/* ===============================================================
   ADMIN MENU
=============================================================== */

function fone_admin_menu() {
    add_menu_page(
        __('Form One', 'form-one'),
        __('Form One', 'form-one'),
        'manage_options',
        'fone-forms',
        'fone_forms_list_page',
        'dashicons-feedback',
        58
    );
    add_submenu_page(
        'fone-forms',
        __('Tutti i Form', 'form-one'),
        __('Tutti i Form', 'form-one'),
        'manage_options',
        'fone-forms',
        'fone_forms_list_page'
    );
    add_submenu_page(
        'fone-forms',
        __('Nuovo Form', 'form-one'),
        __('+ Nuovo Form', 'form-one'),
        'manage_options',
        'fone-new-form',
        'fone_new_form_redirect'
    );
    add_submenu_page(
        'fone-forms',
        __('Invii', 'form-one'),
        __('Invii', 'form-one'),
        'manage_options',
        'fone-entries',
        'fone_entries_page'
    );
    add_submenu_page(
        'fone-forms',
        __('Insights', 'form-one'),
        __('Insights', 'form-one'),
        'manage_options',
        'fone-insights',
        'fone_insights_page'
    );
    add_submenu_page(
        'fone-forms',
        __('Form di Login', 'form-one'),
        __('Form di Login', 'form-one'),
        'manage_options',
        'fone-login-settings',
        'fone_login_settings_page'
    );
    add_submenu_page(
        'fone-forms',
        __('Form di Registrazione', 'form-one'),
        __('Form di Registrazione', 'form-one'),
        'manage_options',
        'fone-registration-settings',
        'fone_registration_settings_page'
    );
    add_submenu_page(
        'fone-forms',
        __('Impostazioni', 'form-one'),
        __('Impostazioni', 'form-one'),
        'manage_options',
        'fone-settings',
        'fone_global_settings_page'
    );
    // Pagina diagnostica legacy: raggiungibile via URL, ora integrata in Impostazioni → Debug.
    add_submenu_page(
        null,
        __('Diagnostica', 'form-one'),
        '',
        'manage_options',
        'fone-diag',
        'fone_diagnostics_page'
    );
    // Aiuto / Supporto
    add_submenu_page(
        'fone-forms',
        __('Aiuto', 'form-one'),
        __('Aiuto', 'form-one'),
        'manage_options',
        'fone-help',
        'fone_help_page'
    );

    // Novità (changelog ultima versione)
    add_submenu_page(
        'fone-forms',
        __('Novità', 'form-one'),
        __('Novità', 'form-one'),
        'manage_options',
        'fone-whats-new',
        'fone_whats_new_page'
    );

    // Builder page (nascosto dal menu, raggiunto via URL)
    add_submenu_page(
        null,
        __('Builder — Form One', 'form-one'),
        '',
        'manage_options',
        'fone-builder',
        'fone_builder_page'
    );
}
add_action('admin_menu', 'fone_admin_menu');

/* ---------------------------------------------------------------
   PAGINA LISTA FORM
--------------------------------------------------------------- */

function fone_forms_list_page() {
    settings_errors('fone_forms_notices');
    $forms = fone_get_all_forms();
    ?>
    <div class="wrap fone-admin-wrap">
        <div class="fone-admin-header">
            <div class="fone-admin-header-left">
                <h1 class="fone-admin-title">Form One</h1>
                <p class="fone-admin-subtitle"><?php esc_html_e('Crea form WordPress guidati, multi-step e più facili da completare.', 'form-one'); ?></p>
            </div>
            <div class="fone-admin-header-right">
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=fone-new-form'), 'fone_create_form')); ?>" class="fone-btn fone-btn-primary">
                    <i class="fa-solid fa-plus" aria-hidden="true"></i> <?php esc_html_e('Crea Nuovo Form', 'form-one'); ?>
                </a>
                <form method="post" enctype="multipart/form-data" style="display:inline-flex;align-items:center;gap:8px;margin-left:8px;">
                    <?php wp_nonce_field('fone_import_form', 'fone_import_nonce'); ?>
                    <input type="file" name="fone_import_file" accept="application/json,.json" style="max-width:190px;">
                    <button type="submit" name="fone_import_form" value="1" class="fone-btn fone-btn-ghost">
                        <i class="fa-solid fa-file-import" aria-hidden="true"></i> <?php esc_html_e('Importa JSON', 'form-one'); ?>
                    </button>
                </form>
            </div>
        </div>

        <?php if (empty($forms)) : ?>
            <div class="fone-forms-empty">
                <div class="fone-forms-empty-icon"><i class="fa-solid fa-clipboard-list" aria-hidden="true"></i></div>
                <p><?php esc_html_e('Nessun form ancora. Crea il tuo primo form di registrazione!', 'form-one'); ?></p>
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=fone-new-form'), 'fone_create_form')); ?>" class="fone-btn fone-btn-primary">
                    <i class="fa-solid fa-plus" aria-hidden="true"></i> <?php esc_html_e('Crea il Primo Form', 'form-one'); ?>
                </a>
            </div>
        <?php else : ?>
        <div class="fone-forms-grid">
            <?php foreach ($forms as $form) :
                $entries_count = fone_db_count_entries($form['id']);
                $shortcode     = '[form_one id="' . $form['id'] . '"]';
                $edit_url      = admin_url('admin.php?page=fone-builder&form_id=' . $form['id']);
                $entries_url   = admin_url('admin.php?page=fone-entries&form_id=' . $form['id']);
                $insights_url  = admin_url('admin.php?page=fone-insights&form_id=' . $form['id']);
                $export_url    = wp_nonce_url(
                    admin_url('admin.php?page=fone-forms&fone_action=export_form&form_id=' . $form['id']),
                    'fone_export_form_' . $form['id']
                );
                $delete_url    = wp_nonce_url(
                    admin_url('admin.php?page=fone-forms&fone_action=delete_form&form_id=' . $form['id']),
                    'fone_delete_form_' . $form['id']
                );
            ?>
            <div class="fone-form-card <?php echo $form['is_registration'] ? 'is-registration' : ''; ?>">
                <div class="fone-form-card-header">
                    <div class="fone-form-card-name">
                        <?php echo esc_html($form['form_name']); ?>
                        <?php if ($form['is_registration']) : ?>
                            <span class="fone-reg-badge"><?php esc_html_e('Registrazione', 'form-one'); ?></span>
                        <?php endif; ?>
                        <?php if (!empty($form['is_login'])) : ?>
                            <span class="fone-reg-badge" style="background:#0891b2;"><?php esc_html_e('Login', 'form-one'); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="fone-form-card-meta">
                        <span class="fone-form-card-count">
                            <strong><?php echo (int) $entries_count; ?></strong> <?php echo (int)$entries_count === 1 ? esc_html__('invio', 'form-one') : esc_html__('invii', 'form-one'); ?>
                        </span>
                    </div>
                </div>
                <div class="fone-form-card-shortcode">
                    <code><?php echo esc_html($shortcode); ?></code>
                    <button type="button" class="fone-copy-btn" data-copy="<?php echo esc_attr($shortcode); ?>" title="<?php esc_attr_e('Copia shortcode', 'form-one'); ?>">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                    </button>
                </div>
                <div class="fone-form-card-actions">
                    <a href="<?php echo esc_url($edit_url); ?>" class="fone-btn fone-btn-primary fone-btn-sm">
                        <i class="fa-solid fa-pen-to-square" aria-hidden="true"></i> <?php esc_html_e('Modifica', 'form-one'); ?>
                    </a>
                    <a href="<?php echo esc_url($entries_url); ?>" class="fone-btn fone-btn-ghost fone-btn-sm">
                        <i class="fa-solid fa-inbox" aria-hidden="true"></i> <?php esc_html_e('Invii', 'form-one'); ?>
                    </a>
                    <a href="<?php echo esc_url($insights_url); ?>" class="fone-btn fone-btn-ghost fone-btn-sm">
                        <i class="fa-solid fa-chart-simple" aria-hidden="true"></i> <?php esc_html_e('Insights', 'form-one'); ?>
                    </a>
                    <a href="<?php echo esc_url($export_url); ?>" class="fone-btn fone-btn-ghost fone-btn-sm">
                        <i class="fa-solid fa-file-export" aria-hidden="true"></i> <?php esc_html_e('Esporta', 'form-one'); ?>
                    </a>
                    <a href="<?php echo esc_url($delete_url); ?>" class="fone-btn fone-btn-danger fone-btn-sm"
                       onclick="return confirm('<?php echo esc_js(__('Eliminare questo form e tutti i suoi invii? L\'operazione è irreversibile.', 'form-one')); ?>')">
                        <i class="fa-solid fa-trash-can" aria-hidden="true"></i> <?php esc_html_e('Elimina', 'form-one'); ?>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <script>
    (function(){
        document.querySelectorAll('.fone-copy-btn').forEach(function(btn){
            btn.addEventListener('click', function(){
                var text = this.dataset.copy;
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(text);
                } else {
                    var el = document.createElement('textarea');
                    el.value = text; document.body.appendChild(el);
                    el.select(); document.execCommand('copy');
                    document.body.removeChild(el);
                }
                var orig = this.innerHTML;
                this.innerHTML = '✓';
                var self = this;
                setTimeout(function(){ self.innerHTML = orig; }, 1500);
            });
        });
    })();
    </script>
    <?php
}

/* ---------------------------------------------------------------
   REDIRECT NUOVO FORM
--------------------------------------------------------------- */

function fone_new_form_redirect() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non autorizzato', 'form-one'));
    }
    $create_url = wp_nonce_url(admin_url('admin.php?page=fone-new-form'), 'fone_create_form');
    echo '<div class="wrap fone-admin-wrap">';
    echo '<h1>' . esc_html__('Nuovo Form', 'form-one') . '</h1>';
    echo '<p>' . esc_html__('Per sicurezza, la creazione del form richiede conferma.', 'form-one') . '</p>';
    echo '<p><a class="button button-primary" href="' . esc_url($create_url) . '">' . esc_html__('Crea nuovo form', 'form-one') . '</a></p>';
    echo '</div>';
}

/* ===============================================================
   GESTIONE AZIONI FORM (delete, create)
=============================================================== */

add_action('admin_init', function () {
    if (!is_admin() || !current_user_can('manage_options')) return;

    // Crea nuovo form — protetto da nonce per evitare CSRF admin
    if (isset($_GET['page']) && $_GET['page'] === 'fone-new-form' && isset($_GET['_wpnonce'])) {
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'fone_create_form')) {
            wp_die(esc_html__('Token non valido', 'form-one'));
        }
        $form_id = fone_create_form('Nuovo Form');
        if ($form_id) {
            wp_safe_redirect(admin_url('admin.php?page=fone-builder&form_id=' . $form_id . '&fone_msg=created'));
            exit;
        }
    }

    // Esporta form in JSON
    if (
        isset($_GET['page'], $_GET['fone_action'], $_GET['form_id']) &&
        $_GET['page'] === 'fone-forms' &&
        $_GET['fone_action'] === 'export_form'
    ) {
        $form_id = (int) $_GET['form_id'];
        if ($form_id && check_admin_referer('fone_export_form_' . $form_id)) {
            fone_export_form_json($form_id);
            exit;
        }
    }

    // Importa form da JSON
    if (!empty($_POST['fone_import_form'])) {
        if (empty($_POST['fone_import_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_import_nonce'])), 'fone_import_form')) {
            wp_die(esc_html__('Token non valido', 'form-one'));
        }
        $import_id = fone_import_form_json_upload('fone_import_file');
        if ($import_id) {
            set_transient('fone_admin_notices', [['msg' => __('Form importato correttamente.', 'form-one'), 'type' => 'updated']], 30);
            wp_safe_redirect(admin_url('admin.php?page=fone-builder&form_id=' . (int) $import_id . '&fone_msg=imported'));
            exit;
        }
        add_settings_error('fone_forms_notices', 'import_failed', __('Import non riuscito. Controlla il file JSON.', 'form-one'), 'error');
    }

    // Elimina form
    if (
        isset($_GET['page'], $_GET['fone_action'], $_GET['form_id']) &&
        $_GET['page'] === 'fone-forms' &&
        $_GET['fone_action'] === 'delete_form'
    ) {
        $form_id = (int) $_GET['form_id'];
        if ($form_id && check_admin_referer('fone_delete_form_' . $form_id)) {
            fone_delete_form($form_id);
            add_settings_error('fone_forms_notices', 'deleted', __('Form eliminato correttamente.', 'form-one'), 'updated');
            set_transient('fone_admin_notices', [['msg' => __('Form eliminato.', 'form-one'), 'type' => 'updated']], 30);
            wp_safe_redirect(admin_url('admin.php?page=fone-forms'));
            exit;
        }
    }
});

/* ===============================================================
   ENQUEUE — ADMIN
=============================================================== */

function fone_admin_enqueue($hook) {
    if (strpos((string) $hook, 'fone') === false) return;

    wp_enqueue_style('fone-fontawesome', FONE_URL . 'assets/vendor/fontawesome/css/fontawesome.min.css', [], '7.2.0');
    wp_enqueue_style('fone-fontawesome-solid', FONE_URL . 'assets/vendor/fontawesome/css/solid.min.css', ['fone-fontawesome'], '7.2.0');
    wp_enqueue_style('fone-fontawesome-brands', FONE_URL . 'assets/vendor/fontawesome/css/brands.min.css', ['fone-fontawesome'], '7.2.0');

    wp_enqueue_style('fone-admin', FONE_URL . 'assets/fone-admin.css', ['fone-fontawesome-solid', 'fone-fontawesome-brands'], FONE_VERSION);
    wp_enqueue_style('fone-front', FONE_URL . 'assets/fone-front.css', ['fone-admin'], FONE_VERSION);

    if (strpos($hook, 'fone-builder') !== false) {
        wp_enqueue_media();

        $form_id  = isset($_GET['form_id']) ? (int) $_GET['form_id'] : 0;
        $form     = $form_id ? fone_get_form($form_id) : null;

        if (!$form) {
            // fallback: primo form disponibile
            $all_forms = fone_get_all_forms();
            $form = $all_forms ? $all_forms[0] : null;
            if ($form) $form_id = $form['id'];
        }

        $schema   = $form ? wp_json_encode($form['schema'], JSON_UNESCAPED_UNICODE) : wp_json_encode(fone_get_default_schema(), JSON_UNESCAPED_UNICODE);
        $settings = $form ? $form['settings'] : fone_default_settings();
        $strings  = fone_get_all_strings();
        $library  = fone_get_field_library();

        // Conta i form con registrazione attiva (per la warning nell'UI)
        global $wpdb;
        $reg_form_id   = (int) $wpdb->get_var("SELECT id FROM " . fone_table_forms() . " WHERE is_registration = 1 LIMIT 1");
        $login_form_id = (int) $wpdb->get_var("SELECT id FROM " . fone_table_forms() . " WHERE is_login = 1 LIMIT 1");

        wp_enqueue_script('fone-admin', FONE_URL . 'assets/fone-admin.js', ['jquery'], FONE_VERSION, true);
        wp_localize_script('fone-admin', 'FONE_ADMIN', [
            'schema'           => $schema,
            'settings'         => $settings,
            'strings'          => $strings,
            'library'          => $library,
            'shortcode'        => '[form_one id="' . $form_id . '"]',
            'formId'           => $form_id,
            'formName'         => $form ? $form['form_name'] : '',
            'regFormId'        => $reg_form_id,
            'loginFormId'      => $login_form_id,
            'builderPage'      => true,
            'isPro'            => function_exists('fone_is_premium') ? fone_is_premium() : false,
            'licenseUrl'       => admin_url('admin.php?page=fone-settings&tab=licenza'),
            'nonce'            => wp_create_nonce('fone_ajax'),
            'ajaxUrl'          => admin_url('admin-ajax.php'),
            'mediaTitle'       => __('Seleziona la foto profilo', 'form-one'),
            'mediaButton'      => __('Usa questa foto', 'form-one'),
            'defaultCustomCss' => fone_get_default_custom_css(),
            'formsListUrl'     => admin_url('admin.php?page=fone-forms'),
        ]);
    }
}
add_action('admin_enqueue_scripts', 'fone_admin_enqueue');

/* ===============================================================
   ENQUEUE — FRONTEND
=============================================================== */

if (!function_exists('fone_page_contains_form_one')) {
    /**
     * Prova leggera per evitare di caricare asset Form One su pagine dove non servono.
     * Copre shortcode classici e pagine create con Elementor che contengono il widget/shortcode.
     */
    function fone_page_contains_form_one() {
        if (is_admin() || wp_doing_ajax()) return false;

        $post = get_post();
        if ($post instanceof WP_Post) {
            $content = (string) $post->post_content;
            $shortcodes = ['form_one', 'form_nogip', 'mega_gip_form', 'fone_account', 'fone_login', 'user_login_gip'];
            foreach ($shortcodes as $shortcode) {
                if (has_shortcode($content, $shortcode)) return true;
            }

            $elementor_data = (string) get_post_meta($post->ID, '_elementor_data', true);
            if ($elementor_data !== '' && (strpos($elementor_data, 'form_one') !== false || strpos($elementor_data, 'form-one') !== false || strpos($elementor_data, 'Form One') !== false)) {
                return true;
            }
        }

        return (bool) apply_filters('fone_should_enqueue_front_assets', false);
    }
}

if (!function_exists('fone_get_front_settings_for_assets')) {
    function fone_get_front_settings_for_assets() {
        $login_form_fe = function_exists('fone_get_login_form') ? fone_get_login_form() : null;
        $reg_form      = function_exists('fone_get_registration_form') ? fone_get_registration_form() : null;
        $all_forms     = function_exists('fone_get_all_forms') ? fone_get_all_forms() : [];
        return $login_form_fe ? $login_form_fe['settings'] : ($reg_form ? $reg_form['settings'] : ($all_forms ? $all_forms[0]['settings'] : fone_default_settings()));
    }
}

if (!function_exists('fone_enqueue_front_assets')) {
    function fone_enqueue_front_assets($force = false) {
        static $localized = false;

        $global_settings = function_exists('fone_get_global_settings') ? fone_get_global_settings() : [];
        $load_css = $force || !isset($global_settings['load_front_css']) || !empty($global_settings['load_front_css']);
        $load_js  = $force || !isset($global_settings['load_front_js'])  || !empty($global_settings['load_front_js']);

        if ($load_css) {
            wp_enqueue_style('fone-fontawesome', FONE_URL . 'assets/vendor/fontawesome/css/fontawesome.min.css', [], '7.2.0');
            wp_enqueue_style('fone-fontawesome-solid', FONE_URL . 'assets/vendor/fontawesome/css/solid.min.css', ['fone-fontawesome'], '7.2.0');
            wp_enqueue_style('fone-fontawesome-brands', FONE_URL . 'assets/vendor/fontawesome/css/brands.min.css', ['fone-fontawesome'], '7.2.0');
            wp_enqueue_style('fone-front', FONE_URL . 'assets/fone-front.css', ['fone-fontawesome-solid', 'fone-fontawesome-brands'], FONE_VERSION);
            wp_enqueue_style('fone-cropper-lite', FONE_URL . 'assets/vendor/cropper-lite.css', [], FONE_VERSION);
        }

        if ($load_js) {
            /**
             * Nessuna CDN obbligatoria: Form One include un cropper locale leggero
             * compatibile con l'interfaccia avatar del plugin.
             */
            wp_enqueue_script('fone-cropper-lite', FONE_URL . 'assets/vendor/cropper-lite.js', [], FONE_VERSION, true);
            wp_enqueue_script('fone-front', FONE_URL . 'assets/fone-front.js', ['fone-cropper-lite'], FONE_VERSION, true);

            if (!$localized) {
                wp_localize_script('fone-front', 'FONE_FRONT', [
                    'settings' => fone_get_front_settings_for_assets(),
                    'strings'  => fone_get_all_strings(),
                    'ajaxUrl'  => admin_url('admin-ajax.php'),
                    'nonce'    => wp_create_nonce('fone_front_ajax'),
                ]);
                $localized = true;
            }
        }
    }
}

function fone_front_enqueue() {
    if (fone_page_contains_form_one()) {
        fone_enqueue_front_assets(false);
    }
}
add_action('wp_enqueue_scripts', 'fone_front_enqueue');


/* ===============================================================
   AJAX — REFRESH FRONTEND FORM NONCE
   Evita errori "Token di sicurezza non valido" su pagine servite
   da cache o rimaste aperte a lungo.
=============================================================== */
if (!function_exists('fone_ajax_refresh_form_nonce')) {
    function fone_ajax_refresh_form_nonce() {
        $form_id = isset($_POST['form_id']) ? absint($_POST['form_id']) : 0;
        if (!$form_id || !function_exists('fone_get_form') || !fone_get_form($form_id)) {
            wp_send_json_error(['message' => __('Form non valido.', 'form-one')], 400);
        }

        wp_send_json_success([
            'nonce'  => wp_create_nonce('fone_submit_form_' . $form_id),
            'formId' => $form_id,
        ]);
    }
}
add_action('wp_ajax_fone_refresh_form_nonce', 'fone_ajax_refresh_form_nonce');
add_action('wp_ajax_nopriv_fone_refresh_form_nonce', 'fone_ajax_refresh_form_nonce');

/* ===============================================================
   INIETTA CUSTOM CSS NEL FRONTEND
   Carica il CSS di tutti i form attivi in pagina
=============================================================== */

function fone_print_custom_css() {
    $forms = fone_get_all_forms();
    $css_parts = [];
    foreach ($forms as $form) {
        if (!empty($form['custom_css'])) {
            $css_parts[] = $form['custom_css'];
        }
    }
    // Fallback legacy
    $legacy_css = get_option('fone_custom_css', '');
    if ($legacy_css && !$css_parts) {
        $css_parts[] = $legacy_css;
    }
    if (empty($css_parts)) return;
    echo "\n<style id=\"fone-custom-css\">\n" . wp_strip_all_tags(implode("\n", $css_parts)) . "\n</style>\n";
}
add_action('wp_head', 'fone_print_custom_css', 99);

/* ===============================================================
   PLUGIN LINKS
=============================================================== */

function fone_plugin_links($links) {
    $url = admin_url('admin.php?page=fone-forms');
    array_unshift($links, '<a href="' . esc_url($url) . '">' . __('Form', 'form-one') . '</a>');
    return $links;
}
add_filter('plugin_action_links_' . FONE_BASENAME, 'fone_plugin_links');

/* ===============================================================
   SHORTCODES
=============================================================== */

// Principale: [form_one id="1"]
add_shortcode('form_one',      'fone_render_form_shortcode');
// Legacy
add_shortcode('form_nogip',    'fone_render_form_shortcode');
add_shortcode('mega_gip_form', 'fone_render_form_shortcode');
// Account utente
add_shortcode('fone_account',  'fone_render_account_shortcode');

/* ===============================================================
   PAGINA DIAGNOSTICA REGISTRAZIONE
=============================================================== */

if (!function_exists('fone_diagnostics_page')) {
    function fone_diagnostics_page() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');

        // Reset log su click
        if (!empty($_POST['fone_diag_clear']) && check_admin_referer('fone_diag_clear')) {
            delete_transient('fone_reg_debug');
            echo '<div class="notice notice-success"><p>Log diagnostica cancellato.</p></div>';
        }

        $debug = get_transient('fone_reg_debug');
        $reg_form = function_exists('fone_get_registration_form') ? fone_get_registration_form() : null;

        ?>
        <div class="wrap">
            <h1><i class="fa-solid fa-stethoscope" aria-hidden="true"></i> Diagnostica Registrazione</h1>
            <p>Questa pagina mostra cosa è successo all'<strong>ultima volta</strong> che qualcuno ha inviato il form di registrazione. Usala per capire perché un utente non viene creato.</p>

            <h2><i class="fa-solid fa-clipboard-list" aria-hidden="true"></i> Stato configurazione</h2>
            <table class="widefat striped" style="max-width:800px;">
                <tbody>
                    <tr>
                        <th style="width:280px;">Form di registrazione attivo</th>
                        <td><?php echo $reg_form
                            ? ' <i class="fa-solid fa-circle-check" aria-hidden="true"></i> <strong>' . esc_html($reg_form['form_name']) . '</strong> (ID: ' . (int) $reg_form['id'] . ')'
                            : ' <i class="fa-solid fa-circle-xmark" aria-hidden="true"></i> <strong>NESSUN form impostato come registrazione.</strong> Vai sul tuo form → Impostazioni → spunta "Usa come form di registrazione" → SALVA.'; ?></td>
                    </tr>
                    <?php if ($reg_form) :
                        $s = $reg_form['settings'];
                    ?>
                    <tr>
                        <th>enable_registration</th>
                        <td><?php echo !empty($s['enable_registration']) ? '<i class="fa-solid fa-circle-check" aria-hidden="true"></i> Abilitato' : '<i class="fa-solid fa-circle-xmark" aria-hidden="true"></i> Disabilitato'; ?></td>
                    </tr>
                    <tr>
                        <th>Ruolo assegnato</th>
                        <td><?php echo esc_html($s['registration_role'] ?? 'subscriber'); ?></td>
                    </tr>
                    <tr>
                        <th>Login automatico</th>
                        <td><?php echo !empty($s['registration_autologin']) ? '<i class="fa-solid fa-circle-check" aria-hidden="true"></i> Sì' : '<i class="fa-solid fa-circle-xmark" aria-hidden="true"></i> No'; ?></td>
                    </tr>
                    <tr>
                        <th>Email benvenuto WP</th>
                        <td><?php echo !empty($s['registration_send_wp_email']) ? '<i class="fa-solid fa-circle-check" aria-hidden="true"></i> Sì' : '<i class="fa-solid fa-circle-xmark" aria-hidden="true"></i> No'; ?></td>
                    </tr>
                    <tr>
                        <th>users_can_register di WordPress</th>
                        <td><?php echo get_option('users_can_register') ? '<i class="fa-solid fa-circle-check" aria-hidden="true"></i> Sì' : '<i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> No (non blocca, ma può creare problemi con plugin di terze parti)'; ?></td>
                    </tr>
                    <tr>
                        <th>Campi del form</th>
                        <td>
                            <?php
                            $types = [];
                            foreach ($reg_form['schema'] as $f) {
                                $t = $f['type'] ?? '?';
                                $types[$t] = ($types[$t] ?? 0) + 1;
                            }
                            $has_email = !empty($types['email']);
                            $has_pwd   = !empty($types['password']);
                            echo $has_email ? ' <i class="fa-solid fa-circle-check" aria-hidden="true"></i> Email presente' : ' <i class="fa-solid fa-circle-xmark" aria-hidden="true"></i> <strong>NESSUN campo email!</strong> Aggiungi un campo Email al form.';
                            echo '<br>';
                            echo $has_pwd ? ' <i class="fa-solid fa-circle-check" aria-hidden="true"></i> Password presente' : ' <i class="fa-solid fa-circle-info" aria-hidden="true"></i> Nessun campo password (la password sarà generata automaticamente)';
                            echo '<br><small>Riepilogo tipi: ';
                            foreach ($types as $t => $n) echo esc_html($t . '×' . $n . ' ');
                            echo '</small>';
                            ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <h2 style="margin-top:32px;"><i class="fa-solid fa-scroll" aria-hidden="true"></i> Log ultima registrazione</h2>
            <?php if (!$debug) : ?>
                <div class="notice notice-info inline"><p>
                    Nessun log presente. <strong>Prova ad inviare il form di registrazione</strong> dal frontend, poi torna su questa pagina e ricarica.
                </p></div>
            <?php else : ?>
                <p><small>Ultimo invio: <strong><?php echo esc_html($debug['time'] ?? '?'); ?></strong></small></p>
                <pre style="background:#0f172a;color:#a5f3fc;padding:16px;border-radius:6px;overflow:auto;max-height:500px;font-size:12px;line-height:1.6;"><?php
                    foreach ($debug['entries'] as $line) {
                        echo esc_html($line) . "\n";
                    }
                ?></pre>

                <form method="post" style="margin-top:12px;">
                    <?php wp_nonce_field('fone_diag_clear'); ?>
                    <button type="submit" name="fone_diag_clear" value="1" class="button"><i class="fa-solid fa-trash-can" aria-hidden="true"></i> Cancella log</button>
                </form>
            <?php endif; ?>

            <h2 style="margin-top:32px;"><i class="fa-solid fa-screwdriver-wrench" aria-hidden="true"></i> Soluzioni comuni</h2>
            <ul style="list-style:disc;margin-left:24px;line-height:1.8;">
                <li><strong>"STOP: enable_registration=0"</strong> → vai sul form, spunta "Usa come form di registrazione" e CLICCA SALVA in alto</li>
                <li><strong>"nessun campo email trovato"</strong> → aggiungi un campo Email al form (tipo email obbligatorio)</li>
                <li><strong>"email già in uso"</strong> → l'email che stai testando è già registrata. Usa una nuova oppure elimina l'utente esistente</li>
                <li><strong>"Registrazione fallita: …"</strong> → il messaggio dopo è l'errore esatto di WordPress (ruolo invalido, username vuoto, ecc.)</li>
                <li><strong>Nessun log appare</strong> → l'hook non viene chiamato. Il form non sta processando il submit. Controlla che il submit vada a buon fine (vedi "Invii")</li>
            </ul>
        </div>
        <?php
    }
}

/* ===============================================================
   PAGINA AIUTO / SUPPORTO
=============================================================== */

if (!function_exists('fone_help_page')) {
    function fone_help_page() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        $support_email = apply_filters('fone_support_email', get_option('admin_email')); // niente email finta nella release pubblica
        $docs_url      = apply_filters('fone_docs_url', 'https://neetly.eu/formone/');
        ?>
        <div class="wrap fone-help-wrap" style="max-width:880px;">
            <h1><?php esc_html_e('Aiuto e Supporto', 'form-one'); ?></h1>
            <p style="font-size:14px;color:#52525b;line-height:1.6;">
                <?php esc_html_e('Tutto quello che serve per partire con Form One e per chiedere aiuto se qualcosa non torna.', 'form-one'); ?>
            </p>

            <div class="fone-help-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px;margin-top:24px;">

                <div class="fone-help-card" style="background:#fff;border:1px solid #e4e4e7;border-radius:12px;padding:22px;">
                    <h2 style="margin:0 0 8px;font-size:18px;"><?php esc_html_e('Primi passi', 'form-one'); ?></h2>
                    <p style="margin:0 0 12px;color:#52525b;font-size:13px;line-height:1.6;">
                        <?php esc_html_e('Crea il primo form, aggiungi i campi via drag & drop, salvalo e incolla lo shortcode in una pagina.', 'form-one'); ?>
                    </p>
                    <ol style="margin:0;padding-left:18px;color:#3f3f46;font-size:13px;line-height:1.8;">
                        <li><?php esc_html_e('Vai su Form One → Tutti i Form e clicca "Nuovo Form"', 'form-one'); ?></li>
                        <li><?php esc_html_e('Trascina i campi dalla libreria al canvas', 'form-one'); ?></li>
                        <li><?php esc_html_e('Salva e copia lo shortcode mostrato in alto', 'form-one'); ?></li>
                        <li><?php esc_html_e('Incollalo in qualsiasi pagina o post', 'form-one'); ?></li>
                    </ol>
                </div>

                <div class="fone-help-card" style="background:#fff;border:1px solid #e4e4e7;border-radius:12px;padding:22px;">
                    <h2 style="margin:0 0 8px;font-size:18px;"><?php esc_html_e('Form di registrazione', 'form-one'); ?></h2>
                    <p style="margin:0 0 12px;color:#52525b;font-size:13px;line-height:1.6;">
                        <?php esc_html_e('Trasforma un form in registrazione utenti WordPress in 3 step:', 'form-one'); ?>
                    </p>
                    <ol style="margin:0;padding-left:18px;color:#3f3f46;font-size:13px;line-height:1.8;">
                        <li><?php esc_html_e('Aggiungi un campo email obbligatorio', 'form-one'); ?></li>
                        <li><?php esc_html_e('Apri Impostazioni del form → "Registrazione Utenti" → abilita', 'form-one'); ?></li>
                        <li><?php esc_html_e('Scegli il ruolo da assegnare e salva', 'form-one'); ?></li>
                    </ol>
                </div>

                <div class="fone-help-card" style="background:#fff;border:1px solid #e4e4e7;border-radius:12px;padding:22px;">
                    <h2 style="margin:0 0 8px;font-size:18px;"><?php esc_html_e('Webhook e integrazioni', 'form-one'); ?></h2>
                    <p style="margin:0 0 12px;color:#52525b;font-size:13px;line-height:1.6;">
                        <?php esc_html_e('Manda i dati a Make, Zapier, n8n o un endpoint custom. Form One invia POST JSON ad ogni invio.', 'form-one'); ?>
                    </p>
                    <p style="margin:0;color:#3f3f46;font-size:13px;">
                        <?php esc_html_e('Vai su Form One → Impostazioni → tab "Webhook".', 'form-one'); ?>
                    </p>
                </div>

                <div class="fone-help-card" style="background:#fff;border:1px solid #e4e4e7;border-radius:12px;padding:22px;">
                    <h2 style="margin:0 0 8px;font-size:18px;"><?php esc_html_e('Diagnostica registrazione', 'form-one'); ?></h2>
                    <p style="margin:0 0 12px;color:#52525b;font-size:13px;line-height:1.6;">
                        <?php esc_html_e('Se la registrazione non crea utenti, apri la pagina Diagnostica per vedere il log dell\'ultimo invio.', 'form-one'); ?>
                    </p>
                    <p style="margin:0;">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=fone-diag')); ?>" class="button"><?php esc_html_e('Apri diagnostica', 'form-one'); ?></a>
                    </p>
                </div>

            </div>

            <div style="background:linear-gradient(135deg,#FAFAFB 0%,#F4F1FA 100%);border:1px solid #e4e4e7;border-radius:12px;padding:26px;margin-top:28px;">
                <h2 style="margin:0 0 10px;font-size:20px;color:#1A1F4D;"><?php esc_html_e('Hai bisogno di assistenza diretta?', 'form-one'); ?></h2>
                <p style="margin:0 0 16px;color:#3f3f46;font-size:14px;line-height:1.7;">
                    <?php esc_html_e('Per richieste di supporto, segnalazioni di bug o suggerimenti, scrivi a:', 'form-one'); ?>
                </p>
                <p style="margin:0 0 8px;font-size:16px;">
                    <strong><?php esc_html_e('Email:', 'form-one'); ?></strong>
                    <a href="mailto:<?php echo esc_attr($support_email); ?>?subject=Form%20One%20-%20Richiesta%20supporto" style="color:#6C2BD9;font-weight:600;text-decoration:none;">
                        <?php echo esc_html($support_email); ?>
                    </a>
                </p>
                <p style="margin:0;font-size:14px;color:#52525b;">
                    <strong><?php esc_html_e('Documentazione online:', 'form-one'); ?></strong>
                    <a href="<?php echo esc_url($docs_url); ?>" target="_blank" rel="noopener" style="color:#2D6CFF;text-decoration:none;">
                        <?php echo esc_html($docs_url); ?> ↗
                    </a>
                </p>

                <hr style="border:none;border-top:1px solid #e4e4e7;margin:18px 0;">

                <p style="margin:0;font-size:12px;color:#71717A;line-height:1.6;">
                    <strong><?php esc_html_e('Quando scrivi, indica:', 'form-one'); ?></strong>
                    <?php esc_html_e('versione Form One installata, versione WordPress, versione PHP, tema usato e una breve descrizione del problema. Se possibile allega uno screenshot o il log dalla pagina Diagnostica.', 'form-one'); ?>
                </p>
            </div>

            <p style="margin-top:24px;font-size:13px;color:#71717A;text-align:center;">
                Form One v<?php echo esc_html(FONE_VERSION); ?> ·
                <a href="<?php echo esc_url(admin_url('admin.php?page=fone-whats-new')); ?>"><?php esc_html_e('Vedi le novità di questa versione', 'form-one'); ?></a>
            </p>
        </div>
        <?php
    }
}

/* ===============================================================
   PAGINA NOVITÀ (changelog ultima versione)
=============================================================== */

if (!function_exists('fone_whats_new_page')) {
    function fone_whats_new_page() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');

        // Leggo le entries del changelog dal readme.txt
        $readme_path = FONE_DIR . 'readme.txt';
        $latest_entries = [];
        $latest_version = FONE_VERSION;

        if (file_exists($readme_path)) {
            $content = file_get_contents($readme_path);
            if (preg_match('/== Changelog ==(.*)$/s', $content, $m)) {
                $cl = $m[1];
                // Estraggo i blocchi `= X.Y.Z =` con relative voci
                preg_match_all('/^=\s*([\d.]+)\s*=\s*\n((?:\*[^\n]*\n)+)/m', $cl, $blocks, PREG_SET_ORDER);
                foreach ($blocks as $b) {
                    $latest_entries[] = [
                        'version' => trim($b[1]),
                        'lines'   => array_filter(array_map('trim', explode("\n", $b[2]))),
                    ];
                }
            }
        }
        ?>
        <div class="wrap" style="max-width:880px;">
            <h1><?php esc_html_e('Novità di Form One', 'form-one'); ?></h1>
            <p style="font-size:14px;color:#52525b;line-height:1.6;">
                <?php esc_html_e('Tutte le nuove funzioni e i miglioramenti, versione per versione.', 'form-one'); ?>
            </p>

            <?php if (empty($latest_entries)) : ?>
                <p><?php esc_html_e('Nessun changelog disponibile.', 'form-one'); ?></p>
            <?php else : ?>
                <?php foreach (array_slice($latest_entries, 0, 6) as $i => $entry) : ?>
                    <div style="background:#fff;border:1px solid #e4e4e7;border-radius:12px;padding:24px;margin-top:18px;<?php echo $i === 0 ? 'border-left:4px solid #6C2BD9;' : ''; ?>">
                        <h2 style="margin:0 0 14px;font-size:18px;color:<?php echo $i === 0 ? '#6C2BD9' : '#1A1F4D'; ?>;">
                            <?php if ($i === 0) : ?>
                                <span style="background:#6C2BD9;color:#fff;font-size:11px;padding:3px 8px;border-radius:4px;margin-right:8px;vertical-align:middle;">ATTUALE</span>
                            <?php endif; ?>
                            v<?php echo esc_html($entry['version']); ?>
                        </h2>
                        <ul style="margin:0;padding-left:20px;color:#3f3f46;font-size:14px;line-height:1.8;">
                            <?php foreach ($entry['lines'] as $line) :
                                $line = ltrim($line, '* ');
                                if (!$line) continue;
                                ?>
                                <li><?php echo esc_html($line); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <p style="margin-top:24px;text-align:center;">
                <a href="<?php echo esc_url(admin_url('admin.php?page=fone-help')); ?>" class="button"><?php esc_html_e('← Torna alla pagina Aiuto', 'form-one'); ?></a>
            </p>
        </div>
        <?php
    }
}
