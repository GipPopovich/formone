<?php
/**
 * Form One — Pannello Form di Registrazione
 *
 * Pagina admin dedicata per personalizzare titolo/sottotitolo/colori/microcopy
 * del form di registrazione utenti, con anteprima e shortcode pronto.
 *
 * Differenza rispetto al login: la registrazione vera e propria è gestita
 * dal motore Form One esistente (fone-submit.php). Qui forniamo solo:
 *   1. Settings personalizzazione UX/branding del form di registrazione
 *   2. Shortcode [fone_registration] pronto da incollare in pagina,
 *      che renderizza il form di registrazione attivo (is_registration=1)
 *   3. Pulsante "Crea form di registrazione preimpostato" se non esiste
 */
if (!defined('ABSPATH')) { exit; }

add_shortcode('fone_registration', 'fone_render_registration_shortcode');
add_shortcode('user_register_gip', 'fone_render_registration_shortcode'); // legacy alias

/* ---------------------------------------------------------------
   DEFAULTS + GETTER/SETTER OPZIONI
--------------------------------------------------------------- */

if (!function_exists('fone_registration_default_settings')) {
    function fone_registration_default_settings() {
        return [
            // Testi
            'title'                => 'Crea il tuo account',
            'subtitle'             => 'Bastano pochi dati per iniziare. Riceverai una email di conferma.',
            'msg_success'          => 'Account creato con successo! Benvenuto.',
            'msg_already_logged'   => 'Sei già loggato come {name}.',
            'lostpass_label'       => 'Password dimenticata?',
            'login_link_label'     => 'Hai già un account? Accedi',
            'show_lostpass'        => 1,
            'show_login_link'      => 1,

            // Stile
            'accent_color'         => '#2563eb',
            'bg_color'             => '#ffffff',
            'text_color'           => '#0a0a0f',
            'border_radius'        => 10,
            'btn_text_color'       => '#ffffff',
            'show_box_shadow'      => 1,

            // Comportamento
            'redirect_after_register' => '', // se vuoto, va alla pagina account predefinita
            'autologin'               => 1,  // logga subito dopo la creazione
            'send_welcome_email'      => 1,  // email branded di benvenuto
            'default_role'            => 'subscriber',
        ];
    }
}

if (!function_exists('fone_registration_get_settings')) {
    function fone_registration_get_settings() {
        $saved = get_option('fone_registration_settings', []);
        if (!is_array($saved)) $saved = [];
        return wp_parse_args($saved, fone_registration_default_settings());
    }
}

if (!function_exists('fone_registration_save_settings')) {
    function fone_registration_save_settings($new) {
        if (!is_array($new)) return false;
        $defaults = fone_registration_default_settings();
        $clean = [];

        foreach (['title','subtitle','msg_success','msg_already_logged',
                  'lostpass_label','login_link_label'] as $k) {
            $clean[$k] = isset($new[$k]) ? sanitize_text_field(wp_unslash($new[$k])) : $defaults[$k];
        }
        foreach (['show_lostpass','show_login_link','show_box_shadow','autologin','send_welcome_email'] as $k) {
            $clean[$k] = !empty($new[$k]) ? 1 : 0;
        }
        foreach (['accent_color','bg_color','text_color','btn_text_color'] as $k) {
            $color = isset($new[$k]) ? sanitize_hex_color(wp_unslash($new[$k])) : null;
            $clean[$k] = $color ?: $defaults[$k];
        }
        $clean['border_radius'] = isset($new['border_radius']) ? max(0, min(40, (int) $new['border_radius'])) : $defaults['border_radius'];

        // Redirect: solo URL stesso dominio
        $redir = isset($new['redirect_after_register']) ? trim(wp_unslash($new['redirect_after_register'])) : '';
        if ($redir) {
            $redir = esc_url_raw($redir);
            $home_host  = wp_parse_url(home_url(), PHP_URL_HOST);
            $redir_host = wp_parse_url($redir, PHP_URL_HOST);
            if ($redir_host && $redir_host !== $home_host) $redir = '';
        }
        $clean['redirect_after_register'] = $redir;

        // Ruolo: filtrato con safe role helper se disponibile
        $role = isset($new['default_role']) ? sanitize_key($new['default_role']) : 'subscriber';
        if (function_exists('fone_get_safe_registration_role')) {
            $role = fone_get_safe_registration_role($role);
        } elseif ($role === 'administrator') {
            $role = 'subscriber';
        }
        $clean['default_role'] = $role ?: 'subscriber';

        update_option('fone_registration_settings', $clean, false);
        return true;
    }
}

/* ---------------------------------------------------------------
   HELPER: trova il form di registrazione attivo
--------------------------------------------------------------- */

if (!function_exists('fone_get_registration_form_id')) {
    function fone_get_registration_form_id() {
        global $wpdb;
        $table = function_exists('fone_table_forms') ? fone_table_forms() : $wpdb->prefix . 'fone_forms';
        $id = (int) $wpdb->get_var("SELECT id FROM {$table} WHERE is_registration = 1 ORDER BY id ASC LIMIT 1");
        return $id ?: 0;
    }
}

if (!function_exists('fone_create_default_registration_form')) {
    /**
     * Crea un form di registrazione preimpostato (usando il template registrazione-utenti
     * dalla libreria template). Restituisce l'ID del form creato.
     */
    function fone_create_default_registration_form() {
        if (!function_exists('fone_create_form_from_template')) {
            return 0;
        }
        $form_id = (int) fone_create_form_from_template('registrazione-utenti');
        if (!$form_id) return 0;

        // Applica le opzioni del pannello al form appena creato
        if (function_exists('fone_get_form') && function_exists('fone_save_form')) {
            $form = fone_get_form($form_id);
            $opts = fone_registration_get_settings();
            $s = is_array($form['settings'] ?? null) ? $form['settings'] : [];
            $s['form_title']             = $opts['title'];
            $s['form_subtitle']          = $opts['subtitle'];
            $s['accent_color']           = $opts['accent_color'];
            $s['border_radius']          = (int) $opts['border_radius'];
            $s['success_message']        = $opts['msg_success'];
            $s['enable_registration']    = 1;
            $s['registration_role']      = $opts['default_role'];
            $s['registration_autologin'] = !empty($opts['autologin']) ? 1 : 0;
            $s['registration_send_wp_email'] = !empty($opts['send_welcome_email']) ? 1 : 0;
            $s['registration_redirect']  = $opts['redirect_after_register'];

            fone_save_form($form_id, [
                'schema'          => $form['schema'],
                'settings'        => $s,
                'layouts'         => $form['layouts'] ?? [],
                'is_registration' => 1,
                'is_login'        => 0,
            ]);
        }
        return $form_id;
    }
}

/* ---------------------------------------------------------------
   SHORTCODE [fone_registration]
   Wrapper che renderizza il form di registrazione attivo applicando
   le opzioni del pannello.
--------------------------------------------------------------- */

if (!function_exists('fone_render_registration_shortcode')) {
    function fone_render_registration_shortcode($atts = []) {
        $atts = shortcode_atts(['id' => 0], $atts, 'fone_registration');
        $form_id = (int) $atts['id'];
        if (!$form_id) {
            $form_id = fone_get_registration_form_id();
        }
        if (!$form_id) {
            // Niente form di registrazione: mostriamo un messaggio chiaro per l'admin
            if (current_user_can('manage_options')) {
                return '<div class="fone-wrap" style="padding:20px;background:#fef3c7;border:1px solid #fcd34d;border-radius:10px;color:#92400e;">⚠️ ' .
                    esc_html__('Nessun form di registrazione attivo. Vai su Form One → Form di Registrazione e crea quello preimpostato.', 'form-one') .
                    '</div>';
            }
            return '';
        }
        return do_shortcode('[form_one id="' . (int) $form_id . '"]');
    }
}

/* ===============================================================
   PAGINA ADMIN — Form di Registrazione
=============================================================== */

if (!function_exists('fone_registration_settings_page')) {
    function fone_registration_settings_page() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');

        // Crea form preimpostato se richiesto
        if (!empty($_POST['fone_create_default_form']) && check_admin_referer('fone_reg_save_nonce', 'fone_reg_nonce_field')) {
            $new_id = fone_create_default_registration_form();
            if ($new_id) {
                echo '<div class="notice notice-success is-dismissible"><p>✅ Form di registrazione preimpostato creato (ID #' . (int) $new_id . '). Puoi modificarlo dal Builder.</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>❌ Errore creazione form. Verifica che il template "registrazione-utenti" sia disponibile.</p></div>';
            }
        }

        // Salvataggio impostazioni
        if (!empty($_POST['fone_registration_save']) && check_admin_referer('fone_reg_save_nonce', 'fone_reg_nonce_field')) {
            $payload = isset($_POST['fone_registration']) && is_array($_POST['fone_registration']) ? wp_unslash($_POST['fone_registration']) : [];
            fone_registration_save_settings($payload);

            // Applica anche al form di registrazione attivo (se esiste)
            $reg_form_id = fone_get_registration_form_id();
            if ($reg_form_id && function_exists('fone_get_form') && function_exists('fone_save_form')) {
                $form = fone_get_form($reg_form_id);
                $opts = fone_registration_get_settings();
                $s = is_array($form['settings'] ?? null) ? $form['settings'] : [];
                $s['form_title']                 = $opts['title'];
                $s['form_subtitle']              = $opts['subtitle'];
                $s['accent_color']               = $opts['accent_color'];
                $s['border_radius']              = (int) $opts['border_radius'];
                $s['success_message']            = $opts['msg_success'];
                $s['enable_registration']        = 1;
                $s['registration_role']          = $opts['default_role'];
                $s['registration_autologin']     = !empty($opts['autologin']) ? 1 : 0;
                $s['registration_send_wp_email'] = !empty($opts['send_welcome_email']) ? 1 : 0;
                $s['registration_redirect']      = $opts['redirect_after_register'];
                fone_save_form($reg_form_id, [
                    'schema'          => $form['schema'],
                    'settings'        => $s,
                    'layouts'         => $form['layouts'] ?? [],
                    'is_registration' => 1,
                    'is_login'        => 0,
                ]);
            }
            echo '<div class="notice notice-success is-dismissible"><p>✅ Impostazioni Form di Registrazione salvate.</p></div>';
        }

        $opts = fone_registration_get_settings();
        $reg_form_id = fone_get_registration_form_id();

        // Lista ruoli WP per il select
        $roles = wp_roles()->roles ?: [];
        ?>
        <div class="wrap" style="max-width:1280px;">
            <h1>👤 Form di Registrazione</h1>
            <p style="font-size:14px;color:#52525b;line-height:1.6;max-width:780px;">
                Personalizza il form di registrazione utenti del tuo sito. Lo shortcode <code>[fone_registration]</code> renderizza il form di registrazione attivo applicando queste impostazioni.
            </p>

            <?php if (!$reg_form_id) : ?>
                <div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:10px;padding:18px 22px;margin:18px 0;color:#92400e;">
                    <h3 style="margin:0 0 8px;color:#92400e;">⚠️ Nessun form di registrazione attivo</h3>
                    <p style="margin:0 0 12px;line-height:1.6;">Per usare questo pannello hai bisogno di almeno un form con il flag "registrazione" attivo. Possiamo crearne uno preimpostato per te (Nome, Cognome, Email, Password, Privacy in 3 step).</p>
                    <form method="post" style="margin:0;">
                        <?php wp_nonce_field('fone_reg_save_nonce', 'fone_reg_nonce_field'); ?>
                        <input type="hidden" name="fone_create_default_form" value="1">
                        <button type="submit" class="button button-primary">✨ Crea form di registrazione preimpostato</button>
                    </form>
                </div>
            <?php else : ?>
                <div style="background:#dcfce7;border:1px solid #86efac;border-radius:10px;padding:14px 18px;margin:18px 0;color:#166534;display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                    <span style="font-weight:600;">✅ Form di registrazione attivo: ID #<?php echo (int) $reg_form_id; ?></span>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=fone-builder&form_id=' . $reg_form_id)); ?>" class="button button-secondary" style="margin-left:auto;">✏️ Modifica nel Builder</a>
                </div>
            <?php endif; ?>

            <form method="post" id="fone-reg-form-settings">
                <?php wp_nonce_field('fone_reg_save_nonce', 'fone_reg_nonce_field'); ?>
                <input type="hidden" name="fone_registration_save" value="1">

                <div style="display:grid;grid-template-columns:1fr 380px;gap:24px;margin-top:18px;">

                    <div>
                        <nav class="nav-tab-wrapper" style="margin-bottom:0;">
                            <a href="#tab-testi" class="nav-tab nav-tab-active" data-tab="testi">📝 Testi</a>
                            <a href="#tab-stile" class="nav-tab" data-tab="stile">🎨 Stile</a>
                            <a href="#tab-comportamento" class="nav-tab" data-tab="comportamento">⚙️ Comportamento</a>
                        </nav>

                        <!-- TESTI -->
                        <div class="fone-tab-panel" data-panel="testi" style="background:#fff;border:1px solid #e4e4e7;border-top:none;padding:22px 24px;">
                            <h2 style="margin:0 0 14px;font-size:16px;">Testi del form</h2>

                            <p><label><strong>Titolo</strong><br>
                                <input type="text" name="fone_registration[title]" value="<?php echo esc_attr($opts['title']); ?>" class="regular-text fone-live" data-target="title" style="width:100%;max-width:520px;">
                            </label></p>

                            <p><label><strong>Sottotitolo</strong><br>
                                <input type="text" name="fone_registration[subtitle]" value="<?php echo esc_attr($opts['subtitle']); ?>" class="regular-text fone-live" data-target="subtitle" style="width:100%;max-width:520px;">
                            </label></p>

                            <h3 style="margin:18px 0 8px;font-size:14px;color:#52525b;">Messaggi</h3>

                            <p><label>Messaggio di successo:
                                <input type="text" name="fone_registration[msg_success]" value="<?php echo esc_attr($opts['msg_success']); ?>" style="width:520px;">
                            </label></p>

                            <p><label>Saluto se già loggato:
                                <input type="text" name="fone_registration[msg_already_logged]" value="<?php echo esc_attr($opts['msg_already_logged']); ?>" style="width:340px;">
                            </label> &nbsp; <small><code>{name}</code> = nome utente</small></p>

                            <h3 style="margin:18px 0 8px;font-size:14px;color:#52525b;">Link sotto al form</h3>

                            <p><label><input type="checkbox" name="fone_registration[show_lostpass]" value="1" <?php checked(!empty($opts['show_lostpass'])); ?>> Mostra "Password dimenticata?"</label> &nbsp;<input type="text" name="fone_registration[lostpass_label]" value="<?php echo esc_attr($opts['lostpass_label']); ?>"></p>

                            <p><label><input type="checkbox" name="fone_registration[show_login_link]" value="1" <?php checked(!empty($opts['show_login_link'])); ?>> Mostra link al login</label> &nbsp;<input type="text" name="fone_registration[login_link_label]" value="<?php echo esc_attr($opts['login_link_label']); ?>"></p>
                        </div>

                        <!-- STILE -->
                        <div class="fone-tab-panel" data-panel="stile" style="display:none;background:#fff;border:1px solid #e4e4e7;border-top:none;padding:22px 24px;">
                            <h2 style="margin:0 0 14px;font-size:16px;">Stile</h2>
                            <p><label>Colore principale (accent): <input type="color" name="fone_registration[accent_color]" value="<?php echo esc_attr($opts['accent_color']); ?>" class="fone-live" data-target="accent_color"></label></p>
                            <p><label>Sfondo card: <input type="color" name="fone_registration[bg_color]" value="<?php echo esc_attr($opts['bg_color']); ?>" class="fone-live" data-target="bg_color"></label></p>
                            <p><label>Colore testo: <input type="color" name="fone_registration[text_color]" value="<?php echo esc_attr($opts['text_color']); ?>" class="fone-live" data-target="text_color"></label></p>
                            <p><label>Colore testo pulsante: <input type="color" name="fone_registration[btn_text_color]" value="<?php echo esc_attr($opts['btn_text_color']); ?>" class="fone-live" data-target="btn_text_color"></label></p>
                            <p><label>Border radius (px): <input type="number" name="fone_registration[border_radius]" value="<?php echo (int) $opts['border_radius']; ?>" min="0" max="40" class="fone-live" data-target="border_radius"></label></p>
                            <p><label><input type="checkbox" name="fone_registration[show_box_shadow]" value="1" <?php checked(!empty($opts['show_box_shadow'])); ?>> Mostra ombra box</label></p>
                        </div>

                        <!-- COMPORTAMENTO -->
                        <div class="fone-tab-panel" data-panel="comportamento" style="display:none;background:#fff;border:1px solid #e4e4e7;border-top:none;padding:22px 24px;">
                            <h2 style="margin:0 0 14px;font-size:16px;">Comportamento dopo registrazione</h2>

                            <p style="max-width:680px;color:#52525b;">Cosa succede quando un utente completa la registrazione.</p>

                            <p><label>URL di redirect (lascia vuoto = pagina account):<br>
                                <input type="url" name="fone_registration[redirect_after_register]" value="<?php echo esc_attr($opts['redirect_after_register']); ?>" placeholder="<?php echo esc_attr(home_url('/benvenuto/')); ?>" style="width:480px;">
                            </label></p>
                            <p style="font-size:13px;color:#71717A;">⚠️ Per sicurezza accettiamo solo URL dello stesso dominio.</p>

                            <p><label><input type="checkbox" name="fone_registration[autologin]" value="1" <?php checked(!empty($opts['autologin'])); ?>> Login automatico dopo la registrazione</label></p>
                            <p style="font-size:13px;color:#71717A;margin-left:24px;">L'utente viene loggato automaticamente senza dover ripetere le credenziali.</p>

                            <p><label><input type="checkbox" name="fone_registration[send_welcome_email]" value="1" <?php checked(!empty($opts['send_welcome_email'])); ?>> Invia email di benvenuto WordPress</label></p>
                            <p style="font-size:13px;color:#71717A;margin-left:24px;">Email di conferma con branding "Form One" (mittente blindato a 3 strati di protezione).</p>

                            <h3 style="margin:18px 0 8px;font-size:14px;color:#52525b;">Ruolo utente alla registrazione</h3>
                            <p><label>Ruolo predefinito:
                                <select name="fone_registration[default_role]">
                                    <?php foreach ($roles as $role_key => $role_data) :
                                        // Escludo administrator per sicurezza
                                        if ($role_key === 'administrator') continue; ?>
                                        <option value="<?php echo esc_attr($role_key); ?>" <?php selected($opts['default_role'], $role_key); ?>>
                                            <?php echo esc_html($role_data['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </label></p>
                            <p style="font-size:13px;color:#71717A;">⚠️ Il ruolo "administrator" è bloccato per registrazione pubblica.</p>
                        </div>
                    </div>

                    <!-- ANTEPRIMA -->
                    <div>
                        <h3 style="margin:0 0 8px;font-size:14px;color:#52525b;">👁 Anteprima</h3>
                        <div id="fone-reg-preview" style="background:#f4f4f5;border:1px dashed #d4d4d8;padding:24px;border-radius:8px;position:sticky;top:32px;">
                            <div id="fone-reg-preview-card" style="background:<?php echo esc_attr($opts['bg_color']); ?>;color:<?php echo esc_attr($opts['text_color']); ?>;padding:28px;border-radius:<?php echo (int)$opts['border_radius']+4; ?>px;<?php echo !empty($opts['show_box_shadow']) ? 'box-shadow:0 4px 24px rgba(0,0,0,.08);' : ''; ?>">
                                <h2 data-prev="title" style="margin:0 0 6px;font-size:22px;font-weight:700;color:<?php echo esc_attr($opts['text_color']); ?>;"><?php echo esc_html($opts['title']); ?></h2>
                                <p data-prev="subtitle" style="margin:0 0 18px;font-size:13px;color:#64748b;"><?php echo esc_html($opts['subtitle']); ?></p>
                                <label style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">Nome *</label>
                                <input type="text" disabled style="width:100%;padding:10px;border:1px solid #e4e4e7;border-radius:6px;margin-bottom:10px;background:#fafafa;">
                                <label style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">Email *</label>
                                <input type="email" disabled style="width:100%;padding:10px;border:1px solid #e4e4e7;border-radius:6px;margin-bottom:10px;background:#fafafa;">
                                <label style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">Password *</label>
                                <input type="password" disabled style="width:100%;padding:10px;border:1px solid #e4e4e7;border-radius:6px;margin-bottom:14px;background:#fafafa;">
                                <button type="button" disabled id="fone-reg-preview-btn" style="width:100%;padding:11px;background:<?php echo esc_attr($opts['accent_color']); ?>;color:<?php echo esc_attr($opts['btn_text_color']); ?>;border:none;border-radius:8px;font-weight:700;font-size:14px;cursor:not-allowed;">Crea il mio account</button>
                            </div>
                            <div style="margin-top:14px;padding:12px;background:#f1f5f9;border-radius:6px;font-size:12px;color:#475569;line-height:1.5;">
                                <strong>📋 Shortcode da usare:</strong><br>
                                <code style="background:#fff;padding:3px 7px;border-radius:4px;display:inline-block;margin-top:4px;">[fone_registration]</code><br>
                                <span style="color:#71717A;">Oppure usa <code style="background:#fff;padding:1px 5px;border-radius:3px;">[form_one id="<?php echo $reg_form_id ? (int) $reg_form_id : 'X'; ?>"]</code></span>
                            </div>
                        </div>
                    </div>
                </div>

                <p style="margin-top:24px;">
                    <button type="submit" class="button button-primary button-large">💾 Salva impostazioni</button>
                </p>
            </form>
        </div>

        <script>
        (function(){
            // Tabs
            var tabs = document.querySelectorAll('.nav-tab[data-tab]');
            var panels = document.querySelectorAll('.fone-tab-panel[data-panel]');
            tabs.forEach(function(t){
                t.addEventListener('click', function(e){
                    e.preventDefault();
                    tabs.forEach(function(x){ x.classList.remove('nav-tab-active'); });
                    t.classList.add('nav-tab-active');
                    var name = t.getAttribute('data-tab');
                    panels.forEach(function(p){ p.style.display = (p.getAttribute('data-panel') === name) ? 'block' : 'none'; });
                });
            });

            // Anteprima live
            document.querySelectorAll('.fone-live').forEach(function(input){
                input.addEventListener('input', function(){
                    var key = input.getAttribute('data-target');
                    var val = input.value;
                    var prev = document.querySelector('[data-prev="' + key + '"]');
                    if (prev) prev.textContent = val;
                    var card = document.getElementById('fone-reg-preview-card');
                    var btn  = document.getElementById('fone-reg-preview-btn');
                    if (key === 'accent_color' && btn) btn.style.background = val;
                    if (key === 'btn_text_color' && btn) btn.style.color = val;
                    if (key === 'bg_color' && card) card.style.background = val;
                    if (key === 'text_color' && card) {
                        card.style.color = val;
                        card.querySelectorAll('h2, label').forEach(function(el){ el.style.color = val; });
                    }
                    if (key === 'border_radius' && card) card.style.borderRadius = (parseInt(val,10)+4) + 'px';
                });
            });
        })();
        </script>
        <?php
    }
}
