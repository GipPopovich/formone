<?php
/**
 * Form One — Impostazioni globali, WhatsApp, Webhook, Debug, Template e Lead Action Panel.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('fone_global_default_settings')) {
    function fone_global_default_settings() {
        return [
            'load_front_css'              => 1,
            'load_front_js'               => 1,
            'save_entries'                => 1,
            'debug_enabled'               => 0,
            'whatsapp_enabled'            => 0,
            'whatsapp_number'             => '',
            'whatsapp_button_label'       => 'Scrivici su WhatsApp',
            'whatsapp_message'            => 'Ciao, ho appena inviato una richiesta dal sito.',
            'whatsapp_include_values'     => 0,
            'whatsapp_entry_message'      => 'Ciao, ti contatto per la richiesta inviata sul sito.',
            'webhook_enabled'             => 0,
            'webhook_url'                 => '',
            'webhook_send_values'         => 1,
            'webhook_send_meta'           => 1,
            'webhook_timeout'             => 8,
            'builder_interface'           => 'modern',
        ];
    }
}

if (!function_exists('fone_get_global_settings')) {
    function fone_get_global_settings() {
        $saved = get_option('fone_global_settings', []);
        if (!is_array($saved)) $saved = [];
        $settings = wp_parse_args($saved, fone_global_default_settings());
        if ($saved !== $settings) {
            update_option('fone_global_settings', $settings, false);
        }
        return $settings;
    }
}

if (!function_exists('fone_is_debug_enabled')) {
    /**
     * Ritorna true solo quando il debug Form One deve scrivere log tecnici.
     * Evita file di log permanenti in produzione quando il debug non è attivo.
     */
    function fone_is_debug_enabled() {
        $settings = function_exists('fone_get_global_settings') ? fone_get_global_settings() : [];
        return (defined('WP_DEBUG') && WP_DEBUG) || !empty($settings['debug_enabled']);
    }
}

if (!function_exists('fone_write_debug_log')) {
    /**
     * Scrive log tecnici in uploads/form-one-logs solo con debug attivo.
     * Context viene ridotto a caratteri sicuri per evitare percorsi arbitrari.
     */
    function fone_write_debug_log($context, $message) {
        if (!function_exists('fone_is_debug_enabled') || !fone_is_debug_enabled()) {
            return false;
        }

        $context = sanitize_key($context ?: 'debug');
        if ($context === '') {
            $context = 'debug';
        }

        $uploads = wp_upload_dir(null, false);
        $base_dir = !empty($uploads['basedir']) ? trailingslashit($uploads['basedir']) . 'form-one-logs' : trailingslashit(WP_CONTENT_DIR) . 'form-one-logs';

        if (!is_dir($base_dir)) {
            wp_mkdir_p($base_dir);
        }

        if (is_dir($base_dir) && !file_exists(trailingslashit($base_dir) . 'index.php')) {
            @file_put_contents(trailingslashit($base_dir) . 'index.php', "<?php\n// Silence is golden.\n");
        }

        $file = trailingslashit($base_dir) . 'fone-' . $context . '-debug.log';
        $line = '[' . current_time('mysql') . '] ' . wp_strip_all_tags((string) $message) . "\n";
        return (bool) @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
    }
}

if (!function_exists('fone_clean_bool')) {
    function fone_clean_bool($value) {
        return !empty($value) ? 1 : 0;
    }
}

if (!function_exists('fone_clean_whatsapp_number')) {
    function fone_clean_whatsapp_number($number) {
        $number = trim((string) $number);
        if ($number === '') return '';
        $number = preg_replace('/[^0-9+]/', '', $number);
        if (strpos($number, '00') === 0) {
            $number = '+' . substr($number, 2);
        }
        return $number;
    }
}

if (!function_exists('fone_sanitize_global_settings')) {
    function fone_sanitize_global_settings($input) {
        $input = is_array($input) ? $input : [];
        $out = fone_get_global_settings();

        if (array_key_exists('load_front_css', $input)) $out['load_front_css'] = fone_clean_bool($input['load_front_css']);
        if (array_key_exists('load_front_js', $input)) $out['load_front_js'] = fone_clean_bool($input['load_front_js']);
        if (array_key_exists('save_entries', $input)) $out['save_entries'] = fone_clean_bool($input['save_entries']);
        if (array_key_exists('debug_enabled', $input)) $out['debug_enabled'] = fone_clean_bool($input['debug_enabled']);

        if (array_key_exists('builder_interface', $input)) {
            $builder_interface = sanitize_key(wp_unslash($input['builder_interface']));
            $out['builder_interface'] = in_array($builder_interface, ['classic', 'modern'], true) ? $builder_interface : 'modern';
        }

        if (array_key_exists('whatsapp_enabled', $input)) $out['whatsapp_enabled'] = fone_clean_bool($input['whatsapp_enabled']);
        if (array_key_exists('whatsapp_number', $input)) $out['whatsapp_number'] = fone_clean_whatsapp_number($input['whatsapp_number']);
        if (array_key_exists('whatsapp_button_label', $input)) $out['whatsapp_button_label'] = sanitize_text_field(wp_unslash($input['whatsapp_button_label']));
        if (array_key_exists('whatsapp_message', $input)) $out['whatsapp_message'] = sanitize_textarea_field(wp_unslash($input['whatsapp_message']));
        if (array_key_exists('whatsapp_include_values', $input)) $out['whatsapp_include_values'] = fone_clean_bool($input['whatsapp_include_values']);
        if (array_key_exists('whatsapp_entry_message', $input)) $out['whatsapp_entry_message'] = sanitize_textarea_field(wp_unslash($input['whatsapp_entry_message']));

        if (array_key_exists('webhook_enabled', $input)) $out['webhook_enabled'] = fone_clean_bool($input['webhook_enabled']);
        if (array_key_exists('webhook_url', $input)) $out['webhook_url'] = esc_url_raw(wp_unslash($input['webhook_url']));
        if (array_key_exists('webhook_send_values', $input)) $out['webhook_send_values'] = fone_clean_bool($input['webhook_send_values']);
        if (array_key_exists('webhook_send_meta', $input)) $out['webhook_send_meta'] = fone_clean_bool($input['webhook_send_meta']);
        if (array_key_exists('webhook_timeout', $input)) $out['webhook_timeout'] = max(3, min(30, absint($input['webhook_timeout'])));

        if (empty($out['whatsapp_button_label'])) $out['whatsapp_button_label'] = 'Scrivici su WhatsApp';
        if (empty($out['whatsapp_message'])) $out['whatsapp_message'] = 'Ciao, ho appena inviato una richiesta dal sito.';
        if (empty($out['whatsapp_entry_message'])) $out['whatsapp_entry_message'] = 'Ciao, ti contatto per la richiesta inviata sul sito.';
        if (empty($out['webhook_timeout'])) $out['webhook_timeout'] = 8;

        return wp_parse_args($out, fone_global_default_settings());
    }
}

if (!function_exists('fone_update_global_settings_from_post')) {
    function fone_update_global_settings_from_post() {
        if (!current_user_can('manage_options')) return;

        if (!empty($_POST['fone_global_license_submit'])) {
            if (empty($_POST['fone_global_settings_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_global_settings_nonce'])), 'fone_save_global_settings')) return;
            $code  = isset($_POST['fone_license_code']) ? sanitize_text_field(wp_unslash($_POST['fone_license_code'])) : '';
            $email = isset($_POST['fone_license_email']) ? sanitize_email(wp_unslash($_POST['fone_license_email'])) : '';
            if (function_exists('fone_license_verify_remote')) {
                fone_license_verify_remote($code, $email, false);
                add_settings_error('fone_global_settings', 'license_checked', __('Licenza verificata.', 'form-one'), 'updated');
            }
            return;
        }

        if (!empty($_POST['fone_global_license_deactivate'])) {
            if (empty($_POST['fone_global_settings_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_global_settings_nonce'])), 'fone_save_global_settings')) return;
            if (function_exists('fone_save_license')) {
                fone_save_license([
                    'code'       => '',
                    'status'     => 'inactive',
                    'expires'    => '',
                    'message'    => __('Licenza disattivata localmente.', 'form-one'),
                    'last_check' => time(),
                ]);
                add_settings_error('fone_global_settings', 'license_deactivated', __('Licenza disattivata.', 'form-one'), 'updated');
            }
            return;
        }

        if (empty($_POST['fone_save_global_settings'])) return;
        if (empty($_POST['fone_global_settings_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_global_settings_nonce'])), 'fone_save_global_settings')) return;
        $input = isset($_POST['fone_global_settings']) && is_array($_POST['fone_global_settings']) ? wp_unslash($_POST['fone_global_settings']) : [];
        update_option('fone_global_settings', fone_sanitize_global_settings($input), false);
        add_settings_error('fone_global_settings', 'saved', __('Impostazioni Form One salvate.', 'form-one'), 'updated');
    }
}
add_action('admin_init', 'fone_update_global_settings_from_post');

if (!function_exists('fone_template_definitions')) {
    function fone_template_definitions() {
        return [
            'preventivo-veloce' => [
                'name' => 'Richiesta preventivo veloce',
                'description' => 'Tre step leggeri: contatto, bisogno, conferma. Pensato per non spaventare subito l\'utente.',
                'fields' => [
                    ['type'=>'html','slug'=>'intro','label'=>'<strong>Partiamo dalle cose essenziali.</strong><br>Ti chiediamo pochi dati per capire come aiutarti.','step'=>1,'width'=>'full'],
                    ['type'=>'text','slug'=>'name','label'=>'Nome','placeholder'=>'Il tuo nome','required'=>1,'step'=>1,'width'=>'half'],
                    ['type'=>'email','slug'=>'email','label'=>'Email','placeholder'=>'nome@email.it','required'=>1,'step'=>1,'width'=>'half'],
                    ['type'=>'select','slug'=>'service','label'=>'Che cosa ti serve?','placeholder'=>'Scegli una voce','options'=>'Sito web\nLanding page\nModulo contatti\nAutomazione\nAltro','required'=>1,'step'=>2,'width'=>'full'],
                    ['type'=>'textarea','slug'=>'message','label'=>'Raccontaci in breve il progetto','placeholder'=>'Scrivi poche righe, anche semplici.','required'=>0,'step'=>2,'width'=>'full'],
                    ['type'=>'tel','slug'=>'phone','label'=>'Telefono / WhatsApp','placeholder'=>'+39 ...','required'=>0,'step'=>3,'width'=>'half'],
                    ['type'=>'consent','slug'=>'privacy','label'=>'Accetto il trattamento dei dati per essere ricontattato.','required'=>1,'step'=>3,'width'=>'full'],
                    ['type'=>'submit','slug'=>'submit','label'=>'Richiedi il preventivo','step'=>3,'width'=>'full'],
                ],
            ],
            'lead-magnet' => [
                'name' => 'Lead magnet leggero',
                'description' => 'Template essenziale per scaricare una risorsa senza creare attrito inutile.',
                'fields' => [
                    ['type'=>'html','slug'=>'intro','label'=>'<strong>Ricevi la risorsa gratuita.</strong><br>Inserisci i dati minimi: niente passaggi inutili.','step'=>1,'width'=>'full'],
                    ['type'=>'text','slug'=>'name','label'=>'Nome','placeholder'=>'Il tuo nome','required'=>0,'step'=>1,'width'=>'half'],
                    ['type'=>'email','slug'=>'email','label'=>'Email','placeholder'=>'nome@email.it','required'=>1,'step'=>1,'width'=>'half'],
                    ['type'=>'consent','slug'=>'privacy','label'=>'Accetto di ricevere la risorsa e comunicazioni collegate.','required'=>1,'step'=>2,'width'=>'full'],
                    ['type'=>'submit','slug'=>'submit','label'=>'Ricevi la risorsa','step'=>2,'width'=>'full'],
                ],
            ],
            'iscrizione-evento' => [
                'name' => 'Iscrizione evento',
                'description' => 'Per raccogliere iscrizioni a eventi, webinar, incontri o presentazioni.',
                'fields' => [
                    ['type'=>'text','slug'=>'name','label'=>'Nome e cognome','placeholder'=>'Mario Rossi','required'=>1,'step'=>1,'width'=>'full'],
                    ['type'=>'email','slug'=>'email','label'=>'Email','placeholder'=>'nome@email.it','required'=>1,'step'=>1,'width'=>'half'],
                    ['type'=>'tel','slug'=>'phone','label'=>'Telefono','placeholder'=>'+39 ...','required'=>0,'step'=>1,'width'=>'half'],
                    ['type'=>'number','slug'=>'participants','label'=>'Numero partecipanti','placeholder'=>'1','required'=>0,'step'=>2,'width'=>'half','default_value'=>'1'],
                    ['type'=>'textarea','slug'=>'notes','label'=>'Note o richieste','placeholder'=>'Scrivi qui eventuali esigenze.','required'=>0,'step'=>2,'width'=>'full'],
                    ['type'=>'consent','slug'=>'privacy','label'=>'Accetto il trattamento dei dati per l\'iscrizione.','required'=>1,'step'=>2,'width'=>'full'],
                    ['type'=>'submit','slug'=>'submit','label'=>'Conferma iscrizione','step'=>2,'width'=>'full'],
                ],
            ],
            'candidatura-smart' => [
                'name' => 'Candidatura smart',
                'description' => 'Modulo candidatura con dati essenziali, file e messaggio breve.',
                'fields' => [
                    ['type'=>'text','slug'=>'name','label'=>'Nome e cognome','placeholder'=>'Mario Rossi','required'=>1,'step'=>1,'width'=>'full'],
                    ['type'=>'email','slug'=>'email','label'=>'Email','placeholder'=>'nome@email.it','required'=>1,'step'=>1,'width'=>'half'],
                    ['type'=>'tel','slug'=>'phone','label'=>'Telefono','placeholder'=>'+39 ...','required'=>0,'step'=>1,'width'=>'half'],
                    ['type'=>'file','slug'=>'cv','label'=>'Carica CV','required'=>0,'step'=>2,'width'=>'full','accept_types'=>'application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document','max_size_mb'=>'10'],
                    ['type'=>'textarea','slug'=>'message','label'=>'Perché ti interessa?','placeholder'=>'Scrivi poche righe.','required'=>0,'step'=>2,'width'=>'full'],
                    ['type'=>'consent','slug'=>'privacy','label'=>'Accetto il trattamento dei dati per la candidatura.','required'=>1,'step'=>3,'width'=>'full'],
                    ['type'=>'submit','slug'=>'submit','label'=>'Invia candidatura','step'=>3,'width'=>'full'],
                ],
            ],
            'registrazione-utenti' => [
                'name' => 'Registrazione utenti',
                'description' => 'Form di registrazione completo: crea automaticamente l\'utente WordPress.',
                'fields' => [
                    ['type'=>'html','slug'=>'intro','label'=>'<strong>Crea il tuo account.</strong><br>Pochi dati per iniziare. Potrai completare il profilo dopo.','step'=>1,'width'=>'full'],
                    ['type'=>'text','slug'=>'first_name','label'=>'Nome','placeholder'=>'Il tuo nome','required'=>1,'step'=>1,'width'=>'half','wp_field'=>'first_name'],
                    ['type'=>'text','slug'=>'last_name','label'=>'Cognome','placeholder'=>'Il tuo cognome','required'=>1,'step'=>1,'width'=>'half','wp_field'=>'last_name'],
                    ['type'=>'email','slug'=>'email','label'=>'Email','placeholder'=>'nome@email.it','required'=>1,'step'=>2,'width'=>'full','wp_field'=>'user_email'],
                    ['type'=>'password','slug'=>'password','label'=>'Password','placeholder'=>'Almeno 8 caratteri','required'=>1,'step'=>2,'width'=>'full','wp_field'=>'user_pass','opt_min_length'=>8,'opt_show_strength'=>1],
                    ['type'=>'consent','slug'=>'privacy','label'=>'Accetto il trattamento dei dati per la registrazione.','required'=>1,'step'=>3,'width'=>'full'],
                    ['type'=>'submit','slug'=>'submit','label'=>'Crea il mio account','step'=>3,'width'=>'full'],
                ],
                'enable_registration' => 1,
            ],
        ];
    }
}

if (!function_exists('fone_template_field')) {
    function fone_template_field($field, $index) {
        return wp_parse_args($field, [
            'id' => 'fone_tpl_' . substr(md5($field['slug'] . $index . wp_rand()), 0, 8),
            'type' => 'text',
            'slug' => 'field_' . $index,
            'label' => '',
            'placeholder' => '',
            'help' => '',
            'required' => 0,
            'step' => 1,
            'width' => 'full',
            'options' => '',
            'max_chars' => '',
            'autocomp' => 'off',
            'meta_key' => '',
            'accept_types' => '',
            'max_size_mb' => '',
            'default_value' => '',
            'opt_min' => '',
            'opt_max' => '',
            'opt_step' => '',
        ]);
    }
}

if (!function_exists('fone_create_form_from_template')) {
    function fone_create_form_from_template($template_key) {
        $templates = fone_template_definitions();
        if (empty($templates[$template_key])) return 0;
        $tpl = $templates[$template_key];
        $form_id = fone_create_form($tpl['name']);
        if (!$form_id) return 0;
        $schema = [];
        foreach ($tpl['fields'] as $i => $field) {
            $schema[] = fone_template_field($field, $i);
        }
        $settings = fone_default_settings();
        $settings['success_message'] = 'Grazie, richiesta inviata correttamente.';
        $settings['form_subtitle'] = $tpl['description'];

        // Applica eventuali setting opzionali dal template
        if (!empty($tpl['enable_registration'])) {
            $settings['enable_registration'] = 1;
            $settings['registration_role'] = isset($tpl['registration_role']) ? $tpl['registration_role'] : 'subscriber';
            $settings['registration_autologin'] = 1;
            $settings['registration_send_wp_email'] = 1;
            $settings['success_message'] = 'Account creato con successo. Benvenuto!';
        }

        fone_save_form($form_id, [
            'schema' => $schema,
            'settings' => $settings,
            'layouts' => [],
        ]);

        // Se è un form di registrazione, segnalo come "is_registration"
        if (!empty($tpl['enable_registration']) && function_exists('fone_set_registration_form')) {
            fone_set_registration_form($form_id);
        }

        return $form_id;
    }
}

if (!function_exists('fone_handle_template_create')) {
    function fone_handle_template_create() {
        if (!current_user_can('manage_options')) return;
        if (empty($_POST['fone_create_template'])) return;
        if (empty($_POST['fone_template_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_template_nonce'])), 'fone_create_template')) return;
        $key = sanitize_key(wp_unslash($_POST['fone_template_key'] ?? ''));
        $form_id = fone_create_form_from_template($key);
        if ($form_id) {
            wp_safe_redirect(admin_url('admin.php?page=fone-builder&form_id=' . $form_id . '&fone_msg=created'));
            exit;
        }
        add_settings_error('fone_global_settings', 'template_error', __('Template non valido o non creato.', 'form-one'), 'error');
    }
}
add_action('admin_init', 'fone_handle_template_create');

if (!function_exists('fone_field_value_by_types')) {
    function fone_field_value_by_types($schema, $values, $types = [], $slugs = []) {
        foreach ((array) $schema as $field) {
            $id = $field['id'] ?? '';
            if (!$id || !isset($values[$id])) continue;
            $type = $field['type'] ?? '';
            $slug = $field['slug'] ?? '';
            $value = $values[$id];
            if (is_array($value)) $value = implode(', ', array_map('sanitize_text_field', $value));
            $value = trim((string) $value);
            if ($value === '') continue;
            if ($types && in_array($type, $types, true)) return $value;
            if ($slugs && in_array($slug, $slugs, true)) return $value;
        }
        return '';
    }
}

if (!function_exists('fone_entry_summary_text')) {
    function fone_entry_summary_text($entry_or_schema, $values = null) {
        if ($values === null && is_array($entry_or_schema) && isset($entry_or_schema['schema'], $entry_or_schema['values'])) {
            $schema = $entry_or_schema['schema'];
            $values = $entry_or_schema['values'];
        } else {
            $schema = $entry_or_schema;
        }
        $lines = [];
        foreach ((array) $schema as $field) {
            $type = $field['type'] ?? '';
            if (empty($field['id']) || in_array($type, ['html','submit','password','paypal_button'], true)) continue;
            $id = $field['id'];
            $label = !empty($field['label']) ? wp_strip_all_tags($field['label']) : $id;
            $value = $values[$id] ?? '';
            if ($type === 'avatar') {
                $value = !empty($values[$id . '__url']) ? $values[$id . '__url'] : $value;
            }
            if (is_array($value)) $value = implode(', ', $value);
            $value = trim(wp_strip_all_tags((string) $value));
            if ($value === '') continue;
            $lines[] = $label . ': ' . $value;
        }
        return implode("\n", $lines);
    }
}

if (!function_exists('fone_resolve_whatsapp_config')) {
    function fone_resolve_whatsapp_config($form_settings = []) {
        $global = fone_get_global_settings();
        $mode = $form_settings['whatsapp_mode'] ?? 'inherit';
        if ($mode === 'off') return null;
        $cfg = [
            'enabled' => !empty($global['whatsapp_enabled']),
            'number' => $global['whatsapp_number'] ?? '',
            'button_label' => $global['whatsapp_button_label'] ?? 'Scrivici su WhatsApp',
            'message' => $global['whatsapp_message'] ?? 'Ciao, ho appena inviato una richiesta dal sito.',
            'include_values' => !empty($global['whatsapp_include_values']),
        ];
        if ($mode === 'custom') {
            $cfg['enabled'] = !empty($form_settings['whatsapp_enabled']);
            $cfg['number'] = fone_clean_whatsapp_number($form_settings['whatsapp_number'] ?? $cfg['number']);
            $cfg['button_label'] = !empty($form_settings['whatsapp_button_label']) ? $form_settings['whatsapp_button_label'] : $cfg['button_label'];
            $cfg['message'] = !empty($form_settings['whatsapp_message']) ? $form_settings['whatsapp_message'] : $cfg['message'];
            $cfg['include_values'] = !empty($form_settings['whatsapp_include_values']);
        }
        if (empty($cfg['enabled']) || empty($cfg['number'])) return null;
        return $cfg;
    }
}

if (!function_exists('fone_whatsapp_href')) {
    function fone_whatsapp_href($number, $message) {
        $number = fone_clean_whatsapp_number($number);
        if ($number === '') return '';
        $digits = preg_replace('/[^0-9]/', '', $number);
        if ($digits === '') return '';
        return 'https://wa.me/' . $digits . '?text=' . rawurlencode((string) $message);
    }
}

if (!function_exists('fone_render_success_whatsapp_button')) {
    function fone_render_success_whatsapp_button($form_settings, $schema, $values, $form_id) {
        $cfg = fone_resolve_whatsapp_config($form_settings);
        if (!$cfg) return '';
        $message = (string) $cfg['message'];
        if (!empty($cfg['include_values']) && is_array($values) && !empty($values)) {
            $summary = fone_entry_summary_text($schema, $values);
            if ($summary !== '') $message .= "\n\nDati inviati:\n" . $summary;
        }
        $href = fone_whatsapp_href($cfg['number'], $message);
        if (!$href) return '';
        return '<a class="fone-whatsapp-btn" href="' . esc_url($href) . '" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i> ' . esc_html($cfg['button_label']) . '</a>';
    }
}

if (!function_exists('fone_resolve_webhook_config')) {
    function fone_resolve_webhook_config($form_settings = []) {
        $global = fone_get_global_settings();
        $mode = $form_settings['webhook_mode'] ?? 'inherit';
        if ($mode === 'off') return null;
        $cfg = [
            'enabled' => !empty($global['webhook_enabled']),
            'url' => $global['webhook_url'] ?? '',
            'send_values' => !empty($global['webhook_send_values']),
            'send_meta' => !empty($global['webhook_send_meta']),
            'timeout' => max(3, min(30, absint($global['webhook_timeout'] ?? 8))),
        ];
        if ($mode === 'custom') {
            $cfg['enabled'] = !empty($form_settings['webhook_enabled']);
            $cfg['url'] = esc_url_raw($form_settings['webhook_url'] ?? '');
            $cfg['send_values'] = !empty($form_settings['webhook_send_values']);
            $cfg['send_meta'] = !empty($form_settings['webhook_send_meta']);
        }
        if (empty($cfg['enabled']) || empty($cfg['url'])) return null;
        return $cfg;
    }
}

if (!function_exists('fone_dispatch_webhook')) {
    function fone_dispatch_webhook($values, $schema, $form_id = 0) {
        $form = $form_id ? fone_get_form($form_id) : null;
        $settings = $form ? $form['settings'] : [];
        $cfg = fone_resolve_webhook_config($settings);
        if (!$cfg) return;

        $payload = [
            'event' => 'form_one_submission',
            'plugin' => 'Form One',
            'version' => defined('FONE_VERSION') ? FONE_VERSION : '',
            'form_id' => (int) $form_id,
            'form_name' => $form['form_name'] ?? '',
            'submitted_at' => current_time('mysql'),
        ];
        if (!empty($cfg['send_values'])) $payload['values'] = $values;
        if (!empty($cfg['send_meta'])) {
            $payload['meta'] = [
                'site_url' => home_url(),
                'page_url' => isset($_SERVER['REQUEST_URI']) ? esc_url_raw(home_url(wp_unslash($_SERVER['REQUEST_URI']))) : '',
                'ip' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '',
                'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '',
            ];
        }
        $response = wp_remote_post($cfg['url'], [
            'timeout' => (int) $cfg['timeout'],
            'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
            'body' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE),
        ]);
        $log = [
            'time' => current_time('mysql'),
            'url' => $cfg['url'],
            'form_id' => (int) $form_id,
            'ok' => !is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) >= 200 && (int) wp_remote_retrieve_response_code($response) < 300,
            'code' => is_wp_error($response) ? 0 : (int) wp_remote_retrieve_response_code($response),
            'message' => is_wp_error($response) ? $response->get_error_message() : wp_remote_retrieve_response_message($response),
        ];
        set_transient('fone_last_webhook_log', $log, DAY_IN_SECONDS);
        if (!empty(fone_get_global_settings()['debug_enabled'])) {
            error_log('[Form One WEBHOOK] ' . wp_json_encode($log));
        }
    }
}
add_action('fone_after_submission', 'fone_dispatch_webhook', 20, 3);

if (!function_exists('fone_get_entry_statuses')) {
    function fone_get_entry_statuses() {
        $statuses = get_option('fone_entry_statuses', []);
        return is_array($statuses) ? $statuses : [];
    }
}

if (!function_exists('fone_get_entry_status')) {
    function fone_get_entry_status($entry_id) {
        $statuses = fone_get_entry_statuses();
        return sanitize_key($statuses[(int) $entry_id] ?? 'nuovo');
    }
}

if (!function_exists('fone_set_entry_status')) {
    function fone_set_entry_status($entry_id, $status) {
        $allowed = ['nuovo','da_contattare','contattato','interessato','cliente','perso','archiviato'];
        $status = sanitize_key($status);
        if (!in_array($status, $allowed, true)) $status = 'nuovo';
        $statuses = fone_get_entry_statuses();
        $statuses[(int) $entry_id] = $status;
        update_option('fone_entry_statuses', $statuses, false);
    }
}

if (!function_exists('fone_entry_status_label')) {
    function fone_entry_status_label($status) {
        $labels = [
            'nuovo' => 'Nuovo',
            'da_contattare' => 'Da contattare',
            'contattato' => 'Contattato',
            'interessato' => 'Interessato',
            'cliente' => 'Cliente',
            'perso' => 'Perso',
            'archiviato' => 'Archiviato',
        ];
        return $labels[$status] ?? 'Nuovo';
    }
}

if (!function_exists('fone_handle_entry_status_update')) {
    function fone_handle_entry_status_update() {
        if (!current_user_can('manage_options')) return;
        if (empty($_POST['fone_update_entry_status'])) return;
        if (empty($_POST['fone_entry_status_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_entry_status_nonce'])), 'fone_update_entry_status')) return;
        $entry_id = absint($_POST['fone_entry_id'] ?? 0);
        $status = sanitize_key(wp_unslash($_POST['fone_entry_status'] ?? 'nuovo'));
        if ($entry_id) {
            fone_set_entry_status($entry_id, $status);
            add_settings_error('fone_entries_notices', 'status_updated', __('Stato lead aggiornato.', 'form-one'), 'updated');
        }
    }
}
add_action('admin_init', 'fone_handle_entry_status_update');

if (!function_exists('fone_global_settings_page')) {
    function fone_global_settings_page() {
        if (!current_user_can('manage_options')) return;
        settings_errors('fone_global_settings');
        $settings = fone_get_global_settings();
        $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'generali';
        $tabs = [
            'generali' => 'Generali',
            'invii' => 'Invii',
            'whatsapp' => 'WhatsApp',
            'webhook' => 'Webhook',
            'licenza' => 'Licenza Pro',
            'debug' => 'Debug',
            'strumenti' => 'Strumenti',
        ];
        ?>
        <div class="wrap fone-admin-wrap fone-settings-wrap">
            <div class="fone-admin-header">
                <div>
                    <h1 class="fone-admin-title"><i class="fa-solid fa-gear" aria-hidden="true"></i> <?php esc_html_e('Impostazioni Form One', 'form-one'); ?></h1>
                    <p class="fone-hint"><?php esc_html_e('Impostazioni globali valide per tutto il plugin. I singoli form possono usare queste impostazioni o sovrascriverle dal builder.', 'form-one'); ?></p>
                </div>
            </div>
            <nav class="fone-settings-tabs">
                <?php foreach ($tabs as $key => $label) : ?>
                    <a class="fone-settings-tab <?php echo $tab === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=fone-settings&tab=' . $key)); ?>"><?php echo esc_html($label); ?></a>
                <?php endforeach; ?>
            </nav>

            <?php if ($tab !== 'strumenti') : ?>
            <form method="post" class="fone-settings-panel">
                <?php wp_nonce_field('fone_save_global_settings', 'fone_global_settings_nonce'); ?>
                <input type="hidden" name="fone_save_global_settings" value="1">
                <?php if ($tab === 'generali') : ?>
                    <h2>Generali</h2>
                    <label class="fone-toggle-row"><input type="hidden" name="fone_global_settings[load_front_css]" value="0"><input type="checkbox" name="fone_global_settings[load_front_css]" value="1" <?php checked(!empty($settings['load_front_css'])); ?>> <span>Carica CSS frontend di Form One</span></label>
                    <label class="fone-toggle-row"><input type="hidden" name="fone_global_settings[load_front_js]" value="0"><input type="checkbox" name="fone_global_settings[load_front_js]" value="1" <?php checked(!empty($settings['load_front_js'])); ?>> <span>Carica JavaScript frontend di Form One</span></label>
                    <p class="fone-hint">Disattiva queste voci solo per test avanzati: senza JS il multi-step e alcune funzioni non lavorano.</p>
                    <div class="fone-settings-ui-choice" style="margin-top:18px;padding-top:16px;border-top:1px solid #e2e8f0;">
                        <h3 style="margin:0 0 8px;">Interfaccia Builder</h3>
                        <p class="fone-hint" style="margin-top:0;">Scegli se usare il builder storico a tre colonne o la nuova interfaccia moderna con le opzioni del campo nella colonna sinistra.</p>
                        <label>
                            <span>Modalità interfaccia</span>
                            <select name="fone_global_settings[builder_interface]" class="regular-text">
                                <option value="classic" <?php selected($settings['builder_interface'] ?? 'modern', 'classic'); ?>>Interfaccia attuale / classica</option>
                                <option value="modern" <?php selected($settings['builder_interface'] ?? 'modern', 'modern'); ?>>Nuova interfaccia moderna</option>
                            </select>
                        </label>
                    </div>
                <?php elseif ($tab === 'invii') : ?>
                    <h2>Invii</h2>
                    <label class="fone-toggle-row"><input type="hidden" name="fone_global_settings[save_entries]" value="0"><input type="checkbox" name="fone_global_settings[save_entries]" value="1" <?php checked(!empty($settings['save_entries'])); ?>> <span>Salva gli invii nel database</span></label>
                    <div class="fone-stats-grid">
                        <div class="fone-stat-box"><strong><?php echo (int) fone_db_count_entries(); ?></strong><span>Invii totali</span></div>
                        <div class="fone-stat-box"><strong><?php echo (int) count(fone_get_all_forms()); ?></strong><span>Form presenti</span></div>
                    </div>
                    <p class="fone-hint">La dashboard avanzata per view/start/completamenti arriverà su questa base. Ora il plugin conserva e lavora gli invii reali.</p>
                <?php elseif ($tab === 'whatsapp') : ?>
                    <h2>WhatsApp globale</h2>
                    <label class="fone-toggle-row"><input type="hidden" name="fone_global_settings[whatsapp_enabled]" value="0"><input type="checkbox" name="fone_global_settings[whatsapp_enabled]" value="1" <?php checked(!empty($settings['whatsapp_enabled'])); ?>> <span>Abilita pulsante WhatsApp dopo invio</span></label>
                    <label>Numero WhatsApp predefinito</label>
                    <input type="text" name="fone_global_settings[whatsapp_number]" value="<?php echo esc_attr($settings['whatsapp_number']); ?>" placeholder="+391234567890" class="regular-text">
                    <label>Testo pulsante</label>
                    <input type="text" name="fone_global_settings[whatsapp_button_label]" value="<?php echo esc_attr($settings['whatsapp_button_label']); ?>" class="regular-text">
                    <label>Messaggio predefinito dopo invio</label>
                    <textarea name="fone_global_settings[whatsapp_message]" rows="4" class="large-text"><?php echo esc_textarea($settings['whatsapp_message']); ?></textarea>
                    <label class="fone-toggle-row"><input type="hidden" name="fone_global_settings[whatsapp_include_values]" value="0"><input type="checkbox" name="fone_global_settings[whatsapp_include_values]" value="1" <?php checked(!empty($settings['whatsapp_include_values'])); ?>> <span>Includi riepilogo dati inviati nel messaggio WhatsApp frontend</span></label>
                    <label>Messaggio rapido da backend verso il lead</label>
                    <textarea name="fone_global_settings[whatsapp_entry_message]" rows="3" class="large-text"><?php echo esc_textarea($settings['whatsapp_entry_message']); ?></textarea>
                <?php elseif ($tab === 'webhook') : ?>
                    <h2>Webhook globale</h2>
                    <label class="fone-toggle-row"><input type="hidden" name="fone_global_settings[webhook_enabled]" value="0"><input type="checkbox" name="fone_global_settings[webhook_enabled]" value="1" <?php checked(!empty($settings['webhook_enabled'])); ?>> <span>Invia ogni submission a un webhook</span></label>
                    <label>URL webhook</label>
                    <input type="url" name="fone_global_settings[webhook_url]" value="<?php echo esc_attr($settings['webhook_url']); ?>" placeholder="https://hook.eu1.make.com/..." class="large-text">
                    <label class="fone-toggle-row"><input type="hidden" name="fone_global_settings[webhook_send_values]" value="0"><input type="checkbox" name="fone_global_settings[webhook_send_values]" value="1" <?php checked(!empty($settings['webhook_send_values'])); ?>> <span>Invia valori del form</span></label>
                    <label class="fone-toggle-row"><input type="hidden" name="fone_global_settings[webhook_send_meta]" value="0"><input type="checkbox" name="fone_global_settings[webhook_send_meta]" value="1" <?php checked(!empty($settings['webhook_send_meta'])); ?>> <span>Invia meta tecnici: sito, pagina, IP, user agent</span></label>
                    <label>Timeout richiesta webhook</label>
                    <input type="number" min="3" max="30" name="fone_global_settings[webhook_timeout]" value="<?php echo (int) $settings['webhook_timeout']; ?>" style="width:90px;"> secondi
                    <?php $last = get_transient('fone_last_webhook_log'); if ($last) : ?>
                        <div class="fone-debug-box"><strong>Ultimo webhook:</strong><br><pre><?php echo esc_html(print_r($last, true)); ?></pre></div>
                    <?php endif; ?>
                <?php elseif ($tab === 'licenza') : ?>
                    <?php $lic = function_exists('fone_get_license') ? fone_get_license() : ['status'=>'inactive','code'=>'','email'=>'','message'=>'','last_check'=>0]; ?>
                    <h2>Licenza Pro</h2>
                    <div class="fone-pro-box">
                        <h3>Form One Pro</h3>
                        <p>Inserisci qui il seriale per sbloccare le funzioni avanzate nel builder. Per i test di Gigi il seriale valido è quello concordato internamente.</p>
                        <p><strong>Stato:</strong> <?php echo !empty($lic['status']) && $lic['status'] === 'active' ? '<i class="fa-solid fa-circle-check" aria-hidden="true"></i> Attiva' : '<i class="fa-solid fa-lock" aria-hidden="true"></i> Free / non attiva'; ?></p>
                        <?php if (!empty($lic['message'])) : ?><p class="fone-hint"><?php echo esc_html($lic['message']); ?></p><?php endif; ?>
                    </div>
                    <label>Codice seriale</label>
                    <input type="text" name="fone_license_code" value="<?php echo esc_attr($lic['code'] ?? ''); ?>" class="regular-text code" placeholder="XXXX-XXXX-XXXX-XXXX" style="font-family:monospace;letter-spacing:1px;">
                    <label>Email licenza</label>
                    <input type="email" name="fone_license_email" value="<?php echo esc_attr(!empty($lic['email']) ? $lic['email'] : wp_get_current_user()->user_email); ?>" class="regular-text">
                    <p style="margin-top:16px;">
                        <button type="submit" name="fone_global_license_submit" value="1" class="fone-btn fone-btn-primary"><i class="fa-solid fa-unlock-keyhole" aria-hidden="true"></i> Attiva / verifica seriale</button>
                        <?php if (!empty($lic['status']) && $lic['status'] === 'active') : ?>
                            <button type="submit" name="fone_global_license_deactivate" value="1" class="fone-btn" onclick="return confirm('Disattivare la licenza su questo sito?');">Disattiva</button>
                        <?php endif; ?>
                    </p>
                <?php elseif ($tab === 'debug') : ?>
                    <h2>Debug</h2>
                    <label class="fone-toggle-row"><input type="hidden" name="fone_global_settings[debug_enabled]" value="0"><input type="checkbox" name="fone_global_settings[debug_enabled]" value="1" <?php checked(!empty($settings['debug_enabled'])); ?>> <span>Abilita log debug Form One</span></label>
                    <div class="fone-debug-box">
                        <strong>Ambiente</strong>
                        <pre><?php
                            echo esc_html('Form One: ' . (defined('FONE_VERSION') ? FONE_VERSION : '?') . "\n");
                            echo esc_html('WordPress: ' . get_bloginfo('version') . "\n");
                            echo esc_html('PHP: ' . PHP_VERSION . "\n");
                            echo esc_html('DB Form One: ' . get_option('fone_db_version', '?') . "\n");
                            echo esc_html('Forms table: ' . fone_table_forms() . "\n");
                            echo esc_html('Entries table: ' . fone_table_entries() . "\n");
                        ?></pre>
                    </div>
                    <?php $debug = get_transient('fone_reg_debug'); if ($debug) : ?>
                    <div class="fone-debug-box"><strong>Ultima diagnostica registrazione</strong><pre><?php echo esc_html(print_r($debug, true)); ?></pre></div>
                    <?php endif; ?>
                <?php endif; ?>
                <p><button type="submit" class="fone-btn fone-btn-primary"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Salva impostazioni</button></p>
            </form>
            <?php else : ?>
                <div class="fone-settings-panel">
                    <h2>Strumenti</h2>

                    <!-- Setup Wizard riavvio -->
                    <div class="fone-tool-block" style="background:linear-gradient(135deg,#FAF7FF 0%,#FFEEF8 100%);border:1px solid #e4e4e7;border-radius:14px;padding:22px 24px;margin-bottom:24px;display:flex;align-items:center;gap:18px;flex-wrap:wrap;">
                        <div class="fone-tool-icon"><i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i></div>
                        <div style="flex:1;min-width:240px;">
                            <h3 style="margin:0 0 6px;font-size:16px;color:#1A1F4D;">Setup Wizard di benvenuto</h3>
                            <p style="margin:0;font-size:13px;color:#52525b;line-height:1.6;">
                                Rilancia il wizard guidato di configurazione iniziale: 5 step per creare un form pronto in 30 secondi (obiettivo, stile, email, pagina, completamento).
                            </p>
                        </div>
                        <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=fone-settings&tab=strumenti&fone_action=relaunch_wizard'), 'fone_relaunch_wizard')); ?>"
                           class="fone-btn fone-btn-primary"
                           style="white-space:nowrap;">
                            <i class="fa-solid fa-rocket" aria-hidden="true"></i> Avvia il wizard
                        </a>
                    </div>

                    <h3 style="margin:24px 0 10px;font-size:15px;color:#1A1F4D;">Template di partenza</h3>
                    <p class="fone-hint">Crea form già strutturati per ridurre l'abbandono. Ogni template crea un nuovo form modificabile nel builder.</p>
                    <div class="fone-template-grid">
                    <?php foreach (fone_template_definitions() as $key => $tpl) : ?>
                        <form method="post" class="fone-template-card">
                            <?php wp_nonce_field('fone_create_template', 'fone_template_nonce'); ?>
                            <input type="hidden" name="fone_template_key" value="<?php echo esc_attr($key); ?>">
                            <h3><?php echo esc_html($tpl['name']); ?></h3>
                            <p><?php echo esc_html($tpl['description']); ?></p>
                            <button type="submit" name="fone_create_template" value="1" class="fone-btn fone-btn-primary"><i class="fa-solid fa-plus" aria-hidden="true"></i> Crea questo form</button>
                        </form>
                    <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}


/* ---------------------------------------------------------------
   IMPORT / EXPORT FORM JSON
--------------------------------------------------------------- */

if (!function_exists('fone_export_form_json')) {
    function fone_export_form_json($form_id) {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Non autorizzato', 'form-one'));
        }

        $form = fone_get_form((int) $form_id);
        if (!$form) {
            wp_die(esc_html__('Form non trovato.', 'form-one'));
        }

        $payload = [
            'generator'  => 'Form One',
            'version'    => defined('FONE_VERSION') ? FONE_VERSION : '',
            'exported_at'=> current_time('mysql'),
            'form'       => [
                'form_name'  => $form['form_name'],
                'form_slug'  => $form['form_slug'],
                'schema'     => $form['schema'],
                'settings'   => $form['settings'],
                'layouts'    => $form['layouts'],
                'custom_css' => $form['custom_css'],
            ],
        ];

        $filename = 'form-one-' . sanitize_title($form['form_name']) . '-' . (int) $form_id . '.json';
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if (!function_exists('fone_import_form_json_upload')) {
    function fone_import_form_json_upload($file_key) {
        if (!current_user_can('manage_options')) return 0;
        if (empty($_FILES[$file_key]['tmp_name']) || !is_uploaded_file($_FILES[$file_key]['tmp_name'])) return 0;
        if (!empty($_FILES[$file_key]['size']) && (int) $_FILES[$file_key]['size'] > 1024 * 1024) return 0;

        $name = isset($_FILES[$file_key]['name']) ? sanitize_file_name($_FILES[$file_key]['name']) : '';
        if ($name && !preg_match('/\.json$/i', $name)) return 0;

        $raw = file_get_contents($_FILES[$file_key]['tmp_name']);
        if (!$raw || strlen($raw) > 1024 * 1024) return 0;

        $data = json_decode($raw, true);
        if (!is_array($data)) return 0;
        $form_data = isset($data['form']) && is_array($data['form']) ? $data['form'] : $data;

        $schema = isset($form_data['schema']) && is_array($form_data['schema']) ? $form_data['schema'] : [];
        if (!$schema) return 0;

        $name = !empty($form_data['form_name']) ? sanitize_text_field($form_data['form_name']) : __('Form importato', 'form-one');
        $form_id = fone_create_form($name . ' — import');
        if (!$form_id) return 0;

        $settings = isset($form_data['settings']) && is_array($form_data['settings'])
            ? wp_parse_args($form_data['settings'], fone_default_settings())
            : fone_default_settings();

        // Per sicurezza un import non può auto-diventare login/registrazione senza scelta esplicita.
        $settings['enable_registration'] = 0;
        $settings['enable_login'] = 0;

        $layouts = isset($form_data['layouts']) && is_array($form_data['layouts']) ? $form_data['layouts'] : [];
        $custom_css = isset($form_data['custom_css']) ? wp_strip_all_tags((string) $form_data['custom_css']) : fone_get_default_custom_css();

        fone_save_form($form_id, [
            'schema' => $schema,
            'settings' => $settings,
            'layouts' => $layouts,
            'custom_css' => $custom_css,
        ]);

        return (int) $form_id;
    }
}
