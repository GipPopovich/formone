<?php
/**
 * Form One — Pagina Invii + Export CSV
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('fone_entries_page')) {
    function fone_entries_page() {
        if (!current_user_can('manage_options')) return;
        settings_errors('fone_entries_notices');

        $form_id  = isset($_GET['form_id'])  ? (int) $_GET['form_id']  : 0;
        $form     = $form_id ? fone_get_form($form_id) : null;

        // Delete all per questo form
        if (
            !empty($_POST['fone_delete_all']) &&
            !empty($_POST['fone_delete_nonce']) &&
            wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_delete_nonce'])), 'fone_delete_entries')
        ) {
            fone_db_delete_all_entries($form_id);
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Tutti gli invii sono stati eliminati.', 'form-one') . '</p></div>';
        }

        // Delete single
        if (
            !empty($_POST['fone_delete_one']) &&
            !empty($_POST['fone_delete_one_nonce']) &&
            wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_delete_one_nonce'])), 'fone_delete_single')
        ) {
            fone_db_delete_entry((int) $_POST['fone_delete_one']);
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Invio eliminato.', 'form-one') . '</p></div>';
        }

        // Invia email manuale all'utente di un'entry
        if (
            !empty($_POST['fone_send_manual_email']) &&
            !empty($_POST['fone_manual_email_nonce']) &&
            wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_manual_email_nonce'])), 'fone_manual_email')
        ) {
            $entry_id = (int) $_POST['fone_send_manual_email'];
            $action_text = isset($_POST['fone_manual_action']) ? sanitize_textarea_field(wp_unslash($_POST['fone_manual_action'])) : '';
            $extra_msg   = isset($_POST['fone_manual_message']) ? sanitize_textarea_field(wp_unslash($_POST['fone_manual_message'])) : '';
            $cta_url     = isset($_POST['fone_manual_cta_url']) ? esc_url_raw(wp_unslash($_POST['fone_manual_cta_url'])) : '';
            $cta_label   = isset($_POST['fone_manual_cta_label']) ? sanitize_text_field(wp_unslash($_POST['fone_manual_cta_label'])) : '';

            $sent = fone_send_manual_action_email($entry_id, $action_text, $extra_msg, $cta_url, $cta_label);
            if ($sent === true) {
                echo '<div class="notice notice-success is-dismissible"><p>✅ ' . esc_html__('Email inviata con successo!', 'form-one') . '</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>⚠️ ' . esc_html($sent) . '</p></div>';
            }
        }

        $search      = isset($_GET['fone_search']) ? sanitize_text_field(wp_unslash($_GET['fone_search'])) : '';
        $per_page    = 20;
        $paged       = isset($_GET['fone_paged']) ? max(1, (int) $_GET['fone_paged']) : 1;
        $result      = fone_db_get_entries(['per_page' => $per_page, 'page' => $paged, 'search' => $search, 'form_id' => $form_id]);
        $filtered    = $result['entries'];
        $total       = $result['total'];
        $total_pages = $total > 0 ? (int) ceil($total / $per_page) : 1;
        $total_all   = fone_db_count_entries($form_id);

        $export_nonce = wp_create_nonce('fone_export_csv');
        $export_url   = admin_url('admin.php?action=fone_export_csv&fone_export_nonce=' . $export_nonce . ($form_id ? '&form_id=' . $form_id : ''));

        $all_forms    = fone_get_all_forms();
        ?>
        <div class="wrap fone-admin-wrap">
            <div class="fone-admin-header">
                <div class="fone-admin-header-left">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=fone-forms')); ?>" class="fone-back-link">← <?php esc_html_e('Tutti i Form', 'form-one'); ?></a>
                    <h1 class="fone-admin-title">
                        <?php esc_html_e('Invii ricevuti', 'form-one'); ?>
                        <?php if ($form) : ?>
                            — <span style="font-weight:400;font-size:18px;color:#64748b;"><?php echo esc_html($form['form_name']); ?></span>
                        <?php endif; ?>
                        <span class="fone-count-badge"><?php echo (int) $total_all; ?></span>
                    </h1>
                </div>
                <div class="fone-admin-header-right" style="gap:8px;display:flex;align-items:center;flex-wrap:wrap;">
                    <?php if (count($all_forms) > 1) : ?>
                    <select onchange="location.href=this.value" class="fone-select-sm">
                        <option value="<?php echo esc_url(admin_url('admin.php?page=fone-entries')); ?>"><?php esc_html_e('Tutti i form', 'form-one'); ?></option>
                        <?php foreach ($all_forms as $f) : ?>
                        <option value="<?php echo esc_url(admin_url('admin.php?page=fone-entries&form_id=' . $f['id'])); ?>" <?php selected($form_id, $f['id']); ?>>
                            <?php echo esc_html($f['form_name']); ?> (<?php echo (int) fone_db_count_entries($f['id']); ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php endif; ?>
                    <?php if ($total_all > 0) : ?>
                        <a href="<?php echo esc_url($export_url); ?>" class="fone-btn fone-btn-ghost">
                            ↓ <?php esc_html_e('Esporta CSV', 'form-one'); ?>
                        </a>
                        <form method="post" style="display:inline;" onsubmit="return confirm('<?php esc_attr_e('Eliminare tutti gli invii? Operazione irreversibile.', 'form-one'); ?>');">
                            <?php wp_nonce_field('fone_delete_entries', 'fone_delete_nonce'); ?>
                            <?php if ($form_id) : ?><input type="hidden" name="form_id" value="<?php echo (int) $form_id; ?>"><?php endif; ?>
                            <button type="submit" name="fone_delete_all" value="1" class="fone-btn fone-btn-danger">
                                🗑 <?php esc_html_e('Elimina tutti', 'form-one'); ?>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($total_all > 0) : ?>
            <form method="get" class="fone-entries-search-form">
                <input type="hidden" name="page" value="fone-entries">
                <?php if ($form_id) : ?><input type="hidden" name="form_id" value="<?php echo (int) $form_id; ?>"><?php endif; ?>
                <input type="search" name="fone_search" value="<?php echo esc_attr($search); ?>"
                    placeholder="<?php esc_attr_e('Cerca negli invii…', 'form-one'); ?>"
                    class="fone-entries-search">
                <button type="submit" class="fone-btn fone-btn-sm"><?php esc_html_e('Cerca', 'form-one'); ?></button>
                <?php if ($search !== '') : ?>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=fone-entries' . ($form_id ? '&form_id=' . $form_id : ''))); ?>" class="fone-btn fone-btn-ghost fone-btn-sm"><?php esc_html_e('Azzera ricerca', 'form-one'); ?></a>
                <?php endif; ?>
            </form>
            <?php endif; ?>

            <?php if (empty($filtered)) : ?>
                <div class="fone-empty-state">
                    <span class="fone-empty-icon">📭</span>
                    <p><?php esc_html_e('Nessun invio ricevuto ancora.', 'form-one'); ?></p>
                </div>
            <?php else : ?>
                <div class="fone-entries-grid">
                    <?php foreach ($filtered as $entry) :
                        // Trova nome del form se non abbiamo filtro
                        $entry_form_name = '';
                        if (!$form_id && !empty($entry['form_id'])) {
                            foreach ($all_forms as $f) {
                                if ($f['id'] === $entry['form_id']) { $entry_form_name = $f['form_name']; break; }
                            }
                        }
                    ?>
                    <div class="fone-entry-card">
                        <div class="fone-entry-meta">
                            <span class="fone-entry-time">🕐 <?php echo esc_html($entry['time'] ?? ''); ?></span>
                            <?php if ($entry_form_name) : ?>
                                <span class="fone-entry-form-name">📋 <?php echo esc_html($entry_form_name); ?></span>
                            <?php endif; ?>
                            <?php if (!empty($entry['url'])) : ?>
                                <span class="fone-entry-url" title="<?php echo esc_attr($entry['url']); ?>">
                                    🔗 <?php echo esc_html(trailingslashit(parse_url(site_url(), PHP_URL_PATH)) !== '/' ? basename($entry['url']) : $entry['url']); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        <ul class="fone-entry-values">
                            <?php
                            if (!empty($entry['schema']) && !empty($entry['values'])) :
                                foreach ($entry['schema'] as $field) :
                                    if (empty($field['id']) || in_array($field['type'] ?? '', ['html', 'submit', 'paypal_button'], true)) continue;
                                    if (($field['type'] ?? '') === 'password') continue;
                                    $fid   = $field['id'];
                                    $label = !empty($field['label']) ? $field['label'] : $fid;
                                    $value = isset($entry['values'][$fid]) ? $entry['values'][$fid] : '';
                                    if (($field['type'] ?? '') === 'avatar') :
                                        $att_id  = is_numeric($value) ? (int) $value : 0;
                                        $img_url = $att_id ? wp_get_attachment_image_url($att_id, 'thumbnail') : '';
                                        echo '<li><strong>' . esc_html($label) . ':</strong> ';
                                        echo $img_url
                                            ? '<img src="' . esc_url($img_url) . '" alt="" class="fone-entry-avatar-thumb">'
                                            : '<em>' . esc_html__('—', 'form-one') . '</em>';
                                        echo '</li>';
                                        continue;
                                    endif;
                                    if (is_array($value)) $value = implode(', ', $value);
                                    ?>
                                    <li><strong><?php echo esc_html($label); ?>:</strong> <?php echo esc_html((string) $value); ?></li>
                                <?php endforeach;
                            endif;
                            ?>
                        </ul>
                        <?php
                        // Estraggo email utente dall'entry per il bottone "invia email"
                        $entry_user_email = '';
                        if (!empty($entry['schema']) && !empty($entry['values'])) {
                            foreach ($entry['schema'] as $f) {
                                if (($f['type'] ?? '') === 'email' && !empty($entry['values'][$f['id']]) && is_email($entry['values'][$f['id']])) {
                                    $entry_user_email = $entry['values'][$f['id']];
                                    break;
                                }
                            }
                        }
                            $entry_user_phone = function_exists('fone_field_value_by_types') ? fone_field_value_by_types($entry['schema'], $entry['values'], ['tel','phone','whatsapp'], ['phone','telefono','whatsapp','mobile']) : '';
                            $entry_summary = function_exists('fone_entry_summary_text') ? fone_entry_summary_text($entry) : '';
                            $entry_status = function_exists('fone_get_entry_status') ? fone_get_entry_status($entry['id']) : 'nuovo';
                            $entry_status_label = function_exists('fone_entry_status_label') ? fone_entry_status_label($entry_status) : 'Nuovo';
                            $global_settings = function_exists('fone_get_global_settings') ? fone_get_global_settings() : [];
                            $entry_wa_msg = !empty($global_settings['whatsapp_entry_message']) ? $global_settings['whatsapp_entry_message'] : 'Ciao, ti contatto per la richiesta inviata sul sito.';
                            $entry_whatsapp_url = ($entry_user_phone && function_exists('fone_whatsapp_href')) ? fone_whatsapp_href($entry_user_phone, $entry_wa_msg) : '';
                        ?>
                        <div class="fone-lead-panel">
                            <span class="fone-lead-status fone-lead-status-<?php echo esc_attr($entry_status); ?>">● <?php echo esc_html($entry_status_label); ?></span>
                            <form method="post" class="fone-lead-status-form">
                                <?php wp_nonce_field('fone_update_entry_status', 'fone_entry_status_nonce'); ?>
                                <input type="hidden" name="fone_entry_id" value="<?php echo (int) $entry['id']; ?>">
                                <select name="fone_entry_status" class="fone-select-sm">
                                    <?php foreach (['nuovo','da_contattare','contattato','interessato','cliente','perso','archiviato'] as $st) : ?>
                                        <option value="<?php echo esc_attr($st); ?>" <?php selected($entry_status, $st); ?>><?php echo esc_html(function_exists('fone_entry_status_label') ? fone_entry_status_label($st) : $st); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" name="fone_update_entry_status" value="1" class="fone-btn fone-btn-ghost fone-btn-sm">Aggiorna</button>
                            </form>
                        </div>
                        <div class="fone-entry-actions" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                            <?php if ($entry_whatsapp_url) : ?>
                            <a href="<?php echo esc_url($entry_whatsapp_url); ?>" target="_blank" rel="noopener noreferrer" class="fone-btn fone-btn-primary fone-btn-sm">💬 WhatsApp</a>
                            <?php endif; ?>
                            <?php if ($entry_summary) : ?>
                            <button type="button" class="fone-btn fone-btn-ghost fone-btn-sm fone-copy-summary" data-summary="<?php echo esc_attr($entry_summary); ?>">📋 Copia riepilogo</button>
                            <?php endif; ?>
                            <?php if ($entry_user_email) : ?>
                            <button type="button" class="fone-btn fone-btn-ghost fone-btn-sm" onclick="document.getElementById('fone-manual-email-<?php echo (int) $entry['id']; ?>').classList.toggle('is-open');">
                                📧 <?php echo esc_html__('Invia email', 'form-one'); ?>
                            </button>
                            <?php endif; ?>

                            <form method="post" style="display:inline;" onsubmit="return confirm('<?php esc_attr_e('Eliminare questo invio?', 'form-one'); ?>');">
                                <?php wp_nonce_field('fone_delete_single', 'fone_delete_one_nonce'); ?>
                                <button type="submit" name="fone_delete_one" value="<?php echo esc_attr($entry['id']); ?>" class="fone-btn fone-btn-ghost fone-btn-sm fone-btn-danger-ghost">
                                    ✕ <?php esc_html_e('Elimina invio', 'form-one'); ?>
                                </button>
                            </form>
                        </div>

                        <?php if ($entry_user_email) : ?>
                        <div id="fone-manual-email-<?php echo (int) $entry['id']; ?>" class="fone-manual-email-box">
                            <form method="post" class="fone-manual-email-form">
                                <?php wp_nonce_field('fone_manual_email', 'fone_manual_email_nonce'); ?>
                                <input type="hidden" name="fone_send_manual_email" value="<?php echo esc_attr($entry['id']); ?>">

                                <h4 class="fone-manual-email-title">📧 <?php esc_html_e('Invia email a', 'form-one'); ?> <code><?php echo esc_html($entry_user_email); ?></code></h4>

                                <label class="fone-manual-email-label">
                                    <span><?php esc_html_e('Ora puoi…', 'form-one'); ?> <small>(<?php esc_html_e('completa la frase: descrivi cosa può fare ora l\'utente', 'form-one'); ?>)</small></span>
                                    <input type="text" name="fone_manual_action" placeholder="<?php esc_attr_e('es. accedere alla tua area riservata, scaricare il PDF, prenotare una call…', 'form-one'); ?>" required>
                                </label>

                                <label class="fone-manual-email-label">
                                    <span><?php esc_html_e('Messaggio aggiuntivo (opzionale)', 'form-one'); ?></span>
                                    <textarea name="fone_manual_message" rows="3" placeholder="<?php esc_attr_e('Aggiungi qualche dettaglio personalizzato…', 'form-one'); ?>"></textarea>
                                </label>

                                <div class="fone-manual-email-cta-row">
                                    <label class="fone-manual-email-label" style="flex:2;">
                                        <span><?php esc_html_e('URL del pulsante (opzionale)', 'form-one'); ?></span>
                                        <input type="url" name="fone_manual_cta_url" placeholder="https://…">
                                    </label>
                                    <label class="fone-manual-email-label" style="flex:1;">
                                        <span><?php esc_html_e('Testo del pulsante', 'form-one'); ?></span>
                                        <input type="text" name="fone_manual_cta_label" placeholder="<?php esc_attr_e('Vai →', 'form-one'); ?>">
                                    </label>
                                </div>

                                <div style="display:flex;gap:8px;">
                                    <button type="submit" class="fone-btn fone-btn-primary fone-btn-sm">📨 <?php esc_html_e('Invia adesso', 'form-one'); ?></button>
                                    <button type="button" class="fone-btn fone-btn-ghost fone-btn-sm" onclick="document.getElementById('fone-manual-email-<?php echo (int) $entry['id']; ?>').classList.remove('is-open');">
                                        <?php esc_html_e('Annulla', 'form-one'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>

                <?php if ($total_pages > 1) : ?>
                <div class="fone-pagination">
                    <?php if ($paged > 1) : ?>
                        <a href="<?php echo esc_url(add_query_arg(['fone_paged' => $paged - 1, 'fone_search' => $search, 'form_id' => $form_id ?: null])); ?>" class="fone-btn fone-btn-ghost fone-btn-sm">← <?php esc_html_e('Precedente', 'form-one'); ?></a>
                    <?php endif; ?>
                    <span class="fone-pagination-info">
                        <?php printf(esc_html__('Pagina %d di %d (%d invii)', 'form-one'), $paged, $total_pages, $total); ?>
                    </span>
                    <?php if ($paged < $total_pages) : ?>
                        <a href="<?php echo esc_url(add_query_arg(['fone_paged' => $paged + 1, 'fone_search' => $search, 'form_id' => $form_id ?: null])); ?>" class="fone-btn fone-btn-ghost fone-btn-sm"><?php esc_html_e('Successiva', 'form-one'); ?> →</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        <script>
        (function(){
            document.querySelectorAll('.fone-copy-summary').forEach(function(btn){
                btn.addEventListener('click', function(){
                    var text = this.getAttribute('data-summary') || '';
                    if (navigator.clipboard) { navigator.clipboard.writeText(text); }
                    else { var t=document.createElement('textarea'); t.value=text; document.body.appendChild(t); t.select(); document.execCommand('copy'); document.body.removeChild(t); }
                    var old = this.textContent; this.textContent = '✓ Copiato';
                    var self = this; setTimeout(function(){ self.textContent = old; }, 1200);
                });
            });
        })();
        </script>
        </div>
        <?php
    }
}

/* ---------------------------------------------------------------
   CSV EXPORT
--------------------------------------------------------------- */

if (!function_exists('fone_csv_escape')) {
    function fone_csv_escape($value) {
        $value = (string) $value;
        if ($value === '') return $value;
        $first = $value[0];
        if (in_array($first, ['=', '+', '-', '@', "\t", "\r"], true)) {
            return "'" . $value;
        }
        return $value;
    }
}

if (!function_exists('fone_export_csv')) {
    function fone_export_csv() {
        if (!current_user_can('manage_options')) wp_die('Non autorizzato');
        if (
            empty($_GET['fone_export_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['fone_export_nonce'])), 'fone_export_csv')
        ) {
            wp_die('Token non valido');
        }

        $form_id = isset($_GET['form_id']) ? (int) $_GET['form_id'] : 0;

        while (ob_get_level()) ob_end_clean();

        $filename = 'form-one-invii-' . ($form_id ? 'form' . $form_id . '-' : '') . current_time('Y-m-d') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-store, no-cache, must-revalidate');

        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF"); // BOM UTF-8 per Excel

        global $wpdb;
        $table = fone_table_entries();

        // Costruisci mappa campi
        $field_map = [];
        if ($form_id) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $schemas = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT schema_json FROM {$table} WHERE form_id = %d", $form_id));
        } else {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $schemas = $wpdb->get_col("SELECT DISTINCT schema_json FROM {$table}");
        }
        foreach ((array) $schemas as $schema_json) {
            $schema = json_decode($schema_json, true);
            if (!is_array($schema)) continue;
            foreach ($schema as $field) {
                if (empty($field['id']) || in_array($field['type'] ?? '', ['html', 'submit', 'password'], true)) continue;
                if (!isset($field_map[$field['id']])) {
                    $field_map[$field['id']] = !empty($field['label']) ? $field['label'] : $field['id'];
                }
            }
        }
        unset($schemas);

        fputcsv($out, array_map('fone_csv_escape', array_merge(['Data', 'Pagina'], array_values($field_map))));

        $chunk_size = 500;
        $offset     = 0;
        do {
            if ($form_id) {
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $rows = $wpdb->get_results(
                    $wpdb->prepare("SELECT submitted_at, page_url, values_json, schema_json FROM {$table} WHERE form_id = %d ORDER BY submitted_at DESC LIMIT %d OFFSET %d", $form_id, $chunk_size, $offset),
                    ARRAY_A
                );
            } else {
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $rows = $wpdb->get_results(
                    $wpdb->prepare("SELECT submitted_at, page_url, values_json, schema_json FROM {$table} ORDER BY submitted_at DESC LIMIT %d OFFSET %d", $chunk_size, $offset),
                    ARRAY_A
                );
            }
            if (empty($rows)) break;

            foreach ($rows as $row) {
                $values  = json_decode($row['values_json'], true) ?: [];
                $schema  = json_decode($row['schema_json'],  true) ?: [];
                $csv_row = [$row['submitted_at'] ?: '', $row['page_url'] ?: ''];
                foreach ($field_map as $fid => $label) {
                    $val = $values[$fid] ?? '';
                    foreach ($schema as $f) {
                        if (($f['id'] ?? '') === $fid && ($f['type'] ?? '') === 'avatar') {
                            $url = $values[$fid . '__url'] ?? '';
                            if (!$url && is_numeric($val)) $url = wp_get_attachment_url((int) $val) ?: '';
                            $val = $url;
                            break;
                        }
                    }
                    if (is_array($val)) $val = implode(', ', $val);
                    $csv_row[] = fone_csv_escape($val);
                }
                fputcsv($out, $csv_row);
            }
            if (function_exists('flush')) @flush();
            $offset += $chunk_size;
        } while (count($rows) === $chunk_size);

        fclose($out);
        exit;
    }
}
add_action('admin_action_fone_export_csv', 'fone_export_csv');

/* ---------------------------------------------------------------
   INVIO EMAIL MANUALE A UN UTENTE DA UN'ENTRY
--------------------------------------------------------------- */

if (!function_exists('fone_send_manual_action_email')) {
    /**
     * Invia un'email "ora puoi…" personalizzata all'utente di un'entry.
     * Usa lo stesso template visivo di Form One.
     *
     * @param int    $entry_id    ID entry
     * @param string $action_text Frase "ora puoi …"
     * @param string $extra_msg   Messaggio aggiuntivo libero
     * @param string $cta_url     URL bottone (opzionale)
     * @param string $cta_label   Label bottone
     * @return true|string True se ok, stringa errore se fallisce
     */
    function fone_send_manual_action_email($entry_id, $action_text, $extra_msg = '', $cta_url = '', $cta_label = '') {
        if (!current_user_can('manage_options')) return 'Permesso negato.';
        $entry_id = (int) $entry_id;
        if (!$entry_id) return 'Entry non valida.';

        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . fone_table_entries() . " WHERE id = %d", $entry_id
        ), ARRAY_A);
        if (!$row) return 'Invio non trovato.';

        $schema = json_decode($row['schema_json'] ?? '[]', true);
        $values = json_decode($row['values_json'] ?? '{}', true);
        if (!is_array($schema) || !is_array($values)) return 'Dati invio corrotti.';

        // Cerco l'email
        $user_email = '';
        $first_name = '';
        foreach ($schema as $f) {
            $type = $f['type'] ?? '';
            $slug = $f['slug'] ?? '';
            if ($type === 'email' && !empty($values[$f['id']]) && is_email($values[$f['id']])) {
                if (!$user_email) $user_email = $values[$f['id']];
            }
            if (in_array($slug, ['first_name', 'full_name', 'name'], true) && !empty($values[$f['id']])) {
                if (!$first_name) $first_name = $values[$f['id']];
            }
        }
        if (!$user_email) return 'Nessuna email valida trovata in questo invio.';

        $action_text = trim((string) $action_text);
        if ($action_text === '') return 'Devi specificare cosa l\'utente può fare ora.';

        $site_name = function_exists('fone_get_from_name') ? fone_get_from_name() : 'Form One';
        $site_url  = get_bloginfo('url');
        $greeting  = $first_name ? 'Ciao <strong>' . esc_html($first_name) . '</strong>! 👋' : 'Ciao! 👋';

        $intro = $greeting . '<br><br>Abbiamo una bella notizia: <strong>ora puoi ' . esc_html($action_text) . '</strong>.';

        $body_html = '';
        if ($extra_msg) {
            $body_html = '<div style="margin:18px 0;padding:18px 20px;background:linear-gradient(135deg,#FAFAFB 0%,#F4F1FA 100%);border-left:4px solid #E91E80;border-radius:8px;font-size:14px;line-height:1.7;color:#0A0A0F;">'
                . nl2br(esc_html($extra_msg))
                . '</div>';
        }

        $cta = null;
        if ($cta_url && filter_var($cta_url, FILTER_VALIDATE_URL)) {
            $cta = [
                'label' => $cta_label ?: 'Vai',
                'url'   => $cta_url,
            ];
        }

        $html = fone_email_template([
            'emoji'     => '🚀',
            'title'     => 'Una novità per te!',
            'subtitle'  => 'Form One',
            'intro'     => $intro,
            'body_html' => $body_html,
            'cta'       => $cta,
            'footer_note' => 'Hai ricevuto questa email tramite <strong>Form One</strong>. Se non eri tu, ignora pure questo messaggio.',
            'site_name' => $site_name,
            'site_url'  => $site_url,
        ]);

        $subject = function_exists('fone_normalize_email_subject') ? fone_normalize_email_subject('Ora puoi ' . wp_strip_all_tags($action_text), '[Form One] Ora puoi agire') : '🚀 [Form One] Ora puoi ' . wp_strip_all_tags($action_text);
        $from_email = function_exists('fone_get_from_address') ? fone_get_from_address() : 'wordpress@' . preg_replace('/^www\./', '', (string) parse_url(home_url(), PHP_URL_HOST));
        $from_name  = function_exists('fone_get_from_name') ? fone_get_from_name() : 'Form One';
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ];

        $sent = function_exists('fone_wp_mail_with_brand')
            ? fone_wp_mail_with_brand($user_email, $subject, $html, $headers)
            : wp_mail($user_email, $subject, $html, $headers);
        if (!$sent) return 'Invio fallito (controlla la configurazione SMTP).';
        return true;
    }
}
