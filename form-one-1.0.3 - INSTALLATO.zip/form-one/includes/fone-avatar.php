<?php
/**
 * Form One — Avatar / Foto profilo autore
 *
 * COSA FA
 * -------
 * Quando l'utente carica una foto dal form nel campo "avatar":
 *
 * 1) Salva il file come attachment nella Media Library di WordPress
 *    (gestione sicura via wp_handle_upload + wp_generate_attachment_metadata).
 *
 * 2) Se l'utente è LOGGATO o viene creato/identificato durante il submit:
 *    - Scrive l'attachment_id in due user_meta per massima compatibilità:
 *      * wp_user_avatar      (standard del plugin WP User Avatar / ProfilePress)
 *      * simple_local_avatar (standard del plugin Simple Local Avatars di 10up)
 *    - Filtra get_avatar_url() e pre_get_avatar_data() così Elementor Pro
 *      Author Box e qualsiasi tema WP mostreranno la foto caricata al posto
 *      del Gravatar, anche senza quei plugin installati.
 *
 * 3) Se l'utente NON è loggato:
 *    - L'ID dell'attachment viene comunque salvato nell'entry del form,
 *      così lo puoi associare a un utente in un secondo momento.
 *
 * NOTA TECNICA IMPORTANTE
 * -----------------------
 * WordPress core NON ha un meta_key ufficiale per l'avatar utente.
 * Core usa Gravatar via email. I due meta_key sopra sono gli
 * standard de-facto della community WP e Elementor Pro li legge
 * automaticamente se è attivo uno dei due plugin.
 * Questo modulo implementa il comportamento corretto ANCHE se
 * quei plugin non sono installati.
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   UPLOAD SICURO DELL'IMMAGINE
--------------------------------------------------------------- */

if (!function_exists('fone_handle_avatar_upload')) {
    /**
     * Carica il file dal $_FILES e ne fa un attachment.
     * Accetta tutti i formati immagine standard: JPEG, PNG, WEBP, GIF, AVIF, BMP, TIFF.
     * NON accetta SVG (rischio sicurezza - può contenere script).
     * Ritorna ['ok'=>true, 'attachment_id'=>int, 'url'=>string] o ['ok'=>false, 'error'=>string]
     */
    function fone_handle_avatar_upload($file_key, $allowed_mimes = null, $max_size_bytes = null) {

        // Allowlist dura: immagini raster reali, mai SVG.
        if (function_exists('fone_safe_file_mimes')) {
            $allowed_mimes = fone_safe_file_mimes($allowed_mimes, 'avatar');
        } elseif ($allowed_mimes === null) {
            $allowed_mimes = [
                'image/jpeg',
                'image/png',
                'image/webp',
                'image/gif',
                'image/avif',
                'image/bmp',
                'image/tiff',
                'image/heic',
                'image/heif',
            ];
        }

        if (empty($allowed_mimes)) {
            return ['ok' => false, 'error' => fone_t('error_file_type')];
        }
        // Default: 12 MB
        if ($max_size_bytes === null) {
            $max_size_bytes = 12 * 1024 * 1024;
        }

        if (empty($_FILES[$file_key]) || empty($_FILES[$file_key]['tmp_name'])) {
            return ['ok' => false, 'error' => fone_t('error_required')];
        }

        $file = $_FILES[$file_key];
        $file['name'] = sanitize_file_name($file['name'] ?? '');
        if ($file['name'] === '' || preg_match('/\.(php|phtml|phar|cgi|pl|py|rb|sh|bash|js|html?|xhtml|svg)(\.|$)/i', $file['name'])) {
            return ['ok' => false, 'error' => fone_t('error_file_type')];
        }

        // Upload error check
        if (!empty($file['error']) && (int) $file['error'] !== UPLOAD_ERR_OK) {
            return ['ok' => false, 'error' => fone_t('error_file_size')];
        }

        // Size check
        if (!empty($file['size']) && (int) $file['size'] > $max_size_bytes) {
            return ['ok' => false, 'error' => fone_t('error_file_size')];
        }

        // Costruisco la mappa estensione → MIME per wp_handle_upload
        $mimes_map = [
            'jpg|jpeg|jpe' => 'image/jpeg',
            'png'          => 'image/png',
            'webp'         => 'image/webp',
            'gif'          => 'image/gif',
            'avif'         => 'image/avif',
            'bmp'          => 'image/bmp',
            'tif|tiff'     => 'image/tiff',
            'heic'         => 'image/heic',
            'heif'         => 'image/heif',
        ];
        $filtered_mimes = [];
        foreach ($mimes_map as $ext => $mime_type) {
            if (in_array($mime_type, $allowed_mimes, true)) {
                $filtered_mimes[$ext] = $mime_type;
            }
        }

        // Estensione dal filename (utile sia per check sia per fallback)
        $ext_name = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $ext_to_mime = [
            'jpg'  => 'image/jpeg', 'jpeg' => 'image/jpeg', 'jpe'  => 'image/jpeg',
            'png'  => 'image/png',
            'webp' => 'image/webp',
            'gif'  => 'image/gif',
            'avif' => 'image/avif',
            'bmp'  => 'image/bmp',
            'tif'  => 'image/tiff', 'tiff' => 'image/tiff',
            'heic' => 'image/heic', 'heif' => 'image/heif',
        ];

        // MIME check tollerante: server-side prima, poi fallback su estensione
        // (Alcuni server non rilevano correttamente formati moderni come avif/heic/webp
        // anche se validi — si controlla anche l'estensione del filename).
        $detected = wp_check_filetype_and_ext($file['tmp_name'], $file['name'], $filtered_mimes);
        $mime     = $detected['type'] ?? '';

        // Fallback 1: se wp_check ha fallito ma l'estensione è tra quelle permesse, uso quello
        if (empty($mime) && isset($ext_to_mime[$ext_name]) && in_array($ext_to_mime[$ext_name], $allowed_mimes, true)) {
            $mime = $ext_to_mime[$ext_name];
        }

        // Verifica server-side più stretta: il file deve essere davvero un'immagine leggibile.
        // Non ci fidiamo del MIME dichiarato dal browser, perché può essere falsificato.
        $real_image_mime = '';
        if (function_exists('wp_get_image_mime')) {
            $real_image_mime = (string) wp_get_image_mime($file['tmp_name']);
        }
        if (empty($real_image_mime) && function_exists('getimagesize')) {
            $image_info = @getimagesize($file['tmp_name']);
            if (is_array($image_info) && !empty($image_info['mime'])) {
                $real_image_mime = (string) $image_info['mime'];
            }
        }

        // Per avatar pubblici richiediamo che il server riesca a leggere davvero
        // il file come immagine. Niente fallback solo su estensione: più sicuro.
        if (empty($real_image_mime) || !in_array($real_image_mime, $allowed_mimes, true)) {
            return ['ok' => false, 'error' => fone_t('error_file_type')];
        }
        $mime = $real_image_mime;

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Filtro temporaneo su upload_mimes per abilitare formati moderni che WP
        // core può non avere nella whitelist di default (heic/avif/tiff/bmp).
        $mime_filter = function($mimes) use ($filtered_mimes) {
            return array_merge($mimes, $filtered_mimes);
        };
        add_filter('upload_mimes', $mime_filter, 99);

        // Bypass temporaneo di wp_check_filetype_and_ext quando il nostro check
        // interno è già passato (evita doppi falsi negativi sui formati moderni).
        $check_filter = function($data, $file_path, $filename, $mimes, $real_mime) use ($mime, $ext_name, $ext_to_mime) {
            if (!empty($data['type'])) return $data;
            if (isset($ext_to_mime[$ext_name]) && $ext_to_mime[$ext_name] === $mime) {
                return [
                    'ext'             => $ext_name,
                    'type'            => $mime,
                    'proper_filename' => false,
                ];
            }
            return $data;
        };
        add_filter('wp_check_filetype_and_ext', $check_filter, 99, 5);

        $overrides = ['test_form' => false, 'mimes' => $filtered_mimes];
        $uploaded  = wp_handle_upload($file, $overrides);

        // Rimuovo i filtri temporanei
        remove_filter('upload_mimes', $mime_filter, 99);
        remove_filter('wp_check_filetype_and_ext', $check_filter, 99);

        if (empty($uploaded['file']) || !empty($uploaded['error'])) {
            // Normalizzo i messaggi tecnici di WP core (es. "Il file è vuoto...
            // Questo errore può anche essere causato dal fatto che gli upload
            // sono stati disabilitati nel file php.ini...") con messaggi puliti.
            $raw = isset($uploaded['error']) ? (string) $uploaded['error'] : '';
            $clean = fone_t('error_file_type');
            if (stripos($raw, 'php.ini') !== false || stripos($raw, 'empty') !== false || stripos($raw, 'vuoto') !== false) {
                // Era solo il caso di file mancante → messaggio generico
                $clean = fone_t('error_required');
            }
            return ['ok' => false, 'error' => $clean];
        }

        // Crea l'attachment
        $attachment = [
            'post_mime_type' => $uploaded['type'],
            'post_title'     => sanitize_file_name(pathinfo($uploaded['file'], PATHINFO_FILENAME)),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ];
        $attach_id = wp_insert_attachment($attachment, $uploaded['file']);
        if (is_wp_error($attach_id) || !$attach_id) {
            return ['ok' => false, 'error' => 'Attachment error'];
        }

        $metadata = wp_generate_attachment_metadata($attach_id, $uploaded['file']);
        wp_update_attachment_metadata($attach_id, $metadata);

        return [
            'ok'            => true,
            'attachment_id' => (int) $attach_id,
            'url'           => $uploaded['url'],
        ];
    }
}

/* ---------------------------------------------------------------
   ASSOCIA L'AVATAR A UN USER
--------------------------------------------------------------- */

if (!function_exists('fone_assign_avatar_to_user')) {
    function fone_assign_avatar_to_user($user_id, $attachment_id) {
        $user_id       = (int) $user_id;
        $attachment_id = (int) $attachment_id;
        if (!$user_id || !$attachment_id) {
            return false;
        }

        // WP User Avatar / ProfilePress
        update_user_meta($user_id, 'wp_user_avatar', $attachment_id);

        // Simple Local Avatars (salva in array con url per size)
        $url = wp_get_attachment_url($attachment_id);
        if ($url) {
            update_user_meta($user_id, 'simple_local_avatar', [
                'full'          => $url,
                'media_id'      => $attachment_id,
            ]);
        }

        // Meta custom del plugin (sempre utile)
        update_user_meta($user_id, 'fone_avatar_id', $attachment_id);

        return true;
    }
}

/* ---------------------------------------------------------------
   FILTRA get_avatar_url E get_avatar
   Così Elementor Pro Author Box e qualsiasi tema mostra la foto
   caricata, anche senza WP User Avatar / Simple Local Avatars.
--------------------------------------------------------------- */

if (!function_exists('fone_resolve_user_id')) {
    function fone_resolve_user_id($id_or_email) {
        if (is_numeric($id_or_email)) {
            return (int) $id_or_email;
        }
        if (is_object($id_or_email)) {
            if (!empty($id_or_email->user_id))    return (int) $id_or_email->user_id;
            if (!empty($id_or_email->ID))         return (int) $id_or_email->ID;
            if (!empty($id_or_email->comment_author_email)) {
                $u = get_user_by('email', $id_or_email->comment_author_email);
                return $u ? $u->ID : 0;
            }
        }
        if (is_string($id_or_email) && is_email($id_or_email)) {
            $u = get_user_by('email', $id_or_email);
            return $u ? $u->ID : 0;
        }
        return 0;
    }
}

if (!function_exists('fone_get_stored_avatar_url')) {
    function fone_get_stored_avatar_url($user_id) {
        if (!$user_id) return '';

        // Priorità: 1) simple_local_avatar 2) wp_user_avatar 3) fone_avatar_id
        $sla = get_user_meta($user_id, 'simple_local_avatar', true);
        if (is_array($sla) && !empty($sla['full'])) {
            return $sla['full'];
        }

        $wp_ua = (int) get_user_meta($user_id, 'wp_user_avatar', true);
        if ($wp_ua) {
            $url = wp_get_attachment_url($wp_ua);
            if ($url) return $url;
        }

        $fone_av = (int) get_user_meta($user_id, 'fone_avatar_id', true);
        if ($fone_av) {
            $url = wp_get_attachment_url($fone_av);
            if ($url) return $url;
        }

        return '';
    }
}

add_filter('get_avatar_url', function ($url, $id_or_email, $args) {
    $user_id  = fone_resolve_user_id($id_or_email);
    $custom   = fone_get_stored_avatar_url($user_id);
    return $custom ? $custom : $url;
}, 10, 3);

add_filter('pre_get_avatar_data', function ($args, $id_or_email) {
    $user_id = fone_resolve_user_id($id_or_email);
    $custom  = fone_get_stored_avatar_url($user_id);
    if ($custom) {
        $args['url']          = $custom;
        $args['found_avatar'] = true;
    }
    return $args;
}, 10, 2);

/* ---------------------------------------------------------------
   SUPPORTO ELEMENTOR PRO
   Elementor Pro nel tag dinamico "Author Profile Picture" chiama
   get_avatar_url() internamente, quindi i filter sopra bastano.
   Per sicurezza intercettiamo anche il filtro specifico di Elementor
   se disponibile.
--------------------------------------------------------------- */
add_filter('elementor/dynamic_tags/dynamic_tag_value/author-profile-picture', function ($value, $tag) {
    if (is_array($value) && !empty($value['id'])) {
        // Elementor ritorna array ['id' => attachment_id, 'url' => ...]
        $user_id = get_the_author_meta('ID');
        if (!$user_id && is_singular()) {
            global $post;
            if ($post) $user_id = $post->post_author;
        }
        if ($user_id) {
            $custom_id = (int) get_user_meta($user_id, 'fone_avatar_id', true);
            if (!$custom_id) $custom_id = (int) get_user_meta($user_id, 'wp_user_avatar', true);
            if ($custom_id) {
                $url = wp_get_attachment_url($custom_id);
                if ($url) {
                    $value['id']  = $custom_id;
                    $value['url'] = $url;
                }
            }
        }
    }
    return $value;
}, 10, 2);

/* ---------------------------------------------------------------
   TAG DINAMICO PERSONALIZZATO "Form One Avatar"
   Registra un tag dinamico custom in Elementor Pro così puoi
   usarlo in qualsiasi widget Immagine (non solo Author Box).
--------------------------------------------------------------- */
add_action('elementor_pro/init', function () {
    add_action('elementor/dynamic_tags/register', function ($dynamic_tags_manager) {

        if (!class_exists('\Elementor\Core\DynamicTags\Data_Tag')) return;

        class FONE_Dynamic_Avatar_Tag extends \Elementor\Core\DynamicTags\Data_Tag {
            public function get_name()       { return 'fone-avatar'; }
            public function get_title()      { return __('Form One — Foto profilo', 'form-one'); }
            public function get_group()      { return 'site'; }
            public function get_categories() { return [\Elementor\Modules\DynamicTags\Module::IMAGE_CATEGORY]; }

            public function get_value(array $options = []) {
                $user_id = get_the_author_meta('ID');
                if (!$user_id && is_singular()) {
                    global $post;
                    if ($post) $user_id = $post->post_author;
                }
                if (!$user_id) $user_id = get_current_user_id();

                $custom_id = 0;
                if ($user_id) {
                    $custom_id = (int) get_user_meta($user_id, 'fone_avatar_id', true);
                    if (!$custom_id) $custom_id = (int) get_user_meta($user_id, 'wp_user_avatar', true);
                }

                if ($custom_id) {
                    return ['id' => $custom_id, 'url' => wp_get_attachment_url($custom_id)];
                }

                // Fallback Gravatar
                return ['id' => '', 'url' => $user_id ? get_avatar_url($user_id) : ''];
            }
        }

        $dynamic_tags_manager->register(new FONE_Dynamic_Avatar_Tag());
    });
});
