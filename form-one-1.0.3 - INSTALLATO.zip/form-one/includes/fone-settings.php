<?php
/**
 * Form One — Settings per-form e globali
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   DEFAULT SETTINGS (per ogni singolo form)
--------------------------------------------------------------- */


if (!function_exists('fone_default_profile_url')) {
    /**
     * URL profilo/account di default.
     * Non deve puntare a un dominio esterno hardcoded: ogni installazione usa il proprio sito.
     */
    function fone_default_profile_url() {
        return apply_filters('fone_default_profile_url', home_url('/account-form-one/'));
    }
}



if (!function_exists('fone_sanitize_local_url')) {
    /**
     * URL sicuro per redirect/profilo interni.
     * Evita che una configurazione o un payload manipolato trasformi il form in
     * un punto di open redirect/phishing verso domini esterni.
     *
     * Per consentire redirect esterni consapevoli, uno sviluppatore può usare:
     * add_filter('fone_allow_external_redirects', '__return_true');
     */
    function fone_sanitize_local_url($url, $fallback = '') {
        $fallback = $fallback ? $fallback : home_url('/');
        $url = is_string($url) ? trim($url) : '';
        if ($url === '') {
            return $fallback;
        }

        $url = esc_url_raw($url);
        if ($url === '') {
            return $fallback;
        }

        if (apply_filters('fone_allow_external_redirects', false, $url)) {
            return $url;
        }

        return wp_validate_redirect($url, $fallback);
    }
}

if (!function_exists('fone_get_safe_registration_role')) {
    /**
     * Ruolo sicuro per registrazioni pubbliche.
     * Blocca ruoli con capacità editoriali/amministrative anche se il valore
     * viene alterato a mano nella richiesta o nel database.
     */
    function fone_get_safe_registration_role($requested_role = '') {
        $requested_role = sanitize_key($requested_role ?: 'subscriber');

        $allowed_roles = apply_filters('fone_allowed_public_registration_roles', [
            'subscriber',
            'customer',
        ]);

        $allowed_roles = array_map('sanitize_key', (array) $allowed_roles);
        if (!in_array($requested_role, $allowed_roles, true)) {
            return 'subscriber';
        }

        $role_obj = get_role($requested_role);
        if (!$role_obj) {
            return 'subscriber';
        }

        $dangerous_caps = [
            'manage_options',
            'edit_posts',
            'publish_posts',
            'upload_files',
            'edit_pages',
            'edit_users',
            'promote_users',
            'delete_users',
            'create_users',
            'activate_plugins',
            'install_plugins',
            'update_plugins',
            'delete_plugins',
            'unfiltered_html',
        ];

        foreach ($dangerous_caps as $cap) {
            if (!empty($role_obj->capabilities[$cap])) {
                return 'subscriber';
            }
        }

        return $requested_role;
    }
}

if (!function_exists('fone_is_protected_user_meta_key')) {
    /**
     * Impedisce a campi custom del form/account di scrivere meta utente sensibili.
     */
    function fone_is_protected_user_meta_key($key) {
        $key = sanitize_key($key);
        if ($key === '') {
            return true;
        }

        $blocked = [
            'wp_capabilities',
            'wp_user_level',
            'capabilities',
            'user_level',
            'session_tokens',
            'user_activation_key',
            'user_pass',
            'user_login',
            'user_email',
            'show_admin_bar_front',
            'rich_editing',
            'admin_color',
            'use_ssl',
            'dismissed_wp_pointers',
            'metaboxhidden_nav-menus',
            'closedpostboxes_dashboard',
            'manageedit-shop_ordercolumnshidden',
        ];

        $blocked = apply_filters('fone_protected_user_meta_keys', $blocked);

        if (in_array($key, $blocked, true)) {
            return true;
        }

        if (preg_match('/(^|_)capabilities$/', $key)) {
            return true;
        }

        if (preg_match('/(^|_)user_level$/', $key)) {
            return true;
        }

        return false;
    }
}

if (!function_exists('fone_default_settings')) {
    function fone_default_settings() {
        return [
            'lang'                       => 'it',
            'admin_email'                => get_option('admin_email'),
            'show_donate_frontend'       => 0,
            'donate_url'                 => 'https://www.paypal.com/donate/?hosted_button_id=EJ4H9D7ZX93M6',
            'success_message'            => 'Messaggio inviato con successo. Ti risponderemo al più presto!',
            'form_title'                 => '',
            'form_subtitle'              => '',
            'accent_color'               => '#2563eb',
            'border_radius'              => '10',
            'reveal_animation'           => 'from-top',
            // Registrazione utente WP
            'enable_registration'        => 0,
            'registration_role'          => 'subscriber',
            'registration_autologin'     => 1,
            'registration_send_wp_email' => 1,
            'registration_redirect'      => '',
            // Login form
            'enable_login'               => 0,
            // Shared
            'profile_url'                => fone_default_profile_url(),
            'auto_redirect_profile'      => 0,
            'auto_redirect_delay'        => 8,
            // WhatsApp per-form: inherit usa le impostazioni globali.
            'whatsapp_mode'              => 'inherit',
            'whatsapp_enabled'           => 0,
            'whatsapp_number'            => '',
            'whatsapp_button_label'      => '',
            'whatsapp_message'           => '',
            'whatsapp_include_values'    => 0,
            // Webhook per-form: inherit usa le impostazioni globali.
            'webhook_mode'               => 'inherit',
            'webhook_enabled'            => 0,
            'webhook_url'                => '',
            'webhook_send_values'        => 1,
            'webhook_send_meta'          => 1,
            'first_yes_enabled'        => 0,
            'first_yes_button_label'   => '',
            'first_yes_hint'           => '',
            'first_yes_preset'         => 'custom',
            'microcopy_goal'           => 'general',
            'resume_later_enabled'     => 0,
            'resume_later_ttl_days'    => 7,
            'microcopy_assistant'      => 1,
        ];
    }
}

// Retrocompatibilità: legge dal primo form, o defaults
if (!function_exists('fone_get_settings')) {
    function fone_get_settings($form_id = 0) {
        if ($form_id) {
            $form = fone_get_form($form_id);
            if ($form) return $form['settings'];
        }
        // Legacy: opzione globale
        $saved = get_option('fone_settings', []);
        if (!is_array($saved)) $saved = [];
        return wp_parse_args($saved, fone_default_settings());
    }
}

if (!function_exists('fone_save_settings')) {
    function fone_save_settings($settings, $form_id = 0) {
        if ($form_id) {
            fone_save_form($form_id, ['settings' => $settings]);
        } else {
            $current = fone_get_settings();
            update_option('fone_settings', wp_parse_args($settings, $current));
        }
    }
}

/* ---------------------------------------------------------------
   STEP LAYOUTS (per-form)
--------------------------------------------------------------- */

if (!function_exists('fone_get_step_layouts')) {
    function fone_get_step_layouts($form_id = 0) {
        if ($form_id) {
            $form = fone_get_form($form_id);
            if ($form) return $form['layouts'];
        }
        $layouts = get_option('fone_step_layouts', []);
        return is_array($layouts) ? $layouts : [];
    }
}

/* ---------------------------------------------------------------
   DEFAULT CSS — commenti utili per gli sviluppatori
--------------------------------------------------------------- */

if (!function_exists('fone_get_default_custom_css')) {
    function fone_get_default_custom_css() {
        return <<<CSS
/* =====================================================================
   🎨  FORM ONE — CSS PERSONALIZZATO
   Modifica queste regole per stilizzare il tuo form.
   Tutti i selettori qui hanno priorità sul CSS predefinito del plugin.
===================================================================== */


/* =====================================================================
   📦  CONTENITORE PRINCIPALE DEL FORM
===================================================================== */
.fone-wrap {
    background: #ffffff;
    padding: 28px 28px 22px;
    border-radius: 14px;
    box-shadow: 0 10px 40px rgba(0,0,0,.06);
    max-width: 920px;
    margin: 0 auto;
}


/* =====================================================================
   🏷️  TITOLO E SOTTOTITOLO DEL FORM
===================================================================== */
.fone-form-title {
    color: #0f172a;
    font-size: 28px;
    font-weight: 700;
    margin: 0 0 6px;
    line-height: 1.2;
}
.fone-form-subtitle {
    color: #64748b;
    font-size: 15px;
    margin: 0 0 22px;
}


/* =====================================================================
   📋  STEP CARD
===================================================================== */
.fone-step-card {
    background: transparent;
    padding: 0;
    margin-bottom: 18px;
}
.fone-step-grid { gap: 16px 14px; }


/* =====================================================================
   📷  FOTO PROFILO — BLOCCO UPLOAD
===================================================================== */
.fone-field-avatar .fone-avatar-slot {
    border: 2px dashed #cbd5e1;
    border-radius: 16px;
    padding: 22px;
    text-align: center;
    background: #f8fafc;
    transition: border-color .2s, background .2s;
}
.fone-field-avatar .fone-avatar-slot:hover {
    border-color: var(--fone-accent);
    background: #fff;
}
.fone-field-avatar .fone-avatar-preview img {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid var(--fone-accent);
}


/* =====================================================================
   🔤  ETICHETTE (LABEL)
===================================================================== */
.fone-field label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #334155;
    margin-bottom: 6px;
}


/* =====================================================================
   ✏️  CAMPI INPUT
===================================================================== */
.fone-field input[type="text"],
.fone-field input[type="email"],
.fone-field input[type="tel"],
.fone-field input[type="number"],
.fone-field input[type="url"],
.fone-field input[type="date"],
.fone-field input[type="password"],
.fone-field select,
.fone-field textarea {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #e2e8f0;
    border-radius: var(--fone-radius);
    font-size: 15px;
    background: #fff;
    color: #0f172a;
    transition: border-color .15s, box-shadow .15s;
}
.fone-field input:focus,
.fone-field select:focus,
.fone-field textarea:focus {
    outline: none;
    border-color: var(--fone-accent);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--fone-accent) 18%, transparent);
}


/* =====================================================================
   ☑️  RADIO E CHECKBOX
===================================================================== */
.fone-choice-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 12px;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    margin-bottom: 6px;
    cursor: pointer;
    transition: border-color .15s, background .15s;
}
.fone-choice-row:hover { border-color: var(--fone-accent); }


/* =====================================================================
   ➡️  PULSANTE "CONTINUA" (passo successivo)
===================================================================== */
.fone-continue-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 22px;
    background: transparent;
    color: var(--fone-accent);
    border: 1.5px solid var(--fone-accent);
    border-radius: var(--fone-radius);
    font-weight: 600;
    font-size: 15px;
    cursor: pointer;
    transition: background .15s, color .15s;
    margin-top: 14px;
}
.fone-continue-btn:hover { background: var(--fone-accent); color: #fff; }


/* =====================================================================
   ✅  PULSANTE REGISTRATI / INVIA
===================================================================== */
.fone-submit-btn {
    display: inline-block;
    padding: 14px 28px;
    background: var(--fone-accent);
    color: #fff;
    border: none;
    border-radius: var(--fone-radius);
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    width: 100%;
    margin-top: 10px;
    transition: filter .15s, transform .1s;
}
.fone-submit-btn:hover  { filter: brightness(1.07); }
.fone-submit-btn:active { transform: translateY(1px); }


/* =====================================================================
   🎉  MESSAGGIO DI SUCCESSO
===================================================================== */
.fone-success-box {
    background: #ecfdf5;
    color: #065f46;
    border: 1px solid #a7f3d0;
    border-radius: var(--fone-radius);
    padding: 18px 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}


/* =====================================================================
   ⚠️  ERRORI DI VALIDAZIONE
===================================================================== */
.fone-field-error {
    color: #dc2626;
    font-size: 13px;
    margin-top: 4px;
    display: block;
}
.fone-global-error {
    background: #fef2f2;
    color: #991b1b;
    border: 1px solid #fecaca;
    border-radius: var(--fone-radius);
    padding: 12px 16px;
    margin-bottom: 14px;
}


/* =====================================================================
   💡  TESTO DI AIUTO E NOTE
===================================================================== */
.fone-help {
    color: #94a3b8;
    font-size: 12px;
    margin-top: 4px;
    display: block;
}
.fone-trust-text {
    color: #94a3b8;
    font-size: 12px;
    font-style: italic;
    margin: 8px 0 0;
}


/* =====================================================================
   📏  CONTATORE CARATTERI
===================================================================== */
.fone-char-count { display: block; text-align: right; font-size: 12px; color: #94a3b8; margin-top: 4px; }
.fone-char-count.is-near-limit { color: #d97706; }
.fone-char-count.is-over-limit { color: #dc2626; }


/* =====================================================================
   📱  RESPONSIVE — MOBILE
===================================================================== */
@media (max-width: 640px) {
    .fone-wrap { padding: 18px 16px; border-radius: 12px; }
    .fone-form-title { font-size: 22px; }
    .fone-step-grid.is-two-col { grid-template-columns: 1fr !important; }
    .fone-width-half { grid-column: span 2; }
}
CSS;
    }
}
