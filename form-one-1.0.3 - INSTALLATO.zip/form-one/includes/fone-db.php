<?php
/**
 * Form One — Database
 *
 * Tabelle:
 *   {prefix}fone_forms   — ogni form creato (nome, schema, settings, ecc.)
 *   {prefix}fone_entries — ogni invio ricevuto (con form_id)
 *   {prefix}fone_insights_events — eventi anonimi per Conversion Insights
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   NOMI TABELLE
--------------------------------------------------------------- */

if (!function_exists('fone_table_forms')) {
    function fone_table_forms() {
        global $wpdb;
        return $wpdb->prefix . 'fone_forms';
    }
}

if (!function_exists('fone_table_entries')) {
    function fone_table_entries() {
        global $wpdb;
        return $wpdb->prefix . 'fone_entries';
    }
}


if (!function_exists('fone_table_insights_events')) {
    function fone_table_insights_events() {
        global $wpdb;
        return $wpdb->prefix . 'fone_insights_events';
    }
}

// Alias per retrocompatibilità
if (!function_exists('fone_table_name')) {
    function fone_table_name() {
        return fone_table_entries();
    }
}

/* ---------------------------------------------------------------
   CREAZIONE / AGGIORNAMENTO TABELLE (dbDelta)
--------------------------------------------------------------- */

if (!function_exists('fone_create_table')) {
    function fone_create_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Tabella forms
        $sql_forms = "CREATE TABLE " . fone_table_forms() . " (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            form_name    VARCHAR(255)    NOT NULL DEFAULT '',
            form_slug    VARCHAR(255)    NOT NULL DEFAULT '',
            schema_json  LONGTEXT        NOT NULL,
            settings_json LONGTEXT       NOT NULL,
            layouts_json LONGTEXT        NOT NULL DEFAULT '{}',
            custom_css   LONGTEXT        NOT NULL DEFAULT '',
            is_registration TINYINT(1)   NOT NULL DEFAULT 0,
            is_login        TINYINT(1)   NOT NULL DEFAULT 0,
            sort_order   INT             NOT NULL DEFAULT 0,
            created_at   DATETIME        NOT NULL,
            updated_at   DATETIME        NOT NULL,
            PRIMARY KEY  (id),
            KEY form_slug (form_slug(191)),
            KEY is_registration (is_registration),
            KEY is_login (is_login)
        ) {$charset_collate};";
        dbDelta($sql_forms);

        // Tabella entries (con form_id)
        $sql_entries = "CREATE TABLE " . fone_table_entries() . " (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id      BIGINT UNSIGNED NOT NULL DEFAULT 0,
            submitted_at DATETIME        NOT NULL,
            page_url     TEXT            NOT NULL,
            values_json  LONGTEXT        NOT NULL,
            schema_json  LONGTEXT        NOT NULL,
            PRIMARY KEY  (id),
            KEY form_id (form_id),
            KEY submitted_at (submitted_at)
        ) {$charset_collate};";
        dbDelta($sql_entries);

        // Tabella Insights anonimi
        if (function_exists('fone_table_insights_events')) {
            $sql_insights = "CREATE TABLE " . fone_table_insights_events() . " (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                form_id      BIGINT UNSIGNED NOT NULL DEFAULT 0,
                event_type   VARCHAR(32)     NOT NULL DEFAULT '',
                step_number  INT             NOT NULL DEFAULT 0,
                session_hash VARCHAR(80)     NOT NULL DEFAULT '',
                page_url     VARCHAR(500)    NOT NULL DEFAULT '',
                created_at   DATETIME        NOT NULL,
                PRIMARY KEY  (id),
                KEY form_id (form_id),
                KEY event_type (event_type),
                KEY step_number (step_number),
                KEY created_at (created_at)
            ) {$charset_collate};";
            dbDelta($sql_insights);
        }

        update_option('fone_db_version', defined('FONE_DB_VERSION') ? FONE_DB_VERSION : '2.2.0');
    }
}

/* ---------------------------------------------------------------
   MIGRAZIONE: vecchi dati a singolo form → nuova struttura multi-form
--------------------------------------------------------------- */

if (!function_exists('fone_maybe_migrate_to_multiforms')) {
    function fone_maybe_migrate_to_multiforms() {
        if (get_option('fone_multiforms_migrated')) {
            return;
        }

        // Lock anti race-condition
        if (!wp_cache_add('fone_mf_migration_lock', 1, '', 60)) {
            return;
        }
        if (get_option('fone_multiforms_migrated')) {
            wp_cache_delete('fone_mf_migration_lock');
            return;
        }

        global $wpdb;

        // Verifica se esistono già form nella nuova tabella
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . fone_table_forms());
        if ($count === 0) {
            // Importa il vecchio form singolo
            $old_schema   = get_option('fone_form_schema', '');
            $old_settings = get_option('fone_settings', []);
            $old_layouts  = get_option('fone_step_layouts', []);
            $old_css      = get_option('fone_custom_css', '');

            if (empty($old_schema)) {
                $old_schema = wp_json_encode(fone_get_default_schema(), JSON_UNESCAPED_UNICODE);
            }
            if (!is_array($old_settings) || empty($old_settings)) {
                $old_settings = fone_default_settings();
            }

            $is_reg = !empty($old_settings['enable_registration']) ? 1 : 0;

            $wpdb->insert(fone_table_forms(), [
                'form_name'      => 'Form di Registrazione',
                'form_slug'      => 'form-registrazione',
                'schema_json'    => $old_schema,
                'settings_json'  => wp_json_encode($old_settings, JSON_UNESCAPED_UNICODE),
                'layouts_json'   => wp_json_encode(is_array($old_layouts) ? $old_layouts : [], JSON_UNESCAPED_UNICODE),
                'custom_css'     => $old_css ?: fone_get_default_custom_css(),
                'is_registration'=> $is_reg,
                'sort_order'     => 0,
                'created_at'     => current_time('mysql'),
                'updated_at'     => current_time('mysql'),
            ], ['%s','%s','%s','%s','%s','%s','%d','%d','%s','%s']);

            $form_id = (int) $wpdb->insert_id;

            // Aggiorna form_id nelle entries esistenti (se non hanno già form_id)
            if ($form_id > 0) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE " . fone_table_entries() . " SET form_id = %d WHERE form_id = 0",
                    $form_id
                ));
            }
        }

        // Migrazione vecchie entries da wp_options
        $old_entries = get_option('fone_entries', []);
        if (is_array($old_entries) && !empty($old_entries)) {
            $first_form_id = (int) $wpdb->get_var("SELECT id FROM " . fone_table_forms() . " ORDER BY id ASC LIMIT 1");
            foreach (array_reverse($old_entries) as $entry) {
                $wpdb->insert(fone_table_entries(), [
                    'form_id'      => $first_form_id,
                    'submitted_at' => !empty($entry['time']) ? $entry['time'] : current_time('mysql'),
                    'page_url'     => !empty($entry['url'])  ? mb_substr((string)$entry['url'], 0, 2000) : '',
                    'values_json'  => wp_json_encode(!empty($entry['values']) ? $entry['values'] : [], JSON_UNESCAPED_UNICODE),
                    'schema_json'  => wp_json_encode(!empty($entry['schema']) ? $entry['schema'] : [], JSON_UNESCAPED_UNICODE),
                ], ['%d','%s','%s','%s','%s']);
            }
            update_option('fone_entries', []);
        }

        update_option('fone_multiforms_migrated', '1');
        update_option('fone_entries_migrated', '1');
        wp_cache_delete('fone_mf_migration_lock');
    }
}

/* ---------------------------------------------------------------
   CRUD FORMS
--------------------------------------------------------------- */

if (!function_exists('fone_get_all_forms')) {
    function fone_get_all_forms() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT * FROM " . fone_table_forms() . " ORDER BY sort_order ASC, id ASC",
            ARRAY_A
        );
        $forms = [];
        foreach ((array) $rows as $row) {
            $forms[] = fone_hydrate_form($row);
        }
        return $forms;
    }
}

if (!function_exists('fone_get_form')) {
    function fone_get_form($form_id) {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . fone_table_forms() . " WHERE id = %d", (int) $form_id),
            ARRAY_A
        );
        if (!$row) return null;
        return fone_hydrate_form($row);
    }
}

if (!function_exists('fone_schema_has_registration_credentials')) {
    /** Rileva solo la presenza tecnica di email + password, senza decidere da sola che il form è registrazione. */
    function fone_schema_has_registration_credentials($schema) {
        $has_email = false;
        $has_pass  = false;

        if (!is_array($schema)) {
            return false;
        }

        foreach ($schema as $field) {
            if (!is_array($field)) continue;
            $type = sanitize_key($field['type'] ?? '');
            $slug = sanitize_key($field['slug'] ?? '');
            $wp_field = sanitize_key($field['wp_field'] ?? '');

            if ($type === 'email' || $slug === 'email' || $slug === 'login_email' || $wp_field === 'user_email') {
                $has_email = true;
            }
            if (($type === 'password' || $wp_field === 'user_pass') && $slug !== 'password_confirm') {
                $has_pass = true;
            }
        }

        return $has_email && $has_pass;
    }
}

if (!function_exists('fone_form_looks_like_registration')) {
    /**
     * Fallback legacy prudente: il form deve sembrare dichiaratamente un form registrazione/iscrizione/signup.
     * Serve a non interpretare come registrazione un normale form con email + password.
     */
    function fone_form_looks_like_registration($form) {
        if (!is_array($form)) {
            return false;
        }

        if (!empty($form['is_registration'])) {
            return true;
        }

        $settings = isset($form['settings']) && is_array($form['settings']) ? $form['settings'] : [];
        if (!empty($settings['enable_registration'])) {
            return true;
        }

        $name = sanitize_title((string) ($form['form_name'] ?? ''));
        $slug = sanitize_title((string) ($form['form_slug'] ?? ''));
        $haystack = $name . ' ' . $slug;

        return (bool) preg_match('/(registr|iscriz|signup|sign-up|account|utente|user)/i', $haystack);
    }
}

if (!function_exists('fone_maybe_repair_registration_flags')) {
    /**
     * Migrazione leggera: se un vecchio sito ha un form chiaramente di registrazione
     * ma senza flag DB/settings, lo marca correttamente. Non forza form generici.
     */
    function fone_maybe_repair_registration_flags() {
        if (get_option('fone_registration_flags_repaired_1014')) {
            return;
        }
        if (function_exists('fone_get_registration_form') && fone_get_registration_form()) {
            update_option('fone_registration_flags_repaired_1014', '1', false);
            return;
        }

        $forms = function_exists('fone_get_all_forms') ? fone_get_all_forms() : [];
        foreach ((array) $forms as $form) {
            $schema = $form['schema'] ?? [];
            if (!fone_form_looks_like_registration($form) || !fone_schema_has_registration_credentials($schema)) {
                continue;
            }

            $settings = isset($form['settings']) && is_array($form['settings']) ? $form['settings'] : [];
            $settings['enable_registration'] = 1;
            $settings['enable_login'] = 0;

            if (function_exists('fone_save_form')) {
                fone_save_form((int) $form['id'], [
                    'settings' => $settings,
                    'is_registration' => 1,
                    'is_login' => 0,
                ]);
            }
            break;
        }

        update_option('fone_registration_flags_repaired_1014', '1', false);
    }
}

if (!function_exists('fone_get_registration_form')) {
    /** Ritorna il form (idratato) impostato come form di registrazione, o null. */
    function fone_get_registration_form() {
        global $wpdb;
        $row = $wpdb->get_row(
            "SELECT * FROM " . fone_table_forms() . " WHERE is_registration = 1 LIMIT 1",
            ARRAY_A
        );
        if (!$row) return null;
        return fone_hydrate_form($row);
    }
}

if (!function_exists('fone_hydrate_form')) {
    function fone_hydrate_form($row) {
        if (!$row) return null;
        $settings = json_decode($row['settings_json'] ?? '{}', true);
        if (!is_array($settings)) $settings = fone_default_settings();
        $settings = wp_parse_args($settings, fone_default_settings());

        return [
            'id'              => (int) $row['id'],
            'form_name'       => $row['form_name'] ?? '',
            'form_slug'       => $row['form_slug'] ?? '',
            'schema'          => json_decode($row['schema_json'] ?? '[]', true) ?: fone_get_default_schema(),
            'settings'        => $settings,
            'layouts'         => json_decode($row['layouts_json'] ?? '{}', true) ?: [],
            'custom_css'      => $row['custom_css'] ?? '',
            'is_registration' => (int) ($row['is_registration'] ?? 0),
            'is_login'        => (int) ($row['is_login'] ?? 0),
            'sort_order'      => (int) ($row['sort_order'] ?? 0),
            'created_at'      => $row['created_at'] ?? '',
            'updated_at'      => $row['updated_at'] ?? '',
        ];
    }
}

if (!function_exists('fone_create_form')) {
    function fone_create_form($name = '') {
        global $wpdb;
        if (empty($name)) $name = 'Nuovo Form';
        $slug = sanitize_title($name);
        $base = $slug;
        $i = 1;
        while ($wpdb->get_var($wpdb->prepare("SELECT id FROM " . fone_table_forms() . " WHERE form_slug = %s", $slug))) {
            $slug = $base . '-' . $i++;
        }
        $default_schema   = fone_get_default_schema();
        $default_settings = fone_default_settings();
        $default_css      = fone_get_default_custom_css();

        $wpdb->insert(fone_table_forms(), [
            'form_name'      => sanitize_text_field($name),
            'form_slug'      => $slug,
            'schema_json'    => wp_json_encode($default_schema, JSON_UNESCAPED_UNICODE),
            'settings_json'  => wp_json_encode($default_settings, JSON_UNESCAPED_UNICODE),
            'layouts_json'   => '{}',
            'custom_css'     => $default_css,
            'is_registration'=> 0,
            'is_login'       => 0,
            'sort_order'     => 0,
            'created_at'     => current_time('mysql'),
            'updated_at'     => current_time('mysql'),
        ], ['%s','%s','%s','%s','%s','%s','%d','%d','%d','%s','%s']);

        return (int) $wpdb->insert_id;
    }
}

if (!function_exists('fone_save_form')) {
    function fone_save_form($form_id, $data) {
        global $wpdb;
        $form_id = (int) $form_id;
        if (!$form_id) return false;

        $update = ['updated_at' => current_time('mysql')];

        if (isset($data['form_name']))     $update['form_name']       = sanitize_text_field($data['form_name']);
        if (isset($data['schema']))        $update['schema_json']      = wp_json_encode($data['schema'], JSON_UNESCAPED_UNICODE);
        if (isset($data['settings']))      $update['settings_json']    = wp_json_encode($data['settings'], JSON_UNESCAPED_UNICODE);
        if (isset($data['layouts']))       $update['layouts_json']     = wp_json_encode($data['layouts'], JSON_UNESCAPED_UNICODE);
        if (isset($data['custom_css']))    $update['custom_css']       = wp_strip_all_tags($data['custom_css']);
        if (isset($data['is_registration'])) $update['is_registration'] = (int)(bool) $data['is_registration'];
        if (isset($data['is_login']))         $update['is_login']         = (int)(bool) $data['is_login'];

        return (bool) $wpdb->update(fone_table_forms(), $update, ['id' => $form_id]);
    }
}

if (!function_exists('fone_get_login_form')) {
    function fone_get_login_form() {
        global $wpdb;
        $row = $wpdb->get_row("SELECT * FROM " . fone_table_forms() . " WHERE is_login = 1 LIMIT 1", ARRAY_A);
        if (!$row) return null;
        return fone_hydrate_form($row);
    }
}

if (!function_exists('fone_set_login_form')) {
    function fone_set_login_form($form_id) {
        global $wpdb;
        $wpdb->query("UPDATE " . fone_table_forms() . " SET is_login = 0");
        if ($form_id) {
            $wpdb->update(fone_table_forms(), ['is_login' => 1], ['id' => (int) $form_id]);
        }
    }
}

if (!function_exists('fone_set_registration_form')) {
    /**
     * Imposta $form_id come form di registrazione (uno solo alla volta).
     * Se $form_id è 0/null, rimuove il flag da tutti.
     */
    function fone_set_registration_form($form_id) {
        global $wpdb;
        // Rimuove flag da tutti
        $wpdb->query("UPDATE " . fone_table_forms() . " SET is_registration = 0");
        if ($form_id) {
            $wpdb->update(fone_table_forms(), ['is_registration' => 1], ['id' => (int) $form_id]);
        }
    }
}

if (!function_exists('fone_delete_form')) {
    function fone_delete_form($form_id) {
        global $wpdb;
        $form_id = (int) $form_id;
        if (!$form_id) return false;
        // Elimina entries associate
        $wpdb->delete(fone_table_entries(), ['form_id' => $form_id], ['%d']);
        return (bool) $wpdb->delete(fone_table_forms(), ['id' => $form_id], ['%d']);
    }
}

/* ---------------------------------------------------------------
   CRUD ENTRIES
--------------------------------------------------------------- */

if (!function_exists('fone_db_insert_entry')) {
    function fone_db_insert_entry($schema, $values, $page_url = '', $form_id = 0) {
        global $wpdb;
        if (empty($page_url)) {
            $page_url = isset($_SERVER['REQUEST_URI'])
                ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
        }
        $page_url = mb_substr((string) $page_url, 0, 2000);

        $result = $wpdb->insert(fone_table_entries(), [
            'form_id'      => (int) $form_id,
            'submitted_at' => current_time('mysql'),
            'page_url'     => $page_url,
            'values_json'  => wp_json_encode($values, JSON_UNESCAPED_UNICODE),
            'schema_json'  => wp_json_encode($schema, JSON_UNESCAPED_UNICODE),
        ], ['%d','%s','%s','%s','%s']);

        return $result ? (int) $wpdb->insert_id : false;
    }
}

if (!function_exists('fone_db_get_entries')) {
    function fone_db_get_entries($args = []) {
        global $wpdb;
        $defaults = ['per_page' => 20, 'page' => 1, 'search' => '', 'form_id' => 0];
        $args  = wp_parse_args($args, $defaults);
        $table = fone_table_entries();
        $offset = (max(1, (int) $args['page']) - 1) * (int) $args['per_page'];
        $limit  = (int) $args['per_page'];

        $where  = '1=1';
        $params = [];

        if (!empty($args['form_id'])) {
            $where   .= ' AND form_id = %d';
            $params[] = (int) $args['form_id'];
        }
        if (!empty($args['search'])) {
            $where   .= ' AND values_json LIKE %s';
            $params[] = '%' . $wpdb->esc_like($args['search']) . '%';
        }

        if (!empty($params)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE {$where}", ...$params));
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $rows  = $wpdb->get_results(
                $wpdb->prepare("SELECT * FROM {$table} WHERE {$where} ORDER BY submitted_at DESC LIMIT %d OFFSET %d",
                    ...array_merge($params, [$limit, $offset])),
                ARRAY_A
            );
        } else {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $rows  = $wpdb->get_results(
                $wpdb->prepare("SELECT * FROM {$table} ORDER BY submitted_at DESC LIMIT %d OFFSET %d", $limit, $offset),
                ARRAY_A
            );
        }

        $entries = [];
        foreach ((array) $rows as $row) {
            $entries[] = [
                'id'      => (int) $row['id'],
                'form_id' => (int) $row['form_id'],
                'time'    => $row['submitted_at'],
                'url'     => $row['page_url'],
                'values'  => json_decode($row['values_json'], true) ?: [],
                'schema'  => json_decode($row['schema_json'],  true) ?: [],
            ];
        }
        return ['entries' => $entries, 'total' => $total];
    }
}

if (!function_exists('fone_db_delete_entry')) {
    function fone_db_delete_entry($id) {
        global $wpdb;
        return (bool) $wpdb->delete(fone_table_entries(), ['id' => (int) $id], ['%d']);
    }
}

if (!function_exists('fone_db_delete_all_entries')) {
    function fone_db_delete_all_entries($form_id = 0) {
        global $wpdb;
        if ($form_id) {
            return (bool) $wpdb->delete(fone_table_entries(), ['form_id' => (int) $form_id], ['%d']);
        }
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return (bool) $wpdb->query("DELETE FROM " . fone_table_entries());
    }
}

if (!function_exists('fone_db_count_entries')) {
    function fone_db_count_entries($form_id = 0) {
        global $wpdb;
        $table = fone_table_entries();
        if ($form_id) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE form_id = %d", (int) $form_id));
        }
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
    }
}

if (!function_exists('fone_db_get_all_entries_for_export')) {
    function fone_db_get_all_entries_for_export($form_id = 0) {
        global $wpdb;
        $table = fone_table_entries();
        if ($form_id) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $rows = $wpdb->get_results(
                $wpdb->prepare("SELECT * FROM {$table} WHERE form_id = %d ORDER BY submitted_at DESC", (int) $form_id),
                ARRAY_A
            );
        } else {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $rows = $wpdb->get_results("SELECT * FROM {$table} ORDER BY submitted_at DESC", ARRAY_A);
        }
        $entries = [];
        foreach ((array) $rows as $row) {
            $entries[] = [
                'id'      => (int) $row['id'],
                'form_id' => (int) $row['form_id'],
                'time'    => $row['submitted_at'],
                'url'     => $row['page_url'],
                'values'  => json_decode($row['values_json'], true) ?: [],
                'schema'  => json_decode($row['schema_json'],  true) ?: [],
            ];
        }
        return $entries;
    }
}

/* ---------------------------------------------------------------
   HOOK: crea tabelle / verifica versione / migrazione
--------------------------------------------------------------- */

add_action('plugins_loaded', function () {
    $target = defined('FONE_DB_VERSION') ? FONE_DB_VERSION : '2.2.0';
    if (get_option('fone_db_version') !== $target) {
        fone_create_table();
    }
    fone_maybe_migrate_to_multiforms();
    if (function_exists('fone_maybe_repair_registration_flags')) {
        fone_maybe_repair_registration_flags();
    }
}, 5);
