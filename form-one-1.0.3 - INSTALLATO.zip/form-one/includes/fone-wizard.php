<?php
/**
 * Form One — Setup Wizard
 *
 * Wizard di onboarding mostrato alla prima attivazione del plugin.
 * 5 step: Benvenuto / Stile / Email / Pagina / Completato.
 * Crea automaticamente un form di partenza basato sull'obiettivo scelto.
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   ATTIVAZIONE: marca il flag "wizard da fare"
--------------------------------------------------------------- */

if (!function_exists('fone_wizard_mark_for_activation')) {
    function fone_wizard_mark_for_activation() {
        // Marca solo se non già completato in passato
        if (!get_option('fone_wizard_completed')) {
            set_transient('fone_wizard_redirect', 1, 60);
        }
    }
}
add_action('fone_after_activate', 'fone_wizard_mark_for_activation');

/* ---------------------------------------------------------------
   REDIRECT AUTOMATICO al wizard alla prima attivazione
--------------------------------------------------------------- */

if (!function_exists('fone_wizard_maybe_redirect')) {
    function fone_wizard_maybe_redirect() {
        if (!get_transient('fone_wizard_redirect')) return;
        delete_transient('fone_wizard_redirect');
        if (wp_doing_ajax() || is_network_admin() || isset($_GET['activate-multi'])) return;
        if (!current_user_can('manage_options')) return;
        wp_safe_redirect(admin_url('admin.php?page=fone-wizard'));
        exit;
    }
}
add_action('admin_init', 'fone_wizard_maybe_redirect');

/* ---------------------------------------------------------------
   MENU: pagina nascosta del wizard
--------------------------------------------------------------- */

if (!function_exists('fone_wizard_register_menu')) {
    function fone_wizard_register_menu() {
        add_submenu_page(
            null, // nascosto dal menu
            __('Setup Wizard — Form One', 'form-one'),
            '',
            'manage_options',
            'fone-wizard',
            'fone_wizard_render_page'
        );
    }
}
add_action('admin_menu', 'fone_wizard_register_menu', 99);

/* ---------------------------------------------------------------
   AJAX: salva lo step e prosegui
--------------------------------------------------------------- */

if (!function_exists('fone_wizard_ajax_save')) {
    function fone_wizard_ajax_save() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'forbidden'], 403);
        }
        check_ajax_referer('fone_wizard', 'nonce');

        $step = isset($_POST['step']) ? absint($_POST['step']) : 0;
        $data = isset($_POST['data']) && is_array($_POST['data']) ? wp_unslash($_POST['data']) : [];

        $state = get_option('fone_wizard_state', []);
        if (!is_array($state)) $state = [];

        switch ($step) {
            case 1: // Obiettivo
                $goal = isset($data['goal']) ? sanitize_key($data['goal']) : 'lead';
                if (!in_array($goal, ['lead', 'registration', 'request', 'other'], true)) {
                    $goal = 'lead';
                }
                $state['goal'] = $goal;
                break;

            case 2: // Stile
                $color = isset($data['color']) ? sanitize_hex_color($data['color']) : '#374151';
                $tone  = isset($data['tone']) ? sanitize_key($data['tone']) : 'friendly';
                if (!in_array($tone, ['direct', 'friendly', 'pro'], true)) $tone = 'friendly';
                $state['color']      = $color ? $color : '#374151';
                $state['tone']       = $tone;
                $state['anti_drop']  = !empty($data['anti_drop']) ? 1 : 0;
                break;

            case 3: // Email
                $email = isset($data['admin_email']) ? sanitize_email($data['admin_email']) : '';
                if (!is_email($email)) $email = get_option('admin_email');
                $state['admin_email']        = $email;
                $state['send_user_email']    = !empty($data['send_user_email']) ? 1 : 0;
                break;

            case 4: // Pagina
                $action = isset($data['page_action']) ? sanitize_key($data['page_action']) : 'create';
                if (!in_array($action, ['create', 'shortcode', 'skip'], true)) $action = 'create';
                $state['page_action'] = $action;
                break;
        }

        update_option('fone_wizard_state', $state, false);
        wp_send_json_success(['state' => $state]);
    }
}
add_action('wp_ajax_fone_wizard_save', 'fone_wizard_ajax_save');

/* ---------------------------------------------------------------
   AJAX: completa il wizard — crea form, applica settings, ecc.
--------------------------------------------------------------- */

if (!function_exists('fone_wizard_ajax_complete')) {
    function fone_wizard_ajax_complete() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'forbidden'], 403);
        }
        check_ajax_referer('fone_wizard', 'nonce');

        $state = get_option('fone_wizard_state', []);
        if (!is_array($state)) $state = [];

        $goal     = isset($state['goal']) ? $state['goal'] : 'lead';
        $color    = isset($state['color']) ? $state['color'] : '#374151';
        $tone     = isset($state['tone']) ? $state['tone'] : 'friendly';
        $antidrop = !empty($state['anti_drop']);
        $email    = !empty($state['admin_email']) ? $state['admin_email'] : get_option('admin_email');
        $send_user= !empty($state['send_user_email']);
        $action   = isset($state['page_action']) ? $state['page_action'] : 'create';

        // 1. Mappa obiettivo → template
        $template_map = [
            'lead'         => 'lead-magnet',
            'registration' => 'registrazione-utenti',
            'request'      => 'preventivo-veloce',
            'other'        => '', // form vuoto
        ];
        $template_key = isset($template_map[$goal]) ? $template_map[$goal] : '';

        // 2. Crea il form
        $form_id = 0;
        if ($template_key && function_exists('fone_create_form_from_template')) {
            $form_id = fone_create_form_from_template($template_key);
        } else {
            // Form vuoto base
            if (function_exists('fone_create_form')) {
                $form_id = fone_create_form('Il mio primo form');
            }
        }

        if (!$form_id) {
            wp_send_json_error(['message' => __('Impossibile creare il form.', 'form-one')]);
        }

        // 3. Applica settings (colore, email, tone, anti-drop)
        if (function_exists('fone_get_form') && function_exists('fone_save_form')) {
            $form = fone_get_form($form_id);
            if ($form && !empty($form['settings'])) {
                $s = $form['settings'];
                $s['accent_color']                 = $color;
                $s['admin_email']                  = $email;
                $s['send_user_email']              = $send_user ? 1 : 0;

                if ($antidrop) {
                    $s['resume_later_enabled'] = 1;
                    $s['first_yes_enabled']    = 1;
                }

                // Microcopy in base al tone — solo placeholder/help, non rompe nulla
                if ($tone === 'direct') {
                    $s['success_message'] = 'Fatto. Ti rispondiamo a breve.';
                } elseif ($tone === 'pro') {
                    $s['success_message'] = 'La sua richiesta è stata inviata correttamente. La contatteremo al più presto.';
                } else { // friendly
                    $s['success_message'] = 'Grazie! 🌿 Abbiamo ricevuto la tua richiesta e ti risponderemo a breve.';
                }

                fone_save_form($form_id, [
                    'schema'   => $form['schema'],
                    'settings' => $s,
                    'layouts'  => isset($form['layouts']) ? $form['layouts'] : [],
                ]);
            }
        }

        // 4. Pagina con shortcode
        $page_url = '';
        if ($action === 'create') {
            $page_title = $goal === 'registration' ? 'Registrati' :
                          ($goal === 'request' ? 'Richiedi un preventivo' : 'Contatti');
            $page_slug  = $goal === 'registration' ? 'registrati' :
                          ($goal === 'request' ? 'richiedi-preventivo' : 'contatti');

            $shortcode = '[form_one id="' . (int) $form_id . '"]';
            $existing = get_page_by_path($page_slug);
            if (!$existing) {
                $page_id = wp_insert_post([
                    'post_title'   => $page_title,
                    'post_name'    => $page_slug,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_content' => $shortcode,
                    'post_author'  => get_current_user_id() ?: 1,
                ]);
                if ($page_id && !is_wp_error($page_id)) {
                    $page_url = get_permalink($page_id);
                }
            } else {
                $page_id = (int) $existing->ID;
                $content = (string) $existing->post_content;
                if (has_shortcode($content, 'form_one')) {
                    // Se la pagina esiste già ma contiene uno shortcode vecchio,
                    // aggiorno l'ID al form appena creato dal wizard.
                    $new_content = preg_replace('/\[form_one(?:\s+[^\]]*)?\]/', $shortcode, $content, 1);
                    if ($new_content && $new_content !== $content) {
                        wp_update_post([
                            'ID'           => $page_id,
                            'post_content' => $new_content,
                        ]);
                    }
                } else {
                    wp_update_post([
                        'ID'           => $page_id,
                        'post_content' => trim($content) !== '' ? $content . "

" . $shortcode : $shortcode,
                    ]);
                }
                $page_url = get_permalink($page_id);
            }
        }

        // 5. Marca wizard completato
        update_option('fone_wizard_completed', 1, false);
        delete_option('fone_wizard_state'); // pulizia stato temporaneo

        wp_send_json_success([
            'form_id'      => (int) $form_id,
            'shortcode'    => '[form_one id="' . (int) $form_id . '"]',
            'builder_url'  => admin_url('admin.php?page=fone-builder&form_id=' . (int) $form_id),
            'page_url'     => $page_url,
            'page_action'  => $action,
        ]);
    }
}
add_action('wp_ajax_fone_wizard_complete', 'fone_wizard_ajax_complete');

/* ---------------------------------------------------------------
   AJAX: skip wizard
--------------------------------------------------------------- */

if (!function_exists('fone_wizard_ajax_skip')) {
    function fone_wizard_ajax_skip() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'forbidden'], 403);
        }
        check_ajax_referer('fone_wizard', 'nonce');
        update_option('fone_wizard_completed', 1, false);
        delete_option('fone_wizard_state');
        wp_send_json_success(['redirect' => admin_url('admin.php?page=fone-forms')]);
    }
}
add_action('wp_ajax_fone_wizard_skip', 'fone_wizard_ajax_skip');

/* ---------------------------------------------------------------
   PAGINA WIZARD
--------------------------------------------------------------- */

if (!function_exists('fone_wizard_render_page')) {
    function fone_wizard_render_page() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');

        $nonce = wp_create_nonce('fone_wizard');
        $ajax  = admin_url('admin-ajax.php');
        $admin_email = get_option('admin_email');
        $forms_url   = admin_url('admin.php?page=fone-forms');
        ?>
        <style>
        /* Reset interno wizard — prende tutto schermo */
        #wpwrap, #wpcontent, #wpbody, #wpbody-content, #wpfooter { background: transparent; }
        #adminmenuback, #adminmenuwrap, #wpadminbar, #wpfooter { display: none !important; }
        html.wp-toolbar { padding-top: 0 !important; }
        body.fone-wizard-body { background: #faf7ff; margin: 0 !important; }
        #wpcontent { margin-left: 0 !important; padding-left: 0 !important; }

        .fone-wiz {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: #0a0a0f;
            background: linear-gradient(135deg, #f9fafb 0%, #f3f4f6 50%, #f9fafb 100%);
        }
        .fone-wiz-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 24px 38px;
        }
        .fone-wiz-brand {
            font-size: 22px;
            font-weight: 900;
            letter-spacing: -.5px;
            background: linear-gradient(135deg, #374151 0%, #374151 50%, #4b5563 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .fone-wiz-skip {
            color: #71717A;
            text-decoration: none;
            font-size: 13px;
        }
        .fone-wiz-skip:hover { color: #374151; }

        .fone-wiz-progress {
            display: flex;
            justify-content: center;
            gap: 8px;
            padding: 0 38px 8px;
        }
        .fone-wiz-progress-dot {
            width: 36px;
            height: 4px;
            border-radius: 2px;
            background: #e4e4e7;
            transition: background .25s;
        }
        .fone-wiz-progress-dot.is-done {
            background: linear-gradient(90deg, #374151, #374151);
        }

        .fone-wiz-stage {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 38px 60px;
        }
        .fone-wiz-card {
            max-width: 720px;
            width: 100%;
            background: #fff;
            border-radius: 24px;
            padding: 48px 52px;
            box-shadow: 0 12px 48px rgba(108, 43, 217, 0.10), 0 4px 12px rgba(108, 43, 217, 0.06);
            animation: foneSlide .35s ease;
        }
        @keyframes foneSlide {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fone-wiz-step-num {
            font-size: 12px;
            font-weight: 700;
            color: #374151;
            letter-spacing: .08em;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .fone-wiz-title {
            font-size: 30px;
            font-weight: 800;
            line-height: 1.2;
            margin: 0 0 12px;
            letter-spacing: -.5px;
            color: #0A0A0F;
        }
        .fone-wiz-subtitle {
            font-size: 15px;
            color: #52525b;
            margin: 0 0 32px;
            line-height: 1.6;
        }

        /* Card scelta multipla */
        .fone-wiz-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 14px;
            margin-bottom: 32px;
        }
        @media (max-width: 600px) {
            .fone-wiz-grid { grid-template-columns: 1fr; }
            .fone-wiz-card { padding: 32px 24px; }
            .fone-wiz-title { font-size: 24px; }
        }
        .fone-wiz-choice {
            cursor: pointer;
            background: #fff;
            border: 2px solid #e4e4e7;
            border-radius: 14px;
            padding: 20px 18px;
            transition: all .18s;
            text-align: left;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .fone-wiz-choice:hover {
            border-color: #374151;
            transform: translateY(-2px);
            box-shadow: 0 4px 14px rgba(108, 43, 217, 0.12);
        }
        .fone-wiz-choice.is-active {
            border-color: #374151;
            background: linear-gradient(135deg, #f9fafb 0%, #FFFFFF 100%);
            box-shadow: 0 0 0 4px rgba(108, 43, 217, 0.10);
        }
        .fone-wiz-choice-emoji {
            font-size: 28px;
            line-height: 1;
        }
        .fone-wiz-choice-title {
            font-size: 15px;
            font-weight: 700;
            color: #0A0A0F;
        }
        .fone-wiz-choice-desc {
            font-size: 13px;
            color: #71717A;
            line-height: 1.5;
        }

        /* Form fields */
        .fone-wiz-field { margin-bottom: 18px; }
        .fone-wiz-field label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #3F3F46;
            margin-bottom: 6px;
        }
        .fone-wiz-field input[type="email"],
        .fone-wiz-field input[type="text"] {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #e4e4e7;
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            color: #0A0A0F;
            background: #fff;
            box-sizing: border-box;
        }
        .fone-wiz-field input:focus {
            outline: none;
            border-color: #374151;
            box-shadow: 0 0 0 3px rgba(108, 43, 217, 0.15);
        }
        .fone-wiz-checkbox {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            cursor: pointer;
            padding: 12px 14px;
            border: 1px solid #e4e4e7;
            border-radius: 10px;
            transition: all .15s;
        }
        .fone-wiz-checkbox:hover { border-color: #374151; }
        .fone-wiz-checkbox input { margin-top: 3px; flex-shrink: 0; }
        .fone-wiz-checkbox-text { font-size: 13px; color: #3F3F46; line-height: 1.6; }
        .fone-wiz-checkbox-text strong { color: #0A0A0F; }

        /* Color picker */
        .fone-wiz-colors {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 14px;
        }
        .fone-wiz-color {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            cursor: pointer;
            border: 3px solid transparent;
            transition: transform .15s;
        }
        .fone-wiz-color:hover { transform: scale(1.08); }
        .fone-wiz-color.is-active {
            border-color: #0A0A0F;
            transform: scale(1.08);
        }
        .fone-wiz-color-custom {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            border: 1px solid #e4e4e7;
            border-radius: 8px;
            cursor: pointer;
            font-size: 12px;
            color: #52525b;
        }
        .fone-wiz-color-custom input[type="color"] {
            width: 28px;
            height: 28px;
            border: none;
            background: transparent;
            cursor: pointer;
        }

        /* Bottoni nav */
        .fone-wiz-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 24px;
            gap: 12px;
        }
        .fone-wiz-btn {
            padding: 13px 28px;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: all .15s;
            font-family: inherit;
        }
        .fone-wiz-btn-primary {
            background: linear-gradient(135deg, #374151 0%, #374151 100%);
            color: #fff;
            box-shadow: 0 4px 14px rgba(108, 43, 217, 0.30);
        }
        .fone-wiz-btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 18px rgba(108, 43, 217, 0.40);
        }
        .fone-wiz-btn-primary:disabled {
            opacity: 0.45;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        .fone-wiz-btn-back {
            background: transparent;
            color: #71717A;
        }
        .fone-wiz-btn-back:hover { color: #374151; }

        /* Step finale: success card */
        .fone-wiz-success {
            text-align: center;
        }
        .fone-wiz-success-emoji {
            font-size: 64px;
            line-height: 1;
            margin-bottom: 18px;
        }
        .fone-wiz-shortcode {
            background: #0F172A;
            color: #A5F3FC;
            padding: 14px 18px;
            border-radius: 10px;
            font-family: 'SF Mono', Menlo, monospace;
            font-size: 14px;
            margin: 24px 0;
            display: inline-block;
            font-weight: 600;
        }
        .fone-wiz-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 8px;
        }
        .fone-wiz-actions .fone-wiz-btn {
            padding: 14px 24px;
        }
        .fone-wiz-secondary-link {
            display: inline-block;
            margin-top: 22px;
            color: #374151;
            font-size: 13px;
            text-decoration: none;
            font-weight: 500;
        }
        .fone-wiz-secondary-link:hover { text-decoration: underline; }

        /* Loader */
        .fone-wiz-loader {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: #fff;
            border-radius: 50%;
            animation: foneSpin .7s linear infinite;
            vertical-align: middle;
            margin-right: 6px;
        }
        @keyframes foneSpin { to { transform: rotate(360deg); } }
        </style>

        <div class="fone-wiz" id="fone-wiz-root">
            <div class="fone-wiz-top">
                <div class="fone-wiz-brand"><i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i> Form One</div>
                <a href="#" class="fone-wiz-skip" id="fone-wiz-skip-link"><?php esc_html_e('Salta il setup', 'form-one'); ?></a>
            </div>

            <div class="fone-wiz-progress" id="fone-wiz-progress">
                <span class="fone-wiz-progress-dot is-done"></span>
                <span class="fone-wiz-progress-dot"></span>
                <span class="fone-wiz-progress-dot"></span>
                <span class="fone-wiz-progress-dot"></span>
                <span class="fone-wiz-progress-dot"></span>
            </div>

            <div class="fone-wiz-stage">
                <div class="fone-wiz-card" id="fone-wiz-card">
                    <!-- Contenuto generato da JS -->
                </div>
            </div>
        </div>

        <script>
        (function() {
            var ajaxUrl = <?php echo wp_json_encode($ajax); ?>;
            var nonce   = <?php echo wp_json_encode($nonce); ?>;
            var defaultEmail = <?php echo wp_json_encode($admin_email); ?>;
            var formsUrl = <?php echo wp_json_encode($forms_url); ?>;

            var state = {
                step: 1,
                goal: 'lead',
                color: '#374151',
                tone: 'friendly',
                anti_drop: 1,
                admin_email: defaultEmail,
                send_user_email: 1,
                page_action: 'create'
            };

            document.body.classList.add('fone-wizard-body');
            var card = document.getElementById('fone-wiz-card');
            var progress = document.getElementById('fone-wiz-progress');

            function updateProgress() {
                var dots = progress.querySelectorAll('.fone-wiz-progress-dot');
                dots.forEach(function(d, i) {
                    d.classList.toggle('is-done', i < state.step);
                });
            }

            function ajax(action, data) {
                var fd = new FormData();
                fd.append('action', action);
                fd.append('nonce', nonce);
                if (data) {
                    fd.append('step', data.step || 0);
                    if (data.payload) {
                        Object.keys(data.payload).forEach(function(k) {
                            fd.append('data[' + k + ']', data.payload[k]);
                        });
                    }
                }
                return fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
                    .then(function(r) { return r.json(); });
            }

            function escapeHtml(s) {
                return String(s).replace(/[&<>"']/g, function(c) {
                    return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c];
                });
            }
            function faIcon(iconClass) {
                iconClass = String(iconClass || '').replace(/[^a-zA-Z0-9_\- ]/g, '').trim();
                return iconClass ? '<i class="' + escapeHtml(iconClass) + '" aria-hidden="true"></i>' : '';
            }

            // ===== STEP 1: OBIETTIVO =====
            function renderStep1() {
                state.step = 1;
                updateProgress();
                card.innerHTML = ''
                    + '<div class="fone-wiz-step-num">PASSO 1 DI 5</div>'
                    + '<h1 class="fone-wiz-title">Cosa vuoi fare con Form One?</h1>'
                    + '<p class="fone-wiz-subtitle">Scegli il tuo obiettivo principale. Imposteremo tutto in base a questa scelta — potrai sempre cambiare dopo.</p>'
                    + '<div class="fone-wiz-grid">'
                    +   choiceCard('lead', 'fa-solid fa-envelope-open-text', 'Raccogliere contatti', 'Lead generation, lead magnet, iscrizioni a newsletter.')
                    +   choiceCard('registration', 'fa-solid fa-user-plus', 'Far registrare utenti', 'Crea account WordPress automaticamente al submit.')
                    +   choiceCard('request', 'fa-solid fa-comments', 'Ricevere richieste', 'Preventivi, contatti, richieste di informazioni.')
                    +   choiceCard('other', 'fa-solid fa-sliders', 'Altro / configuro io', 'Parto da un form vuoto e lo costruisco da zero.')
                    + '</div>'
                    + navButtons({ back: false, nextDisabled: false });
                bindChoiceClicks('goal');
                bindNext(function() { saveStepAndGo(1, { goal: state.goal }, renderStep2); });
            }

            // ===== STEP 2: STILE =====
            function renderStep2() {
                state.step = 2;
                updateProgress();
                var palette = [
                    { color: '#374151', name: 'Fucsia' },
                    { color: '#374151', name: 'Viola' },
                    { color: '#4b5563', name: 'Blu elettrico' },
                    { color: '#16A34A', name: 'Verde' },
                    { color: '#F97316', name: 'Arancio' },
                    { color: '#0A0A0F', name: 'Nero' }
                ];

                card.innerHTML = ''
                    + '<div class="fone-wiz-step-num">PASSO 2 DI 5</div>'
                    + '<h1 class="fone-wiz-title">Dai uno stile ai tuoi form</h1>'
                    + '<p class="fone-wiz-subtitle">Colore principale, tono delle parole, e qualche aiutino contro l\'abbandono.</p>'
                    + '<div class="fone-wiz-field"><label>Colore principale</label>'
                    +   '<div class="fone-wiz-colors" id="fone-wiz-colors">'
                    +     palette.map(function(p) {
                            return '<span class="fone-wiz-color' + (state.color === p.color ? ' is-active' : '') + '" data-color="' + p.color + '" style="background:' + p.color + '" title="' + p.name + '"></span>';
                          }).join('')
                    +     '<label class="fone-wiz-color-custom"><input type="color" id="fone-wiz-color-custom" value="' + state.color + '"> Custom</label>'
                    +   '</div>'
                    + '</div>'

                    + '<div class="fone-wiz-field"><label>Tono dei testi</label>'
                    +   '<div class="fone-wiz-grid" style="grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:0;">'
                    +     toneCard('direct', 'fa-solid fa-bolt', 'Diretto', 'Va al punto. Frasi brevi.')
                    +     toneCard('friendly', 'fa-solid fa-leaf', 'Amichevole', 'Tono caldo e accogliente.')
                    +     toneCard('pro', 'fa-solid fa-briefcase', 'Professionale', 'Formale, "Lei", aziendale.')
                    +   '</div>'
                    + '</div>'

                    + '<label class="fone-wiz-checkbox">'
                    +   '<input type="checkbox" id="fone-wiz-antidrop" ' + (state.anti_drop ? 'checked' : '') + '>'
                    +   '<span class="fone-wiz-checkbox-text"><strong>Attiva funzioni anti-abbandono</strong><br>Resume Later (salva il form mentre l\'utente scrive) e First Yes Mode (primo step più leggero) per ridurre l\'abbandono.</span>'
                    + '</label>'

                    + navButtons({ back: true, nextDisabled: false });

                bindColorPickers();
                bindToneCards();
                document.getElementById('fone-wiz-antidrop').addEventListener('change', function() {
                    state.anti_drop = this.checked ? 1 : 0;
                });
                bindBack(renderStep1);
                bindNext(function() {
                    saveStepAndGo(2, { color: state.color, tone: state.tone, anti_drop: state.anti_drop }, renderStep3);
                });
            }

            // ===== STEP 3: EMAIL =====
            function renderStep3() {
                state.step = 3;
                updateProgress();
                card.innerHTML = ''
                    + '<div class="fone-wiz-step-num">PASSO 3 DI 5</div>'
                    + '<h1 class="fone-wiz-title">Notifiche email</h1>'
                    + '<p class="fone-wiz-subtitle">Dove ti arrivano gli invii? E vuoi mandare anche una conferma al visitatore?</p>'

                    + '<div class="fone-wiz-field">'
                    +   '<label>A che indirizzo vuoi ricevere gli invii?</label>'
                    +   '<input type="email" id="fone-wiz-email" value="' + escapeHtml(state.admin_email || '') + '" placeholder="tu@tuosito.it">'
                    + '</div>'

                    + '<label class="fone-wiz-checkbox">'
                    +   '<input type="checkbox" id="fone-wiz-userMail" ' + (state.send_user_email ? 'checked' : '') + '>'
                    +   '<span class="fone-wiz-checkbox-text"><strong>Manda anche una conferma all\'utente</strong><br>Quando un visitatore compila il form, riceve un\'email di conferma con il riepilogo dei dati inseriti.</span>'
                    + '</label>'

                    + navButtons({ back: true, nextDisabled: false });

                document.getElementById('fone-wiz-email').addEventListener('input', function() {
                    state.admin_email = this.value;
                });
                document.getElementById('fone-wiz-userMail').addEventListener('change', function() {
                    state.send_user_email = this.checked ? 1 : 0;
                });
                bindBack(renderStep2);
                bindNext(function() {
                    saveStepAndGo(3, { admin_email: state.admin_email, send_user_email: state.send_user_email }, renderStep4);
                });
            }

            // ===== STEP 4: PAGINA =====
            function renderStep4() {
                state.step = 4;
                updateProgress();
                card.innerHTML = ''
                    + '<div class="fone-wiz-step-num">PASSO 4 DI 5</div>'
                    + '<h1 class="fone-wiz-title">Dove vuoi mostrare il form?</h1>'
                    + '<p class="fone-wiz-subtitle">Possiamo creare automaticamente una pagina pronta, oppure darti solo lo shortcode da incollare dove vuoi.</p>'

                    + '<div class="fone-wiz-grid" style="grid-template-columns:1fr;gap:10px;">'
                    +   pageCard('create', 'fa-solid fa-file-circle-plus', 'Crea una pagina automaticamente', 'Creiamo /' + (state.goal === 'registration' ? 'registrati' : (state.goal === 'request' ? 'richiedi-preventivo' : 'contatti')) + '/ con il form già pronto.')
                    +   pageCard('shortcode', 'fa-solid fa-code', 'Mostrami solo lo shortcode', 'Lo copierai e incollerai dove preferisci tu.')
                    +   pageCard('skip', 'fa-solid fa-forward', 'Salta — decido dopo', 'Vai direttamente al builder per personalizzare.')
                    + '</div>'

                    + navButtons({ back: true, nextDisabled: false });

                bindPageCards();
                bindBack(renderStep3);
                bindNext(function() {
                    saveStepAndGo(4, { page_action: state.page_action }, function() {
                        completeWizard();
                    });
                });
            }

            // ===== STEP 5: COMPLETATO =====
            function renderStep5(result) {
                state.step = 5;
                updateProgress();

                var pageBlock = '';
                if (result.page_action === 'create' && result.page_url) {
                    pageBlock = '<p style="margin:18px 0;color:#52525b;">Abbiamo creato la pagina: <a href="' + escapeHtml(result.page_url) + '" target="_blank" style="color:#374151;font-weight:600;">' + escapeHtml(result.page_url) + ' ↗</a></p>';
                } else if (result.page_action === 'shortcode') {
                    pageBlock = '<p style="margin:18px 0;color:#52525b;">Incolla questo shortcode in qualsiasi pagina o post:</p>'
                              + '<div class="fone-wiz-shortcode">' + escapeHtml(result.shortcode) + '</div>';
                }

                card.innerHTML = ''
                    + '<div class="fone-wiz-success">'
                    +   '<div class="fone-wiz-success-emoji">' + faIcon('fa-solid fa-circle-check') + '</div>'
                    +   '<h1 class="fone-wiz-title">Tutto pronto!</h1>'
                    +   '<p class="fone-wiz-subtitle">Il tuo primo form è stato creato e configurato. Da qui puoi iniziare a usarlo subito o personalizzarlo.</p>'
                    +   pageBlock
                    +   '<div class="fone-wiz-actions">'
                    +     '<a href="' + escapeHtml(result.builder_url) + '" class="fone-wiz-btn fone-wiz-btn-primary"><i class="fa-solid fa-pen-to-square" aria-hidden="true"></i> Personalizza il form</a>'
                    +     (result.page_url ? '<a href="' + escapeHtml(result.page_url) + '" target="_blank" class="fone-wiz-btn fone-wiz-btn-back" style="border:1px solid #e4e4e7;">Vedi il form pubblicato</a>' : '')
                    +   '</div>'
                    +   '<a href="' + escapeHtml(formsUrl) + '" class="fone-wiz-secondary-link">oppure vai alla lista form</a>'
                    + '</div>';
            }

            // ===== HELPERS RENDER =====
            function choiceCard(value, iconClass, title, desc) {
                var active = state.goal === value ? ' is-active' : '';
                return '<div class="fone-wiz-choice' + active + '" data-goal="' + value + '">'
                    +    '<div class="fone-wiz-choice-emoji">' + faIcon(iconClass) + '</div>'
                    +    '<div class="fone-wiz-choice-title">' + title + '</div>'
                    +    '<div class="fone-wiz-choice-desc">' + desc + '</div>'
                    +  '</div>';
            }
            function toneCard(value, iconClass, title, desc) {
                var active = state.tone === value ? ' is-active' : '';
                return '<div class="fone-wiz-choice' + active + '" data-tone="' + value + '" style="text-align:center;align-items:center;">'
                    +    '<div class="fone-wiz-choice-emoji">' + faIcon(iconClass) + '</div>'
                    +    '<div class="fone-wiz-choice-title">' + title + '</div>'
                    +    '<div class="fone-wiz-choice-desc">' + desc + '</div>'
                    +  '</div>';
            }
            function pageCard(value, iconClass, title, desc) {
                var active = state.page_action === value ? ' is-active' : '';
                return '<div class="fone-wiz-choice' + active + '" data-page="' + value + '" style="flex-direction:row;align-items:center;gap:14px;">'
                    +    '<div class="fone-wiz-choice-emoji" style="font-size:32px;">' + faIcon(iconClass) + '</div>'
                    +    '<div><div class="fone-wiz-choice-title">' + title + '</div>'
                    +    '<div class="fone-wiz-choice-desc">' + desc + '</div></div>'
                    +  '</div>';
            }
            function navButtons(opts) {
                var back = opts.back ? '<button class="fone-wiz-btn fone-wiz-btn-back" id="fone-wiz-back"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Indietro</button>' : '<span></span>';
                var next = '<button class="fone-wiz-btn fone-wiz-btn-primary" id="fone-wiz-next"' + (opts.nextDisabled ? ' disabled' : '') + '><i class="fa-solid fa-arrow-right" aria-hidden="true"></i> Continua</button>';
                return '<div class="fone-wiz-nav">' + back + next + '</div>';
            }

            // ===== BINDERS =====
            function bindChoiceClicks(stateKey) {
                card.querySelectorAll('[data-' + stateKey + ']').forEach(function(el) {
                    el.addEventListener('click', function() {
                        card.querySelectorAll('[data-' + stateKey + ']').forEach(function(x) { x.classList.remove('is-active'); });
                        this.classList.add('is-active');
                        state[stateKey] = this.getAttribute('data-' + stateKey);
                    });
                });
            }
            function bindToneCards() {
                card.querySelectorAll('[data-tone]').forEach(function(el) {
                    el.addEventListener('click', function() {
                        card.querySelectorAll('[data-tone]').forEach(function(x) { x.classList.remove('is-active'); });
                        this.classList.add('is-active');
                        state.tone = this.getAttribute('data-tone');
                    });
                });
            }
            function bindPageCards() {
                card.querySelectorAll('[data-page]').forEach(function(el) {
                    el.addEventListener('click', function() {
                        card.querySelectorAll('[data-page]').forEach(function(x) { x.classList.remove('is-active'); });
                        this.classList.add('is-active');
                        state.page_action = this.getAttribute('data-page');
                    });
                });
            }
            function bindColorPickers() {
                card.querySelectorAll('.fone-wiz-color[data-color]').forEach(function(el) {
                    el.addEventListener('click', function() {
                        card.querySelectorAll('.fone-wiz-color[data-color]').forEach(function(x) { x.classList.remove('is-active'); });
                        this.classList.add('is-active');
                        state.color = this.getAttribute('data-color');
                        document.getElementById('fone-wiz-color-custom').value = state.color;
                    });
                });
                document.getElementById('fone-wiz-color-custom').addEventListener('input', function() {
                    state.color = this.value;
                    card.querySelectorAll('.fone-wiz-color[data-color]').forEach(function(x) { x.classList.remove('is-active'); });
                });
            }
            function bindBack(fn) {
                var b = document.getElementById('fone-wiz-back');
                if (b) b.addEventListener('click', fn);
            }
            function bindNext(fn) {
                var b = document.getElementById('fone-wiz-next');
                if (b) b.addEventListener('click', fn);
            }

            // ===== AZIONI =====
            function saveStepAndGo(step, payload, after) {
                var btn = document.getElementById('fone-wiz-next');
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = '<span class="fone-wiz-loader"></span>Continua…';
                }
                ajax('fone_wizard_save', { step: step, payload: payload }).then(function(res) {
                    if (res && res.success) { after(); }
                    else { alert('Errore salvataggio. Riprova.'); if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-arrow-right" aria-hidden="true"></i> Continua'; } }
                }).catch(function() {
                    alert('Errore di rete. Riprova.');
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-arrow-right" aria-hidden="true"></i> Continua'; }
                });
            }

            function completeWizard() {
                card.innerHTML = '<div class="fone-wiz-success">'
                    + '<div class="fone-wiz-success-emoji">' + faIcon('fa-solid fa-gear') + '</div>'
                    + '<h1 class="fone-wiz-title">Sto preparando tutto…</h1>'
                    + '<p class="fone-wiz-subtitle">Creo il tuo form, applico le impostazioni e configuro le pagine. Un attimo.</p>'
                    + '</div>';

                ajax('fone_wizard_complete', {}).then(function(res) {
                    if (res && res.success) {
                        renderStep5(res.data);
                    } else {
                        alert('Errore durante la configurazione finale. Riprova.');
                        renderStep4();
                    }
                });
            }

            // Skip button
            document.getElementById('fone-wiz-skip-link').addEventListener('click', function(e) {
                e.preventDefault();
                if (!confirm('Saltare il setup? Potrai sempre rifarlo o configurare tutto manualmente.')) return;
                ajax('fone_wizard_skip', {}).then(function(res) {
                    if (res && res.success && res.data && res.data.redirect) {
                        window.location.href = res.data.redirect;
                    } else {
                        window.location.href = formsUrl;
                    }
                });
            });

            // Avvio
            renderStep1();
        })();
        </script>
        <?php
    }
}

/* ---------------------------------------------------------------
   RILANCIO MANUALE: link "Avvia wizard" dalle Impostazioni → Strumenti
--------------------------------------------------------------- */

if (!function_exists('fone_wizard_handle_relaunch')) {
    function fone_wizard_handle_relaunch() {
        if (!is_admin() || !current_user_can('manage_options')) return;
        if (empty($_GET['fone_action']) || $_GET['fone_action'] !== 'relaunch_wizard') return;
        if (empty($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'fone_relaunch_wizard')) {
            wp_die(esc_html__('Link scaduto o non valido. Torna su Impostazioni → Strumenti e riprova.', 'form-one'));
        }
        // Reset flag e stato
        delete_option('fone_wizard_completed');
        delete_option('fone_wizard_state');
        wp_safe_redirect(admin_url('admin.php?page=fone-wizard'));
        exit;
    }
}
add_action('admin_init', 'fone_wizard_handle_relaunch');

/* ---------------------------------------------------------------
   HOOK SU ATTIVAZIONE: scatena il flag wizard
--------------------------------------------------------------- */

if (!function_exists('fone_wizard_on_activation')) {
    function fone_wizard_on_activation() {
        if (!get_option('fone_wizard_completed')) {
            set_transient('fone_wizard_redirect', 1, 60);
        }
    }
}
register_activation_hook(FONE_DIR . 'form-one.php', 'fone_wizard_on_activation');
