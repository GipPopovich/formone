<?php
/**
 * Form One — Builder page (multi-form)
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   SAVE HANDLER
--------------------------------------------------------------- */

if (!function_exists('fone_handle_builder_save')) {
    function fone_handle_builder_save() {
        if (!is_admin() || !current_user_can('manage_options')) return;
        if (empty($_POST['fone_save_builder'])) return;
        if (
            empty($_POST['fone_builder_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_builder_nonce'])), 'fone_builder_save')
        ) return;

        $form_id = isset($_POST['fone_form_id']) ? (int) $_POST['fone_form_id'] : 0;
        if (!$form_id) return;

        $form = fone_get_form($form_id);
        if (!$form) return;

        // Schema
        $schema_json = isset($_POST['fone_schema_json']) ? wp_unslash($_POST['fone_schema_json']) : '';
        $schema      = json_decode($schema_json, true);
        if (!is_array($schema)) $schema = $form['schema'];

        // Step layouts
        $layouts_json = isset($_POST['fone_step_layouts_json']) ? wp_unslash($_POST['fone_step_layouts_json']) : '{}';
        $layouts      = json_decode($layouts_json, true);
        if (!is_array($layouts)) $layouts = [];
        $clean_layouts = [];
        foreach ($layouts as $step => $val) {
            $clean_layouts[(int) $step] = ($val === '2col') ? '2col' : '1col';
        }

        // Registrazione: un solo form alla volta
        $want_registration = !empty($_POST['fone_enable_registration']) ? 1 : 0;
        if ($want_registration) {
            global $wpdb;
            $existing_reg = (int) $wpdb->get_var(
                $wpdb->prepare("SELECT id FROM " . fone_table_forms() . " WHERE is_registration = 1 AND id != %d LIMIT 1", $form_id)
            );
            if ($existing_reg) {
                // Non possiamo abilitare — mostriamo errore
                add_settings_error('fone_builder_notices', 'fone_reg_conflict',
                    __('Un altro form è già impostato come form di registrazione. Disattivalo prima di abilitare questo.', 'form-one'),
                    'error'
                );
                $want_registration = 0; // forza a 0
            }
        }

        // Login: un solo form alla volta
        $want_login = !empty($_POST['fone_enable_login']) ? 1 : 0;
        if ($want_login) {
            global $wpdb;
            $existing_login = (int) $wpdb->get_var(
                $wpdb->prepare("SELECT id FROM " . fone_table_forms() . " WHERE is_login = 1 AND id != %d LIMIT 1", $form_id)
            );
            if ($existing_login) {
                add_settings_error('fone_builder_notices', 'fone_login_conflict',
                    __('Un altro form è già impostato come form di login. Disattivalo prima.', 'form-one'), 'error');
                $want_login = 0;
            }
        }

        $is_pro  = function_exists('fone_is_premium') ? fone_is_premium() : false;
        $settings = [
            'lang'                       => isset($_POST['fone_lang'])                        ? sanitize_text_field(wp_unslash($_POST['fone_lang']))                        : 'it',
            'admin_email'                => isset($_POST['fone_admin_email'])                 ? sanitize_email(wp_unslash($_POST['fone_admin_email']))                      : get_option('admin_email'),
            'show_donate_frontend'       => !empty($_POST['fone_show_donate'])                ? 1 : 0,
            'donate_url'                 => isset($_POST['fone_donate_url'])                  ? esc_url_raw(wp_unslash($_POST['fone_donate_url']))                          : fone_default_settings()['donate_url'],
            'success_message'            => isset($_POST['fone_success_message'])             ? sanitize_text_field(wp_unslash($_POST['fone_success_message']))             : fone_default_settings()['success_message'],
            'form_title'                 => ($is_pro && isset($_POST['fone_form_title']))     ? sanitize_text_field(wp_unslash($_POST['fone_form_title']))                  : ($is_pro ? $form['settings']['form_title'] : ''),
            'form_subtitle'              => isset($_POST['fone_form_subtitle'])               ? sanitize_text_field(wp_unslash($_POST['fone_form_subtitle']))               : '',
            'accent_color'               => isset($_POST['fone_accent_color'])                ? sanitize_hex_color(wp_unslash($_POST['fone_accent_color']))                 : '#374151',
            'border_radius'              => isset($_POST['fone_border_radius'])               ? absint(wp_unslash($_POST['fone_border_radius']))                            : 10,
            'reveal_animation'           => isset($_POST['fone_reveal_animation'])            ? sanitize_text_field(wp_unslash($_POST['fone_reveal_animation']))            : 'from-top',
            'enable_registration'        => $want_registration,
            'registration_role'          => function_exists('fone_get_safe_registration_role')
                                               ? fone_get_safe_registration_role(isset($_POST['fone_registration_role']) ? wp_unslash($_POST['fone_registration_role']) : 'subscriber')
                                               : 'subscriber',
            'registration_autologin'     => !empty($_POST['fone_registration_autologin'])     ? 1 : 0,
            'registration_send_wp_email' => !empty($_POST['fone_registration_send_wp_email']) ? 1 : 0,
            'registration_redirect'      => (isset($_POST['fone_registration_redirect']) && trim((string) wp_unslash($_POST['fone_registration_redirect'])) !== '')
                                               ? (function_exists('fone_sanitize_local_url')
                                                   ? fone_sanitize_local_url(wp_unslash($_POST['fone_registration_redirect']), '')
                                                   : esc_url_raw(wp_unslash($_POST['fone_registration_redirect'])))
                                               : '',
            'enable_login'               => $want_login,
            'profile_url'                => function_exists('fone_sanitize_local_url')
                                               ? fone_sanitize_local_url(isset($_POST['fone_profile_url']) ? wp_unslash($_POST['fone_profile_url']) : '', fone_default_profile_url())
                                               : (isset($_POST['fone_profile_url']) ? esc_url_raw(wp_unslash($_POST['fone_profile_url'])) : fone_default_profile_url()),
            'auto_redirect_profile'      => !empty($_POST['fone_auto_redirect_profile'])      ? 1 : 0,
            'auto_redirect_delay'        => isset($_POST['fone_auto_redirect_delay'])         ? max(3, min(30, absint(wp_unslash($_POST['fone_auto_redirect_delay']))))        : 8,
            'whatsapp_mode'              => isset($_POST['fone_whatsapp_mode']) && in_array(wp_unslash($_POST['fone_whatsapp_mode']), ['inherit','off','custom'], true) ? sanitize_key(wp_unslash($_POST['fone_whatsapp_mode'])) : 'inherit',
            'whatsapp_enabled'           => !empty($_POST['fone_whatsapp_enabled']) ? 1 : 0,
            'whatsapp_number'            => function_exists('fone_clean_whatsapp_number') ? fone_clean_whatsapp_number(isset($_POST['fone_whatsapp_number']) ? wp_unslash($_POST['fone_whatsapp_number']) : '') : sanitize_text_field(isset($_POST['fone_whatsapp_number']) ? wp_unslash($_POST['fone_whatsapp_number']) : ''),
            'whatsapp_button_label'      => isset($_POST['fone_whatsapp_button_label']) ? sanitize_text_field(wp_unslash($_POST['fone_whatsapp_button_label'])) : '',
            'whatsapp_message'           => isset($_POST['fone_whatsapp_message']) ? sanitize_textarea_field(wp_unslash($_POST['fone_whatsapp_message'])) : '',
            'whatsapp_include_values'    => !empty($_POST['fone_whatsapp_include_values']) ? 1 : 0,
            'webhook_mode'               => isset($_POST['fone_webhook_mode']) && in_array(wp_unslash($_POST['fone_webhook_mode']), ['inherit','off','custom'], true) ? sanitize_key(wp_unslash($_POST['fone_webhook_mode'])) : 'inherit',
            'webhook_enabled'            => !empty($_POST['fone_webhook_enabled']) ? 1 : 0,
            'webhook_url'                => isset($_POST['fone_webhook_url']) ? esc_url_raw(wp_unslash($_POST['fone_webhook_url'])) : '',
            'webhook_send_values'        => !empty($_POST['fone_webhook_send_values']) ? 1 : 0,
            'webhook_send_meta'          => !empty($_POST['fone_webhook_send_meta']) ? 1 : 0,
            'first_yes_enabled'        => !empty($_POST['fone_first_yes_enabled']) ? 1 : 0,
            'first_yes_button_label'   => isset($_POST['fone_first_yes_button_label']) ? sanitize_text_field(wp_unslash($_POST['fone_first_yes_button_label'])) : '',
            'first_yes_hint'           => isset($_POST['fone_first_yes_hint']) ? sanitize_text_field(wp_unslash($_POST['fone_first_yes_hint'])) : '',
            'first_yes_preset'         => isset($_POST['fone_first_yes_preset']) ? sanitize_key(wp_unslash($_POST['fone_first_yes_preset'])) : 'custom',
            'microcopy_goal'           => isset($_POST['fone_microcopy_goal']) ? sanitize_key(wp_unslash($_POST['fone_microcopy_goal'])) : 'general',
            'resume_later_enabled'     => !empty($_POST['fone_resume_later_enabled']) ? 1 : 0,
            'resume_later_ttl_days'    => isset($_POST['fone_resume_later_ttl_days']) ? max(1, min(30, absint($_POST['fone_resume_later_ttl_days']))) : 7,
            'microcopy_assistant'      => !empty($_POST['fone_microcopy_assistant']) ? 1 : 0,
        ];

        // Nome form
        $form_name = isset($_POST['fone_form_name']) ? sanitize_text_field(wp_unslash($_POST['fone_form_name'])) : $form['form_name'];

        // Custom CSS
        $custom_css = isset($_POST['fone_custom_css_builder']) ? wp_strip_all_tags(wp_unslash($_POST['fone_custom_css_builder'])) : $form['custom_css'];

        fone_save_form($form_id, [
            'form_name'       => $form_name,
            'schema'          => $schema,
            'settings'        => $settings,
            'layouts'         => $clean_layouts,
            'custom_css'      => $custom_css,
            'is_registration' => $want_registration,
            'is_login'        => $want_login,
        ]);

        // Aggiorna tabella forms per is_registration (se si disattiva)
        if (!$want_registration) {
            global $wpdb;
            $wpdb->update(fone_table_forms(), ['is_registration' => 0], ['id' => $form_id]);
        } else {
            fone_set_registration_form($form_id);
        }

        if ($want_login) {
            fone_set_login_form($form_id);
        } else {
            global $wpdb;
            $wpdb->update(fone_table_forms(), ['is_login' => 0], ['id' => $form_id]);
        }

        // Verifica se c'è già un errore di conflitto registrazione
        $existing_errors = get_settings_errors('fone_builder_notices');
        $has_conflict    = false;
        foreach ($existing_errors as $err) {
            if (isset($err['code']) && $err['code'] === 'fone_reg_conflict') {
                $has_conflict = true;
                break;
            }
        }
        if (!$has_conflict) {
            add_settings_error('fone_builder_notices', 'fone_saved', fone_t('saved', $form_id), 'updated');
        }
    }
}
add_action('admin_init', 'fone_handle_builder_save');

/* ---------------------------------------------------------------
   RESET CSS
--------------------------------------------------------------- */

if (!function_exists('fone_handle_custom_css_reset')) {
    function fone_handle_custom_css_reset() {
        if (!is_admin() || !current_user_can('manage_options')) return;
        if (empty($_POST['fone_reset_custom_css'])) return;
        if (
            empty($_POST['fone_css_reset_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fone_css_reset_nonce'])), 'fone_custom_css_reset')
        ) return;

        $form_id = isset($_POST['fone_form_id']) ? (int) $_POST['fone_form_id'] : 0;
        if ($form_id) {
            fone_save_form($form_id, ['custom_css' => fone_get_default_custom_css()]);
        }
        add_settings_error('fone_builder_notices', 'fone_css_reset', fone_t('css_saved', $form_id), 'updated');
    }
}
add_action('admin_init', 'fone_handle_custom_css_reset');

/* ---------------------------------------------------------------
   BUILDER PAGE
--------------------------------------------------------------- */

if (!function_exists('fone_builder_page')) {
    function fone_builder_page() {
        $form_id = isset($_GET['form_id']) ? (int) $_GET['form_id'] : 0;
        $form    = $form_id ? fone_get_form($form_id) : null;

        if (!$form) {
            $all_forms = fone_get_all_forms();
            if ($all_forms) {
                $form    = $all_forms[0];
                $form_id = $form['id'];
            }
        }

        if (!$form) {
            echo '<div class="wrap"><p>' . esc_html__('Nessun form trovato. Creane uno prima.', 'form-one') . '</p></div>';
            return;
        }

        $settings  = $form['settings'];
        $schema    = wp_json_encode($form['schema'], JSON_UNESCAPED_UNICODE);
        $layouts   = $form['layouts'];
        $is_pro    = function_exists('fone_is_premium') ? fone_is_premium() : false;
        $global_settings = function_exists('fone_get_global_settings') ? fone_get_global_settings() : [];
        $builder_interface = !empty($global_settings['builder_interface']) && $global_settings['builder_interface'] === 'classic' ? 'classic' : 'modern';
        $builder_layout_class = $builder_interface === 'modern' ? 'fone-builder-layout fone-builder-ui-modern' : 'fone-builder-layout fone-builder-ui-classic';

        // Controlla conflitto registrazione
        global $wpdb;
        $other_reg_id = (int) $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM " . fone_table_forms() . " WHERE is_registration = 1 AND id != %d LIMIT 1", $form_id)
        );
        $other_reg_name = '';
        if ($other_reg_id) {
            $other_reg_form = fone_get_form($other_reg_id);
            $other_reg_name = $other_reg_form ? $other_reg_form['form_name'] : '#' . $other_reg_id;
        }

        settings_errors('fone_builder_notices');

        if (isset($_GET['fone_msg']) && $_GET['fone_msg'] === 'created') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Nuovo form creato. Inizia ad aggiungere i campi!', 'form-one') . '</p></div>';
        }
        ?>
        <div class="wrap fone-admin-wrap">
            <div class="fone-admin-header">
                <div class="fone-admin-header-left">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=fone-forms')); ?>" class="fone-back-link">
                        ← <?php esc_html_e('Tutti i Form', 'form-one'); ?>
                    </a>
                    <h1 class="fone-admin-title fone-builder-title-editable">
                        <span id="fone-form-name-display"><?php echo esc_html($form['form_name']); ?></span>
                        <?php if ($form['is_registration']) : ?>
                            <span class="fone-reg-badge"><?php esc_html_e('Registrazione', 'form-one'); ?></span>
                        <?php endif; ?>
                    </h1>
                </div>
                <div class="fone-admin-header-right">
                    <select name="fone_lang" id="fone_lang_top" class="fone-lang-select">
                        <option value="it" <?php selected($settings['lang'], 'it'); ?>><?php echo esc_html(fone_t('italian')); ?></option>
                        <option value="en" <?php selected($settings['lang'], 'en'); ?>><?php echo esc_html(fone_t('english')); ?></option>
                    </select>
                    <code class="fone-shortcode-pill">[form_one id="<?php echo (int) $form_id; ?>"]</code>
                    <?php
                    $all_switch_forms = fone_get_all_forms();
                    if (count($all_switch_forms) > 1) : ?>
                    <select class="fone-form-switcher" onchange="if(this.value)location.href=this.value;">
                        <option value=""><?php esc_html_e('↕ Cambia form', 'form-one'); ?></option>
                        <?php foreach ($all_switch_forms as $sf) : ?>
                        <option value="<?php echo esc_url(admin_url('admin.php?page=fone-builder&form_id='.$sf['id'])); ?>"
                            <?php selected($sf['id'], $form_id); ?>>
                            <?php echo esc_html($sf['form_name']); ?>
                            <?php if ($sf['is_registration']) echo ' ✓ Reg.'; ?>
                            <?php if ($sf['is_login']) echo ' ✓ Login'; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!$is_pro) : ?>
                <div class="fone-pro-reminder-box">
                    <strong>Form One Pro disponibile</strong>
                    <span>Alcuni campi avanzati sono bloccati nella versione Free. Inserisci il seriale da Impostazioni → Licenza Pro per sbloccarli.</span>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=fone-settings&tab=licenza')); ?>">Attiva Pro</a>
                </div>
            <?php endif; ?>

            <form method="post" class="fone-admin-form" id="fone-admin-form">
                <?php wp_nonce_field('fone_builder_save', 'fone_builder_nonce'); ?>
                <input type="hidden" name="fone_form_id" value="<?php echo (int) $form_id; ?>">
                <input type="hidden" name="fone_lang" id="fone_lang_hidden" value="<?php echo esc_attr($settings['lang']); ?>">
                <input type="hidden" name="fone_form_name" id="fone_form_name_input" value="<?php echo esc_attr($form['form_name']); ?>">

                <div class="<?php echo esc_attr($builder_layout_class); ?>">

                    <!-- LEFT SIDEBAR -->
                    <aside class="fone-sidebar fone-sidebar-left">
                        <nav class="fone-sidebar-nav">
                            <button type="button" class="fone-tab is-active" data-fone-tab="fields"><?php echo esc_html(fone_t('tab_fields')); ?></button>
                            <button type="button" class="fone-tab" data-fone-tab="settings"><?php echo esc_html(fone_t('tab_form')); ?></button>
                            <button type="button" class="fone-tab" data-fone-tab="design"><?php echo esc_html(fone_t('tab_design')); ?></button>
                            <button type="button" class="fone-tab" data-fone-tab="publish"><?php echo esc_html(fone_t('tab_publish')); ?></button>
                        </nav>

                        <button type="button" class="fone-sidebar-compact-toggle" id="fone-sidebar-compact-toggle" aria-label="<?php echo esc_attr(fone_t('collapse_to_fields')); ?>">
                            <span class="fone-sidebar-compact-toggle-icon">←</span>
                            <span class="fone-sidebar-compact-toggle-text"><?php echo esc_html(fone_t('collapse_to_fields')); ?></span>
                        </button>

                        <!-- FIELDS TAB -->
                        <div class="fone-panel is-active" data-fone-panel="fields">
                            <div class="fone-field-library-shell">
                                <p class="fone-panel-label"><?php echo esc_html(fone_t('field_library')); ?></p>
                                <input type="search" class="fone-library-search" id="fone-library-search"
                                    placeholder="<?php echo esc_attr(fone_t('library_search')); ?>">
                                <div id="fone-field-library" class="fone-field-library"></div>
                            </div>

                            <?php if ($builder_interface === 'modern') : ?>
                                <div class="fone-field-settings-left">
                                    <button type="button" class="fone-field-editor-back" id="fone-back-to-fields">← <?php esc_html_e('Torna ai campi', 'form-one'); ?></button>
                                    <p class="fone-panel-label"><?php echo esc_html(fone_t('field_settings')); ?></p>
                                    <div id="fone-field-settings" class="fone-field-settings" data-fone-settings-panel="modern">
                                        <p class="fone-muted"><?php echo esc_html(fone_t('select_field')); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- SETTINGS TAB -->
                        <div class="fone-panel" data-fone-panel="settings">
                            <p class="fone-panel-label"><?php echo esc_html(fone_t('tab_form')); ?></p>

                            <div class="fone-control-group">
                                <label><?php esc_html_e('Nome del form', 'form-one'); ?></label>
                                <input type="text" id="fone_form_name_visible"
                                    value="<?php echo esc_attr($form['form_name']); ?>"
                                    placeholder="<?php esc_attr_e('es. Form di Registrazione', 'form-one'); ?>">
                                <small class="fone-hint"><?php esc_html_e('Usato solo in admin, non visibile agli utenti.', 'form-one'); ?></small>
                            </div>

                            <div class="fone-control-group">
                                <label>
                                    <?php echo esc_html(fone_t('form_title')); ?>
                                    <?php if (!$is_pro) : ?>
                                        <span class="fone-pro-badge">PRO</span>
                                    <?php endif; ?>
                                </label>
                                <input type="text" name="fone_form_title"
                                    value="<?php echo esc_attr($settings['form_title']); ?>"
                                    <?php echo $is_pro ? '' : 'disabled readonly'; ?>
                                    placeholder="<?php echo $is_pro ? '' : esc_attr__('Funzione PRO', 'form-one'); ?>"
                                    <?php if (!$is_pro) echo 'style="background:#f4f4f5;color:#999;cursor:not-allowed;"'; ?>>
                                <?php if (!$is_pro) : ?>
                                    <small class="fone-hint">
                                        <?php esc_html_e('Disponibile con licenza PRO.', 'form-one'); ?>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=fone-license')); ?>"><?php esc_html_e('Attiva licenza →', 'form-one'); ?></a>
                                    </small>
                                <?php endif; ?>
                            </div>

                            <div class="fone-control-group">
                                <label><?php echo esc_html(fone_t('form_subtitle')); ?></label>
                                <input type="text" name="fone_form_subtitle" value="<?php echo esc_attr($settings['form_subtitle']); ?>">
                            </div>

                            <div class="fone-control-group">
                                <label><?php echo esc_html(fone_t('admin_email')); ?></label>
                                <input type="email" name="fone_admin_email" value="<?php echo esc_attr($settings['admin_email']); ?>">
                            </div>

                            <div class="fone-control-group">
                                <label><?php echo esc_html(fone_t('success_message')); ?></label>
                                <input type="text" name="fone_success_message" value="<?php echo esc_attr($settings['success_message']); ?>">
                            </div>

                            <div class="fone-control-group fone-form-automation-section" style="margin-top:18px;padding-top:16px;border-top:1px solid #e2e8f0;">
                                <p class="fone-panel-label fone-section-label"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i> <?php esc_html_e('WhatsApp del form', 'form-one'); ?></p>
                                <label><?php esc_html_e('Comportamento WhatsApp', 'form-one'); ?></label>
                                <select name="fone_whatsapp_mode">
                                    <option value="inherit" <?php selected($settings['whatsapp_mode'] ?? 'inherit', 'inherit'); ?>><?php esc_html_e('Usa impostazioni globali', 'form-one'); ?></option>
                                    <option value="off" <?php selected($settings['whatsapp_mode'] ?? 'inherit', 'off'); ?>><?php esc_html_e('Disattiva per questo form', 'form-one'); ?></option>
                                    <option value="custom" <?php selected($settings['whatsapp_mode'] ?? 'inherit', 'custom'); ?>><?php esc_html_e('Personalizza per questo form', 'form-one'); ?></option>
                                </select>
                                <label class="fone-toggle-row"><input type="checkbox" name="fone_whatsapp_enabled" value="1" <?php checked(!empty($settings['whatsapp_enabled'])); ?>> <span><?php esc_html_e('Mostra pulsante WhatsApp dopo invio', 'form-one'); ?></span></label>
                                <input type="text" name="fone_whatsapp_number" value="<?php echo esc_attr($settings['whatsapp_number'] ?? ''); ?>" placeholder="+391234567890">
                                <input type="text" name="fone_whatsapp_button_label" value="<?php echo esc_attr($settings['whatsapp_button_label'] ?? ''); ?>" placeholder="Scrivici su WhatsApp">
                                <textarea name="fone_whatsapp_message" rows="3" placeholder="Ciao, ho appena inviato una richiesta dal sito."><?php echo esc_textarea($settings['whatsapp_message'] ?? ''); ?></textarea>
                                <label class="fone-toggle-row"><input type="checkbox" name="fone_whatsapp_include_values" value="1" <?php checked(!empty($settings['whatsapp_include_values'])); ?>> <span><?php esc_html_e('Includi riepilogo campi nel messaggio', 'form-one'); ?></span></label>
                            </div>

                            <div class="fone-control-group fone-form-automation-section" style="margin-top:18px;padding-top:16px;border-top:1px solid #e2e8f0;">
                                <p class="fone-panel-label fone-section-label"><i class="fa-solid fa-link" aria-hidden="true"></i> <?php esc_html_e('Webhook del form', 'form-one'); ?></p>
                                <label><?php esc_html_e('Comportamento webhook', 'form-one'); ?></label>
                                <select name="fone_webhook_mode">
                                    <option value="inherit" <?php selected($settings['webhook_mode'] ?? 'inherit', 'inherit'); ?>><?php esc_html_e('Usa impostazioni globali', 'form-one'); ?></option>
                                    <option value="off" <?php selected($settings['webhook_mode'] ?? 'inherit', 'off'); ?>><?php esc_html_e('Disattiva per questo form', 'form-one'); ?></option>
                                    <option value="custom" <?php selected($settings['webhook_mode'] ?? 'inherit', 'custom'); ?>><?php esc_html_e('Personalizza per questo form', 'form-one'); ?></option>
                                </select>
                                <label class="fone-toggle-row"><input type="checkbox" name="fone_webhook_enabled" value="1" <?php checked(!empty($settings['webhook_enabled'])); ?>> <span><?php esc_html_e('Invia questo form a un webhook', 'form-one'); ?></span></label>
                                <input type="url" name="fone_webhook_url" value="<?php echo esc_attr($settings['webhook_url'] ?? ''); ?>" placeholder="https://hook.eu1.make.com/...">
                                <label class="fone-toggle-row"><input type="checkbox" name="fone_webhook_send_values" value="1" <?php checked(!empty($settings['webhook_send_values'] ?? 1)); ?>> <span><?php esc_html_e('Invia valori del form', 'form-one'); ?></span></label>
                                <label class="fone-toggle-row"><input type="checkbox" name="fone_webhook_send_meta" value="1" <?php checked(!empty($settings['webhook_send_meta'] ?? 1)); ?>> <span><?php esc_html_e('Invia meta tecnici', 'form-one'); ?></span></label>
                            </div>

                            <div class="fone-control-group fone-conversion-section" style="margin-top:18px;padding-top:16px;border-top:1px solid #e2e8f0;">
                                <p class="fone-panel-label fone-section-label"><i class="fa-solid fa-chart-line" aria-hidden="true"></i> <?php esc_html_e('Conversione leggera', 'form-one'); ?></p>

                                <label class="fone-toggle-row">
                                    <input type="checkbox" name="fone_first_yes_enabled" value="1" <?php checked(!empty($settings['first_yes_enabled'])); ?>>
                                    <span><?php esc_html_e('Attiva First Yes Mode sul primo step', 'form-one'); ?></span>
                                </label>
                                <small class="fone-hint"><?php esc_html_e('Usa il primo step come micro-sì leggero: bottone e microtesto più morbidi, senza trasformare il form in una progress bar.', 'form-one'); ?></small>
                                <input type="text" name="fone_first_yes_button_label" value="<?php echo esc_attr($settings['first_yes_button_label'] ?? ''); ?>" placeholder="Inizia">
                                <input type="text" name="fone_first_yes_hint" value="<?php echo esc_attr($settings['first_yes_hint'] ?? ''); ?>" placeholder="Partiamo da una domanda semplice.">

                                <label class="fone-toggle-row" style="margin-top:12px;">
                                    <input type="checkbox" name="fone_resume_later_enabled" value="1" <?php checked(!empty($settings['resume_later_enabled'])); ?>>
                                    <span><?php esc_html_e('Attiva Resume Later locale', 'form-one'); ?></span>
                                </label>
                                <small class="fone-hint"><?php esc_html_e('Salva nel browser i campi compilati e ripristina il form se l\'utente torna sulla pagina. Non salva file, password o dati sul server.', 'form-one'); ?></small>

                                <label class="fone-toggle-row" style="margin-top:12px;">
                                    <input type="checkbox" name="fone_microcopy_assistant" value="1" <?php checked(!isset($settings['microcopy_assistant']) || !empty($settings['microcopy_assistant'])); ?>>
                                    <span><?php esc_html_e('Mostra Microcopy Assistant nel builder', 'form-one'); ?></span>
                                </label>
                                <small class="fone-hint"><?php esc_html_e('Suggerimenti locali per label, placeholder e aiuti più umani.', 'form-one'); ?></small>
                            </div>

                            <!-- REGISTRAZIONE UTENTE -->
                            <div class="fone-control-group fone-registration-section">
                                <p class="fone-panel-label fone-section-label"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> <?php esc_html_e('Registrazione Utente WordPress', 'form-one'); ?></p>

                                <?php if ($other_reg_id) : ?>
                                <div class="fone-notice fone-notice-warning" id="fone-reg-conflict-notice">
                                    <i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> <?php printf(
                                        esc_html__('Il form "%s" è già impostato come form di registrazione. Disattivalo prima di abilitare questo.', 'form-one'),
                                        '<strong>' . esc_html($other_reg_name) . '</strong>'
                                    ); ?>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=fone-builder&form_id=' . $other_reg_id)); ?>" class="fone-link">
                                        <?php esc_html_e('Vai a quel form →', 'form-one'); ?>
                                    </a>
                                </div>
                                <?php endif; ?>

                                <label class="fone-toggle-row" style="<?php echo $other_reg_id ? 'opacity:.5;pointer-events:none;' : ''; ?>">
                                    <input type="checkbox" name="fone_enable_registration" id="fone_enable_registration" value="1"
                                        <?php checked(!empty($settings['enable_registration'])); ?>
                                        <?php echo $other_reg_id ? 'disabled' : ''; ?>>
                                    <span><?php esc_html_e('Usa questo form per registrare nuovi utenti WordPress', 'form-one'); ?></span>
                                </label>
                                <small class="fone-hint"><?php esc_html_e('All\'invio verrà creato un nuovo account WordPress. Solo un form alla volta può avere questa opzione attiva.', 'form-one'); ?></small>
                            </div>

                            <div id="fone-registration-options" style="<?php echo empty($settings['enable_registration']) ? 'display:none;' : ''; ?>">
                                <div class="fone-control-group">
                                    <label><?php esc_html_e('Ruolo assegnato al nuovo utente', 'form-one'); ?></label>
                                    <select name="fone_registration_role">
                                        <?php
                                        $cur_role = $settings['registration_role'] ?? 'subscriber';
                                        foreach (get_editable_roles() as $role_key => $role_info) :
                                            if ($role_key === 'administrator') continue;
                                            printf(
                                                '<option value="%s"%s>%s</option>',
                                                esc_attr($role_key),
                                                selected($cur_role, $role_key, false),
                                                esc_html(translate_user_role($role_info['name']))
                                            );
                                        endforeach;
                                        ?>
                                    </select>
                                </div>
                                <div class="fone-control-group fone-control-check">
                                    <label>
                                        <input type="checkbox" name="fone_registration_autologin" value="1" <?php checked(!empty($settings['registration_autologin'])); ?>>
                                        <span><?php esc_html_e('Login automatico dopo la registrazione', 'form-one'); ?></span>
                                    </label>
                                </div>
                                <div class="fone-control-group fone-control-check">
                                    <label>
                                        <input type="checkbox" name="fone_registration_send_wp_email" value="1" <?php checked(!empty($settings['registration_send_wp_email'])); ?>>
                                        <span><?php esc_html_e('Invia email di benvenuto WordPress al nuovo utente', 'form-one'); ?></span>
                                    </label>
                                </div>
                                <div class="fone-control-group">
                                    <label><?php esc_html_e('URL di reindirizzamento dopo la registrazione', 'form-one'); ?></label>
                                    <input type="url" name="fone_registration_redirect"
                                        value="<?php echo esc_attr($settings['registration_redirect'] ?? ''); ?>"
                                        placeholder="https://tuosito.it/benvenuto">
                                    <small class="fone-hint"><?php esc_html_e('Lascia vuoto per mostrare il messaggio di completamento.', 'form-one'); ?></small>
                                </div>

                                <div class="fone-notice fone-notice-info">
                                    <strong><i class="fa-solid fa-lightbulb" aria-hidden="true"></i> <?php esc_html_e('Campi richiesti per la registrazione:', 'form-one'); ?></strong>
                                    <ul>
                                        <li><?php esc_html_e('Campo Email → mappato a "email" o "user_email"', 'form-one'); ?></li>
                                        <li><?php esc_html_e('Campo Password → mappato a "user_pass" (se assente, viene generata automaticamente)', 'form-one'); ?></li>
                                        <li><?php esc_html_e('Campo Testo → mappato a "user_login" per lo username', 'form-one'); ?></li>
                                    </ul>
                                </div>
                            </div>


                            <!-- ===== LOGIN FORM SECTION (legacy, pannello dedicato consigliato) ===== -->
                            <div class="fone-control-group fone-login-section" style="margin-top:20px;padding-top:18px;border-top:2px dashed #e2e8f0;">
                                <p class="fone-panel-label fone-section-label"><i class="fa-solid fa-key" aria-hidden="true"></i> <?php esc_html_e('Form Login WordPress', 'form-one'); ?></p>
                                <div class="fone-notice fone-notice-info" style="background:#e0f2fe;border:1px solid #7dd3fc;border-radius:8px;padding:14px 16px;color:#075985;line-height:1.6;">
                                    <strong>ℹ️ <?php esc_html_e('Il login ha ora un pannello dedicato', 'form-one'); ?></strong><br>
                                    <?php esc_html_e('Il form di login WordPress si configura dal pannello dedicato "Form di Login", più potente e semplice. Lo shortcode da usare nelle pagine è', 'form-one'); ?>
                                    <code>[fone_login]</code>.
                                    <br><br>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=fone-login-settings')); ?>" class="button button-primary">
                                        <i class="fa-solid fa-lock" aria-hidden="true"></i> <?php esc_html_e('Vai al pannello Form di Login', 'form-one'); ?>
                                    </a>
                                </div>
                                <?php // Mantengo hidden per non perdere il valore esistente nel POST se l'utente ha un form legacy con is_login=1 ?>
                                <input type="hidden" name="fone_enable_login" value="<?php echo !empty($settings['enable_login']) ? '1' : '0'; ?>">
                            </div>

                            <!-- ===== URL PROFILO + AUTO-REDIRECT ===== -->
                            <div class="fone-control-group" style="margin-top:18px;padding-top:16px;border-top:1px solid #e2e8f0;">
                                <p class="fone-panel-label fone-section-label"><i class="fa-solid fa-house-user" aria-hidden="true"></i> <?php esc_html_e('Pagina Profilo & Redirect','form-one'); ?></p>
                                <div class="fone-control-group">
                                    <label><?php esc_html_e('URL pagina profilo / account','form-one'); ?></label>
                                    <input type="url" name="fone_profile_url" value="<?php echo esc_attr($settings['profile_url'] ?? fone_default_profile_url()); ?>" placeholder="<?php echo esc_attr(fone_default_profile_url()); ?>">
                                    <small class="fone-hint"><?php esc_html_e('Link mostrato nel messaggio di successo di registrazione e login.','form-one'); ?></small>
                                </div>
                                <div class="fone-control-group fone-control-check">
                                    <label>
                                        <input type="checkbox" name="fone_auto_redirect_profile" value="1" <?php checked(!empty($settings['auto_redirect_profile'] ?? 0)); ?>>
                                        <span><?php esc_html_e('Reindirizza automaticamente al profilo dopo registrazione/login','form-one'); ?></span>
                                    </label>
                                </div>
                                <div class="fone-control-group">
                                    <label><?php esc_html_e('Secondi prima del reindirizzamento','form-one'); ?></label>
                                    <input type="number" name="fone_auto_redirect_delay" value="<?php echo (int)($settings['auto_redirect_delay'] ?? 8); ?>" min="3" max="30" style="width:80px;">
                                </div>
                            </div>
                            <script>
                            (function(){
                                var cb   = document.getElementById('fone_enable_registration');
                                var opts = document.getElementById('fone-registration-options');
                                if (cb && opts) {
                                    cb.addEventListener('change', function(){ opts.style.display = this.checked ? '' : 'none'; });
                                }
                                // (login section doesn't have collapsible options, so no extra JS needed)
                                // Sync nome form visibile → hidden
                                var visibleInput = document.getElementById('fone_form_name_visible');
                                var hiddenInput  = document.getElementById('fone_form_name_input');
                                var displaySpan  = document.getElementById('fone-form-name-display');
                                if (visibleInput && hiddenInput) {
                                    visibleInput.addEventListener('input', function(){
                                        hiddenInput.value  = this.value;
                                        if (displaySpan) displaySpan.textContent = this.value || '<?php echo esc_js(__('Senza nome', 'form-one')); ?>';
                                    });
                                }
                            })();
                            </script>
                        </div>

                        <!-- DESIGN TAB -->
                        <div class="fone-panel" data-fone-panel="design">
                            <p class="fone-panel-label"><?php echo esc_html(fone_t('tab_design')); ?></p>

                            <div class="fone-control-group">
                                <label><?php echo esc_html(fone_t('accent_color')); ?></label>
                                <div class="fone-color-row">
                                    <input type="color" name="fone_accent_color" id="fone_accent_color" value="<?php echo esc_attr($settings['accent_color']); ?>">
                                    <span class="fone-color-value"><?php echo esc_html($settings['accent_color']); ?></span>
                                </div>
                            </div>
                            <div class="fone-control-group">
                                <label><?php echo esc_html(fone_t('border_radius')); ?></label>
                                <input type="number" name="fone_border_radius" value="<?php echo esc_attr($settings['border_radius']); ?>" min="0" max="40">
                            </div>
                            <div class="fone-control-group">
                                <label><?php echo esc_html(fone_t('reveal_animation')); ?></label>
                                <select name="fone_reveal_animation">
                                    <option value="from-top"    <?php selected($settings['reveal_animation'], 'from-top'); ?>><?php echo esc_html(fone_t('reveal_from_top')); ?></option>
                                    <option value="fade"        <?php selected($settings['reveal_animation'], 'fade'); ?>><?php echo esc_html(fone_t('reveal_fade')); ?></option>
                                    <option value="slide-right" <?php selected($settings['reveal_animation'], 'slide-right'); ?>><?php echo esc_html(fone_t('reveal_slide_right')); ?></option>
                                    <option value="scale"       <?php selected($settings['reveal_animation'], 'scale'); ?>><?php echo esc_html(fone_t('reveal_scale')); ?></option>
                                </select>
                            </div>

                            <p class="fone-panel-label" style="margin-top:18px"><?php echo esc_html(fone_t('custom_css_title')); ?></p>
                            <p class="fone-hint"><?php echo esc_html(fone_t('custom_css_subtitle')); ?></p>
                            <?php
                            $current_css = $form['custom_css'];
                            if (empty($current_css)) $current_css = fone_get_default_custom_css();
                            ?>
                            <textarea id="fone_custom_css_builder" name="fone_custom_css_builder"
                                class="fone-design-css-editor" rows="18" spellcheck="false" autocomplete="off" wrap="off"><?php echo esc_textarea($current_css); ?></textarea>
                            <small class="fone-design-css-hint"><i class="fa-solid fa-lightbulb" aria-hidden="true"></i> <?php esc_html_e('Le modifiche si applicano all\'anteprima in tempo reale. Clicca "Salva Modifiche" per renderle permanenti.', 'form-one'); ?></small>
                            <div class="fone-design-css-actions">
                                <button type="button" id="fone-reset-custom-css" class="fone-btn fone-btn-ghost fone-btn-sm"><?php echo esc_html(fone_t('reset_css')); ?></button>
                            </div>
                        </div>

                        <!-- PUBLISH TAB -->
                        <div class="fone-panel" data-fone-panel="publish">
                            <p class="fone-panel-label"><?php echo esc_html(fone_t('publish_title')); ?></p>
                            <p class="fone-hint"><?php echo esc_html(fone_t('publish_text')); ?></p>

                            <div class="fone-shortcode-copy-row">
                                <input type="text" value="<?php echo esc_attr('[form_one id="' . $form_id . '"]'); ?>" readonly class="fone-shortcode-input" id="fone-shortcode-input">
                                <button type="button" id="fone-copy-shortcode" class="fone-btn fone-btn-sm"><?php echo esc_html(fone_t('copy_shortcode')); ?></button>
                            </div>

                            <div class="fone-publish-links">
                                <a class="fone-btn fone-btn-ghost" href="<?php echo esc_url(admin_url('post-new.php?post_type=page')); ?>" target="_blank" rel="noopener noreferrer">
                                    <i class="fa-solid fa-file-circle-plus" aria-hidden="true"></i> <?php echo esc_html(fone_t('new_page')); ?>
                                </a>
                                <a class="fone-btn fone-btn-ghost" href="<?php echo esc_url(admin_url('edit.php?post_type=page')); ?>" target="_blank" rel="noopener noreferrer">
                                    <i class="fa-solid fa-file-lines" aria-hidden="true"></i> <?php echo esc_html(fone_t('all_pages')); ?>
                                </a>
                            </div>

                            <div style="margin-top:20px;padding-top:16px;border-top:1px solid #e2e8f0;">
                                <p class="fone-panel-label" style="margin-top:0;"><?php esc_html_e('Shortcode account utente', 'form-one'); ?></p>
                                <p class="fone-hint"><?php esc_html_e('Per mostrare il profilo dell\'utente loggato:', 'form-one'); ?></p>
                                <div class="fone-shortcode-copy-row">
                                    <input type="text" value="[fone_account]" readonly class="fone-shortcode-input">
                                    <button type="button" class="fone-btn fone-btn-sm fone-copy-btn" data-copy="[fone_account]"><?php esc_html_e('Copia', 'form-one'); ?></button>
                                </div>
                            </div>
                        </div>
                    </aside>

                    <!-- CENTER CANVAS -->
                    <main class="fone-center">
                        <div class="fone-canvas-header">
                            <span class="fone-canvas-label"><?php echo esc_html(fone_t('form_canvas')); ?></span>
                            <div class="fone-canvas-actions">
                                <button type="button" id="fone-add-step" class="fone-btn fone-btn-ghost fone-btn-sm">
                                    <?php echo esc_html(fone_t('add_step')); ?>
                                </button>
                                <button type="submit" class="fone-btn fone-btn-primary" name="fone_save_builder" value="1">
                                    <i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> <?php echo esc_html(fone_t('save_form')); ?>
                                </button>
                            </div>
                        </div>
                        <div id="fone-form-canvas" class="fone-form-canvas"></div>
                    </main>

                    <?php if ($builder_interface === 'classic') : ?>
                    <!-- RIGHT SIDEBAR -->
                    <aside class="fone-sidebar fone-sidebar-right">
                        <p class="fone-panel-label"><?php echo esc_html(fone_t('field_settings')); ?></p>
                        <div id="fone-field-settings" class="fone-field-settings">
                            <p class="fone-muted"><?php echo esc_html(fone_t('select_field')); ?></p>
                        </div>
                    </aside>
                    <?php endif; ?>
                </div>

                <!-- PREVIEW -->
                <div class="fone-preview-section">
                    <div class="fone-preview-topbar">
                        <div class="fone-preview-devices">
                            <button type="button" class="fone-device-btn is-active" data-device="desktop"><?php echo esc_html(fone_t('desktop')); ?></button>
                            <button type="button" class="fone-device-btn" data-device="tablet"><?php echo esc_html(fone_t('tablet')); ?></button>
                            <button type="button" class="fone-device-btn" data-device="mobile"><?php echo esc_html(fone_t('mobile')); ?></button>
                        </div>
                        <div class="fone-preview-meta">
                            <span class="fone-preview-label"><?php echo esc_html(fone_t('live_preview')); ?></span>
                        </div>
                    </div>
                    <div class="fone-preview-stage" id="fone-preview-stage">
                        <div id="fone-preview-viewport" class="fone-preview-viewport is-desktop">
                            <div id="fone-preview-inner" class="fone-preview-inner"></div>
                        </div>
                    </div>
                </div>

                <textarea id="fone_schema_json" name="fone_schema_json" class="fone-hidden-input"><?php echo esc_textarea($schema); ?></textarea>
                <textarea id="fone_step_layouts_json" name="fone_step_layouts_json" class="fone-hidden-input"><?php echo esc_textarea(wp_json_encode($layouts)); ?></textarea>
            </form>
        </div>
        <script>
        (function(){
            // Copy shortcode buttons generici
            document.querySelectorAll('.fone-copy-btn').forEach(function(btn){
                btn.addEventListener('click', function(){
                    var text = this.dataset.copy;
                    if (navigator.clipboard) { navigator.clipboard.writeText(text); }
                    else {
                        var el = document.createElement('textarea');
                        el.value = text; document.body.appendChild(el);
                        el.select(); document.execCommand('copy');
                        document.body.removeChild(el);
                    }
                    var orig = this.textContent;
                    this.textContent = '✓ Copiato!';
                    var self = this;
                    setTimeout(function(){ self.textContent = orig; }, 1500);
                });
            });
        })();
        </script>
        <?php
    }
}
