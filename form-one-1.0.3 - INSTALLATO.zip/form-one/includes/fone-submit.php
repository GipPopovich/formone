<?php
/**
 * Form One — Submission handling
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   RATE LIMITING
--------------------------------------------------------------- */

if (!function_exists('fone_check_rate_limit')) {
    /**
     * Rate limit reale per IP.
     *
     * Prima della 10.0.0 il sistema apriva una finestra di 10 minuti con invii
     * illimitati e bloccava solo alla fine della finestra. Era troppo debole
     * contro spam/bot. Ora conta gli invii dentro la finestra.
     *
     * Filtri disponibili:
     * - fone_rate_limit_window_seconds  default 10 minuti
     * - fone_rate_limit_block_seconds   default 5 minuti
     * - fone_rate_limit_max_submissions default 10 invii/finestra
     */
    function fone_check_rate_limit() {

        if (defined('FONE_DISABLE_RATE_LIMIT') && FONE_DISABLE_RATE_LIMIT) {
            return true;
        }

        if (is_user_logged_in() && current_user_can('manage_options')) {
            return true;
        }

        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $hash = md5($ip);

        $key_window = 'fone_win_' . $hash;
        $key_block  = 'fone_blk_' . $hash;

        $now = time();

        $window_seconds = (int) apply_filters('fone_rate_limit_window_seconds', 10 * MINUTE_IN_SECONDS);
        $block_seconds  = (int) apply_filters('fone_rate_limit_block_seconds', 5 * MINUTE_IN_SECONDS);
        $max_submits    = (int) apply_filters('fone_rate_limit_max_submissions', 10);

        $window_seconds = max(60, $window_seconds);
        $block_seconds  = max(60, $block_seconds);
        $max_submits    = max(1, $max_submits);

        $block_until = (int) get_transient($key_block);
        if ($block_until && $now < $block_until) {
            return false;
        }

        $state = get_transient($key_window);
        if (!is_array($state) || empty($state['start'])) {
            set_transient($key_window, [
                'start' => $now,
                'count' => 1,
            ], $window_seconds + $block_seconds);
            return true;
        }

        $start = (int) $state['start'];
        $count = isset($state['count']) ? (int) $state['count'] : 0;

        if (($now - $start) >= $window_seconds) {
            set_transient($key_window, [
                'start' => $now,
                'count' => 1,
            ], $window_seconds + $block_seconds);
            delete_transient($key_block);
            return true;
        }

        if ($count >= $max_submits) {
            set_transient($key_block, $now + $block_seconds, $block_seconds);
            delete_transient($key_window);
            return false;
        }

        $state['count'] = $count + 1;
        set_transient($key_window, $state, $window_seconds + $block_seconds);
        return true;
    }
}




if (!function_exists('fone_check_context_rate_limit')) {
    /**
     * Rate limit generico per azioni pubbliche sensibili.
     * Usato anche dal login per ridurre brute force automatico.
     */
    function fone_check_context_rate_limit($context = 'generic', $max_submits = 10, $window_seconds = null, $block_seconds = null, $identity = '') {
        if (defined('FONE_DISABLE_RATE_LIMIT') && FONE_DISABLE_RATE_LIMIT) {
            return true;
        }

        if ($window_seconds === null) {
            $window_seconds = 10 * MINUTE_IN_SECONDS;
        }
        if ($block_seconds === null) {
            $block_seconds = 5 * MINUTE_IN_SECONDS;
        }

        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $identity = sanitize_text_field((string) $identity);
        $hash = md5($context . '|' . $ip . '|' . $identity);

        $key_window = 'fone_ctx_win_' . $hash;
        $key_block  = 'fone_ctx_blk_' . $hash;

        $now = time();
        $window_seconds = max(60, (int) $window_seconds);
        $block_seconds  = max(60, (int) $block_seconds);
        $max_submits    = max(1, (int) $max_submits);

        $block_until = (int) get_transient($key_block);
        if ($block_until && $now < $block_until) {
            return false;
        }

        $state = get_transient($key_window);
        if (!is_array($state) || empty($state['start'])) {
            set_transient($key_window, ['start' => $now, 'count' => 1], $window_seconds + $block_seconds);
            return true;
        }

        $start = (int) $state['start'];
        $count = isset($state['count']) ? (int) $state['count'] : 0;

        if (($now - $start) >= $window_seconds) {
            set_transient($key_window, ['start' => $now, 'count' => 1], $window_seconds + $block_seconds);
            delete_transient($key_block);
            return true;
        }

        if ($count >= $max_submits) {
            set_transient($key_block, $now + $block_seconds, $block_seconds);
            delete_transient($key_window);
            return false;
        }

        $state['count'] = $count + 1;
        set_transient($key_window, $state, $window_seconds + $block_seconds);
        return true;
    }
}

if (!function_exists('fone_safe_file_mimes')) {
    /**
     * Allowlist MIME dura per upload pubblici.
     * Non eredita ciecamente mimes aggiunti da altri plugin: prima interseca con
     * questa lista, poi passa da wp_check_filetype_and_ext.
     */
    function fone_safe_file_mimes($requested_mimes = null, $context = 'file') {
        $safe_file_mimes = [
            // Documenti
            'application/pdf',
            'application/msword',                                                          // .doc
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',     // .docx
            'application/vnd.ms-excel',                                                    // .xls
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',           // .xlsx
            'application/vnd.ms-powerpoint',                                               // .ppt
            'application/vnd.openxmlformats-officedocument.presentationml.presentation',   // .pptx
            'application/vnd.oasis.opendocument.text',                                     // .odt
            'application/vnd.oasis.opendocument.spreadsheet',                              // .ods
            'application/vnd.oasis.opendocument.presentation',                             // .odp
            'application/rtf',                                                             // .rtf
            'text/rtf',                                                                    // .rtf alt
            'text/plain',                                                                  // .txt
            'text/csv',                                                                    // .csv
            // Immagini
            'image/jpeg',
            'image/png',
            'image/webp',
            'image/gif',
            'image/avif',
            'image/bmp',
            'image/tiff',
            'image/heic',
            'image/heif',
            // Video
            'video/mp4',
            'video/webm',
            'video/quicktime',                                                             // .mov
            'video/x-msvideo',                                                             // .avi
            'video/x-matroska',                                                            // .mkv
            // Audio
            'audio/mpeg',                                                                  // .mp3
            'audio/wav',
            'audio/x-wav',
            'audio/ogg',
            'audio/mp4',                                                                   // .m4a
            'audio/webm',
            // Archivi
            'application/zip',
            'application/x-zip-compressed',
        ];

        $safe_avatar_mimes = [
            'image/jpeg',
            'image/png',
            'image/webp',
            'image/gif',
            'image/avif',
            'image/bmp',
            'image/tiff',
            'image/heic',
            'image/heif',
        ];

        $base = ($context === 'avatar') ? $safe_avatar_mimes : $safe_file_mimes;
        $base = apply_filters('fone_safe_upload_mimes', $base, $context);

        $dangerous = [
            'image/svg+xml',
            'text/html',
            'application/xhtml+xml',
            'application/xml',
            'text/xml',
            'application/javascript',
            'text/javascript',
            'application/x-httpd-php',
            'application/x-php',
            'application/x-sh',
            'application/x-msdownload',
            'application/octet-stream',
        ];

        $base = array_values(array_diff(array_unique(array_filter((array) $base)), $dangerous));

        if ($requested_mimes === null || $requested_mimes === '') {
            return $base;
        }

        $requested_mimes = array_map('trim', (array) $requested_mimes);
        $requested_mimes = array_values(array_filter($requested_mimes, function($mime) use ($dangerous) {
            return is_string($mime) && strpos($mime, '/') !== false && !in_array($mime, $dangerous, true);
        }));

        $allowed = array_values(array_intersect($requested_mimes, $base));
        return !empty($allowed) ? $allowed : $base;
    }
}

if (!function_exists('fone_handle_generic_file_upload')) {
    /**
     * Upload generico sicuro per campi file. Crea attachment WP e ritorna ID + URL.
     * Default prudente: immagini, PDF, TXT, DOC/DOCX. Niente eseguibili.
     */
    function fone_handle_generic_file_upload($file_key, $allowed_mimes = null, $max_size_bytes = null) {
        $allowed_mimes = function_exists('fone_safe_file_mimes')
            ? fone_safe_file_mimes($allowed_mimes, 'file')
            : (array) $allowed_mimes;

        if (empty($allowed_mimes)) {
            return ['ok' => false, 'error' => fone_t('error_file_type')];
        }
        if ($max_size_bytes === null) {
            $max_size_bytes = 20 * 1024 * 1024;
        }
        if (empty($_FILES[$file_key]) || empty($_FILES[$file_key]['tmp_name'])) {
            return ['ok' => false, 'error' => fone_t('error_required')];
        }
        $file = $_FILES[$file_key];
        $file['name'] = sanitize_file_name($file['name'] ?? '');
        if ($file['name'] === '' || preg_match('/\.(php|phtml|phar|cgi|pl|py|rb|sh|bash|js|html?|xhtml|svg)(\.|$)/i', $file['name'])) {
            return ['ok' => false, 'error' => fone_t('error_file_type')];
        }
        if (!empty($file['error']) && (int) $file['error'] !== UPLOAD_ERR_OK) {
            return ['ok' => false, 'error' => fone_t('error_file_size')];
        }
        if (!empty($file['size']) && (int) $file['size'] > $max_size_bytes) {
            return ['ok' => false, 'error' => fone_t('error_file_size')];
        }

        $all_mimes = wp_get_mime_types();
        $filtered_mimes = [];
        foreach ($all_mimes as $ext => $mime) {
            if (in_array($mime, $allowed_mimes, true)) {
                $filtered_mimes[$ext] = $mime;
            }
        }
        if (empty($filtered_mimes)) {
            return ['ok' => false, 'error' => fone_t('error_file_type')];
        }

        $detected = wp_check_filetype_and_ext($file['tmp_name'], $file['name'], $filtered_mimes);
        $mime = $detected['type'] ?? '';
        if (empty($mime) || !in_array($mime, $allowed_mimes, true)) {
            return ['ok' => false, 'error' => fone_t('error_file_type')];
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $mime_filter = function($mimes) use ($filtered_mimes) {
            return array_merge($mimes, $filtered_mimes);
        };
        add_filter('upload_mimes', $mime_filter, 99);
        $uploaded = wp_handle_upload($file, ['test_form' => false, 'mimes' => $filtered_mimes]);
        remove_filter('upload_mimes', $mime_filter, 99);

        if (empty($uploaded['file']) || !empty($uploaded['error'])) {
            return ['ok' => false, 'error' => fone_t('error_file_type')];
        }

        $attachment = [
            'post_mime_type' => $uploaded['type'],
            'post_title'     => sanitize_file_name(pathinfo($uploaded['file'], PATHINFO_FILENAME)),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ];
        $attach_id = wp_insert_attachment($attachment, $uploaded['file']);
        if (is_wp_error($attach_id) || !$attach_id) {
            return ['ok' => false, 'error' => 'Attachment error'];
        }
        $metadata = wp_generate_attachment_metadata($attach_id, $uploaded['file']);
        wp_update_attachment_metadata($attach_id, $metadata);

        return ['ok' => true, 'attachment_id' => (int) $attach_id, 'url' => $uploaded['url']];
    }
}

/* ---------------------------------------------------------------
   SUBMISSION
--------------------------------------------------------------- */

if (!function_exists('fone_is_our_submission')) {
    function fone_is_our_submission() {
        return !empty($_POST['fone_form_submit']) && !empty($_POST['fone_form_nonce']);
    }
}

if (!function_exists('fone_collect_values')) {
    function fone_collect_values($schema) {
        $values = [];
        foreach ($schema as $field) {
            if (empty($field['id']) || empty($field['type'])) {
                continue;
            }
            $id   = $field['id'];
            $type = $field['type'];

            if ($type === 'html' || $type === 'html_admin' || $type === 'submit' || $type === 'paypal_button' || $type === 'divider') {
                continue;
            }

            // Hidden — usa valore inviato o default schema
            if ($type === 'hidden') {
                $raw = isset($_POST[$id]) ? wp_unslash($_POST[$id]) : ($field['default_value'] ?? '');
                $values[$id] = sanitize_text_field($raw);
                continue;
            }

            // Consent — checkbox singola privacy/terms
            if ($type === 'consent') {
                $values[$id] = isset($_POST[$id]) ? '1' : '';
                continue;
            }

            // File upload generico
            if ($type === 'file') {
                $file_key = $id;
                $has_tmp  = !empty($_FILES[$file_key]['tmp_name']);
                $has_size = !empty($_FILES[$file_key]['size']) && (int) $_FILES[$file_key]['size'] > 0;
                $err_code = isset($_FILES[$file_key]['error']) ? (int) $_FILES[$file_key]['error'] : UPLOAD_ERR_NO_FILE;
                $really_uploaded = $has_tmp && $has_size && $err_code === UPLOAD_ERR_OK;

                if ($really_uploaded) {
                    $allowed = null;
                    if (!empty($field['accept_types'])) {
                        $parts = array_map('trim', explode(',', $field['accept_types']));
                        $allowed = function_exists('fone_safe_file_mimes') ? fone_safe_file_mimes($parts, 'file') : array_values($parts);
                    }
                    $max_mb = !empty($field['max_size_mb']) ? (int) $field['max_size_mb'] : 10;
                    $max_bytes = $max_mb * 1024 * 1024;
                    $up = fone_handle_generic_file_upload($file_key, $allowed, $max_bytes);
                    if (!empty($up['ok'])) {
                        $values[$id] = $up['attachment_id'];
                        $values[$id . '__url'] = $up['url'];
                    } else {
                        $values[$id] = '';
                        $values[$id . '__err'] = $up['error'] ?? '';
                    }
                } else {
                    $values[$id] = '';
                    if ($err_code !== UPLOAD_ERR_NO_FILE) {
                        $values[$id . '__err'] = in_array($err_code, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)
                            ? fone_t('error_file_size')
                            : fone_t('error_file_type');
                    }
                }
                continue;
            }

            // Avatar — gestione file upload
            if ($type === 'avatar') {
                // Prima prova sul file principale, poi sul "_capture"
                $file_key = $id;
                if (empty($_FILES[$file_key]['tmp_name']) && !empty($_FILES[$id . '_capture']['tmp_name'])) {
                    $file_key = $id . '_capture';
                }

                // Il file è stato realmente caricato solo se:
                // - esiste tmp_name non vuoto
                // - size > 0 (altrimenti è un placeholder "fittizio" del browser)
                // - error è UPLOAD_ERR_OK (0) oppure NO_FILE (4, → lo consideriamo "assente", non errore reale)
                $has_tmp   = !empty($_FILES[$file_key]['tmp_name']);
                $has_size  = !empty($_FILES[$file_key]['size']) && (int) $_FILES[$file_key]['size'] > 0;
                $err_code  = isset($_FILES[$file_key]['error']) ? (int) $_FILES[$file_key]['error'] : UPLOAD_ERR_NO_FILE;
                $really_uploaded = $has_tmp && $has_size && $err_code === UPLOAD_ERR_OK;

                if ($really_uploaded) {
                    $allowed = null; // lascia al default sicuro di fone_handle_avatar_upload
                    if (!empty($field['accept_types'])) {
                        $parts = array_map('trim', explode(',', $field['accept_types']));
                        $allowed = function_exists('fone_safe_file_mimes') ? fone_safe_file_mimes($parts, 'avatar') : array_values($parts);
                    }
                    $max_mb    = !empty($field['max_size_mb']) ? (int) $field['max_size_mb'] : 12;
                    $max_bytes = $max_mb * 1024 * 1024;

                    $up = fone_handle_avatar_upload($file_key, $allowed, $max_bytes);
                    if (!empty($up['ok'])) {
                        $values[$id]          = $up['attachment_id'];
                        $values[$id . '__url']= $up['url'];
                    } else {
                        $values[$id]          = '';
                        $values[$id . '__err']= $up['error'] ?? '';
                    }
                } else {
                    $values[$id] = '';
                }
                continue;
            }

            if ($type === 'checkbox') {
                $raw = isset($_POST[$id]) ? wp_unslash($_POST[$id]) : [];
                if (!is_array($raw)) {
                    $raw = [];
                }
                $values[$id] = array_map('sanitize_text_field', $raw);
            } else {
                $raw = isset($_POST[$id]) ? wp_unslash($_POST[$id]) : '';
                if ($type === 'email') {
                    $values[$id] = sanitize_email($raw);
                } elseif ($type === 'url') {
                    $values[$id] = esc_url_raw($raw);
                } elseif (in_array($type, ['number','date','time','color','range','rating','nps'], true)) {
                    $values[$id] = sanitize_text_field($raw);
                } elseif (in_array($type, ['tel','phone','whatsapp'], true)) {
                    // Concateno prefisso internazionale + numero in un unico valore
                    $prefix = isset($_POST[$id . '_prefix']) ? sanitize_text_field(wp_unslash($_POST[$id . '_prefix'])) : '';
                    // Pulisco il numero: solo cifre e spazi ammessi
                    $number_clean = preg_replace('/[^0-9 ]/', '', (string) $raw);
                    $number_clean = trim($number_clean);
                    if ($prefix && $number_clean !== '') {
                        $values[$id] = $prefix . ' ' . $number_clean;
                    } else {
                        $values[$id] = $number_clean;
                    }
                } elseif ($type === 'password') {
                    // Le password non le sanitizziamo in modo aggressivo: solo strip di tag
                    $values[$id] = wp_strip_all_tags($raw);
                } else {
                    $values[$id] = sanitize_textarea_field($raw);
                }

                // Trasformazioni post-sanitize per text/name
                if (($type === 'text' || $type === 'name') && isset($values[$id]) && is_string($values[$id])) {
                    if (!empty($field['opt_lowercase'])) {
                        $values[$id] = mb_strtolower($values[$id]);
                    }
                    if (!empty($field['opt_capitalize']) && $values[$id] !== '') {
                        $values[$id] = mb_convert_case($values[$id], MB_CASE_TITLE, 'UTF-8');
                    }
                }
            }
        }

        // --- META PAGAMENTO (campo paypal_button) ---
        // Se c'è almeno un campo paypal_button nello schema, raccolgo i meta
        // dai campi hidden iniettati dal JS dopo onApprove/onCancel.
        $has_paypal = false;
        foreach ($schema as $f) {
            if (($f['type'] ?? '') === 'paypal_button') { $has_paypal = true; break; }
        }
        if ($has_paypal) {
            /*
             * HARDENING 10.1.2:
             * Non fidarsi mai di campi hidden client-side come prova di pagamento.
             * Un utente può forzare fone_payment_status=paid con DevTools/cURL.
             * Finché non esiste una verifica server-side con PayPal API/webhook, il
             * pagamento resta "unverified" e non viene marcato come PAGATO.
             */
            $pay_tx      = isset($_POST['fone_payment_tx'])      ? sanitize_text_field(wp_unslash($_POST['fone_payment_tx']))    : '';
            $pay_gateway = isset($_POST['fone_payment_gateway']) ? sanitize_key(wp_unslash($_POST['fone_payment_gateway']))      : 'paypal';

            $values['_fone_payment'] = [
                'status'  => 'unverified',
                'tx'      => $pay_tx,
                'gateway' => $pay_gateway ?: 'paypal',
                'at'      => current_time('mysql'),
                'note'    => 'Pagamento non verificato server-side: non trattare come pagato.',
            ];
        }

        return $values;
    }
}


if (!function_exists('fone_condition_value_from_schema')) {
    function fone_condition_value_from_schema($schema, $values, $field_ref) {
        $field_ref = (string) $field_ref;
        if ($field_ref === '') return '';
        foreach ($schema as $f) {
            $fid = isset($f['id']) ? (string) $f['id'] : '';
            $slug = isset($f['slug']) ? (string) $f['slug'] : '';
            if ($field_ref === $fid || $field_ref === $slug) {
                return isset($values[$fid]) ? $values[$fid] : '';
            }
        }
        return isset($values[$field_ref]) ? $values[$field_ref] : '';
    }
}

if (!function_exists('fone_field_condition_matches')) {
    function fone_field_condition_matches($schema, $values, $field) {
        if (empty($field['conditional_enabled'])) return true;

        $ref = sanitize_text_field($field['conditional_field'] ?? '');
        if ($ref === '') return true;

        $operator = sanitize_key($field['conditional_operator'] ?? 'is');
        $expected = (string) sanitize_text_field($field['conditional_value'] ?? '');
        $action = sanitize_key($field['conditional_action'] ?? 'show');

        $actual = fone_condition_value_from_schema($schema, $values, $ref);
        if (is_array($actual)) {
            $actual_list = array_map('strval', $actual);
            $actual_str = implode(' ', $actual_list);
        } else {
            $actual_list = [(string) $actual];
            $actual_str = (string) $actual;
        }

        $match = false;
        switch ($operator) {
            case 'is_not':
                $match = !in_array($expected, $actual_list, true) && $actual_str !== $expected;
                break;
            case 'contains':
                $match = $expected !== '' && stripos($actual_str, $expected) !== false;
                break;
            case 'not_empty':
                $match = trim($actual_str) !== '';
                break;
            case 'empty':
                $match = trim($actual_str) === '';
                break;
            case 'is':
            default:
                $match = in_array($expected, $actual_list, true) || $actual_str === $expected;
                break;
        }

        return $action === 'hide' ? !$match : $match;
    }
}


if (!function_exists('fone_validate_submission')) {
    function fone_validate_submission($schema, $values) {
        $errors = [];
        $pw_pairs = [];

        foreach ($schema as $field) {
            if (empty($field['id']) || empty($field['type'])) {
                continue;
            }
            $id    = $field['id'];
            $slug  = $field['slug'] ?? '';
            $type  = $field['type'];
            $label = !empty($field['label']) ? $field['label'] : $id;

            if ($type === 'html' || $type === 'html_admin' || $type === 'submit' || $type === 'paypal_button' || $type === 'divider') {
                continue;
            }

            if (function_exists('fone_field_condition_matches') && !fone_field_condition_matches($schema, $values, $field)) {
                continue;
            }

            $value = isset($values[$id]) ? $values[$id] : '';

            // Required
            if (!empty($field['required'])) {
                if ($type === 'checkbox') {
                    if (empty($value)) $errors[$id] = $label . ': ' . fone_t('error_required');
                } elseif ($type === 'avatar' || $type === 'file') {
                    if (empty($value)) {
                        $err_upload = isset($values[$id . '__err']) ? $values[$id . '__err'] : fone_t('error_required');
                        $errors[$id] = $label . ': ' . $err_upload;
                    }
                } elseif ($type === 'consent') {
                    if (empty($value)) $errors[$id] = $label . ': ' . fone_t('error_required');
                } else {
                    if ((string) $value === '') $errors[$id] = $label . ': ' . fone_t('error_required');
                }
            }

            // Email
            if ($type === 'email' && (string) $value !== '' && !is_email($value)) {
                $errors[$id] = $label . ': ' . fone_t('error_email');
            }

            // URL
            if ($type === 'url' && (string) $value !== '' && !filter_var($value, FILTER_VALIDATE_URL)) {
                $errors[$id] = $label . ': ' . fone_t('error_url');
            }

            // Password strength
            if ($type === 'password' && (string) $value !== '' && mb_strlen((string) $value) < 8) {
                $errors[$id] = $label . ': ' . fone_t('error_password_weak');
            }

            // Raccolgo password per confronto
            if ($type === 'password') {
                $pw_pairs[$slug] = $value;
            }

            /* ==========================================================
               VALIDAZIONE AVANZATA PER-OPZIONE (3.5.1+)
            ========================================================== */
            $v = is_string($value) ? $value : '';

            // EMAIL: blocco email temporanee + dominio specifico + conferma
            if ($type === 'email' && $v !== '') {
                if (!empty($field['opt_block_temp_email'])) {
                    $temp_domains = ['mailinator.com','tempmail.com','10minutemail.com','guerrillamail.com','yopmail.com','throwaway.email','temp-mail.org','getnada.com','maildrop.cc','fakeinbox.com','dispostable.com','trashmail.com'];
                    $email_domain = strtolower(substr(strrchr($v, '@') ?: '', 1));
                    if (in_array($email_domain, $temp_domains, true)) {
                        $errors[$id] = $label . ': ' . __('Email temporanee non ammesse.', 'form-one');
                    }
                }
                if (!empty($field['opt_email_domain'])) {
                    $required_domain = ltrim(strtolower($field['opt_email_domain']), '@');
                    $email_domain = strtolower(substr(strrchr($v, '@') ?: '', 1));
                    if ($email_domain !== $required_domain) {
                        $errors[$id] = $label . ': ' . sprintf(__('Deve appartenere al dominio @%s', 'form-one'), $required_domain);
                    }
                }
                if (!empty($field['opt_require_confirm'])) {
                    $confirm = isset($_POST[$id . '_confirm']) ? sanitize_email(wp_unslash($_POST[$id . '_confirm'])) : '';
                    if ($confirm !== $v) {
                        $errors[$id] = $label . ': ' . __('Le due email non coincidono.', 'form-one');
                    }
                }
            }

            // PASSWORD: regole di complessità
            if ($type === 'password' && $v !== '') {
                $min_len = !empty($field['opt_min_length']) ? (int) $field['opt_min_length'] : 8;
                if (mb_strlen($v) < $min_len) {
                    $errors[$id] = $label . ': ' . sprintf(__('Minimo %d caratteri.', 'form-one'), $min_len);
                }
                if (!empty($field['opt_require_upper']) && !preg_match('/[A-Z]/', $v)) {
                    $errors[$id] = $label . ': ' . __('Deve contenere almeno una lettera maiuscola.', 'form-one');
                }
                if (!empty($field['opt_require_lower']) && !preg_match('/[a-z]/', $v)) {
                    $errors[$id] = $label . ': ' . __('Deve contenere almeno una lettera minuscola.', 'form-one');
                }
                if (!empty($field['opt_require_number']) && !preg_match('/[0-9]/', $v)) {
                    $errors[$id] = $label . ': ' . __('Deve contenere almeno un numero.', 'form-one');
                }
                if (!empty($field['opt_require_symbol']) && !preg_match('/[^A-Za-z0-9]/', $v)) {
                    $errors[$id] = $label . ': ' . __('Deve contenere almeno un carattere speciale.', 'form-one');
                }
            }

            // TELEFONO / WHATSAPP: lunghezza numero
            if (in_array($type, ['tel','phone','whatsapp'], true) && $v !== '') {
                $digits_only = preg_replace('/[^0-9]/', '', $v);
                if (!empty($field['opt_min_digits']) && strlen($digits_only) < (int) $field['opt_min_digits']) {
                    $errors[$id] = $label . ': ' . sprintf(__('Almeno %d cifre.', 'form-one'), (int) $field['opt_min_digits']);
                }
                if (!empty($field['opt_max_digits']) && strlen($digits_only) > (int) $field['opt_max_digits']) {
                    $errors[$id] = $label . ': ' . sprintf(__('Massimo %d cifre.', 'form-one'), (int) $field['opt_max_digits']);
                }
            }

            // NUMERO: min/max/intero/step
            if ($type === 'number' && $v !== '') {
                $numv = (float) $v;
                if (isset($field['opt_min']) && $field['opt_min'] !== '' && $numv < (float) $field['opt_min']) {
                    $errors[$id] = $label . ': ' . sprintf(__('Minimo %s.', 'form-one'), $field['opt_min']);
                }
                if (isset($field['opt_max']) && $field['opt_max'] !== '' && $numv > (float) $field['opt_max']) {
                    $errors[$id] = $label . ': ' . sprintf(__('Massimo %s.', 'form-one'), $field['opt_max']);
                }
                if (!empty($field['opt_integer_only']) && $numv != (int) $numv) {
                    $errors[$id] = $label . ': ' . __('Solo numeri interi.', 'form-one');
                }
            }

            // RANGE / RATING / NPS: limiti numerici
            if (in_array($type, ['range','rating','nps'], true) && $v !== '') {
                if (!is_numeric($v)) {
                    $errors[$id] = $label . ': ' . __('Valore numerico non valido.', 'form-one');
                } else {
                    $numv = (float) $v;
                    $min = isset($field['opt_min']) && $field['opt_min'] !== '' ? (float) $field['opt_min'] : ($type === 'nps' ? 0 : 1);
                    $max = isset($field['opt_max']) && $field['opt_max'] !== '' ? (float) $field['opt_max'] : ($type === 'nps' ? 10 : 5);
                    if ($numv < $min) $errors[$id] = $label . ': ' . sprintf(__('Minimo %s.', 'form-one'), $min);
                    if ($numv > $max) $errors[$id] = $label . ': ' . sprintf(__('Massimo %s.', 'form-one'), $max);
                }
            }

            // TIME: formato HH:MM e min/max
            if ($type === 'time' && $v !== '') {
                if (!preg_match('/^\d{2}:\d{2}$/', $v)) {
                    $errors[$id] = $label . ': ' . __('Orario non valido.', 'form-one');
                } else {
                    if (!empty($field['opt_min']) && $v < $field['opt_min']) $errors[$id] = $label . ': ' . sprintf(__('Orario minimo %s.', 'form-one'), $field['opt_min']);
                    if (!empty($field['opt_max']) && $v > $field['opt_max']) $errors[$id] = $label . ': ' . sprintf(__('Orario massimo %s.', 'form-one'), $field['opt_max']);
                }
            }

            // COLOR: esadecimale #rrggbb
            if ($type === 'color' && $v !== '' && !preg_match('/^#[0-9a-fA-F]{6}$/', $v)) {
                $errors[$id] = $label . ': ' . __('Colore non valido.', 'form-one');
            }

            // URL: HTTPS / dominio
            if ($type === 'url' && $v !== '') {
                if (!empty($field['opt_require_https']) && stripos($v, 'https://') !== 0) {
                    $errors[$id] = $label . ': ' . __('Deve iniziare con https://', 'form-one');
                }
                if (!empty($field['opt_url_domain'])) {
                    $req_host = strtolower(ltrim($field['opt_url_domain'], '@'));
                    $cur_host = strtolower((string) parse_url($v, PHP_URL_HOST));
                    $cur_host = preg_replace('/^www\./', '', $cur_host);
                    if ($cur_host !== $req_host) {
                        $errors[$id] = $label . ': ' . sprintf(__('Il dominio deve essere %s', 'form-one'), $req_host);
                    }
                }
            }

            // DATA: passato/futuro/età min/max
            if ($type === 'date' && $v !== '') {
                $ts = strtotime($v);
                if ($ts) {
                    $today = strtotime(date('Y-m-d'));
                    if (!empty($field['opt_future_only']) && $ts < $today) {
                        $errors[$id] = $label . ': ' . __('Solo date future.', 'form-one');
                    }
                    if (!empty($field['opt_past_only']) && $ts > $today) {
                        $errors[$id] = $label . ': ' . __('Solo date passate.', 'form-one');
                    }
                    $age = (int) date('Y') - (int) date('Y', $ts);
                    if (date('md', $today) < date('md', $ts)) $age--;
                    if (!empty($field['opt_min_age']) && $age < (int) $field['opt_min_age']) {
                        $errors[$id] = $label . ': ' . sprintf(__('Età minima richiesta: %d anni.', 'form-one'), (int) $field['opt_min_age']);
                    }
                    if (!empty($field['opt_max_age']) && $age > (int) $field['opt_max_age']) {
                        $errors[$id] = $label . ': ' . sprintf(__('Età massima consentita: %d anni.', 'form-one'), (int) $field['opt_max_age']);
                    }
                }
            }

            // TESTO / NOME: vincoli caratteri / lunghezza
            if (($type === 'text' || $type === 'name') && $v !== '') {
                if (!empty($field['opt_letters_only']) && !preg_match('/^[\p{L}\s\'’\-]+$/u', $v)) {
                    $errors[$id] = $label . ': ' . __('Solo lettere.', 'form-one');
                }
                if (!empty($field['opt_alphanum_only']) && !preg_match('/^[\p{L}0-9\s]+$/u', $v)) {
                    $errors[$id] = $label . ': ' . __('Solo lettere e numeri.', 'form-one');
                }
                if (!empty($field['opt_no_spaces']) && preg_match('/\s/', $v)) {
                    $errors[$id] = $label . ': ' . __('Non sono ammessi spazi.', 'form-one');
                }
                if (!empty($field['opt_min_length']) && mb_strlen($v) < (int) $field['opt_min_length']) {
                    $errors[$id] = $label . ': ' . sprintf(__('Minimo %d caratteri.', 'form-one'), (int) $field['opt_min_length']);
                }
                if (!empty($field['opt_max_length']) && mb_strlen($v) > (int) $field['opt_max_length']) {
                    $errors[$id] = $label . ': ' . sprintf(__('Massimo %d caratteri.', 'form-one'), (int) $field['opt_max_length']);
                }
            }

            // TEXTAREA: blocco link + parolacce
            if ($type === 'textarea' && $v !== '') {
                if (!empty($field['opt_block_links']) && preg_match('/(https?:\/\/|www\.)/i', $v)) {
                    $errors[$id] = $label . ': ' . __('Non sono ammessi link nel messaggio.', 'form-one');
                }
                if (!empty($field['opt_block_badwords'])) {
                    $bad = ['fuck','shit','bitch','asshole','cazzo','merda','stronzo','puttana','vaffanculo','troia'];
                    foreach ($bad as $w) {
                        if (stripos($v, $w) !== false) {
                            $errors[$id] = $label . ': ' . __('Il messaggio contiene linguaggio non ammesso.', 'form-one');
                            break;
                        }
                    }
                }
            }

            // Max chars
            if (!empty($field['max_chars']) && (int) $field['max_chars'] > 0 && !is_array($value) && $type !== 'avatar') {
                if (mb_strlen((string) $value) > (int) $field['max_chars']) {
                    $errors[$id] = $label . ': ' . fone_t('error_max_chars');
                }
            }

            // Avatar/File - errore di upload
            if ($type === 'avatar' || $type === 'file') {
                $has_err = isset($values[$id . '__err']) && $values[$id . '__err'] !== '';
                $has_val = !empty($value);
                $is_required = !empty($field['required']);

                if ($has_val) {
                    // File caricato con successo → nessun errore
                } elseif ($has_err && $is_required) {
                    // File mancante / errato e campo obbligatorio → messaggio pulito
                    $errors[$id] = $label . ': ' . fone_t('error_required');
                } elseif ($has_err && !$is_required) {
                    // Se un campo file opzionale viene lasciato vuoto, nessun errore.
                    // Se però l'utente prova davvero a caricare un file e l'upload fallisce,
                    // non si deve mostrare un successo silenzioso.
                    if ($type === 'file') {
                        $errors[$id] = $label . ': ' . $values[$id . '__err'];
                    }
                } elseif (!$has_val && $is_required) {
                    // Già gestito dal check required generico sopra
                }
            }
        }

        // Password match check (se ci sono sia "password" che "password_confirm")
        if (!empty($pw_pairs['password']) && isset($pw_pairs['password_confirm'])) {
            if ($pw_pairs['password'] !== $pw_pairs['password_confirm']) {
                // Trova l'ID del campo password_confirm
                foreach ($schema as $f) {
                    if (($f['slug'] ?? '') === 'password_confirm') {
                        $errors[$f['id']] = ($f['label'] ?? '') . ': ' . fone_t('error_password_match');
                    }
                }
            }
        }

        return $errors;
    }
}

/* ---------------------------------------------------------------
   STORE & NOTIFY
--------------------------------------------------------------- */

if (!function_exists('fone_store_entry')) {
    function fone_store_entry($schema, $values, $form_id = 0) {
        $global_settings = function_exists('fone_get_global_settings') ? fone_get_global_settings() : [];
        if (isset($global_settings['save_entries']) && empty($global_settings['save_entries'])) {
            return false;
        }
        return fone_db_insert_entry($schema, $values, '', $form_id);
    }
}

/* ===============================================================
   EMAIL HTML — TEMPLATE UNIFICATO v11
   Palette Form One: fucsia, viola, blu scuro opaco, blu elettrico.
   Testo nero quasi puro (#0a0a0f).
   Mobile-first, dark-mode safe, compatibile con tutti i client.
=============================================================== */

if (!function_exists('fone_get_plugin_admin_email')) {
    /**
     * Email amministratore plugin: priorità a costante, poi opzione globale.
     * Usata per CC/BCC e fallback destinatario notifiche.
     */
    function fone_get_plugin_admin_email() {
        if (defined('FONE_ADMIN_EMAIL') && is_email(FONE_ADMIN_EMAIL)) {
            return FONE_ADMIN_EMAIL;
        }
        $opt = get_option('fone_plugin_admin_email', '');
        return is_email($opt) ? $opt : '';
    }
}

if (!function_exists('fone_get_from_name')) {
    /**
     * Nome mittente ufficiale delle email Form One.
     * Default obbligatorio: "Form One".
     * Filtrabile via 'fone_from_name', ma sempre ripulito per evitare header strani.
     */
    function fone_get_from_name() {
        // 1.0: il brand è sempre "Form One". Filtri esterni non possono cambiarlo
        // per garantire coerenza visuale a chi riceve le email.
        $from_name = 'Form One';
        $from_name = apply_filters('fone_from_name', $from_name);
        $from_name = wp_strip_all_tags((string) $from_name);
        $from_name = preg_replace('/[\r\n<>]+/', '', $from_name);
        $from_name = trim($from_name);
        // Whitelist hard: se il filtro ritorna qualcosa di vuoto o sospetto,
        // forziamo "Form One". Questo evita che plugin di terze parti che
        // sovrascrivono wp_mail_from_name producano un mittente fuori brand.
        if ($from_name === '' || strlen($from_name) > 60) {
            $from_name = 'Form One';
        }
        return $from_name;
    }
}

if (!function_exists('fone_get_from_address')) {
    /**
     * Mittente email "From:" del plugin.
     * Usa wordpress@<host> per massima deliverability (convenzione standard WP).
     * Filtrabile via 'fone_from_email'.
     */
    function fone_get_from_address() {
        $host = (string) parse_url(home_url(), PHP_URL_HOST);
        $host = preg_replace('/^www\./i', '', $host);
        if (!$host) $host = 'localhost';

        $from_email = apply_filters('fone_from_email', 'wordpress@' . $host);
        $from_email = sanitize_email($from_email);

        return is_email($from_email) ? $from_email : get_option('admin_email');
    }
}


if (!function_exists('fone_email_brand_name')) {
    /**
     * Nome pubblico ufficiale da usare dentro email e subject.
     * Per la release 1.0.0 viene forzato a Form One per evitare nomi sito strani.
     */
    function fone_email_brand_name() {
        return 'Form One';
    }
}

if (!function_exists('fone_normalize_email_subject')) {
    /**
     * Normalizza i subject delle email Form One.
     * Se il subject non contiene Form One, lo prefissa. Se contiene il nome sito, lo sostituisce.
     */
    function fone_normalize_email_subject($subject, $fallback = '') {
        $brand = function_exists('fone_email_brand_name') ? fone_email_brand_name() : 'Form One';
        $subject = wp_strip_all_tags((string) ($subject !== '' ? $subject : $fallback));
        $subject = preg_replace('/[
]+/', ' ', $subject);
        $subject = trim($subject);
        if ($subject === '') {
            $subject = '[' . $brand . '] Notifica';
        }

        $site_name = wp_strip_all_tags((string) get_bloginfo('name'));
        if ($site_name !== '' && strcasecmp($site_name, $brand) !== 0) {
            $subject = str_replace('[' . $site_name . ']', '[' . $brand . ']', $subject);
            $subject = str_ireplace($site_name, $brand, $subject);
        }
        $subject = str_ireplace('[WordPress]', '[' . $brand . ']', $subject);
        $subject = str_ireplace('WordPress', $brand, $subject);

        if (stripos($subject, $brand) === false) {
            $subject = '[' . $brand . '] ' . $subject;
        }
        return $subject;
    }
}

if (!function_exists('fone_send_wp_user_notification_with_brand')) {
    /**
     * Invia la notifica core WordPress di registrazione usando branding Form One
     * anche su mittente, subject e testo. Non lascia uscire [nome sito] o WordPress.
     */
    function fone_send_wp_user_notification_with_brand($user_id, $deprecated = null, $notify = 'user') {
        $from_name  = function_exists('fone_get_from_name') ? fone_get_from_name() : 'Form One';
        $from_email = function_exists('fone_get_from_address') ? fone_get_from_address() : get_option('admin_email');

        $from_name_filter = function ($name) use ($from_name) {
            return $from_name;
        };
        $from_email_filter = function ($email) use ($from_email) {
            return is_email($from_email) ? $from_email : $email;
        };
        $new_user_email_filter = function ($email, $user, $blogname) use ($from_name, $from_email) {
            $brand = function_exists('fone_email_brand_name') ? fone_email_brand_name() : 'Form One';

            if (isset($email['subject'])) {
                $email['subject'] = function_exists('fone_normalize_email_subject')
                    ? fone_normalize_email_subject((string) $email['subject'], '[' . $brand . '] Il tuo account è pronto')
                    : '[' . $brand . '] Il tuo account è pronto';
            } else {
                $email['subject'] = '[' . $brand . '] Il tuo account è pronto';
            }

            if (isset($email['message'])) {
                $email['message'] = str_replace((string) $blogname, $brand, (string) $email['message']);
                $email['message'] = str_ireplace('WordPress', $brand, $email['message']);
            }

            $email['headers'] = [
                'Content-Type: text/plain; charset=UTF-8',
                'From: ' . $from_name . ' <' . $from_email . '>',
            ];
            return $email;
        };

        // Strato finale di blindatura: phpmailer_init per battere SMTP plugins
        $phpmailer_filter = function ($phpmailer) use ($from_name, $from_email) {
            try {
                if (is_email($from_email)) {
                    $phpmailer->From = $from_email;
                }
                $phpmailer->FromName = $from_name;
            } catch (\Exception $e) {
                // Mai bloccare l'invio
            }
        };

        add_filter('wp_mail_from_name', $from_name_filter, PHP_INT_MAX);
        add_filter('wp_mail_from', $from_email_filter, PHP_INT_MAX);
        add_filter('wp_new_user_notification_email', $new_user_email_filter, PHP_INT_MAX, 3);
        add_action('phpmailer_init', $phpmailer_filter, PHP_INT_MAX);

        try {
            wp_new_user_notification($user_id, $deprecated, $notify);
        } finally {
            remove_filter('wp_mail_from_name', $from_name_filter, PHP_INT_MAX);
            remove_filter('wp_mail_from', $from_email_filter, PHP_INT_MAX);
            remove_filter('wp_new_user_notification_email', $new_user_email_filter, PHP_INT_MAX);
            remove_action('phpmailer_init', $phpmailer_filter, PHP_INT_MAX);
        }
    }
}
if (!function_exists('fone_wp_mail_with_brand')) {
    /**
     * Wrapper unico per le email generate da Form One.
     * Mantiene il nome mittente ufficiale "Form One" anche se WordPress, plugin
     * SMTP (WP Mail SMTP, FluentSMTP, Post SMTP, ecc.) o altri filtri provano a
     * sovrascrivere il mittente. Strategia a 3 strati:
     *   1. Header "From:" esplicito nella chiamata wp_mail
     *   2. Filtri wp_mail_from_name / wp_mail_from a priorità altissima
     *   3. Hook phpmailer_init che riscrive direttamente $phpmailer->FromName
     *      e $phpmailer->From PRIMA dell'invio reale via SMTP.
     */
    function fone_wp_mail_with_brand($to, $subject, $message, $headers = [], $attachments = []) {
        $from_name  = function_exists('fone_get_from_name') ? fone_get_from_name() : 'Form One';
        $from_email = function_exists('fone_get_from_address') ? fone_get_from_address() : get_option('admin_email');

        $headers = is_array($headers) ? $headers : [$headers];
        $clean_headers = [];
        $has_content_type = false;
        $has_from = false;

        foreach ($headers as $header) {
            $header = (string) $header;
            if (stripos($header, 'Content-Type:') === 0) {
                $has_content_type = true;
            }
            if (stripos($header, 'From:') === 0) {
                $has_from = true;
                $header = 'From: ' . $from_name . ' <' . $from_email . '>';
            }
            $clean_headers[] = $header;
        }

        if (!$has_content_type) {
            array_unshift($clean_headers, 'Content-Type: text/html; charset=UTF-8');
        }
        if (!$has_from) {
            $clean_headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
        }

        // STRATO 2: filtri standard WP
        $from_name_filter = function ($name) use ($from_name) {
            return $from_name;
        };
        $from_email_filter = function ($email) use ($from_email) {
            return is_email($from_email) ? $from_email : $email;
        };
        add_filter('wp_mail_from_name', $from_name_filter, PHP_INT_MAX);
        add_filter('wp_mail_from', $from_email_filter, PHP_INT_MAX);

        // STRATO 3: hook PHPMailer (eseguito DOPO i filtri SMTP plugins).
        // Riscrive From e FromName a priorità massima possibile, garantendo
        // che il nome che l'utente finale vede sia sempre "Form One".
        $phpmailer_filter = function ($phpmailer) use ($from_name, $from_email) {
            try {
                if (is_email($from_email)) {
                    $phpmailer->From = $from_email;
                }
                $phpmailer->FromName = $from_name;
                // Sender (envelope-from) lasciato gestire al server SMTP per evitare bounce
            } catch (\Exception $e) {
                // Mai bloccare l'invio se PHPMailer è in stato strano
            }
        };
        add_action('phpmailer_init', $phpmailer_filter, PHP_INT_MAX);

        try {
            $subject = function_exists('fone_normalize_email_subject') ? fone_normalize_email_subject($subject, '[Form One] Notifica') : $subject;
            return wp_mail($to, $subject, $message, $clean_headers, $attachments);
        } finally {
            remove_filter('wp_mail_from_name', $from_name_filter, PHP_INT_MAX);
            remove_filter('wp_mail_from', $from_email_filter, PHP_INT_MAX);
            remove_action('phpmailer_init', $phpmailer_filter, PHP_INT_MAX);
        }
    }
}

if (!function_exists('fone_collect_email_attachments')) {
    /**
     * Raccoglie i file caricati nei campi "file" e li passa a wp_mail
     * come allegati reali per la notifica amministratore.
     */
    function fone_collect_email_attachments($schema, $values) {
        $attachments = [];
        foreach ((array) $schema as $field) {
            if (empty($field['id']) || ($field['type'] ?? '') !== 'file') {
                continue;
            }

            $attachment_id = !empty($values[$field['id']]) ? absint($values[$field['id']]) : 0;
            if (!$attachment_id) {
                continue;
            }

            $path = get_attached_file($attachment_id);
            if ($path && file_exists($path) && is_readable($path)) {
                $attachments[] = $path;
            }
        }

        $attachments = array_values(array_unique($attachments));
        return apply_filters('fone_email_attachments', $attachments, $schema, $values);
    }
}

if (!function_exists('fone_email_brand_colors')) {
    /**
     * Palette ufficiale Form One usata in tutte le email.
     * Filtrabile per personalizzare in white-label.
     */
    function fone_email_brand_colors() {
        return apply_filters('fone_email_brand_colors', [
            'fuchsia'     => '#E91E80',  // Fucsia / accent caldo
            'purple'      => '#6C2BD9',  // Viola
            'navy'        => '#1A1F4D',  // Blu scuro opaco
            'electric'    => '#2D6CFF',  // Blu elettrico
            'text'        => '#0A0A0F',  // Nero quasi puro
            'text_soft'   => '#3F3F46',  // Grigio scuro per secondario
            'text_muted'  => '#71717A',  // Muted
            'bg_page'     => '#F4F1FA',  // Sfondo pagina (viola tenue)
            'bg_card'     => '#FFFFFF',  // Card
            'bg_subtle'   => '#FAFAFB',  // Tinte chiare
            'border'      => '#E4E4E7',  // Bordi
            'success'     => '#16A34A',
        ]);
    }
}

if (!function_exists('fone_email_render_data_table')) {
    /**
     * Tabella dati elegante per email — campi del form.
     * @param array $schema
     * @param array $values
     * @param array $opts skip_types, hide_password, show_avatar
     * @return string
     */
    function fone_email_render_data_table($schema, $values, $opts = []) {
        $opts = wp_parse_args($opts, [
            'skip_types'    => ['html', 'html_admin', 'submit', 'paypal_button'],
            'hide_password' => true,
        ]);
        $c = fone_email_brand_colors();

        ob_start();
        ?>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:separate;border-spacing:0;background:<?php echo $c['bg_subtle']; ?>;border:1px solid <?php echo $c['border']; ?>;border-radius:12px;overflow:hidden;">
        <?php
        $row_i = 0;
        foreach ($schema as $field) {
            if (empty($field['id']) || empty($field['type'])) continue;
            if (in_array($field['type'], $opts['skip_types'], true)) continue;
            if ($opts['hide_password'] && $field['type'] === 'password') continue;

            $label = !empty($field['label']) ? $field['label'] : $field['id'];
            $val   = isset($values[$field['id']]) ? $values[$field['id']] : '';

            // Avatar
            if ($field['type'] === 'avatar') {
                $url = isset($values[$field['id'] . '__url']) ? $values[$field['id'] . '__url'] : '';
                if (!$url && is_numeric($val)) $url = wp_get_attachment_url((int) $val);
                $val = $url
                    ? '<a href="' . esc_url($url) . '" target="_blank" style="text-decoration:none;color:' . $c['electric'] . ';"><img src="' . esc_url($url) . '" alt="" style="width:64px;height:64px;border-radius:50%;border:3px solid ' . $c['fuchsia'] . ';display:block;"></a>'
                    : '<em style="color:' . $c['text_muted'] . ';">(nessuna foto)</em>';
            }
            // File allegato: link leggibile in email + allegato reale nell'email admin
            elseif ($field['type'] === 'file') {
                $url = isset($values[$field['id'] . '__url']) ? $values[$field['id'] . '__url'] : '';
                $filename = __('File allegato', 'form-one');

                if (!$url && is_numeric($val)) {
                    $url = wp_get_attachment_url((int) $val);
                }
                if (is_numeric($val)) {
                    $path = get_attached_file((int) $val);
                    if ($path) {
                        $filename = basename($path);
                    } else {
                        $title = get_the_title((int) $val);
                        if ($title) {
                            $filename = $title;
                        }
                    }
                } elseif ($url) {
                    $url_path = wp_parse_url($url, PHP_URL_PATH);
                    if ($url_path) {
                        $filename = basename($url_path);
                    }
                }

                $val = $url
                    ? '<a href="' . esc_url($url) . '" target="_blank" style="color:' . $c['electric'] . ';text-decoration:none;font-weight:700;">📎 ' . esc_html($filename) . '</a>'
                    : '<em style="color:' . $c['text_muted'] . ';">(nessun file)</em>';
            }
            elseif ($field['type'] === 'whatsapp' && is_string($val) && $val !== '') {
                $num = preg_replace('/[^0-9]/', '', $val);
                $val = $num
                    ? '<a href="https://wa.me/' . esc_attr($num) . '" style="color:#16a34a;text-decoration:none;font-weight:600;">💬 ' . esc_html($val) . '</a>'
                    : esc_html($val);
            }
            elseif (in_array($field['type'], ['tel','phone'], true) && is_string($val) && $val !== '') {
                $num = preg_replace('/[^0-9+]/', '', $val);
                $val = $num
                    ? '<a href="tel:' . esc_attr($num) . '" style="color:' . $c['electric'] . ';text-decoration:none;font-weight:600;">📞 ' . esc_html($val) . '</a>'
                    : esc_html($val);
            }
            elseif ($field['type'] === 'email' && is_string($val) && is_email($val)) {
                $val = '<a href="mailto:' . esc_attr($val) . '" style="color:' . $c['electric'] . ';text-decoration:none;font-weight:600;">' . esc_html($val) . '</a>';
            }
            elseif ($field['type'] === 'url' && is_string($val) && $val !== '') {
                $val = '<a href="' . esc_url($val) . '" target="_blank" style="color:' . $c['electric'] . ';text-decoration:none;">' . esc_html($val) . ' ↗</a>';
            }
            elseif (
                is_string($val) && $val !== '' && (
                    (isset($field['slug']) && in_array($field['slug'], ['address','operational_address','business_address','home_address'], true))
                    || !empty($field['is_address'])
                    || (isset($field['autocomp']) && $field['autocomp'] === 'street-address')
                )
            ) {
                $maps = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($val);
                $val  = '<a href="' . esc_url($maps) . '" target="_blank" style="color:#EA4335;text-decoration:none;font-weight:600;">📍 ' . esc_html($val) . '</a>';
            }
            else {
                if (is_array($val)) $val = implode(', ', $val);
                $val = $val === '' ? '<em style="color:' . $c['text_muted'] . ';">—</em>' : nl2br(esc_html($val));
            }

            $bg = $row_i % 2 === 0 ? $c['bg_card'] : $c['bg_subtle'];
            $border = $row_i > 0 ? 'border-top:1px solid ' . $c['border'] . ';' : '';
            ?>
            <tr>
                <td style="padding:14px 18px;background:<?php echo $bg; ?>;<?php echo $border; ?>vertical-align:top;width:35%;font-size:13px;font-weight:600;color:<?php echo $c['text_soft']; ?>;letter-spacing:.01em;">
                    <?php echo esc_html($label); ?>
                </td>
                <td style="padding:14px 18px;background:<?php echo $bg; ?>;<?php echo $border; ?>vertical-align:top;font-size:14px;color:<?php echo $c['text']; ?>;line-height:1.55;">
                    <?php echo $val; ?>
                </td>
            </tr>
            <?php
            $row_i++;
        }
        ?>
        </table>
        <?php
        return ob_get_clean();
    }
}

if (!function_exists('fone_email_template')) {
    /**
     * TEMPLATE EMAIL UNIFICATO — usato per admin, user, registrazione, login,
     * messaggi manuali. Costruisce un layout responsive con header colorato a
     * gradiente fucsia→viola→navy, card centrale, footer brandizzato.
     *
     * @param array $args {
     *   @type string $emoji         Emoji grande nell'header (default 📩)
     *   @type string $title         Titolo grande nell'header
     *   @type string $subtitle      Sottotitolo nell'header (data/sito)
     *   @type string $intro         Frase di apertura nel corpo
     *   @type string $body_html     HTML libero da inserire nel corpo (sopra ai dati)
     *   @type string $data_html     HTML tabella dati (output di fone_email_render_data_table)
     *   @type array  $cta           ['label'=>..., 'url'=>...] CTA principale (opzionale)
     *   @type string $footer_note   Nota in fondo (opzionale)
     *   @type string $site_name
     *   @type string $site_url
     * }
     */
    function fone_email_template($args) {
        $a = wp_parse_args($args, [
            'emoji'       => '📩',
            'title'       => 'Form One',
            'subtitle'    => '',
            'intro'       => '',
            'body_html'   => '',
            'data_html'   => '',
            'cta'         => null,
            'footer_note' => '',
            'site_name'   => function_exists('fone_email_brand_name') ? fone_email_brand_name() : 'Form One',
            'site_url'    => get_bloginfo('url'),
        ]);
        $c    = fone_email_brand_colors();
        $date = current_time('d/m/Y H:i');

        ob_start(); ?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?php echo esc_html($a['title']); ?></title>
<!--[if mso]><style type="text/css">body,table,td{font-family:Arial,Helvetica,sans-serif !important;}</style><![endif]-->
</head>
<body style="margin:0;padding:0;background:<?php echo $c['bg_page']; ?>;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen,Ubuntu,sans-serif;color:<?php echo $c['text']; ?>;-webkit-font-smoothing:antialiased;">

<!-- preheader nascosto -->
<div style="display:none;font-size:1px;color:<?php echo $c['bg_page']; ?>;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
    <?php echo esc_html($a['intro'] ?: $a['title']); ?>
</div>

<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:<?php echo $c['bg_page']; ?>;padding:36px 16px;">
    <tr><td align="center">

        <!-- Brand bar -->
        <table role="presentation" width="640" cellpadding="0" cellspacing="0" border="0" style="max-width:640px;width:100%;margin-bottom:16px;">
            <tr>
                <td align="center" style="padding-bottom:14px;">
                    <span style="display:inline-block;font-size:22px;font-weight:900;letter-spacing:-.5px;background:linear-gradient(135deg,<?php echo $c['fuchsia']; ?> 0%,<?php echo $c['purple']; ?> 50%,<?php echo $c['electric']; ?> 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;color:<?php echo $c['purple']; ?>;">
                        ✦ Form One
                    </span>
                    <span style="display:inline-block;margin-left:10px;font-size:13px;color:<?php echo $c['text_muted']; ?>;">
                        · <?php echo esc_html($a['site_name']); ?>
                    </span>
                </td>
            </tr>
        </table>

        <!-- Card principale -->
        <table role="presentation" width="640" cellpadding="0" cellspacing="0" border="0" style="max-width:640px;width:100%;background:<?php echo $c['bg_card']; ?>;border-radius:20px;overflow:hidden;box-shadow:0 6px 28px rgba(26,31,77,.10),0 2px 6px rgba(26,31,77,.06);">

            <!-- Header colorato a gradiente -->
            <tr>
                <td style="padding:0;background:linear-gradient(135deg,<?php echo $c['fuchsia']; ?> 0%,<?php echo $c['purple']; ?> 45%,<?php echo $c['navy']; ?> 100%);">
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                        <tr>
                            <td style="padding:36px 38px 32px;color:#fff;">
                                <div style="font-size:44px;line-height:1;margin-bottom:14px;"><?php echo esc_html($a['emoji']); ?></div>
                                <div style="font-size:26px;font-weight:800;letter-spacing:-.4px;line-height:1.2;">
                                    <?php echo esc_html($a['title']); ?>
                                </div>
                                <?php if ($a['subtitle']) : ?>
                                <div style="font-size:14px;margin-top:8px;color:rgba(255,255,255,.85);font-weight:500;">
                                    <?php echo esc_html($a['subtitle']); ?>
                                </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <!-- Corpo -->
            <tr>
                <td style="padding:32px 38px 28px;">
                    <?php if ($a['intro']) : ?>
                    <p style="margin:0 0 22px;font-size:15px;line-height:1.7;color:<?php echo $c['text']; ?>;">
                        <?php echo wp_kses_post($a['intro']); ?>
                    </p>
                    <?php endif; ?>

                    <?php if ($a['body_html']) : ?>
                        <?php echo $a['body_html']; ?>
                    <?php endif; ?>

                    <?php if ($a['data_html']) : ?>
                        <div style="margin-top:8px;"><?php echo $a['data_html']; ?></div>
                    <?php endif; ?>

                    <?php if (is_array($a['cta']) && !empty($a['cta']['url']) && !empty($a['cta']['label'])) : ?>
                    <div style="margin-top:28px;text-align:center;">
                        <table role="presentation" cellpadding="0" cellspacing="0" border="0" align="center">
                            <tr><td style="border-radius:12px;background:linear-gradient(135deg,<?php echo $c['fuchsia']; ?> 0%,<?php echo $c['purple']; ?> 100%);">
                                <a href="<?php echo esc_url($a['cta']['url']); ?>" target="_blank"
                                   style="display:inline-block;padding:14px 32px;color:#fff;font-size:15px;font-weight:700;text-decoration:none;letter-spacing:.01em;border-radius:12px;">
                                    <?php echo esc_html($a['cta']['label']); ?> →
                                </a>
                            </td></tr>
                        </table>
                    </div>
                    <?php endif; ?>

                    <?php if ($a['footer_note']) : ?>
                    <p style="margin:24px 0 0;padding-top:20px;border-top:1px solid <?php echo $c['border']; ?>;font-size:13px;color:<?php echo $c['text_muted']; ?>;line-height:1.6;">
                        <?php echo wp_kses_post($a['footer_note']); ?>
                    </p>
                    <?php endif; ?>
                </td>
            </tr>

            <!-- Striscia decorativa -->
            <tr>
                <td style="height:6px;padding:0;background:linear-gradient(90deg,<?php echo $c['fuchsia']; ?> 0%,<?php echo $c['purple']; ?> 33%,<?php echo $c['navy']; ?> 66%,<?php echo $c['electric']; ?> 100%);font-size:0;line-height:0;">&nbsp;</td>
            </tr>

            <!-- Footer -->
            <tr>
                <td style="padding:18px 38px 22px;background:<?php echo $c['bg_subtle']; ?>;">
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                        <tr>
                            <td style="font-size:12px;color:<?php echo $c['text_muted']; ?>;line-height:1.6;">
                                <a href="<?php echo esc_url($a['site_url']); ?>" style="color:<?php echo $c['electric']; ?>;text-decoration:none;font-weight:600;">
                                    <?php echo esc_html($a['site_name']); ?>
                                </a>
                                · Inviato tramite <strong style="color:<?php echo $c['purple']; ?>;">Form One</strong>
                                · <?php echo esc_html($date); ?>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

        </table>

    </td></tr>
</table>

</body>
</html>
        <?php
        return ob_get_clean();
    }
}

/* ---------------------------------------------------------------
   FUNZIONI EMAIL SPECIFICHE (back-compat: stesse firme di prima)
--------------------------------------------------------------- */

if (!function_exists('fone_build_email_html')) {
    /** Email all'admin per submit generico (non registrazione, non login). */
    function fone_build_email_html($schema, $values, $title = 'Nuovo invio dal form') {
        $data = fone_email_render_data_table($schema, $values);
        return fone_email_template([
            'emoji'    => '📩',
            'title'    => $title,
            'subtitle' => 'Ricevuto il ' . current_time('d/m/Y H:i'),
            'intro'    => 'È stato ricevuto un nuovo invio dal form sul tuo sito. Tutti i dati compilati dall\'utente:',
            'data_html'=> $data,
            'footer_note' => 'Per gestire i tuoi form e gli invii ricevuti, accedi al pannello WordPress.',
        ]);
    }
}

if (!function_exists('fone_build_user_email_html')) {
    /** Email di conferma all'utente per submit generico. */
    function fone_build_user_email_html($schema, $values, $site_name, $site_url) {
        $data = fone_email_render_data_table($schema, $values);
        return fone_email_template([
            'emoji'     => '✅',
            'title'     => 'Messaggio ricevuto!',
            'subtitle'  => 'Grazie per averci contattato',
            'intro'     => 'Ciao! 👋 Abbiamo ricevuto il tuo messaggio. Ti risponderemo al più presto. Ecco un riepilogo dei dati che hai inviato:',
            'data_html' => $data,
            'footer_note' => 'Hai ricevuto questa email perché hai compilato un form su <strong>' . esc_html($site_name) . '</strong>. Se non sei stato tu, puoi ignorare questo messaggio.',
            'site_name' => $site_name,
            'site_url'  => $site_url,
        ]);
    }
}

if (!function_exists('fone_build_registration_admin_email_html')) {
    /** Email all'admin per nuova registrazione utente. */
    function fone_build_registration_admin_email_html($schema, $values) {
        $data = fone_email_render_data_table($schema, $values);
        $admin_users_url = admin_url('users.php');
        return fone_email_template([
            'emoji'    => '🎉',
            'title'    => 'Nuovo utente registrato!',
            'subtitle' => 'Registrazione completata il ' . current_time('d/m/Y H:i'),
            'intro'    => 'Una nuova persona si è appena registrata sul tuo sito. Ecco tutti i dati che ha fornito:',
            'data_html'=> $data,
            'cta'      => ['label' => '👥 Vedi tutti gli utenti', 'url' => $admin_users_url],
            'footer_note' => 'Puoi gestire l\'utente direttamente dal pannello WordPress, e da <strong>Form One → Invii</strong> puoi inviargli un\'email manuale di benvenuto.',
        ]);
    }
}

if (!function_exists('fone_build_registration_user_email_html')) {
    /** Email di benvenuto all'utente appena registrato. */
    function fone_build_registration_user_email_html($schema, $values, $site_name, $site_url) {
        $profile_url = function_exists('fone_default_profile_url') ? fone_default_profile_url() : home_url('/');
        $first_name = '';
        foreach ($schema as $field) {
            $slug = $field['slug'] ?? '';
            $wpf  = $field['wp_field'] ?? '';
            if (in_array($slug, ['first_name','full_name'], true) || $wpf === 'first_name' || $wpf === 'display_name') {
                $first_name = $values[$field['id']] ?? '';
                if ($first_name) break;
            }
        }
        $greeting = $first_name ? 'Ciao <strong>' . esc_html($first_name) . '</strong>! 👋' : 'Ciao! 👋';

        return fone_email_template([
            'emoji'     => '🎉',
            'title'     => 'Benvenuto su ' . $site_name . '!',
            'subtitle'  => 'Il tuo account è stato creato con successo',
            'intro'     => $greeting . '<br><br>Grazie per esserti registrato su <strong>' . esc_html($site_name) . '</strong>! Il tuo account è ora attivo e puoi iniziare a usarlo subito.',
            'cta'       => ['label' => '🚀 Vai alla tua area personale', 'url' => $profile_url],
            'footer_note' => 'Se non sei stato tu a registrarti, ignora pure questa email. Per qualsiasi domanda, rispondi a questo messaggio.',
            'site_name' => $site_name,
            'site_url'  => $site_url,
        ]);
    }
}

if (!function_exists('fone_build_login_user_email_html')) {
    /** Email di notifica accesso all'utente. */
    function fone_build_login_user_email_html($schema, $values, $site_name, $site_url, $profile_url = '') {
        $profile = $profile_url ? esc_url_raw($profile_url) : (function_exists('fone_default_profile_url') ? fone_default_profile_url() : home_url('/account-form-one/'));
        return fone_email_template([
            'emoji'     => '👋',
            'title'     => 'Bentornato!',
            'subtitle'  => 'Accesso effettuato il ' . current_time('d/m/Y H:i'),
            'intro'     => 'Hai effettuato l\'accesso al tuo account su <strong>' . esc_html($site_name) . '</strong>. Se non sei stato tu, contattaci subito.',
            'cta'       => ['label' => '👤 Vai al tuo profilo', 'url' => $profile],
            'site_name' => $site_name,
            'site_url'  => $site_url,
        ]);
    }
}
if (!function_exists('fone_send_email')) {
    /**
     * Invia email all'amministratore + conferma all'utente.
     * Differenzia automaticamente tra form normale e form di registrazione.
     */
    function fone_send_email($schema, $values, $form_id = 0) {
        $settings        = $form_id ? fone_get_settings($form_id) : fone_get_settings();
        $is_registration = !empty($settings['enable_registration']);
        $site_name       = function_exists('fone_email_brand_name') ? fone_email_brand_name() : 'Form One';
        $site_url        = get_bloginfo('url');

        // ---- Destinatario admin (priorità: impostazioni form → admin WP → fallback costante) ----
        $plugin_admin_email = fone_get_plugin_admin_email();
        $settings_email     = !empty($settings['admin_email']) && is_email($settings['admin_email'])
            ? $settings['admin_email'] : '';
        $admin_to = $settings_email ?: ($plugin_admin_email ?: get_option('admin_email'));
        if (!is_email($admin_to)) $admin_to = get_option('admin_email');

        // ---- Mittente ----
        $from_email = fone_get_from_address();
        $from_name  = fone_get_from_name();
        $email_brand_name = $from_name;

        // ---- Reply-To: email dell'utente se presente nel form ----
        $user_email = '';
        foreach ($schema as $field) {
            if (empty($field['id']) || empty($field['type'])) continue;
            if ($field['type'] === 'email') {
                $maybe = isset($values[$field['id']]) ? $values[$field['id']] : '';
                if (is_email($maybe)) { $user_email = $maybe; break; }
            }
        }
        $reply_to = $user_email ?: $admin_to;

        $email_attachments = function_exists('fone_collect_email_attachments')
            ? fone_collect_email_attachments($schema, $values)
            : [];

        $is_login_form = !empty($settings['enable_login']);

        // ---- Error logging ----
        $last_error    = '';
        $error_catcher = function ($wp_error) use (&$last_error) {
            if (is_wp_error($wp_error)) {
                $last_error = $wp_error->get_error_message();
                error_log('[Form One] wp_mail FAILED: ' . $last_error);
            }
        };
        add_action('wp_mail_failed', $error_catcher);

        // ================================================================
        // EMAIL ALL'AMMINISTRATORE
        // ================================================================
        if ($is_registration) {
            $subject_admin = !empty($settings["admin_email_subject"]) ? sanitize_text_field($settings["admin_email_subject"]) : "[" . $email_brand_name . "] Nuovo utente registrato";
            $body_admin    = fone_build_registration_admin_email_html($schema, $values);
        } elseif ($is_login_form) {
            $subject_admin = !empty($settings["admin_email_subject"]) ? sanitize_text_field($settings["admin_email_subject"]) : "[" . $email_brand_name . "] Nuovo accesso utente";
            $body_admin    = fone_build_email_html($schema, $values, "Nuovo accesso tramite Form One");
        } else {
            $subject_admin = !empty($settings["admin_email_subject"]) ? sanitize_text_field($settings["admin_email_subject"]) : "[" . $email_brand_name . "] Nuovo messaggio dal form";
            $body_admin    = fone_build_email_html($schema, $values, "Nuovo messaggio dal form");
        }

        $headers_full = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
            'Reply-To: ' . $reply_to,
        ];
        $sent_admin = fone_wp_mail_with_brand($admin_to, $subject_admin, $body_admin, $headers_full, $email_attachments);

        if (!$sent_admin) {
            error_log('[Form One] Tentativo 1 fallito verso ' . $admin_to . '. Retry con branding Form One.');
            $sent_admin = fone_wp_mail_with_brand($admin_to, $subject_admin, $body_admin, [
                'Content-Type: text/html; charset=UTF-8',
                'From: ' . $from_name . ' <' . $from_email . '>',
                'Reply-To: ' . $reply_to,
            ], $email_attachments);
        }
        if (!$sent_admin) {
            error_log('[Form One] IMPOSSIBILE inviare email admin.');
        }

        // ================================================================
        // EMAIL ALL'UTENTE (solo se ha inserito una email valida)
        // ================================================================
        $user_email_allowed = !array_key_exists("user_email_enabled", $settings) || !empty($settings["user_email_enabled"]);
        if ($user_email_allowed && $user_email && strcasecmp($user_email, $admin_to) !== 0) {
            if ($is_registration) {
                $subject_user = !empty($settings["user_email_subject"]) ? sanitize_text_field($settings["user_email_subject"]) : "Benvenuto su " . $email_brand_name . "!";
                $body_user    = fone_build_registration_user_email_html($schema, $values, $email_brand_name, $site_url);
            } elseif ($is_login_form) {
                $subject_user = !empty($settings["user_email_subject"]) ? sanitize_text_field($settings["user_email_subject"]) : "Accesso effettuato - " . $email_brand_name;
                $body_user    = fone_build_login_user_email_html($schema, $values, $email_brand_name, $site_url, $settings['profile_url'] ?? '');
            } else {
                $subject_user = !empty($settings["user_email_subject"]) ? sanitize_text_field($settings["user_email_subject"]) : "Abbiamo ricevuto il tuo messaggio - " . $email_brand_name;
                $body_user    = fone_build_user_email_html($schema, $values, $email_brand_name, $site_url);
            }

            $headers_user = [
                'Content-Type: text/html; charset=UTF-8',
                'From: ' . $from_name . ' <' . $from_email . '>',
                'Reply-To: ' . $admin_to,
            ];
            $sent_user = fone_wp_mail_with_brand($user_email, $subject_user, $body_user, $headers_user);
            if (!$sent_user) {
                error_log('[Form One] Email utente tentativo 1 fallito. Retry con branding Form One.');
                $sent_user = fone_wp_mail_with_brand($user_email, $subject_user, $body_user, [
                    'Content-Type: text/html; charset=UTF-8',
                    'From: ' . $from_name . ' <' . $from_email . '>',
                    'Reply-To: ' . $admin_to,
                ]);
            }
            if (!$sent_user) {
                error_log('[Form One] IMPOSSIBILE inviare email conferma a ' . $user_email);
            }
        }

        remove_action('wp_mail_failed', $error_catcher);
        return (bool) $sent_admin;
    }
}

/* ---------------------------------------------------------------
   POST-PROCESSING AVATAR: assegna a user loggato
--------------------------------------------------------------- */

if (!function_exists('fone_post_process_avatars')) {
    function fone_post_process_avatars($schema, $values) {
        if (!is_user_logged_in()) {
            return;
        }
        $user_id = get_current_user_id();
        foreach ($schema as $field) {
            if (($field['type'] ?? '') !== 'avatar') continue;
            $id = $field['id'] ?? '';
            if (!$id) continue;
            $att = isset($values[$id]) ? (int) $values[$id] : 0;
            if ($att > 0) {
                fone_assign_avatar_to_user($user_id, $att);
            }
        }
    }
}


/* ---------------------------------------------------------------
   REGISTRAZIONE UTENTE
   La registrazione non è più un post-processing "silenzioso":
   se il form è di registrazione, l'utente deve essere creato PRIMA
   del successo. Se fallisce, il submit fallisce chiaramente.
--------------------------------------------------------------- */
if (!function_exists('fone_submission_is_registration_form')) {
    function fone_submission_is_registration_form($form_id, $schema, $settings) {
        if (!empty($settings['enable_login'])) {
            return false;
        }

        if (!empty($settings['enable_registration'])) {
            return true;
        }

        $form = null;
        if ($form_id && function_exists('fone_get_form')) {
            $form = fone_get_form((int) $form_id);
            if (!empty($form['is_registration'])) {
                return true;
            }
        }

        /**
         * Fallback legacy più stretto del vecchio email+password.
         * Ora email+password NON basta: il form deve anche sembrare esplicitamente
         * una registrazione dal nome/slug oppure tramite filtro sviluppatore.
         */
        $allow_named_legacy = apply_filters('fone_allow_named_registration_autodetect', true, $form_id, $schema, $settings, $form);
        if ($allow_named_legacy && $form && function_exists('fone_form_looks_like_registration') && function_exists('fone_schema_has_registration_credentials')) {
            return fone_form_looks_like_registration($form) && fone_schema_has_registration_credentials($schema);
        }

        return false;
    }
}

if (!function_exists('fone_create_user_from_submission')) {
    function fone_create_user_from_submission($values, $schema, $form_id = 0, $settings = []) {
        $out = ['ok' => false, 'user_id' => 0, 'message' => __('Registrazione non completata.', 'form-one')];

        if (!is_array($schema) || !is_array($values)) {
            $out['message'] = __('Dati di registrazione non validi.', 'form-one');
            return $out;
        }

        $user_email   = '';
        $user_login   = '';
        $user_pass    = '';
        $first_name   = '';
        $last_name    = '';
        $display_name = '';
        $user_url     = '';
        $description  = '';
        $custom_meta  = [];
        $avatar_att   = 0;

        $slug_map = [
            'email'          => 'user_email',
            'login_email'    => 'user_email',
            'username'       => 'user_login',
            'password'       => 'user_pass',
            'first_name'     => 'first_name',
            'last_name'      => 'last_name',
            'full_name'      => 'display_name',
            'display_name'   => 'display_name',
            'profile_name'   => 'display_name',
            'website'        => 'user_url',
            'website_url'    => 'user_url',
            'user_url'       => 'user_url',
            'bio'            => 'description',
            'description'    => 'description',
        ];

        foreach ($schema as $field) {
            $fid  = $field['id'] ?? '';
            $type = $field['type'] ?? '';
            $slug = $field['slug'] ?? '';
            $wp_f = $field['wp_field'] ?? '';

            if (!$fid || in_array($type, ['html', 'html_admin', 'submit', 'paypal_button', 'divider'], true)) {
                continue;
            }

            $val = isset($values[$fid]) ? $values[$fid] : '';
            if (is_array($val)) $val = implode(', ', $val);
            $val = (string) $val;

            if ($type === 'avatar') {
                $att = (int) ($values[$fid] ?? 0);
                if ($att > 0) $avatar_att = $att;
                continue;
            }

            // File generico in registrazione: salva attachment_id come int
            // così wp_get_attachment_url() in area personale funziona corretto.
            if ($type === 'file') {
                $att_id = (int) ($values[$fid] ?? 0);
                if ($att_id > 0) {
                    $meta_key = sanitize_key($fid);
                    if (!function_exists('fone_is_protected_user_meta_key') || !fone_is_protected_user_meta_key($meta_key)) {
                        $custom_meta[$meta_key] = $att_id; // forziamo int, non stringa
                    }
                }
                continue;
            }

            $target = '';
            if ($wp_f && $wp_f !== 'custom_meta') {
                $target = $wp_f;
            } elseif (isset($slug_map[$slug])) {
                $target = $slug_map[$slug];
            } elseif ($type === 'email' && $user_email === '') {
                $target = 'user_email';
            } elseif ($type === 'password' && $user_pass === '' && $slug !== 'password_confirm') {
                $target = 'user_pass';
            }

            switch ($target) {
                case 'user_email':   $user_email   = $val; break;
                case 'user_login':   $user_login   = $val; break;
                case 'user_pass':    $user_pass    = $val; break;
                case 'first_name':   $first_name   = $val; break;
                case 'last_name':    $last_name    = $val; break;
                case 'display_name': $display_name = $val; break;
                case 'user_url':     $user_url     = $val; break;
                case 'description':  $description  = $val; break;
                case 'custom_meta':
                    $meta_key = sanitize_key($fid);
                    if (!function_exists('fone_is_protected_user_meta_key') || !fone_is_protected_user_meta_key($meta_key)) {
                        $custom_meta[$meta_key] = $val;
                    }
                    break;
                default:
                    $meta_key = sanitize_key($fid);
                    if (!function_exists('fone_is_protected_user_meta_key') || !fone_is_protected_user_meta_key($meta_key)) {
                        $custom_meta[$meta_key] = $val;
                    }
                    break;
            }
        }

        $user_email = sanitize_email($user_email);
        if (!is_email($user_email)) {
            $out['message'] = __('Inserisci un indirizzo email valido per creare l’account.', 'form-one');
            return $out;
        }

        if (email_exists($user_email)) {
            $out['message'] = __('Questa email è già registrata. Usa un’altra email oppure accedi al tuo account.', 'form-one');
            return $out;
        }

        $user_login = sanitize_user($user_login, true);
        if (empty($user_login)) {
            $user_login = sanitize_user(strstr($user_email, '@', true), true);
        }
        if (empty($user_login)) {
            $user_login = 'user';
        }
        $base_login = $user_login;
        $counter = 1;
        while (username_exists($user_login)) {
            $user_login = $base_login . $counter;
            $counter++;
        }

        $user_pass = $user_pass !== '' ? $user_pass : wp_generate_password(12, true, false);

        $role = !empty($settings['registration_role']) ? sanitize_key($settings['registration_role']) : 'subscriber';
        $role = function_exists('fone_get_safe_registration_role') ? fone_get_safe_registration_role($role) : ($role === 'administrator' ? 'subscriber' : $role);

        if ($display_name === '') {
            $display_name = trim($first_name . ' ' . $last_name);
            if ($display_name === '') {
                $display_name = $user_login;
            }
        }

        $user_data = [
            'user_login'   => $user_login,
            'user_email'   => $user_email,
            'user_pass'    => $user_pass,
            'role'         => $role,
            'display_name' => sanitize_text_field($display_name),
        ];
        if ($first_name  !== '') $user_data['first_name']  = sanitize_text_field($first_name);
        if ($last_name   !== '') $user_data['last_name']   = sanitize_text_field($last_name);
        if ($user_url    !== '') $user_data['user_url']    = esc_url_raw($user_url);
        if ($description !== '') $user_data['description'] = sanitize_textarea_field($description);

        $user_id = wp_insert_user($user_data);
        if (is_wp_error($user_id)) {
            $out['message'] = $user_id->get_error_message();
            return $out;
        }
        $user_id = (int) $user_id;

        foreach ($custom_meta as $key => $val) {
            // Se è un int (es. attachment_id da campi file), salviamolo come tale.
            // sanitize_text_field lo trasforma in stringa, ma manteniamolo int per
            // usi tipo wp_get_attachment_url().
            if (is_int($val)) {
                update_user_meta($user_id, $key, $val);
            } else {
                update_user_meta($user_id, $key, sanitize_text_field($val));
            }
        }

        if ($avatar_att > 0 && function_exists('fone_assign_avatar_to_user')) {
            fone_assign_avatar_to_user($user_id, $avatar_att);
        }

        if (!empty($settings['registration_send_wp_email'])) {
            fone_send_wp_user_notification_with_brand($user_id, null, 'user');
        }

        if (!empty($settings['registration_autologin']) && !is_user_logged_in()) {
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id, false);
        }

        $GLOBALS['fone_registration_done_' . (int) $form_id] = $user_id;

        return ['ok' => true, 'user_id' => $user_id, 'message' => ''];
    }
}

/* ---------------------------------------------------------------
   LOGIN UTENTE
   I form creati dal builder come login devono autenticare davvero
   l'utente WordPress prima di mostrare il messaggio di successo.
--------------------------------------------------------------- */
if (!function_exists('fone_submission_is_login_form')) {
    function fone_submission_is_login_form($form_id, $schema, $settings) {
        if (!empty($settings['enable_registration'])) {
            return false;
        }
        if (!empty($settings['enable_login'])) {
            return true;
        }
        if ($form_id && function_exists('fone_get_form')) {
            $form = fone_get_form((int) $form_id);
            if (!empty($form['is_login'])) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('fone_login_user_from_submission')) {
    function fone_login_user_from_submission($values, $schema, $form_id = 0, $settings = []) {
        $out = ['ok' => false, 'user_id' => 0, 'message' => __('Accesso non completato.', 'form-one')];

        // Funzione di log (se disponibile dallo shortcode login, riusa quella;
        // altrimenti usa il logger debug centralizzato).
        $log = function($msg) {
            if (function_exists('fone_login_log')) {
                fone_login_log('[BUILDER] ' . $msg);
            } else {
                if (function_exists('fone_write_debug_log')) {
                    fone_write_debug_log('login', '[BUILDER] ' . $msg);
                }
            }
        };

        $log('Tentativo login form builder, form_id=' . (int) $form_id);

        if (is_user_logged_in()) {
            $log('Già loggato, ritorno ok.');
            return ['ok' => true, 'user_id' => get_current_user_id(), 'message' => ''];
        }
        if (!is_array($schema) || !is_array($values)) {
            $out['message'] = __('Dati di accesso non validi.', 'form-one');
            return $out;
        }

        // Estraggo email/username e password dai campi del form
        $login = '';
        $pass  = '';
        foreach ($schema as $field) {
            $fid  = $field['id'] ?? '';
            $type = $field['type'] ?? '';
            $slug = $field['slug'] ?? '';
            $wp_f = $field['wp_field'] ?? '';
            if (!$fid || in_array($type, ['html', 'html_admin', 'submit', 'paypal_button', 'divider'], true)) continue;
            $val = isset($values[$fid]) ? $values[$fid] : '';
            if (is_array($val)) $val = implode(', ', $val);
            $val = (string) $val;
            $is_login_field = ($wp_f === 'user_login' || $wp_f === 'user_email' || $slug === 'username' || $slug === 'login_email' || $slug === 'email' || $type === 'email');
            if ($login === '' && $is_login_field) { $login = trim($val); continue; }
            if ($pass === '' && $type === 'password' && $slug !== 'password_confirm') { $pass = $val; continue; }
        }

        $login = trim($login);
        $pass  = (string) $pass;
        $log('Estratti dal form. login="' . substr($login, 0, 40) . '" pass_len=' . strlen($pass));

        if ($login === '' || $pass === '') {
            $out['message'] = __('Inserisci email/username e password.', 'form-one');
            $log('STOP: campi vuoti.');
            return $out;
        }
        if (function_exists('fone_check_context_rate_limit')) {
            if (!fone_check_context_rate_limit('login', 8, 10 * MINUTE_IN_SECONDS, 10 * MINUTE_IN_SECONDS, strtolower($login))) {
                $out['message'] = __('Troppi tentativi. Attendi qualche minuto e riprova.', 'form-one');
                $log('STOP: rate limit.');
                return $out;
            }
        }

        // Trova utente per email, login, slug
        $user = null;
        if (is_email($login)) {
            $user = get_user_by('email', sanitize_email($login));
            $log('Cercato per email → ' . ($user ? 'ID ' . $user->ID : 'NON trovato'));
        }
        if (!$user) {
            $user = get_user_by('login', sanitize_user($login, true));
            $log('Cercato per login → ' . ($user ? 'ID ' . $user->ID : 'NON trovato'));
        }
        if (!$user) {
            $user = get_user_by('slug', sanitize_title($login));
            if ($user) $log('Trovato per slug → ID ' . $user->ID);
        }
        if (!$user) {
            $log('STOP: nessun utente trovato.');
            $out['message'] = __('Email/username o password non corretti.', 'form-one');
            return $out;
        }

        // Verifica password manualmente (stesso approccio di WooCommerce)
        $pass_ok = wp_check_password($pass, $user->user_pass, $user->ID);
        $log('wp_check_password → ' . ($pass_ok ? 'OK' : 'FALLITA'));
        if (!$pass_ok) {
            $out['message'] = __('Email/username o password non corretti.', 'form-one');
            return $out;
        }

        // Login: setto cookie auth direttamente
        wp_clear_auth_cookie();
        wp_set_current_user($user->ID, $user->user_login);
        wp_set_auth_cookie($user->ID, !empty($settings['login_remember_default']), is_ssl());
        do_action('wp_login', $user->user_login, $user);

        $log('Cookie auth settato per user_id=' . $user->ID);

        return ['ok' => true, 'user_id' => (int) $user->ID, 'message' => ''];
    }
}

/* ---------------------------------------------------------------
   MAIN HANDLER
--------------------------------------------------------------- */

if (!function_exists('fone_handle_submission')) {
    function fone_handle_submission($schema, $form_id = 0) {
        $result = ['success' => false, 'errors' => [], 'values' => []];

        if (!fone_is_our_submission()) return $result;

        $nonce   = sanitize_text_field(wp_unslash($_POST['fone_form_nonce']));
        $post_fid = isset($_POST['fone_form_id']) ? (int) $_POST['fone_form_id'] : 0;
        // Il nonce include il form_id: ogni form ha il suo nonce, non si pestano i piedi.
        // Difesa aggiuntiva: il form_id inviato deve coincidere con quello renderizzato.
        if ((int) $form_id !== $post_fid) {
            $result['errors']['global'] = fone_t('invalid_token');
            return $result;
        }
        if (!wp_verify_nonce($nonce, 'fone_submit_form_' . $post_fid)) {
            $result['errors']['global'] = fone_t('invalid_token');
            return $result;
        }

        if (!empty($_POST['fone_honey'])) {
            $result['errors']['global'] = fone_t('spam_detected');
            return $result;
        }

        if (!fone_check_rate_limit()) {
            $result['errors']['global'] = fone_t('rate_limit_error');
            return $result;
        }

        $values = fone_collect_values($schema);
        $errors = fone_validate_submission($schema, $values);

        $result['values'] = $values;
        $result['errors'] = $errors;

        if (!empty($errors)) return $result;

        $settings = $form_id ? fone_get_settings($form_id) : fone_get_settings();
        $is_login_form = function_exists('fone_submission_is_login_form') ? fone_submission_is_login_form($form_id, $schema, $settings) : !empty($settings['enable_login']);
        $is_registration = function_exists('fone_submission_is_registration_form') ? fone_submission_is_registration_form($form_id, $schema, $settings) : !empty($settings['enable_registration']);

        if ($is_login_form) {
            $login = function_exists('fone_login_user_from_submission') ? fone_login_user_from_submission($values, $schema, $form_id, $settings) : ['ok' => false, 'message' => __('Accesso non disponibile.', 'form-one')];
            if (empty($login['ok'])) {
                $result['errors']['global'] = !empty($login['message']) ? $login['message'] : __('Accesso non completato.', 'form-one');
                return $result;
            }
            $result['logged_user_id'] = (int) ($login['user_id'] ?? 0);
        } elseif ($is_registration) {
            $reg = function_exists('fone_create_user_from_submission') ? fone_create_user_from_submission($values, $schema, $form_id, $settings) : ['ok' => false, 'message' => __('Registrazione non disponibile.', 'form-one')];
            if (empty($reg['ok'])) {
                $result['errors']['global'] = !empty($reg['message']) ? $reg['message'] : __('Registrazione non completata.', 'form-one');
                return $result;
            }
            $result['created_user_id'] = (int) ($reg['user_id'] ?? 0);
        }

        fone_store_entry($schema, $values, $form_id);
        if (function_exists('fone_track_insight_event')) {
            fone_track_insight_event($form_id, 'completion', 0, '', isset($_SERVER['HTTP_REFERER']) ? esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'])) : '');
        }
        $email_sent = fone_send_email($schema, $values, $form_id);
        if (!$email_sent && !empty($settings["require_email_success"])) {
            $result["errors"]["global"] = __("Il form e stato salvato, ma la notifica email non e partita. Controlla Email notifiche o SMTP del sito.", "form-one");
            return $result;
        }
        fone_post_process_avatars($schema, $values);

        /**
         * Hook per integrazioni custom.
         * @param array $values   Valori raccolti
         * @param array $schema   Schema del form
         * @param int   $form_id  ID del form
         */
        do_action('fone_after_submission', $values, $schema, $form_id);

        $result['success'] = true;
        return $result;
    }
}

/* ---------------------------------------------------------------
   REGISTRAZIONE UTENTE WORDPRESS
   Agganciata all'hook fone_after_submission.
   Si attiva solo se enable_registration = 1 nelle impostazioni.
   
   AUTO-RILEVAMENTO CAMPI:
   Non richiede mappatura manuale wp_field. Rileva automaticamente
   email, password, nome, cognome, username, telefono ecc. dal tipo
   e dallo slug del campo.
--------------------------------------------------------------- */

add_action('fone_after_submission', function ($values, $schema, $form_id = 0) {
    // ==================================================================
    // DIAGNOSTICA REGISTRAZIONE — log completo per troubleshooting
    // I messaggi vanno sia in error_log sia nel transient 'fone_reg_debug'
    // visibile dall'admin per diagnosticare problemi.
    // ==================================================================
    $debug = [];
    $global_settings = function_exists('fone_get_global_settings') ? fone_get_global_settings() : [];
    $debug_enabled = !empty($global_settings['debug_enabled']);
    $log = function($msg) use (&$debug, $debug_enabled) {
        $debug[] = '[' . date('H:i:s') . '] ' . $msg;
        if ($debug_enabled) {
            error_log('[Form One REG] ' . preg_replace('/([a-z0-9._%+\-])[^\s@]*@/i', '$1***@', (string) $msg));
        }
    };
    $finish_debug = function() use (&$debug, $debug_enabled) {
        // Salva ultimo log diagnostico in transient (24h) solo se debug attivo.
        if (!$debug_enabled) return;
        set_transient('fone_reg_debug', [
            'time'    => current_time('mysql'),
            'entries' => $debug,
        ], DAY_IN_SECONDS);
    };

    $log('Hook fone_after_submission attivato. form_id=' . (int) $form_id
        . ' schema_count=' . (is_array($schema) ? count($schema) : 'NON-ARRAY')
        . ' values_count=' . (is_array($values) ? count($values) : 'NON-ARRAY'));

    if (!empty($GLOBALS['fone_registration_done_' . (int) $form_id])) {
        $log('SKIP: utente già creato nel flusso principale. user_id=' . (int) $GLOBALS['fone_registration_done_' . (int) $form_id]);
        $finish_debug();
        return;
    }

    // Usa le impostazioni del form specifico, non globali
    $settings = $form_id ? fone_get_settings($form_id) : fone_get_settings();
    if (empty($settings['enable_registration'])) {
        $log('STOP: enable_registration=0 nelle impostazioni del form. Vai in Builder → Impostazioni → spunta "Usa come form di registrazione" e SALVA.');
        $finish_debug();
        return;
    }
    if (!is_array($schema) || !is_array($values)) {
        $log('STOP: schema o values non validi.');
        $finish_debug();
        return;
    }
    $log('OK: registrazione abilitata. Procedo con auto-detect campi…');

    /* -------- AUTO-DETECT campi per tipo/slug -------- */
    $user_email   = '';
    $user_login   = '';
    $user_pass    = '';
    $first_name   = '';
    $last_name    = '';
    $display_name = '';
    $user_url     = '';
    $description  = '';
    $custom_meta  = [];
    $avatar_att   = 0;

    // Slug → WP field mapping automatico
    $slug_map = [
        'email'          => 'user_email',
        'login_email'    => 'user_email',
        'username'       => 'user_login',
        'password'       => 'user_pass',
        'first_name'     => 'first_name',
        'last_name'      => 'last_name',
        'full_name'      => 'display_name',
        'display_name'   => 'display_name',
        'profile_name'   => 'display_name',
        'website'        => 'user_url',
        'website_url'    => 'user_url',
        'user_url'       => 'user_url',
        'bio'            => 'description',
        'description'    => 'description',
    ];

    foreach ($schema as $field) {
        $fid  = $field['id'] ?? '';
        $type = $field['type'] ?? '';
        $slug = $field['slug'] ?? '';
        $wp_f = $field['wp_field'] ?? ''; // mappatura manuale ha priorità

        if (!$fid || in_array($type, ['html', 'html_admin', 'submit', 'paypal_button'], true)) {
            continue;
        }

        $val = isset($values[$fid]) ? $values[$fid] : '';
        if (is_array($val)) $val = implode(', ', $val);
        $val = (string) $val;

        // Avatar
        if ($type === 'avatar') {
            $att = (int) ($values[$fid] ?? 0);
            if ($att > 0) $avatar_att = $att;
            continue;
        }

        // File generico in registrazione: salva attachment_id come int
        if ($type === 'file') {
            $att_id = (int) ($values[$fid] ?? 0);
            if ($att_id > 0) {
                $meta_key = sanitize_key($fid);
                if (!function_exists('fone_is_protected_user_meta_key') || !fone_is_protected_user_meta_key($meta_key)) {
                    $custom_meta[$meta_key] = $att_id;
                }
            }
            continue;
        }

        // Determina il campo WP: prima mappatura manuale, poi slug automatico, poi tipo
        $target = '';
        if ($wp_f && $wp_f !== 'custom_meta') {
            $target = $wp_f;
        } elseif (isset($slug_map[$slug])) {
            $target = $slug_map[$slug];
        } elseif ($type === 'email' && $user_email === '') {
            $target = 'user_email';
        } elseif ($type === 'password' && $user_pass === '') {
            // Salta password_confirm (ha slug password_confirm)
            if ($slug !== 'password_confirm') {
                $target = 'user_pass';
            } else {
                continue;
            }
        }

        switch ($target) {
            case 'user_email':   $user_email   = $val; break;
            case 'user_login':   $user_login   = $val; break;
            case 'user_pass':    $user_pass    = $val; break;
            case 'first_name':   $first_name   = $val; break;
            case 'last_name':    $last_name    = $val; break;
            case 'display_name': $display_name = $val; break;
            case 'user_url':     $user_url     = $val; break;
            case 'description':  $description  = $val; break;
            case 'custom_meta':
                $meta_key = sanitize_key($fid);
                if (!function_exists('fone_is_protected_user_meta_key') || !fone_is_protected_user_meta_key($meta_key)) {
                    $custom_meta[$meta_key] = $val;
                }
                break;
            default:
                // Nessuna mappatura trovata → salva come user meta se la chiave non è sensibile
                $meta_key = sanitize_key($fid);
                if (!function_exists('fone_is_protected_user_meta_key') || !fone_is_protected_user_meta_key($meta_key)) {
                    $custom_meta[$meta_key] = $val;
                }
                break;
        }
    }

    // Email obbligatoria
    $user_email = sanitize_email($user_email);
    if (!is_email($user_email)) {
        $log('STOP: nessun campo Email valido trovato nel form. ' .
             'Aggiungi un campo Email (type=email) al form. Email rilevata: "' . $user_email . '"');
        $finish_debug();
        return;
    }
    $log('OK: Email rilevata = ' . $user_email);

    // Controlla se email già registrata
    if (email_exists($user_email)) {
        $log('STOP: email già in uso nel database → ' . $user_email .
             ' (l\'utente esiste già, non lo ricreo).');
        $finish_debug();
        return;
    }
    $log('OK: email libera, procedo a creare utente.');

    // Username: usa mappato, poi parte locale email
    $user_login = sanitize_user($user_login, true);
    if (empty($user_login)) {
        $user_login = sanitize_user(strstr($user_email, '@', true), true);
    }
    $base_login = $user_login;
    $counter = 1;
    while (username_exists($user_login)) {
        $user_login = $base_login . $counter;
        $counter++;
    }

    // Password: usa campo password, oppure genera automaticamente
    $user_pass = $user_pass !== '' ? $user_pass : wp_generate_password(12, true, false);

    // Ruolo sicuro per registrazione pubblica: niente ruoli editoriali/admin
    $role = !empty($settings['registration_role']) ? sanitize_key($settings['registration_role']) : 'subscriber';
    $role = function_exists('fone_get_safe_registration_role') ? fone_get_safe_registration_role($role) : ($role === 'administrator' ? 'subscriber' : $role);

    // Display name: usa campo mappato, poi nome+cognome, poi username
    if ($display_name === '') {
        if ($first_name !== '' || $last_name !== '') {
            $display_name = trim($first_name . ' ' . $last_name);
        } else {
            $display_name = $user_login;
        }
    }

    // Crea utente
    $user_data = [
        'user_login'    => $user_login,
        'user_email'    => $user_email,
        'user_pass'     => $user_pass,
        'role'          => $role,
        'display_name'  => $display_name,
    ];
    if ($first_name   !== '') $user_data['first_name']  = sanitize_text_field($first_name);
    if ($last_name    !== '') $user_data['last_name']   = sanitize_text_field($last_name);
    if ($user_url     !== '') $user_data['user_url']    = esc_url_raw($user_url);
    if ($description  !== '') $user_data['description'] = sanitize_textarea_field($description);

    $log('Chiamo wp_insert_user con login=' . $user_login . ' role=' . $role);
    $user_id = wp_insert_user($user_data);

    if (is_wp_error($user_id)) {
        $log('STOP: wp_insert_user FALLITO → ' . $user_id->get_error_message());
        $finish_debug();
        return;
    }
    $log('✅ Utente creato con ID #' . (int) $user_id . ' login=' . $user_login . ' role=' . $role);

    // Salva tutti i meta custom
    foreach ($custom_meta as $key => $val) {
        if (is_int($val)) {
            update_user_meta($user_id, $key, $val);
        } else {
            update_user_meta($user_id, $key, sanitize_text_field($val));
        }
    }

    // Avatar
    if ($avatar_att > 0 && function_exists('fone_assign_avatar_to_user')) {
        fone_assign_avatar_to_user($user_id, $avatar_att);
    }

    // Email di benvenuto WordPress
    if (!empty($settings['registration_send_wp_email'])) {
        fone_send_wp_user_notification_with_brand($user_id, null, 'user');
    }

    // Login automatico
    if (!empty($settings['registration_autologin']) && !is_user_logged_in()) {
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id, false);
    }

    $log('Tutto completato. user_id=' . (int) $user_id);
    $finish_debug();

}, 10, 3);

/* ===============================================================
   PRE-RENDER LOGIN HANDLER per form builder (init priorità 1)
   ---------------------------------------------------------------
   Intercetta i submit dei form di login costruiti col builder
   PRIMA che parta l'output HTML. Senza questo, wp_set_auth_cookie
   non riesce a settare i cookie (header HTTP già inviati).
=============================================================== */

add_action('init', 'fone_pre_render_login_handler', 1);

if (!function_exists('fone_pre_render_login_handler')) {
    function fone_pre_render_login_handler() {
        if (is_admin() && !defined('DOING_AJAX')) return;
        if (!fone_is_our_submission()) return;

        $post_fid = isset($_POST['fone_form_id']) ? (int) $_POST['fone_form_id'] : 0;
        if (!$post_fid) return;

        // Log SEMPRE quando arriva un submit form builder
        $log_early = function($msg) {
            if (function_exists('fone_login_log')) {
                fone_login_log('[BUILDER PRE-RENDER] ' . $msg);
            } else {
                if (function_exists('fone_write_debug_log')) {
                    fone_write_debug_log('login', '[BUILDER PRE-RENDER] ' . $msg);
                }
            }
        };
        $log_early('Submit ricevuto da form_id=' . $post_fid);

        // Carico form per sapere se è un login form
        $form = function_exists('fone_get_form') ? fone_get_form($post_fid) : null;
        if (!$form) {
            $log_early('STOP: form non trovato in DB.');
            return;
        }

        $settings = $form['settings'] ?? [];
        $schema   = $form['schema']   ?? [];

        $is_login = function_exists('fone_submission_is_login_form')
            ? fone_submission_is_login_form($post_fid, $schema, $settings)
            : !empty($settings['enable_login']);

        $log_early('is_login=' . ($is_login ? 'sì' : 'no') .
            ' (settings.enable_login=' . (!empty($settings['enable_login']) ? '1' : '0') .
            ', form.is_login=' . (!empty($form['is_login']) ? '1' : '0') .
            ', settings.enable_registration=' . (!empty($settings['enable_registration']) ? '1' : '0') . ')');

        if (!$is_login) return;

        $log = $log_early;

        $log('===== SUBMIT LOGIN BUILDER form_id=' . $post_fid . ' =====');

        // Verifica nonce
        $nonce = sanitize_text_field(wp_unslash($_POST['fone_form_nonce'] ?? ''));
        if (!wp_verify_nonce($nonce, 'fone_submit_form_' . $post_fid)) {
            $log('Nonce NON valido. Lascio gestire al render.');
            return; // lascio gestire al render normale
        }
        $log('Nonce valido.');

        // Honeypot
        if (!empty($_POST['fone_honey'])) {
            $log('Honeypot triggered. Esco silenziosamente.');
            return;
        }

        // Raccogli + valida
        $values = function_exists('fone_collect_values') ? fone_collect_values($schema) : [];
        $errors = function_exists('fone_validate_submission') ? fone_validate_submission($schema, $values) : [];
        if (!empty($errors)) {
            $log('Errori validazione (' . count($errors) . '). Lascio gestire al render.');
            return;
        }

        // Login
        $res = fone_login_user_from_submission($values, $schema, $post_fid, $settings);
        if (empty($res['ok'])) {
            $log('Login FALLITO: ' . ($res['message'] ?? '?') . '. Lascio gestire al render per mostrare errore.');
            return;
        }

        // Login OK → cookie già settato.
        // Dalla linea 1.0.0 il redirect al profilo è opzionale: di default si torna alla pagina del form
        // con il messaggio di successo, così il comportamento resta coerente con gli altri form.
        $done_qkey = 'fone_done_' . (int) $post_fid;

        if (!empty($settings['auto_redirect_profile'])) {
            $profile_url_raw = !empty($settings['profile_url'])
                ? $settings['profile_url']
                : (function_exists('fone_default_profile_url') ? fone_default_profile_url() : home_url('/account-form-one/'));
            $redirect_to = function_exists('fone_sanitize_local_url')
                ? fone_sanitize_local_url($profile_url_raw, home_url('/'))
                : esc_url_raw($profile_url_raw);

            if (!empty($settings['registration_redirect'])) {
                $alt = function_exists('fone_sanitize_local_url')
                    ? fone_sanitize_local_url($settings['registration_redirect'], '')
                    : esc_url_raw($settings['registration_redirect']);
                if ($alt) $redirect_to = $alt;
            }
        } else {
            // Helper robusto: prova permalink + referer + REQUEST_URI prima
            // di cadere su home. Evita redirect alla home dopo login da pagine
            // cached o widget dove get_permalink() ritorna falsy.
            $redirect_to = function_exists('fone_current_url')
                ? fone_current_url()
                : (wp_get_referer() ?: (function_exists('get_permalink') ? get_permalink() : home_url('/')));
            $redirect_to = function_exists('fone_sanitize_local_url')
                ? fone_sanitize_local_url($redirect_to, home_url('/'))
                : esc_url_raw($redirect_to);
        }

        $redirect_to = add_query_arg([$done_qkey => '1'], $redirect_to);

        $log('Redirect → ' . $redirect_to);
        $log('===== FINE LOGIN BUILDER OK =====');

        wp_safe_redirect($redirect_to);
        exit;
    }
}
