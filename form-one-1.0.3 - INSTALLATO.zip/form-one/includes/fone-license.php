<?php
/**
 * Form One — Sistema di licenze / Codice di attivazione PRO
 *
 * COSA FA
 * -------
 * - Aggiunge una pagina admin "Licenza" dove l'utente inserisce il codice seriale.
 * - Mostra un avviso persistente in admin finché il codice non è inserito e valido.
 * - Valida il codice contattando il server remoto (API REST: JSON POST).
 * - Salva in opzione 'fone_license' lo stato attuale (code, status, dominio, email, expires, last_check).
 * - Espone fone_is_premium() per permettere ad altri moduli di abilitare funzioni PRO.
 *
 * CONFIGURAZIONE SERVER
 * ---------------------
 * L'URL del server di licenze è definito nella costante FONE_LICENSE_API_URL.
 * Puoi sovrascriverla nel wp-config.php prima che il plugin venga caricato:
 *     define('FONE_LICENSE_API_URL', 'https://tuosito.it/wp-json/fone/v1/verify');
 *
 * Il server deve rispondere in JSON con almeno questi campi:
 *     { "valid": true/false, "status": "active|expired|invalid", "expires": "YYYY-MM-DD"|null, "message": "..." }
 *
 * SICUREZZA
 * ---------
 * - Il codice viene inviato via HTTPS insieme al dominio e all'admin email per binding.
 * - Il risultato è cachato localmente: viene ricontrollato 1 volta ogni 24h (background).
 * - Se l'utente disattiva il codice dal tuo gestionale, entro 24h il plugin torna FREE.
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   COSTANTI
--------------------------------------------------------------- */

if (!defined('FONE_LICENSE_API_URL')) {
    // ↓↓↓ CAMBIA QUESTO URL col tuo endpoint di verifica reale ↓↓↓
    define('FONE_LICENSE_API_URL', ''); // versione gratuita: endpoint PRO opzionale, non configurato
}

if (!defined('FONE_LICENSE_RECHECK_SECONDS')) {
    // Ogni quanto ricontrollare una licenza già validata (default: 24h)
    define('FONE_LICENSE_RECHECK_SECONDS', 24 * HOUR_IN_SECONDS);
}

if (!defined('FONE_LOCAL_TEST_LICENSE_CODE')) {
    // Seriale locale di prova richiesto da Gigi. Non esistono altri seriali demo hardcoded nello zip.
    define('FONE_LOCAL_TEST_LICENSE_CODE', '1234-5678-9101112-13141516');
}

/* ---------------------------------------------------------------
   STATO LICENZA
--------------------------------------------------------------- */

if (!function_exists('fone_get_license')) {
    /**
     * Ritorna lo stato corrente della licenza, sempre come array.
     */
    function fone_get_license() {
        $default = [
            'code'       => '',
            'status'     => 'inactive',   // inactive | active | expired | invalid | error
            'email'      => '',
            'domain'     => '',
            'expires'    => '',
            'last_check' => 0,
            'message'    => '',
        ];
        $saved = get_option('fone_license', []);
        if (!is_array($saved)) $saved = [];
        return wp_parse_args($saved, $default);
    }
}

if (!function_exists('fone_save_license')) {
    function fone_save_license(array $data) {
        $current = fone_get_license();
        $merged  = array_merge($current, $data);
        update_option('fone_license', $merged, false);
        return $merged;
    }
}

if (!function_exists('fone_is_premium')) {
    /**
     * Funzione pubblica: TRUE se la licenza è attiva.
     * Altri moduli del plugin usano questa per abilitare funzioni PRO.
     *
     * Esempio d'uso in altri file:
     *     if (fone_is_premium()) { // abilita feature premium }
     */
    function fone_is_premium() {
        $lic = fone_get_license();

        // Re-check in background se sono passate più di 24h
        if ($lic['status'] === 'active' && (time() - (int)$lic['last_check']) > FONE_LICENSE_RECHECK_SECONDS) {
            if (!empty($lic['code'])) {
                // Esegue il check senza bloccare: se fallisce (network down) mantiene lo stato attivo
                fone_license_verify_remote($lic['code'], $lic['email'], true);
                $lic = fone_get_license();
            }
        }

        return $lic['status'] === 'active';
    }
}

/* ---------------------------------------------------------------
   NORMALIZZAZIONE CODICI
--------------------------------------------------------------- */

if (!function_exists('fone_normalize_license_code')) {
    function fone_normalize_license_code($code) {
        $code = strtoupper(trim((string) $code));
        $code = preg_replace('/\s+/', '', $code);
        return $code;
    }
}

/* ---------------------------------------------------------------
   VERIFICA REMOTA
--------------------------------------------------------------- */

if (!function_exists('fone_license_verify_remote')) {
    /**
     * Contatta il server di licenze e aggiorna lo stato locale.
     * Ritorna l'array licenza aggiornato.
     *
     * @param string $code     Codice seriale da validare
     * @param string $email    Email dell'acquirente (usata per binding)
     * @param bool   $silent   Se true, in caso di errore rete mantiene lo stato precedente
     */
    function fone_license_verify_remote($code, $email = '', $silent = false) {
        $code   = trim((string) $code);
        $email  = sanitize_email($email);
        $domain = wp_parse_url(home_url(), PHP_URL_HOST);

        if ($code === '') {
            return fone_save_license([
                'code'       => '',
                'status'     => 'inactive',
                'message'    => __('Nessun codice inserito.', 'form-one'),
                'last_check' => time(),
            ]);
        }

        // ---------------------------------------------------------------
        // Seriale locale di test: unico codice demo hardcoded nello zip.
        // ---------------------------------------------------------------
        $normalized_code = function_exists('fone_normalize_license_code') ? fone_normalize_license_code($code) : strtoupper(trim((string) $code));
        $local_test_code = function_exists('fone_normalize_license_code') ? fone_normalize_license_code(FONE_LOCAL_TEST_LICENSE_CODE) : strtoupper(FONE_LOCAL_TEST_LICENSE_CODE);
        if ($normalized_code !== '' && hash_equals($local_test_code, $normalized_code)) {
            return fone_save_license([
                'code'       => FONE_LOCAL_TEST_LICENSE_CODE,
                'email'      => $email,
                'domain'     => $domain,
                'status'     => 'active',
                'expires'    => '',
                'message'    => __('Licenza locale di test attiva.', 'form-one'),
                'last_check' => time(),
            ]);
        }
        // ---------------------------------------------------------------

        if (!defined('FONE_LICENSE_API_URL') || FONE_LICENSE_API_URL === '') {
            return fone_save_license([
                'code'       => $code,
                'email'      => $email,
                'domain'     => $domain,
                'status'     => 'invalid',
                'message'    => __('Codice non valido per questa versione. Usa un seriale valido o configura un server licenze.', 'form-one'),
                'last_check' => time(),
            ]);
        }

        $response = wp_remote_post(FONE_LICENSE_API_URL, [
            'timeout' => 15,
            'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
            'body'    => wp_json_encode([
                'code'    => $code,
                'email'   => $email,
                'domain'  => $domain,
                'version' => defined('FONE_VERSION') ? FONE_VERSION : '',
            ]),
        ]);

        // Errore di rete
        if (is_wp_error($response)) {
            if ($silent) {
                // Non cambio lo stato — aggiorno solo last_check per evitare martellamenti
                return fone_save_license(['last_check' => time()]);
            }
            return fone_save_license([
                'code'       => $code,
                'email'      => $email,
                'domain'     => $domain,
                'status'     => 'error',
                'message'    => sprintf(__('Impossibile contattare il server licenze: %s', 'form-one'), $response->get_error_message()),
                'last_check' => time(),
            ]);
        }

        $code_http = (int) wp_remote_retrieve_response_code($response);
        $body      = wp_remote_retrieve_body($response);
        $data      = json_decode($body, true);

        if ($code_http !== 200 || !is_array($data)) {
            if ($silent) {
                return fone_save_license(['last_check' => time()]);
            }
            return fone_save_license([
                'code'       => $code,
                'email'      => $email,
                'domain'     => $domain,
                'status'     => 'error',
                'message'    => __('Risposta non valida dal server licenze.', 'form-one'),
                'last_check' => time(),
            ]);
        }

        $valid   = !empty($data['valid']);
        $status  = isset($data['status'])  ? sanitize_key($data['status'])  : ($valid ? 'active' : 'invalid');
        $expires = isset($data['expires']) ? sanitize_text_field($data['expires']) : '';
        $message = isset($data['message']) ? sanitize_text_field($data['message']) : '';

        return fone_save_license([
            'code'       => $code,
            'email'      => $email,
            'domain'     => $domain,
            'status'     => $valid ? 'active' : $status,
            'expires'    => $expires,
            'message'    => $message,
            'last_check' => time(),
        ]);
    }
}

/* ---------------------------------------------------------------
   PAGINA ADMIN "LICENZA"
--------------------------------------------------------------- */

add_action('admin_menu', function () {
    add_submenu_page(
        'fone-builder',
        __('Licenza', 'form-one'),
        __('Licenza', 'form-one'),
        'manage_options',
        'fone-license',
        'fone_license_page'
    );
}, 20);

if (!function_exists('fone_license_page')) {
    function fone_license_page() {
        if (!current_user_can('manage_options')) return;

        // Gestione form
        if (!empty($_POST['fone_license_submit']) && check_admin_referer('fone_license_save')) {
            $code  = isset($_POST['fone_license_code'])  ? sanitize_text_field(wp_unslash($_POST['fone_license_code']))  : '';
            $email = isset($_POST['fone_license_email']) ? sanitize_email(wp_unslash($_POST['fone_license_email']))      : '';
            fone_license_verify_remote($code, $email, false);
            echo '<div class="notice notice-info is-dismissible"><p>' . esc_html__('Verifica completata.', 'form-one') . '</p></div>';
        }

        // Gestione disattivazione
        if (!empty($_POST['fone_license_deactivate']) && check_admin_referer('fone_license_save')) {
            fone_save_license([
                'code'       => '',
                'status'     => 'inactive',
                'expires'    => '',
                'message'    => __('Licenza disattivata localmente.', 'form-one'),
                'last_check' => time(),
            ]);
            echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('Licenza disattivata.', 'form-one') . '</p></div>';
        }

        // Test email (diagnostica invio)
        if (!empty($_POST['fone_test_email']) && check_admin_referer('fone_license_save')) {
            $test_to = isset($_POST['fone_test_email_to']) ? sanitize_email(wp_unslash($_POST['fone_test_email_to'])) : '';
            if (!is_email($test_to)) $test_to = get_option('admin_email');

            $from_email = function_exists('fone_get_from_address') ? fone_get_from_address() : get_option('admin_email');
            $from_name  = function_exists('fone_get_from_name') ? fone_get_from_name() : 'Form One';

            $last_err = '';
            $catch = function ($we) use (&$last_err) {
                if (is_wp_error($we)) $last_err = $we->get_error_message();
            };
            add_action('wp_mail_failed', $catch);

            $test_subject = function_exists('fone_normalize_email_subject') ? fone_normalize_email_subject('Email di test', '[Form One] Email di test') : '[Form One] Email di test';
            $test_headers = [
                'Content-Type: text/html; charset=UTF-8',
                'From: ' . $from_name . ' <' . $from_email . '>',
            ];
            $test_body = "<p>Questa è un'email di test inviata dal plugin <strong>Form One</strong>.</p><p>Se la vedi, l'invio email funziona correttamente. ✅</p>";
            $ok = function_exists('fone_wp_mail_with_brand')
                ? fone_wp_mail_with_brand($test_to, $test_subject, $test_body, $test_headers)
                : wp_mail($test_to, $test_subject, $test_body, $test_headers);
            remove_action('wp_mail_failed', $catch);

            if ($ok) {
                echo '<div class="notice notice-success is-dismissible"><p>✅ ' . sprintf(esc_html__('Email di test inviata a %s. Controlla la casella (anche spam).', 'form-one'), esc_html($test_to)) . '</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>❌ ' . esc_html__('Invio fallito.', 'form-one');
                if ($last_err) echo ' <code>' . esc_html($last_err) . '</code>';
                echo '<br>' . esc_html__('Causa probabile: il server non ha un SMTP configurato. Installa un plugin come "WP Mail SMTP" o "FluentSMTP" e configura l\'invio.', 'form-one') . '</p></div>';
            }
        }

        $lic = fone_get_license();

        $status_label = [
            'inactive' => __('Non attiva (versione FREE)', 'form-one'),
            'active'   => __('✅ Attiva — versione PRO', 'form-one'),
            'expired'  => __('⚠️ Scaduta', 'form-one'),
            'invalid'  => __('❌ Codice non valido', 'form-one'),
            'error'    => __('⚠️ Errore di verifica', 'form-one'),
        ];
        $current_status = isset($status_label[$lic['status']]) ? $status_label[$lic['status']] : $lic['status'];
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Form One — Licenza', 'form-one'); ?></h1>

            <div style="max-width:720px; background:#fff; padding:24px; border:1px solid #dcdcde; border-radius:8px; margin-top:20px;">
                <h2 style="margin-top:0;"><?php esc_html_e('Stato attuale', 'form-one'); ?></h2>
                <p style="font-size:16px;"><strong><?php echo esc_html($current_status); ?></strong></p>
                <?php if (!empty($lic['expires'])) : ?>
                    <p><?php printf(esc_html__('Scadenza: %s', 'form-one'), esc_html($lic['expires'])); ?></p>
                <?php endif; ?>
                <?php if (!empty($lic['message'])) : ?>
                    <p style="color:#666;"><em><?php echo esc_html($lic['message']); ?></em></p>
                <?php endif; ?>
                <?php if (!empty($lic['last_check'])) : ?>
                    <p style="color:#999; font-size:12px;">
                        <?php printf(
                            esc_html__('Ultimo controllo: %s', 'form-one'),
                            esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), (int) $lic['last_check']))
                        ); ?>
                    </p>
                <?php endif; ?>
            </div>

            <form method="post" style="max-width:720px; background:#fff; padding:24px; border:1px solid #dcdcde; border-radius:8px; margin-top:20px;">
                <?php wp_nonce_field('fone_license_save'); ?>

                <h2 style="margin-top:0;"><?php esc_html_e('Inserisci il tuo codice di attivazione', 'form-one'); ?></h2>
                <p><?php esc_html_e('Hai ricevuto un codice seriale dopo l\'acquisto. Inseriscilo qui insieme all\'email usata per l\'acquisto.', 'form-one'); ?></p>

                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="fone_license_code"><?php esc_html_e('Codice seriale', 'form-one'); ?></label></th>
                        <td>
                            <input type="text" id="fone_license_code" name="fone_license_code"
                                   value="<?php echo esc_attr($lic['code']); ?>"
                                   class="regular-text code"
                                   placeholder="XXXX-XXXX-XXXX-XXXX"
                                   style="font-family:monospace; letter-spacing:1px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="fone_license_email"><?php esc_html_e('Email acquisto', 'form-one'); ?></label></th>
                        <td>
                            <input type="email" id="fone_license_email" name="fone_license_email"
                                   value="<?php echo esc_attr($lic['email'] ? $lic['email'] : wp_get_current_user()->user_email); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                </table>

                <p>
                    <button type="submit" name="fone_license_submit" class="button button-primary">
                        <?php esc_html_e('Attiva / Verifica licenza', 'form-one'); ?>
                    </button>
                    <?php if ($lic['status'] === 'active') : ?>
                        <button type="submit" name="fone_license_deactivate" class="button" style="margin-left:10px;"
                                onclick="return confirm('<?php echo esc_js(__('Sei sicuro di voler disattivare la licenza su questo sito?', 'form-one')); ?>');">
                            <?php esc_html_e('Disattiva qui', 'form-one'); ?>
                        </button>
                    <?php endif; ?>
                </p>

                <p style="color:#666; font-size:13px; margin-top:20px; border-top:1px solid #eee; padding-top:12px;">
                    <?php esc_html_e('La versione FREE del plugin è completamente funzionante. Con la licenza PRO sblocchi le funzioni avanzate.', 'form-one'); ?>
                </p>
            </form>

            <!-- DIAGNOSTICA EMAIL -->
            <form method="post" style="max-width:720px; background:#fff; padding:24px; border:1px solid #dcdcde; border-radius:8px; margin-top:20px;">
                <?php wp_nonce_field('fone_license_save'); ?>
                <h2 style="margin-top:0;">📧 <?php esc_html_e('Diagnostica invio email', 'form-one'); ?></h2>
                <p><?php esc_html_e('Usa questo test per verificare se il tuo server riesce davvero a inviare email. Se qui fallisce, devi configurare un plugin SMTP (WP Mail SMTP, FluentSMTP, ecc.) — non dipende da Form One.', 'form-one'); ?></p>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="fone_test_email_to"><?php esc_html_e('Invia test a:', 'form-one'); ?></label></th>
                        <td>
                            <input type="email" id="fone_test_email_to" name="fone_test_email_to"
                                   value="<?php echo esc_attr(get_option('admin_email')); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                </table>
                <p>
                    <button type="submit" name="fone_test_email" value="1" class="button">
                        <?php esc_html_e('Invia email di test', 'form-one'); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }
}

/* ---------------------------------------------------------------
   AVVISO IN ADMIN SE NON ATTIVATO
--------------------------------------------------------------- */

add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) return;
    if (!apply_filters('fone_show_license_admin_notice', false)) return;

    // Non mostrare se siamo già nella pagina licenza
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && isset($screen->id) && strpos($screen->id, 'fone-license') !== false) return;

    $lic = fone_get_license();
    if ($lic['status'] === 'active') return;

    // Permetti all'utente di nascondere l'avviso per 7gg
    $snoozed = (int) get_user_meta(get_current_user_id(), 'fone_license_notice_snoozed', true);
    if ($snoozed && $snoozed > time()) return;

    $license_url = admin_url('admin.php?page=fone-license');
    $snooze_url  = wp_nonce_url(add_query_arg(['fone_snooze_license' => 1]), 'fone_snooze_license');
    ?>
    <div class="notice notice-warning" style="border-left-color:#6C63FF;">
        <p style="font-size:14px;">
            <strong>🔐 <?php esc_html_e('Form One — Attivazione richiesta', 'form-one'); ?></strong><br>
            <?php esc_html_e('Stai usando la versione FREE. Inserisci il tuo codice di attivazione per sbloccare le funzioni PRO.', 'form-one'); ?>
        </p>
        <p>
            <a href="<?php echo esc_url($license_url); ?>" class="button button-primary">
                <?php esc_html_e('Inserisci codice', 'form-one'); ?>
            </a>
            <a href="<?php echo esc_url($snooze_url); ?>" class="button" style="margin-left:8px;">
                <?php esc_html_e('Ricordamelo tra 7 giorni', 'form-one'); ?>
            </a>
        </p>
    </div>
    <?php
});

// Gestione snooze dell'avviso
add_action('admin_init', function () {
    if (!empty($_GET['fone_snooze_license']) && current_user_can('manage_options')) {
        check_admin_referer('fone_snooze_license');
        update_user_meta(get_current_user_id(), 'fone_license_notice_snoozed', time() + (7 * DAY_IN_SECONDS));
        wp_safe_redirect(remove_query_arg(['fone_snooze_license', '_wpnonce']));
        exit;
    }
});
