<?php
/**
 * Form One — Elementor Widget Core
 *
 * Widget Elementor leggero e stabile.
 * Il plugin principale inserisce solo form già creati nel builder Form One.
 * Le funzioni avanzate di costruzione/studio da Elementor saranno spostate
 * nell'add-on separato: Form One Elementor Studio.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('fone_elementor_is_editor_context')) {
    function fone_elementor_is_editor_context() {
        if (class_exists('\Elementor\Plugin')) {
            $plugin = \Elementor\Plugin::$instance;
            if (isset($plugin->editor) && method_exists($plugin->editor, 'is_edit_mode') && $plugin->editor->is_edit_mode()) {
                return true;
            }
            if (isset($plugin->preview) && method_exists($plugin->preview, 'is_preview_mode') && $plugin->preview->is_preview_mode()) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('fone_elementor_form_options')) {
    function fone_elementor_form_options() {
        $options = ['' => __('— Seleziona un form —', 'form-one')];

        if (!function_exists('fone_get_all_forms')) {
            return $options;
        }

        foreach ((array) fone_get_all_forms() as $form) {
            if (empty($form['id'])) {
                continue;
            }

            $label = !empty($form['form_name']) ? (string) $form['form_name'] : sprintf(__('Form #%d', 'form-one'), (int) $form['id']);

            if (!empty($form['is_registration'])) {
                $label .= ' — ' . __('Registrazione', 'form-one');
            }
            if (!empty($form['is_login'])) {
                $label .= ' — ' . __('Login', 'form-one');
            }

            $options[(int) $form['id']] = $label;
        }

        return $options;
    }
}

add_action('elementor/elements/categories_registered', function ($elements_manager) {
    if (!method_exists($elements_manager, 'add_category')) {
        return;
    }

    $elements_manager->add_category('form-one', [
        'title' => __('Form One', 'form-one'),
        'icon'  => 'fa fa-plug',
    ]);
});

add_action('elementor/widgets/register', function ($widgets_manager) {
    if (!class_exists('\Elementor\Widget_Base')) {
        return;
    }

    if (!class_exists('FONE_Elementor_Core_Widget', false)) {
        class FONE_Elementor_Core_Widget extends \Elementor\Widget_Base {
            public function get_name() {
                return 'form_one';
            }

            public function get_title() {
                return __('Form One', 'form-one');
            }

            public function get_icon() {
                return 'eicon-form-horizontal';
            }

            public function get_categories() {
                return ['form-one', 'general'];
            }

            public function get_keywords() {
                return ['form', 'contact', 'form one', 'multi step', 'multistep', 'login', 'registration'];
            }

            protected function register_controls() {
                $this->start_controls_section('content_section', [
                    'label' => __('Form', 'form-one'),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                ]);

                $this->add_control('form_id', [
                    'label'       => __('Form One', 'form-one'),
                    'type'        => \Elementor\Controls_Manager::SELECT,
                    'default'     => '',
                    'options'     => fone_elementor_form_options(),
                    'label_block' => true,
                ]);

                $this->add_control('studio_notice', [
                    'type'            => \Elementor\Controls_Manager::RAW_HTML,
                    'raw'             => __('Questo widget core inserisce un form già creato nel builder Form One. Le funzioni avanzate arriveranno nell\'add-on Form One Elementor Studio.', 'form-one'),
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                ]);

                $this->end_controls_section();

                $this->start_controls_section('layout_section', [
                    'label' => __('Layout', 'form-one'),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                ]);

                $this->add_responsive_control('form_align', [
                    'label'   => __('Allineamento', 'form-one'),
                    'type'    => \Elementor\Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __('Sinistra', 'form-one'),
                            'icon'  => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => __('Centro', 'form-one'),
                            'icon'  => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => __('Destra', 'form-one'),
                            'icon'  => 'eicon-text-align-right',
                        ],
                    ],
                    'default'   => 'left',
                    'selectors' => [
                        '{{WRAPPER}} .fone-elementor-core' => 'text-align: {{VALUE}};',
                    ],
                ]);

                $this->add_responsive_control('max_width', [
                    'label'      => __('Larghezza massima', 'form-one'),
                    'type'       => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => ['px', '%'],
                    'range'      => [
                        'px' => ['min' => 240, 'max' => 1400],
                        '%'  => ['min' => 10, 'max' => 100],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .fone-elementor-core .fone-wrap' => 'max-width: {{SIZE}}{{UNIT}};',
                    ],
                ]);

                $this->end_controls_section();

                $this->start_controls_section('style_section', [
                    'label' => __('Stile base', 'form-one'),
                    'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                ]);

                $this->add_control('container_background', [
                    'label'     => __('Sfondo contenitore', 'form-one'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .fone-elementor-core .fone-wrap' => 'background: {{VALUE}};',
                    ],
                ]);

                $this->add_responsive_control('container_padding', [
                    'label'      => __('Padding contenitore', 'form-one'),
                    'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => ['px'],
                    'selectors'  => [
                        '{{WRAPPER}} .fone-elementor-core .fone-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]);

                $this->add_responsive_control('container_radius', [
                    'label'      => __('Raggio contenitore', 'form-one'),
                    'type'       => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => ['px'],
                    'range'      => ['px' => ['min' => 0, 'max' => 60]],
                    'selectors'  => [
                        '{{WRAPPER}} .fone-elementor-core .fone-wrap' => 'border-radius: {{SIZE}}{{UNIT}};',
                    ],
                ]);

                $this->end_controls_section();
            }

            protected function render() {
                $settings = $this->get_settings_for_display();
                $form_id = !empty($settings['form_id']) ? absint($settings['form_id']) : 0;

                echo '<div class="fone-elementor-core">';

                if (!$form_id) {
                    if (fone_elementor_is_editor_context()) {
                        echo '<div class="fone-elementor-empty">' . esc_html__('Seleziona un form Form One.', 'form-one') . '</div>';
                    }
                    echo '</div>';
                    return;
                }

                $preview = fone_elementor_is_editor_context() ? ' preview="1"' : '';
                echo do_shortcode('[form_one id="' . (int) $form_id . '"' . $preview . ']');
                echo '</div>';
            }
        }
    }

    $widget = new FONE_Elementor_Core_Widget();

    if (method_exists($widgets_manager, 'register')) {
        $widgets_manager->register($widget);
    } elseif (method_exists($widgets_manager, 'register_widget_type')) {
        $widgets_manager->register_widget_type($widget);
    }
});

/**
 * Carica asset frontend anche dentro Elementor editor/preview.
 */
add_action('elementor/frontend/after_enqueue_scripts', function () {
    if (function_exists('fone_enqueue_front_assets')) {
        fone_enqueue_front_assets(true);
        return;
    }

    if (wp_script_is('fone-front', 'registered')) {
        wp_enqueue_script('fone-front');
    }
    if (wp_style_is('fone-front', 'registered')) {
        wp_enqueue_style('fone-front');
    }
});
