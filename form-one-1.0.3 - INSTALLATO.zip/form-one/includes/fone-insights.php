<?php
/**
 * Form One — Conversion Insights
 *
 * Tracciamento anonimo e leggero degli eventi di conversione:
 * view, start, step, completion.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('fone_table_insights_events')) {
    function fone_table_insights_events() {
        global $wpdb;
        return $wpdb->prefix . 'fone_insights_events';
    }
}

if (!function_exists('fone_track_insight_event')) {
    function fone_track_insight_event($form_id, $event_type, $step = 0, $session_id = '', $page_url = '') {
        global $wpdb;

        $form_id = absint($form_id);
        if (!$form_id) return false;

        $allowed = ['view', 'start', 'step', 'completion'];
        $event_type = sanitize_key($event_type);
        if (!in_array($event_type, $allowed, true)) return false;

        $step = max(0, absint($step));
        $session_id = sanitize_text_field((string) $session_id);
        $session_hash = $session_id !== '' ? hash('sha256', $session_id) : '';
        $page_url = $page_url ? esc_url_raw($page_url) : '';

        return $wpdb->insert(fone_table_insights_events(), [
            'form_id'      => $form_id,
            'event_type'   => $event_type,
            'step_number'  => $step,
            'session_hash' => $session_hash,
            'page_url'     => mb_substr($page_url, 0, 500),
            'created_at'   => current_time('mysql'),
        ], ['%d', '%s', '%d', '%s', '%s', '%s']);
    }
}

if (!function_exists('fone_ajax_track_insight_event')) {
    function fone_ajax_track_insight_event() {
        check_ajax_referer('fone_front_ajax', 'nonce');

        $form_id = isset($_POST['form_id']) ? absint($_POST['form_id']) : 0;
        $event   = isset($_POST['event']) ? sanitize_key(wp_unslash($_POST['event'])) : '';
        $step    = isset($_POST['step']) ? absint($_POST['step']) : 0;
        $session = isset($_POST['session']) ? sanitize_text_field(wp_unslash($_POST['session'])) : '';
        $url     = isset($_POST['url']) ? esc_url_raw(wp_unslash($_POST['url'])) : '';

        $ok = fone_track_insight_event($form_id, $event, $step, $session, $url);
        wp_send_json_success(['tracked' => (bool) $ok]);
    }
}
add_action('wp_ajax_fone_track_event', 'fone_ajax_track_insight_event');
add_action('wp_ajax_nopriv_fone_track_event', 'fone_ajax_track_insight_event');

if (!function_exists('fone_insights_purge_old_events')) {
    function fone_insights_purge_old_events($days = 90) {
        global $wpdb;
        $days = max(7, min(365, absint($days)));
        $before = gmdate('Y-m-d H:i:s', time() - ($days * DAY_IN_SECONDS));
        return $wpdb->query($wpdb->prepare(
            "DELETE FROM " . fone_table_insights_events() . " WHERE created_at < %s",
            $before
        ));
    }
}

if (!function_exists('fone_insights_clear_events')) {
    function fone_insights_clear_events($form_id = 0) {
        global $wpdb;
        $form_id = absint($form_id);
        if ($form_id) {
            return $wpdb->query($wpdb->prepare(
                "DELETE FROM " . fone_table_insights_events() . " WHERE form_id = %d",
                $form_id
            ));
        }
        return $wpdb->query("TRUNCATE TABLE " . fone_table_insights_events());
    }
}

if (!function_exists('fone_insights_maybe_cleanup')) {
    function fone_insights_maybe_cleanup() {
        if (get_transient('fone_insights_cleanup_done')) return;
        fone_insights_purge_old_events((int) apply_filters('fone_insights_retention_days', 90));
        set_transient('fone_insights_cleanup_done', 1, DAY_IN_SECONDS);
    }
}
add_action('init', 'fone_insights_maybe_cleanup');

if (!function_exists('fone_insights_counts')) {
    function fone_insights_counts($form_id = 0, $days = 30) {
        global $wpdb;
        $form_id = absint($form_id);
        $days = max(1, min(365, absint($days)));
        $since = gmdate('Y-m-d H:i:s', time() - ($days * DAY_IN_SECONDS));

        $where = "created_at >= %s";
        $args = [$since];
        if ($form_id) {
            $where .= " AND form_id = %d";
            $args[] = $form_id;
        }

        $sql = $wpdb->prepare(
            "SELECT form_id, event_type, step_number, COUNT(*) AS c
             FROM " . fone_table_insights_events() . "
             WHERE {$where}
             GROUP BY form_id, event_type, step_number
             ORDER BY form_id ASC, event_type ASC, step_number ASC",
            $args
        );

        $rows = $wpdb->get_results($sql, ARRAY_A);
        $out = [];
        foreach ((array) $rows as $row) {
            $fid = (int) $row['form_id'];
            if (!isset($out[$fid])) {
                $out[$fid] = [
                    'view' => 0,
                    'start' => 0,
                    'completion' => 0,
                    'steps' => [],
                ];
            }
            $event = $row['event_type'];
            $count = (int) $row['c'];
            if ($event === 'step') {
                $out[$fid]['steps'][(int) $row['step_number']] = $count;
            } elseif (isset($out[$fid][$event])) {
                $out[$fid][$event] += $count;
            }
        }
        return $out;
    }
}

if (!function_exists('fone_insights_page')) {
    function fone_insights_page() {
        if (!current_user_can('manage_options')) return;

        $forms = function_exists('fone_get_all_forms') ? fone_get_all_forms() : [];
        $selected = isset($_GET['form_id']) ? absint($_GET['form_id']) : 0;
        $days = isset($_GET['days']) ? absint($_GET['days']) : 30;
        $days = max(7, min(90, $days));

        if (!empty($_POST['fone_insights_clear']) && check_admin_referer('fone_insights_clear')) {
            $clear_form_id = isset($_POST['clear_form_id']) ? absint($_POST['clear_form_id']) : 0;
            fone_insights_clear_events($clear_form_id);
            echo '<div class="notice notice-success"><p>' . esc_html__('Dati Insights cancellati correttamente.', 'form-one') . '</p></div>';
        }

        fone_insights_purge_old_events((int) apply_filters('fone_insights_retention_days', 90));
        $counts = fone_insights_counts($selected, $days);
        ?>
        <div class="wrap fone-admin-wrap">
            <div class="fone-admin-header">
                <div class="fone-admin-header-left">
                    <h1 class="fone-admin-title">Form One Insights</h1>
                    <p class="fone-admin-subtitle"><?php esc_html_e('Misura dove gli utenti iniziano, proseguono e completano i tuoi form.', 'form-one'); ?></p>
                </div>
            </div>

            <form method="get" style="margin:18px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                <input type="hidden" name="page" value="fone-insights">
                <select name="form_id">
                    <option value="0"><?php esc_html_e('Tutti i form', 'form-one'); ?></option>
                    <?php foreach ($forms as $f) : ?>
                        <option value="<?php echo (int) $f['id']; ?>" <?php selected($selected, (int) $f['id']); ?>>
                            <?php echo esc_html($f['form_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select name="days">
                    <option value="7" <?php selected($days, 7); ?>>7 giorni</option>
                    <option value="30" <?php selected($days, 30); ?>>30 giorni</option>
                    <option value="90" <?php selected($days, 90); ?>>90 giorni</option>
                </select>
                <button class="button button-primary"><?php esc_html_e('Filtra', 'form-one'); ?></button>
            </form>

            <div class="notice notice-info" style="margin:12px 0 18px;padding:10px 14px;">
                <p style="margin:0;">
                    <?php esc_html_e('Gli Insights registrano solo eventi tecnici anonimi: vista, inizio, step raggiunto e completamento. Non vengono salvati IP, user agent o dati personali del form. Gli eventi oltre 90 giorni vengono ripuliti automaticamente.', 'form-one'); ?>
                </p>
            </div>

            <form method="post" style="margin:0 0 18px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;" onsubmit="return confirm('<?php echo esc_js(__('Vuoi davvero cancellare i dati Insights selezionati?', 'form-one')); ?>');">
                <?php wp_nonce_field('fone_insights_clear'); ?>
                <input type="hidden" name="clear_form_id" value="<?php echo (int) $selected; ?>">
                <button type="submit" name="fone_insights_clear" value="1" class="button button-secondary">
                    <?php echo $selected ? esc_html__('Svuota Insights del form selezionato', 'form-one') : esc_html__('Svuota tutti gli Insights', 'form-one'); ?>
                </button>
            </form>

            <div class="fone-insights-grid">
                <?php
                $forms_by_id = [];
                foreach ($forms as $f) $forms_by_id[(int) $f['id']] = $f;
                if (empty($counts)) :
                ?>
                    <div class="fone-empty-state">
                        <p><?php esc_html_e('Nessun dato ancora. Appena un form viene visto o completato, gli Insights inizieranno a popolarsi.', 'form-one'); ?></p>
                    </div>
                <?php else :
                    foreach ($counts as $fid => $c) :
                        $views = (int) ($c['view'] ?? 0);
                        $starts = (int) ($c['start'] ?? 0);
                        $completions = (int) ($c['completion'] ?? 0);
                        $start_rate = $views ? round(($starts / $views) * 100, 1) : 0;
                        $completion_rate = $views ? round(($completions / $views) * 100, 1) : 0;
                        $submit_rate = $starts ? round(($completions / $starts) * 100, 1) : 0;
                        $name = !empty($forms_by_id[$fid]) ? $forms_by_id[$fid]['form_name'] : sprintf(__('Form #%d', 'form-one'), $fid);
                ?>
                    <div class="fone-insight-card">
                        <h2><?php echo esc_html($name); ?></h2>
                        <div class="fone-insight-kpis">
                            <div><strong><?php echo (int) $views; ?></strong><span>Views</span></div>
                            <div><strong><?php echo (int) $starts; ?></strong><span>Starts</span></div>
                            <div><strong><?php echo (int) $completions; ?></strong><span>Completions</span></div>
                            <div><strong><?php echo esc_html($completion_rate); ?>%</strong><span>View → Submit</span></div>
                            <div><strong><?php echo esc_html($submit_rate); ?>%</strong><span>Start → Submit</span></div>
                        </div>
                        <?php if (!empty($c['steps'])) : ?>
                            <h3><?php esc_html_e('Step raggiunti', 'form-one'); ?></h3>
                            <div class="fone-insight-steps">
                                <?php foreach ($c['steps'] as $step => $count) :
                                    $pct = $starts ? min(100, round(($count / max(1, $starts)) * 100)) : 0;
                                ?>
                                    <div class="fone-insight-step">
                                        <span>Step <?php echo (int) $step; ?></span>
                                        <div class="fone-insight-bar"><i style="width:<?php echo (int) $pct; ?>%"></i></div>
                                        <em><?php echo (int) $count; ?></em>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
        <?php
    }
}
