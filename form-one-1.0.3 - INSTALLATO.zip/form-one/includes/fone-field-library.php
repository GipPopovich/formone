<?php
/**
 * Form One — Field Library
 *
 * Libreria campi preconfigurati, divisi in categorie.
 * Ogni voce produce un nuovo campo nel canvas con:
 *  - type     : tipo input HTML nativo (o speciale: avatar, textarea, select, radio, checkbox, html, submit)
 *  - autocomp : valore per attributo autocomplete (semantico, riconosciuto dal browser)
 *  - label_it/en, placeholder_it/en, icon, required di default
 *
 * Le categorie rispecchiano esattamente quelle richieste da Gigi.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('fone_free_field_slugs')) {
    function fone_free_field_slugs() {
        return apply_filters('fone_free_field_slugs', [
            'text', 'email', 'tel', 'textarea', 'select', 'radio', 'checkbox',
            'consent', 'hidden', 'divider', 'file_upload', 'submit'
        ]);
    }
}

if (!function_exists('fone_mark_library_pro_fields')) {
    function fone_mark_library_pro_fields(array $library) {
        $free_slugs = array_map('strval', (array) fone_free_field_slugs());
        foreach ($library as &$category) {
            if (empty($category['fields']) || !is_array($category['fields'])) {
                continue;
            }
            foreach ($category['fields'] as &$field) {
                $slug = isset($field['slug']) ? (string) $field['slug'] : '';
                $field['is_pro'] = in_array($slug, $free_slugs, true) ? 0 : 1;
            }
            unset($field);
        }
        unset($category);
        return $library;
    }
}

if (!function_exists('fone_get_field_library')) {
    function fone_get_field_library() {
        $library = [

            /* =========================================================
               STRUTTURA — blocchi tecnici del form
            ========================================================= */
            [
                'category' => 'cat_structure',
                'fields'   => [
                    ['slug'=>'text',     'type'=>'text',     'icon'=>'✏️',  'icon_class'=>'fa-solid fa-font', 'label_it'=>'Campo testo libero',   'label_en'=>'Free text',           'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0],
                    ['slug'=>'email',    'type'=>'email',    'icon'=>'✉️', 'icon_class'=>'fa-solid fa-envelope', 'label_it'=>'Email',                 'label_en'=>'Email',               'placeholder_it'=>'nome@email.it',    'placeholder_en'=>'name@email.com',   'autocomp'=>'email','required'=>1],
                    ['slug'=>'tel',      'type'=>'tel',      'icon'=>'📞', 'icon_class'=>'fa-solid fa-phone', 'label_it'=>'Telefono',              'label_en'=>'Phone',               'placeholder_it'=>'+39 …',            'placeholder_en'=>'+1 …',             'autocomp'=>'tel',  'required'=>0],
                    ['slug'=>'textarea', 'type'=>'textarea', 'icon'=>'📝', 'icon_class'=>'fa-solid fa-align-left', 'label_it'=>'Area di testo',         'label_en'=>'Text area',           'placeholder_it'=>'Scrivi qui…',      'placeholder_en'=>'Write here…',      'autocomp'=>'off',  'required'=>0, 'max_chars'=>'500'],
                    ['slug'=>'select',   'type'=>'select',   'icon'=>'▼',  'icon_class'=>'fa-solid fa-list', 'label_it'=>'Menu a tendina',        'label_en'=>'Dropdown',            'placeholder_it'=>'— Seleziona —',    'placeholder_en'=>'— Select —',       'autocomp'=>'off',  'required'=>0, 'options'=>"Opzione 1\nOpzione 2\nOpzione 3"],
                    ['slug'=>'radio',    'type'=>'radio',    'icon'=>'◉',  'icon_class'=>'fa-solid fa-circle-dot', 'label_it'=>'Scelta singola',        'label_en'=>'Single choice',       'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'options'=>"Opzione 1\nOpzione 2"],
                    ['slug'=>'checkbox', 'type'=>'checkbox', 'icon'=>'☑',  'icon_class'=>'fa-solid fa-square-check', 'label_it'=>'Scelta multipla',       'label_en'=>'Multiple choice',     'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'options'=>"Opzione 1\nOpzione 2"],
                    ['slug'=>'consent',  'type'=>'consent',  'icon'=>'✅', 'icon_class'=>'fa-solid fa-shield-halved', 'label_it'=>'Consenso / Privacy',     'label_en'=>'Consent / Privacy',  'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>1, 'default_value'=>'Acconsento al trattamento dei dati.'],
                    ['slug'=>'hidden',   'type'=>'hidden',   'icon'=>'👁️‍🗨️','icon_class'=>'fa-solid fa-eye-slash', 'label_it'=>'Campo nascosto',       'label_en'=>'Hidden field',       'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'default_value'=>''],
                    ['slug'=>'divider',  'type'=>'divider',  'icon'=>'➖', 'icon_class'=>'fa-solid fa-minus', 'label_it'=>'Titolo sezione / Divider','label_en'=>'Section title / Divider','placeholder_it'=>'',              'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'default_value'=>'Nuova sezione'],
                    ['slug'=>'file_upload','type'=>'file',    'icon'=>'📎', 'icon_class'=>'fa-solid fa-paperclip', 'label_it'=>'Caricamento file',       'label_en'=>'File upload',       'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'accept_types'=>'application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.oasis.opendocument.text,application/rtf,text/plain,text/csv,image/jpeg,image/png,image/webp,image/gif,image/avif,image/bmp,image/tiff,image/heic,video/mp4,video/webm,video/quicktime,audio/mpeg,audio/wav,audio/ogg,audio/mp4,application/zip', 'max_size_mb'=>'20'],
                    ['slug'=>'range_slider','type'=>'range',  'icon'=>'🎚️', 'icon_class'=>'fa-solid fa-sliders', 'label_it'=>'Slider numerico',       'label_en'=>'Number slider',     'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'opt_min'=>'0', 'opt_max'=>'100', 'opt_step'=>'1', 'default_value'=>'50'],
                    ['slug'=>'rating',   'type'=>'rating',   'icon'=>'⭐', 'icon_class'=>'fa-solid fa-star', 'label_it'=>'Valutazione a stelle',   'label_en'=>'Star rating',       'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'opt_min'=>'1', 'opt_max'=>'5', 'opt_step'=>'1'],
                    ['slug'=>'nps',      'type'=>'nps',      'icon'=>'📊', 'icon_class'=>'fa-solid fa-chart-simple', 'label_it'=>'NPS 0–10',              'label_en'=>'NPS 0–10',         'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'opt_min'=>'0', 'opt_max'=>'10', 'opt_step'=>'1'],
                    ['slug'=>'time',     'type'=>'time',     'icon'=>'🕰️', 'icon_class'=>'fa-solid fa-clock', 'label_it'=>'Ora',                   'label_en'=>'Time',             'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0],
                    ['slug'=>'color',    'type'=>'color',    'icon'=>'🎨', 'icon_class'=>'fa-solid fa-palette', 'label_it'=>'Colore',                'label_en'=>'Color',            'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'default_value'=>'#374151'],
                    ['slug'=>'html',     'type'=>'html',     'icon'=>'</>','icon_class'=>'fa-solid fa-code', 'label_it'=>'Blocco HTML',           'label_en'=>'HTML block',          'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'default_content'=>'<p>Testo HTML personalizzato</p>'],
                    ['slug'=>'html_admin','type'=>'html_admin','icon'=>'</>','icon_class'=>'fa-solid fa-code', 'label_it'=>'HTML Admin',            'label_en'=>'Admin HTML',          'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0, 'default_content'=>'<div class="fone-html-admin-box"><strong>Titolo HTML</strong><p>Testo HTML personalizzato.</p></div>', 'default_css'=>'.fone-html-admin-box { padding: 16px; border-radius: 12px; background: #f8fafc; }'],
                    ['slug'=>'submit',   'type'=>'submit',   'icon'=>'→',  'icon_class'=>'fa-solid fa-paper-plane', 'label_it'=>'Pulsante Invio',        'label_en'=>'Submit button',       'placeholder_it'=>'',                 'placeholder_en'=>'',                 'autocomp'=>'off',  'required'=>0],
                ],
            ],

            /* =========================================================
               IDENTITÀ DI BASE
            ========================================================= */
            [
                'category' => 'cat_identity',
                'fields'   => [
                    ['slug'=>'first_name',       'type'=>'text', 'icon'=>'👤', 'icon_class'=>'fa-solid fa-user', 'label_it'=>'Nome',              'label_en'=>'First name',       'placeholder_it'=>'Mario',        'placeholder_en'=>'John',        'autocomp'=>'given-name',       'required'=>1],
                    ['slug'=>'last_name',        'type'=>'text', 'icon'=>'👥', 'icon_class'=>'fa-solid fa-user-group', 'label_it'=>'Cognome',           'label_en'=>'Last name',        'placeholder_it'=>'Rossi',        'placeholder_en'=>'Doe',         'autocomp'=>'family-name',      'required'=>1],
                    ['slug'=>'full_name',        'type'=>'text', 'icon'=>'🪪', 'icon_class'=>'fa-solid fa-id-card', 'label_it'=>'Nome completo',     'label_en'=>'Full name',        'placeholder_it'=>'Mario Rossi',  'placeholder_en'=>'John Doe',    'autocomp'=>'name',             'required'=>1],
                    ['slug'=>'username',         'type'=>'text', 'icon'=>'🆔', 'icon_class'=>'fa-solid fa-id-badge', 'label_it'=>'Nome utente',       'label_en'=>'Username',         'placeholder_it'=>'mario_rossi',  'placeholder_en'=>'john_doe',    'autocomp'=>'username',         'required'=>1],
                    ['slug'=>'display_name',     'type'=>'text', 'icon'=>'✨', 'icon_class'=>'fa-solid fa-signature', 'label_it'=>'Nome visualizzato', 'label_en'=>'Display name',     'placeholder_it'=>'Mario',        'placeholder_en'=>'John',        'autocomp'=>'nickname',         'required'=>0],
                    ['slug'=>'profile_name',     'type'=>'text', 'icon'=>'🎭', 'icon_class'=>'fa-solid fa-user-pen', 'label_it'=>'Nome profilo',      'label_en'=>'Profile name',     'placeholder_it'=>'',              'placeholder_en'=>'',             'autocomp'=>'nickname',         'required'=>0],
                    ['slug'=>'business_name',    'type'=>'text', 'icon'=>'🏪', 'icon_class'=>'fa-solid fa-store', 'label_it'=>'Nome attività',     'label_en'=>'Business name',    'placeholder_it'=>'',              'placeholder_en'=>'',             'autocomp'=>'organization',     'required'=>0],
                    ['slug'=>'organization',     'type'=>'text', 'icon'=>'🏢', 'icon_class'=>'fa-solid fa-building', 'label_it'=>'Nome organizzazione','label_en'=>'Organization',    'placeholder_it'=>'',              'placeholder_en'=>'',             'autocomp'=>'organization',     'required'=>0],
                    ['slug'=>'legal_name',       'type'=>'text', 'icon'=>'📜', 'icon_class'=>'fa-solid fa-scroll', 'label_it'=>'Ragione sociale',   'label_en'=>'Legal name',       'placeholder_it'=>'',              'placeholder_en'=>'',             'autocomp'=>'organization',     'required'=>0],
                    ['slug'=>'role',             'type'=>'text', 'icon'=>'🎯', 'icon_class'=>'fa-solid fa-bullseye', 'label_it'=>'Ruolo',             'label_en'=>'Role',             'placeholder_it'=>'',              'placeholder_en'=>'',             'autocomp'=>'organization-title','required'=>0],
                    ['slug'=>'profile_type',     'type'=>'select','icon'=>'🗂️','icon_class'=>'fa-solid fa-id-card', 'label_it'=>'Tipo profilo',      'label_en'=>'Profile type',     'placeholder_it'=>'— Scegli —',   'placeholder_en'=>'— Choose —',  'autocomp'=>'off',              'required'=>0, 'options'=>"Privato\nAttività\nOrganizzazione\nEnte\nFreelance"],
                    ['slug'=>'account_type',     'type'=>'select','icon'=>'🔖','icon_class'=>'fa-solid fa-bookmark', 'label_it'=>'Tipo account',      'label_en'=>'Account type',     'placeholder_it'=>'— Scegli —',   'placeholder_en'=>'— Choose —',  'autocomp'=>'off',              'required'=>0, 'options'=>"Base\nPremium\nPro\nEnterprise"],
                ],
            ],

            /* =========================================================
               ACCESSO E SICUREZZA
            ========================================================= */
            [
                'category' => 'cat_security',
                'fields'   => [
                    ['slug'=>'email',              'type'=>'email',    'icon'=>'✉️',  'icon_class'=>'fa-solid fa-envelope', 'label_it'=>'Email',                'label_en'=>'Email',             'placeholder_it'=>'mario@email.com', 'placeholder_en'=>'john@email.com', 'autocomp'=>'email',               'required'=>1],
                    ['slug'=>'login_email',        'type'=>'email',    'icon'=>'🔐', 'icon_class'=>'fa-solid fa-lock', 'label_it'=>'Email di accesso',     'label_en'=>'Login email',        'placeholder_it'=>'mario@email.com', 'placeholder_en'=>'john@email.com', 'autocomp'=>'email',               'required'=>1],
                    ['slug'=>'password',           'type'=>'password', 'icon'=>'🔑', 'icon_class'=>'fa-solid fa-key', 'label_it'=>'Password',              'label_en'=>'Password',           'placeholder_it'=>'Almeno 8 caratteri','placeholder_en'=>'At least 8 chars','autocomp'=>'new-password',      'required'=>1],
                    ['slug'=>'password_confirm',   'type'=>'password', 'icon'=>'🔁', 'icon_class'=>'fa-solid fa-rotate', 'label_it'=>'Conferma password',     'label_en'=>'Confirm password',   'placeholder_it'=>'Riscrivi la password','placeholder_en'=>'Retype password','autocomp'=>'new-password',     'required'=>1],
                    ['slug'=>'phone',              'type'=>'tel',      'icon'=>'📞', 'icon_class'=>'fa-solid fa-phone', 'label_it'=>'Numero di telefono',   'label_en'=>'Phone number',       'placeholder_it'=>'+39 ...',        'placeholder_en'=>'+1 ...',         'autocomp'=>'tel',                 'required'=>0],
                    ['slug'=>'login_phone',        'type'=>'tel',      'icon'=>'📱', 'icon_class'=>'fa-solid fa-mobile-screen-button', 'label_it'=>'Telefono di accesso',  'label_en'=>'Login phone',        'placeholder_it'=>'+39 ...',        'placeholder_en'=>'+1 ...',         'autocomp'=>'tel',                 'required'=>0],
                    ['slug'=>'verification_code',  'type'=>'text',     'icon'=>'🔢', 'icon_class'=>'fa-solid fa-hashtag', 'label_it'=>'Codice di verifica',   'label_en'=>'Verification code',  'placeholder_it'=>'123456',         'placeholder_en'=>'123456',         'autocomp'=>'one-time-code',       'required'=>0],
                    ['slug'=>'otp',                'type'=>'text',     'icon'=>'🔐', 'icon_class'=>'fa-solid fa-lock', 'label_it'=>'Codice OTP',           'label_en'=>'OTP',                'placeholder_it'=>'123456',         'placeholder_en'=>'123456',         'autocomp'=>'one-time-code',       'required'=>0],
                    ['slug'=>'security_question',  'type'=>'text',     'icon'=>'❓', 'icon_class'=>'fa-solid fa-circle-question', 'label_it'=>'Domanda di sicurezza', 'label_en'=>'Security question',  'placeholder_it'=>'',                'placeholder_en'=>'',               'autocomp'=>'off',                 'required'=>0],
                    ['slug'=>'security_answer',    'type'=>'text',     'icon'=>'💬', 'icon_class'=>'fa-solid fa-comment-dots', 'label_it'=>'Risposta di sicurezza','label_en'=>'Security answer',    'placeholder_it'=>'',                'placeholder_en'=>'',               'autocomp'=>'off',                 'required'=>0],
                ],
            ],

            /* =========================================================
               ANAGRAFICA GENERALE
            ========================================================= */
            [
                'category' => 'cat_demographics',
                'fields'   => [
                    ['slug'=>'birth_date',    'type'=>'date',   'icon'=>'🎂', 'icon_class'=>'fa-solid fa-cake-candles', 'label_it'=>'Data di nascita', 'label_en'=>'Date of birth',  'placeholder_it'=>'',              'placeholder_en'=>'',           'autocomp'=>'bday',              'required'=>0],
                    ['slug'=>'age',           'type'=>'number', 'icon'=>'🎈', 'icon_class'=>'fa-solid fa-hourglass-half', 'label_it'=>'Età',             'label_en'=>'Age',            'placeholder_it'=>'',              'placeholder_en'=>'',           'autocomp'=>'off',               'required'=>0],
                    ['slug'=>'gender',        'type'=>'select', 'icon'=>'⚧️',  'icon_class'=>'fa-solid fa-venus-mars', 'label_it'=>'Genere',          'label_en'=>'Gender',         'placeholder_it'=>'— Scegli —',    'placeholder_en'=>'— Choose —', 'autocomp'=>'sex',               'required'=>0, 'options'=>"Femminile\nMaschile\nNon binario\nPreferisco non dirlo"],
                    ['slug'=>'language',      'type'=>'select', 'icon'=>'🗣️',  'icon_class'=>'fa-solid fa-language', 'label_it'=>'Lingua',          'label_en'=>'Language',       'placeholder_it'=>'— Scegli —',    'placeholder_en'=>'— Choose —', 'autocomp'=>'language',          'required'=>0, 'options'=>"Italiano\nInglese\nSpagnolo\nFrancese\nTedesco"],
                    ['slug'=>'nationality',   'type'=>'text',   'icon'=>'🌍', 'icon_class'=>'fa-solid fa-earth-europe', 'label_it'=>'Nazionalità',     'label_en'=>'Nationality',    'placeholder_it'=>'Italiana',      'placeholder_en'=>'American',   'autocomp'=>'country-name',      'required'=>0],
                    ['slug'=>'country',       'type'=>'text',   'icon'=>'🏳️',  'icon_class'=>'fa-solid fa-flag', 'label_it'=>'Paese',            'label_en'=>'Country',        'placeholder_it'=>'Italia',        'placeholder_en'=>'USA',        'autocomp'=>'country-name',      'required'=>0],
                    ['slug'=>'city',          'type'=>'text',   'icon'=>'🏙️',  'icon_class'=>'fa-solid fa-city', 'label_it'=>'Città',            'label_en'=>'City',           'placeholder_it'=>'Latina',        'placeholder_en'=>'New York',   'autocomp'=>'address-level2',    'required'=>0],
                    ['slug'=>'province',      'type'=>'text',   'icon'=>'🗺️',  'icon_class'=>'fa-solid fa-map-location-dot', 'label_it'=>'Provincia',        'label_en'=>'State / Province','placeholder_it'=>'LT',           'placeholder_en'=>'NY',         'autocomp'=>'address-level1',    'required'=>0],
                    ['slug'=>'postal_code',   'type'=>'text',   'icon'=>'📮', 'icon_class'=>'fa-solid fa-map-pin', 'label_it'=>'CAP',              'label_en'=>'ZIP / Postal code','placeholder_it'=>'04100',        'placeholder_en'=>'10001',      'autocomp'=>'postal-code',       'required'=>0],
                    ['slug'=>'address',       'type'=>'text',   'icon'=>'🏠', 'icon_class'=>'fa-solid fa-house', 'label_it'=>'Indirizzo',        'label_en'=>'Address',        'placeholder_it'=>'Via Roma 12',   'placeholder_en'=>'12 Main St', 'autocomp'=>'street-address',    'required'=>0],
                    ['slug'=>'full_address',  'type'=>'textarea','icon'=>'📍','icon_class'=>'fa-solid fa-location-dot', 'label_it'=>'Indirizzo completo','label_en'=>'Full address',  'placeholder_it'=>'Via, numero, città, CAP','placeholder_en'=>'Street, city, ZIP','autocomp'=>'street-address','required'=>0],
                    ['slug'=>'geo_area',      'type'=>'text',   'icon'=>'🌐', 'icon_class'=>'fa-solid fa-globe', 'label_it'=>'Area geografica',  'label_en'=>'Geographic area','placeholder_it'=>'Centro Italia', 'placeholder_en'=>'West Coast', 'autocomp'=>'off',               'required'=>0],
                    ['slug'=>'timezone',      'type'=>'text',   'icon'=>'🕒', 'icon_class'=>'fa-solid fa-clock', 'label_it'=>'Fuso orario',      'label_en'=>'Timezone',       'placeholder_it'=>'Europe/Rome',   'placeholder_en'=>'America/New_York','autocomp'=>'off',          'required'=>0],
                ],
            ],

            /* =========================================================
               PROFILO PUBBLICO
            ========================================================= */
            [
                'category' => 'cat_public_profile',
                'fields'   => [
                    ['slug'=>'avatar',            'type'=>'avatar',   'icon'=>'📷', 'icon_class'=>'fa-solid fa-camera', 'label_it'=>'Foto profilo autore',   'label_en'=>'Author profile photo', 'placeholder_it'=>'',                 'placeholder_en'=>'',                  'autocomp'=>'photo',            'required'=>0, 'meta_key'=>'wp_user_avatar'],
                    ['slug'=>'profile_image',     'type'=>'avatar',   'icon'=>'🖼️',  'icon_class'=>'fa-solid fa-image', 'label_it'=>'Immagine profilo',      'label_en'=>'Profile image',        'placeholder_it'=>'',                 'placeholder_en'=>'',                  'autocomp'=>'photo',            'required'=>0, 'meta_key'=>'wp_user_avatar'],
                    ['slug'=>'avatar_legacy',     'type'=>'avatar',   'icon'=>'👤', 'icon_class'=>'fa-solid fa-user', 'label_it'=>'Avatar',                 'label_en'=>'Avatar',               'placeholder_it'=>'',                 'placeholder_en'=>'',                  'autocomp'=>'photo',            'required'=>0, 'meta_key'=>'wp_user_avatar'],
                    ['slug'=>'cover',             'type'=>'avatar',   'icon'=>'🎞️',  'icon_class'=>'fa-solid fa-images', 'label_it'=>'Immagine di copertina', 'label_en'=>'Cover image',          'placeholder_it'=>'',                 'placeholder_en'=>'',                  'autocomp'=>'off',              'required'=>0, 'meta_key'=>'fone_cover_image'],
                    ['slug'=>'bio',               'type'=>'textarea', 'icon'=>'📖', 'icon_class'=>'fa-solid fa-book-open', 'label_it'=>'Biografia',              'label_en'=>'Biography',            'placeholder_it'=>'Racconta chi sei…','placeholder_en'=>'Tell us about you…','autocomp'=>'off',              'required'=>0, 'max_chars'=>'800'],
                    ['slug'=>'short_intro',       'type'=>'text',     'icon'=>'✒️', 'icon_class'=>'fa-solid fa-pen-nib', 'label_it'=>'Presentazione breve',   'label_en'=>'Short intro',          'placeholder_it'=>'Una frase su di te','placeholder_en'=>'One line about you','autocomp'=>'off',             'required'=>0],
                    ['slug'=>'description',       'type'=>'textarea', 'icon'=>'📋', 'icon_class'=>'fa-solid fa-clipboard', 'label_it'=>'Descrizione',            'label_en'=>'Description',          'placeholder_it'=>'',                 'placeholder_en'=>'',                  'autocomp'=>'off',              'required'=>0, 'max_chars'=>'500'],
                    ['slug'=>'website',           'type'=>'url',      'icon'=>'🌐', 'icon_class'=>'fa-solid fa-globe', 'label_it'=>'Sito web',               'label_en'=>'Website',              'placeholder_it'=>'https://…',        'placeholder_en'=>'https://…',         'autocomp'=>'url',              'required'=>0],
                    ['slug'=>'personal_link',     'type'=>'url',      'icon'=>'🔗', 'icon_class'=>'fa-solid fa-link', 'label_it'=>'Link personale',         'label_en'=>'Personal link',        'placeholder_it'=>'https://…',        'placeholder_en'=>'https://…',         'autocomp'=>'url',              'required'=>0],
                    ['slug'=>'public_profile',    'type'=>'url',      'icon'=>'👁️',  'icon_class'=>'fa-solid fa-eye', 'label_it'=>'Profilo pubblico',      'label_en'=>'Public profile',       'placeholder_it'=>'https://…',        'placeholder_en'=>'https://…',         'autocomp'=>'url',              'required'=>0],
                    ['slug'=>'custom_url',        'type'=>'text',     'icon'=>'🔤', 'icon_class'=>'fa-solid fa-link', 'label_it'=>'URL personalizzato',     'label_en'=>'Custom URL',           'placeholder_it'=>'mario-rossi',      'placeholder_en'=>'john-doe',          'autocomp'=>'off',              'required'=>0],
                ],
            ],

            /* =========================================================
               CONTATTI
            ========================================================= */
            [
                'category' => 'cat_contacts',
                'fields'   => [
                    ['slug'=>'phone_main',         'type'=>'tel',   'icon'=>'☎️', 'icon_class'=>'fa-solid fa-phone', 'label_it'=>'Telefono',               'label_en'=>'Phone',             'placeholder_it'=>'+39 …',          'placeholder_en'=>'+1 …',        'autocomp'=>'tel',           'required'=>0],
                    ['slug'=>'mobile',             'type'=>'tel',   'icon'=>'📱', 'icon_class'=>'fa-solid fa-mobile-screen-button', 'label_it'=>'Cellulare',              'label_en'=>'Mobile',            'placeholder_it'=>'+39 …',          'placeholder_en'=>'+1 …',        'autocomp'=>'tel',           'required'=>0],
                    ['slug'=>'whatsapp',           'type'=>'whatsapp','icon'=>'💬', 'icon_class'=>'fa-brands fa-whatsapp', 'label_it'=>'WhatsApp',               'label_en'=>'WhatsApp',          'placeholder_it'=>'+39 …',          'placeholder_en'=>'+1 …',        'autocomp'=>'tel',           'required'=>0],
                    ['slug'=>'telegram',           'type'=>'text',  'icon'=>'✈️', 'icon_class'=>'fa-brands fa-telegram', 'label_it'=>'Telegram',                'label_en'=>'Telegram',          'placeholder_it'=>'@username',      'placeholder_en'=>'@username',   'autocomp'=>'off',           'required'=>0],
                    ['slug'=>'email_secondary',    'type'=>'email', 'icon'=>'📧', 'icon_class'=>'fa-solid fa-envelope-open', 'label_it'=>'Email secondaria',       'label_en'=>'Secondary email',   'placeholder_it'=>'altra@email.com','placeholder_en'=>'other@email.com','autocomp'=>'email',      'required'=>0],
                    ['slug'=>'preferred_contact',  'type'=>'select','icon'=>'⭐', 'icon_class'=>'fa-solid fa-address-book', 'label_it'=>'Contatto preferito',     'label_en'=>'Preferred contact', 'placeholder_it'=>'— Scegli —',    'placeholder_en'=>'— Choose —',  'autocomp'=>'off',           'required'=>0, 'options'=>"Email\nTelefono\nWhatsApp\nTelegram"],
                    ['slug'=>'preferred_time',     'type'=>'select','icon'=>'⏰', 'icon_class'=>'fa-solid fa-clock', 'label_it'=>'Orario preferito di contatto','label_en'=>'Preferred contact time','placeholder_it'=>'— Scegli —','placeholder_en'=>'— Choose —','autocomp'=>'off',           'required'=>0, 'options'=>"Mattina (9-13)\nPomeriggio (14-18)\nSera (18-21)"],
                    ['slug'=>'reference_person',   'type'=>'text',  'icon'=>'🤝', 'icon_class'=>'fa-solid fa-user-check', 'label_it'=>'Referente',              'label_en'=>'Contact person',    'placeholder_it'=>'',                'placeholder_en'=>'',             'autocomp'=>'off',           'required'=>0],
                    ['slug'=>'contact_method',     'type'=>'radio', 'icon'=>'📨', 'icon_class'=>'fa-solid fa-comments', 'label_it'=>'Metodo di contatto preferito','label_en'=>'Preferred contact method','placeholder_it'=>'','placeholder_en'=>'',         'autocomp'=>'off',           'required'=>0, 'options'=>"Email\nTelefono\nWhatsApp\nTelegram"],
                ],
            ],

            /* =========================================================
               DATI PROFESSIONALI
            ========================================================= */
            [
                'category' => 'cat_professional',
                'fields'   => [
                    ['slug'=>'profession',       'type'=>'text',  'icon'=>'💼', 'icon_class'=>'fa-solid fa-briefcase', 'label_it'=>'Professione',          'label_en'=>'Profession',         'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'organization-title','required'=>0],
                    ['slug'=>'qualification',    'type'=>'text',  'icon'=>'🎓', 'icon_class'=>'fa-solid fa-graduation-cap', 'label_it'=>'Qualifica',            'label_en'=>'Qualification',      'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'organization-title','required'=>0],
                    ['slug'=>'job_title',        'type'=>'text',  'icon'=>'🏷️',  'icon_class'=>'fa-solid fa-id-badge', 'label_it'=>'Titolo professionale', 'label_en'=>'Job title',          'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'organization-title','required'=>0],
                    ['slug'=>'sector',           'type'=>'text',  'icon'=>'🏭', 'icon_class'=>'fa-solid fa-industry', 'label_it'=>'Settore',              'label_en'=>'Sector',             'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off',           'required'=>0],
                    ['slug'=>'category',         'type'=>'text',  'icon'=>'🗂️',  'icon_class'=>'fa-solid fa-tags', 'label_it'=>'Categoria',            'label_en'=>'Category',           'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off',           'required'=>0],
                    ['slug'=>'specialization',   'type'=>'text',  'icon'=>'🎯', 'icon_class'=>'fa-solid fa-award', 'label_it'=>'Specializzazione',     'label_en'=>'Specialization',     'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off',           'required'=>0],
                    ['slug'=>'skills',           'type'=>'textarea','icon'=>'🧰','icon_class'=>'fa-solid fa-screwdriver-wrench', 'label_it'=>'Competenze',           'label_en'=>'Skills',             'placeholder_it'=>'Elenca le tue competenze','placeholder_en'=>'List your skills','autocomp'=>'off',       'required'=>0],
                    ['slug'=>'experience',       'type'=>'textarea','icon'=>'📚','icon_class'=>'fa-solid fa-chart-line', 'label_it'=>'Esperienza',           'label_en'=>'Experience',         'placeholder_it'=>'Anni e ruoli…','placeholder_en'=>'Years and roles…','autocomp'=>'off',       'required'=>0],
                    ['slug'=>'experience_level', 'type'=>'select','icon'=>'📈', 'icon_class'=>'fa-solid fa-signal', 'label_it'=>'Livello esperienza',   'label_en'=>'Experience level',   'placeholder_it'=>'— Scegli —',   'placeholder_en'=>'— Choose —',   'autocomp'=>'off',           'required'=>0, 'options'=>"Junior\nMid\nSenior\nLead\nExpert"],
                    ['slug'=>'company',          'type'=>'text',  'icon'=>'🏢', 'icon_class'=>'fa-solid fa-building', 'label_it'=>'Azienda',              'label_en'=>'Company',            'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'organization',  'required'=>0],
                    ['slug'=>'department',       'type'=>'text',  'icon'=>'🗄️', 'icon_class'=>'fa-solid fa-sitemap', 'label_it'=>'Reparto',              'label_en'=>'Department',         'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off',           'required'=>0],
                    ['slug'=>'duty',             'type'=>'text',  'icon'=>'📌', 'icon_class'=>'fa-solid fa-list-check', 'label_it'=>'Mansione',             'label_en'=>'Duty',               'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off',           'required'=>0],
                    ['slug'=>'position',         'type'=>'text',  'icon'=>'🪜', 'icon_class'=>'fa-solid fa-user-tie', 'label_it'=>'Posizione',            'label_en'=>'Position',           'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'organization-title','required'=>0],
                    ['slug'=>'activity_area',    'type'=>'text',  'icon'=>'📐', 'icon_class'=>'fa-solid fa-map-location-dot', 'label_it'=>'Area di attività',     'label_en'=>'Activity area',      'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off',           'required'=>0],
                ],
            ],

            /* =========================================================
               DATI ATTIVITÀ / BUSINESS
            ========================================================= */
            [
                'category' => 'cat_business',
                'fields'   => [
                    ['slug'=>'biz_name',          'type'=>'text',     'icon'=>'🏪', 'icon_class'=>'fa-solid fa-store', 'label_it'=>'Nome attività',       'label_en'=>'Business name',        'placeholder_it'=>'',                'placeholder_en'=>'',             'autocomp'=>'organization','required'=>0],
                    ['slug'=>'biz_type',          'type'=>'text',     'icon'=>'🏷️',  'icon_class'=>'fa-solid fa-shapes', 'label_it'=>'Tipo attività',       'label_en'=>'Business type',        'placeholder_it'=>'Negozio, servizi…','placeholder_en'=>'Shop, services…','autocomp'=>'off',  'required'=>0],
                    ['slug'=>'biz_sector',        'type'=>'text',     'icon'=>'🏭', 'icon_class'=>'fa-solid fa-industry', 'label_it'=>'Settore attività',    'label_en'=>'Business sector',      'placeholder_it'=>'',                'placeholder_en'=>'',             'autocomp'=>'off',       'required'=>0],
                    ['slug'=>'biz_category',      'type'=>'text',     'icon'=>'🗂️',  'icon_class'=>'fa-solid fa-tags', 'label_it'=>'Categoria attività',  'label_en'=>'Business category',    'placeholder_it'=>'',                'placeholder_en'=>'',             'autocomp'=>'off',       'required'=>0],
                    ['slug'=>'biz_description',   'type'=>'textarea', 'icon'=>'📝', 'icon_class'=>'fa-solid fa-align-left', 'label_it'=>'Descrizione attività','label_en'=>'Business description', 'placeholder_it'=>'Cosa fa la tua attività…','placeholder_en'=>'What your business does…','autocomp'=>'off','required'=>0, 'max_chars'=>'800'],
                    ['slug'=>'vat_number',        'type'=>'text',     'icon'=>'🧾', 'icon_class'=>'fa-solid fa-receipt', 'label_it'=>'Partita IVA',         'label_en'=>'VAT number',           'placeholder_it'=>'IT01234567890',   'placeholder_en'=>'GB123456789',  'autocomp'=>'off',       'required'=>0],
                    ['slug'=>'tax_code',          'type'=>'text',     'icon'=>'🪪', 'icon_class'=>'fa-solid fa-id-card', 'label_it'=>'Codice fiscale',      'label_en'=>'Tax code',             'placeholder_it'=>'RSSMRA80A01H501U','placeholder_en'=>'',             'autocomp'=>'off',       'required'=>0],
                    ['slug'=>'registration_nr',   'type'=>'text',     'icon'=>'#️⃣', 'icon_class'=>'fa-solid fa-hashtag', 'label_it'=>'Numero di registrazione','label_en'=>'Registration number','placeholder_it'=>'',              'placeholder_en'=>'',             'autocomp'=>'off',       'required'=>0],
                    ['slug'=>'legal_address',     'type'=>'text',     'icon'=>'⚖️', 'icon_class'=>'fa-solid fa-scale-balanced', 'label_it'=>'Sede legale',         'label_en'=>'Legal address',        'placeholder_it'=>'',                'placeholder_en'=>'',             'autocomp'=>'street-address','required'=>0],
                    ['slug'=>'operational_address','type'=>'text',    'icon'=>'🏛️', 'icon_class'=>'fa-solid fa-building-columns', 'label_it'=>'Sede operativa',      'label_en'=>'Operational address',  'placeholder_it'=>'',                'placeholder_en'=>'',             'autocomp'=>'street-address','required'=>0],
                    ['slug'=>'biz_size',          'type'=>'select',   'icon'=>'📏', 'icon_class'=>'fa-solid fa-ruler-combined', 'label_it'=>'Dimensione attività', 'label_en'=>'Business size',        'placeholder_it'=>'— Scegli —',     'placeholder_en'=>'— Choose —',   'autocomp'=>'off',       'required'=>0, 'options'=>"Micro (1-9)\nPiccola (10-49)\nMedia (50-249)\nGrande (250+)"],
                    ['slug'=>'founding_year',     'type'=>'number',   'icon'=>'📅', 'icon_class'=>'fa-solid fa-calendar', 'label_it'=>'Anno di fondazione',  'label_en'=>'Founding year',        'placeholder_it'=>'2020',            'placeholder_en'=>'2020',         'autocomp'=>'off',       'required'=>0],
                    ['slug'=>'employees_count',   'type'=>'number',   'icon'=>'👥', 'icon_class'=>'fa-solid fa-users', 'label_it'=>'Numero dipendenti',   'label_en'=>'Employees count',      'placeholder_it'=>'0',               'placeholder_en'=>'0',            'autocomp'=>'off',       'required'=>0],
                    ['slug'=>'brand',             'type'=>'text',     'icon'=>'™️', 'icon_class'=>'fa-solid fa-tag', 'label_it'=>'Brand',                'label_en'=>'Brand',                'placeholder_it'=>'',                'placeholder_en'=>'',             'autocomp'=>'off',       'required'=>0],
                    ['slug'=>'services_offered',  'type'=>'textarea', 'icon'=>'🛎️', 'icon_class'=>'fa-solid fa-bell', 'label_it'=>'Servizi offerti',     'label_en'=>'Services offered',     'placeholder_it'=>'',                'placeholder_en'=>'',             'autocomp'=>'off',       'required'=>0],
                    ['slug'=>'products_offered',  'type'=>'textarea', 'icon'=>'📦', 'icon_class'=>'fa-solid fa-box', 'label_it'=>'Prodotti offerti',    'label_en'=>'Products offered',     'placeholder_it'=>'',                'placeholder_en'=>'',             'autocomp'=>'off',       'required'=>0],
                ],
            ],

            /* =========================================================
               UPLOAD E DOCUMENTI
            ========================================================= */
            [
                'category' => 'cat_uploads',
                'fields'   => [
                    ['slug'=>'document_upload', 'type'=>'file', 'icon'=>'📄', 'icon_class'=>'fa-solid fa-file-lines', 'label_it'=>'Documento',        'label_en'=>'Document',        'placeholder_it'=>'', 'placeholder_en'=>'', 'autocomp'=>'off', 'required'=>0, 'accept_types'=>'application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain', 'max_size_mb'=>'10'],
                    ['slug'=>'image_upload',    'type'=>'file', 'icon'=>'🖼️', 'icon_class'=>'fa-solid fa-file-image', 'label_it'=>'Immagine',         'label_en'=>'Image',           'placeholder_it'=>'', 'placeholder_en'=>'', 'autocomp'=>'off', 'required'=>0, 'accept_types'=>'image/jpeg,image/png,image/webp,image/gif', 'max_size_mb'=>'8'],
                    ['slug'=>'cv_upload',       'type'=>'file', 'icon'=>'📎', 'icon_class'=>'fa-solid fa-file-lines', 'label_it'=>'Curriculum / CV',   'label_en'=>'Resume / CV',     'placeholder_it'=>'', 'placeholder_en'=>'', 'autocomp'=>'off', 'required'=>0, 'accept_types'=>'application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'max_size_mb'=>'10'],
                ],
            ],

            /* =========================================================
               SURVEY, FEEDBACK E CONVERSIONE
            ========================================================= */
            [
                'category' => 'cat_surveys',
                'fields'   => [
                    ['slug'=>'satisfaction_rating', 'type'=>'rating', 'icon'=>'⭐', 'icon_class'=>'fa-solid fa-star', 'label_it'=>'Quanto sei soddisfatto?', 'label_en'=>'How satisfied are you?', 'placeholder_it'=>'', 'placeholder_en'=>'', 'autocomp'=>'off', 'required'=>0, 'opt_min'=>'1', 'opt_max'=>'5', 'opt_step'=>'1'],
                    ['slug'=>'recommend_nps',       'type'=>'nps',    'icon'=>'📊', 'icon_class'=>'fa-solid fa-chart-simple', 'label_it'=>'Quanto ci consiglieresti?', 'label_en'=>'How likely are you to recommend us?', 'placeholder_it'=>'', 'placeholder_en'=>'', 'autocomp'=>'off', 'required'=>0, 'opt_min'=>'0', 'opt_max'=>'10', 'opt_step'=>'1'],
                    ['slug'=>'opinion_scale',       'type'=>'range',  'icon'=>'🎚️', 'icon_class'=>'fa-solid fa-sliders', 'label_it'=>'Scala opinione', 'label_en'=>'Opinion scale', 'placeholder_it'=>'', 'placeholder_en'=>'', 'autocomp'=>'off', 'required'=>0, 'opt_min'=>'1', 'opt_max'=>'10', 'opt_step'=>'1', 'default_value'=>'5'],
                    ['slug'=>'likert_agreement',    'type'=>'radio',  'icon'=>'📋', 'icon_class'=>'fa-solid fa-clipboard-list', 'label_it'=>'Grado di accordo', 'label_en'=>'Agreement scale', 'placeholder_it'=>'', 'placeholder_en'=>'', 'autocomp'=>'off', 'required'=>0, 'options'=>"Per niente d'accordo\nPoco d'accordo\nNeutrale\nD'accordo\nMolto d'accordo"],
                    ['slug'=>'lead_temperature',    'type'=>'select', 'icon'=>'🔥', 'icon_class'=>'fa-solid fa-temperature-high', 'label_it'=>'Temperatura lead', 'label_en'=>'Lead temperature', 'placeholder_it'=>'— Scegli —', 'placeholder_en'=>'— Choose —', 'autocomp'=>'off', 'required'=>0, 'options'=>"Freddo\nTiepido\nCaldo\nPronto a comprare"],
                ],
            ],

            /* =========================================================
               DATI OPERATIVI
            ========================================================= */
            [
                'category' => 'cat_operational',
                'fields'   => [
                    ['slug'=>'main_goal',        'type'=>'text',     'icon'=>'🎯', 'icon_class'=>'fa-solid fa-bullseye', 'label_it'=>'Obiettivo principale',       'label_en'=>'Main goal',             'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off', 'required'=>0],
                    ['slug'=>'main_need',        'type'=>'text',     'icon'=>'🆘', 'icon_class'=>'fa-solid fa-life-ring', 'label_it'=>'Esigenza principale',        'label_en'=>'Main need',             'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off', 'required'=>0],
                    ['slug'=>'main_interest',    'type'=>'text',     'icon'=>'💡', 'icon_class'=>'fa-solid fa-lightbulb', 'label_it'=>'Interesse principale',       'label_en'=>'Main interest',         'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off', 'required'=>0],
                    ['slug'=>'usage_context',    'type'=>'text',     'icon'=>'🌱', 'icon_class'=>'fa-solid fa-seedling', 'label_it'=>'Ambito di utilizzo',         'label_en'=>'Usage context',         'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off', 'required'=>0],
                    ['slug'=>'usage_level',      'type'=>'select',   'icon'=>'📊', 'icon_class'=>'fa-solid fa-chart-simple', 'label_it'=>'Livello di utilizzo',        'label_en'=>'Usage level',           'placeholder_it'=>'— Scegli —',   'placeholder_en'=>'— Choose —',   'autocomp'=>'off', 'required'=>0, 'options'=>"Principiante\nIntermedio\nAvanzato\nEsperto"],
                    ['slug'=>'platform_exp',     'type'=>'select',   'icon'=>'🧭', 'icon_class'=>'fa-solid fa-compass', 'label_it'=>'Esperienza con la piattaforma','label_en'=>'Platform experience', 'placeholder_it'=>'— Scegli —',   'placeholder_en'=>'— Choose —',   'autocomp'=>'off', 'required'=>0, 'options'=>"Mai usata\nPoco\nSpesso\nQuotidiana"],
                    ['slug'=>'usage_mode',       'type'=>'select',   'icon'=>'🔄', 'icon_class'=>'fa-solid fa-rotate', 'label_it'=>'Modalità d\'uso',            'label_en'=>'Usage mode',            'placeholder_it'=>'— Scegli —',   'placeholder_en'=>'— Choose —',   'autocomp'=>'off', 'required'=>0, 'options'=>"Personale\nProfessionale\nAcademico\nMisto"],
                    ['slug'=>'usage_frequency',  'type'=>'select',   'icon'=>'📆', 'icon_class'=>'fa-solid fa-calendar-days', 'label_it'=>'Frequenza di utilizzo prevista','label_en'=>'Planned usage frequency','placeholder_it'=>'— Scegli —','placeholder_en'=>'— Choose —',   'autocomp'=>'off', 'required'=>0, 'options'=>"Raramente\nOgni tanto\nSpesso\nQuotidiana"],
                    ['slug'=>'request_type',     'type'=>'select',   'icon'=>'📩', 'icon_class'=>'fa-solid fa-envelope-open-text', 'label_it'=>'Tipologia di richiesta',     'label_en'=>'Request type',          'placeholder_it'=>'— Scegli —',   'placeholder_en'=>'— Choose —',   'autocomp'=>'off', 'required'=>0, 'options'=>"Informazione\nPreventivo\nSupporto\nPartnership\nAltro"],
                    ['slug'=>'priority',         'type'=>'select',   'icon'=>'🚦', 'icon_class'=>'fa-solid fa-traffic-light', 'label_it'=>'Priorità',                   'label_en'=>'Priority',              'placeholder_it'=>'— Scegli —',   'placeholder_en'=>'— Choose —',   'autocomp'=>'off', 'required'=>0, 'options'=>"Bassa\nNormale\nAlta\nUrgente"],
                    ['slug'=>'availability',     'type'=>'text',     'icon'=>'🗓️', 'icon_class'=>'fa-solid fa-calendar-check', 'label_it'=>'Disponibilità',              'label_en'=>'Availability',          'placeholder_it'=>'Lun-Ven',      'placeholder_en'=>'Mon-Fri',      'autocomp'=>'off', 'required'=>0],
                    ['slug'=>'time_slot',        'type'=>'select',   'icon'=>'🕰️', 'icon_class'=>'fa-solid fa-clock', 'label_it'=>'Fascia oraria',              'label_en'=>'Time slot',             'placeholder_it'=>'— Scegli —',   'placeholder_en'=>'— Choose —',   'autocomp'=>'off', 'required'=>0, 'options'=>"Mattina\nPomeriggio\nSera\nTutto il giorno"],
                    ['slug'=>'intervention_area','type'=>'text',     'icon'=>'🧩', 'icon_class'=>'fa-solid fa-puzzle-piece', 'label_it'=>'Area di intervento',         'label_en'=>'Intervention area',     'placeholder_it'=>'',             'placeholder_en'=>'',             'autocomp'=>'off', 'required'=>0],
                ],
            ],
        ];

        return function_exists('fone_mark_library_pro_fields') ? fone_mark_library_pro_fields($library) : $library;
    }
}

/**
 * Converte una voce della libreria in un field schema completo
 * (con id unico) pronto per essere aggiunto al canvas.
 */
if (!function_exists('fone_library_item_to_field')) {
    function fone_library_item_to_field($item, $lang = 'it') {
        $label = $lang === 'en' ? ($item['label_en'] ?? $item['label_it']) : ($item['label_it'] ?? '');
        $ph    = $lang === 'en' ? ($item['placeholder_en'] ?? '') : ($item['placeholder_it'] ?? '');
        return [
            'id'           => 'fone_' . substr(md5(uniqid('', true)), 0, 10),
            'type'         => $item['type'],
            'slug'         => $item['slug'],
            'label'        => $label,
            'placeholder'  => $ph,
            'help'         => '',
            'required'     => (int) ($item['required'] ?? 0),
            'step'         => 1,
            'width'        => in_array($item['type'], ['textarea','html','html_admin','submit','radio','checkbox','avatar','paypal_button','file','consent','divider','rating','nps'], true) ? 'full' : 'half',
            'options'      => $item['options'] ?? '',
            'max_chars'    => $item['max_chars'] ?? '',
            'autocomp'     => $item['autocomp'] ?? 'off',
            'meta_key'     => $item['meta_key'] ?? '',
            'accept_types' => $item['accept_types'] ?? 'image/jpeg,image/png,image/webp,image/gif,image/avif,image/bmp,image/tiff,image/heic,image/heif',
            'max_size_mb'  => $item['max_size_mb'] ?? '12',
            'default_value'=> $item['default_value'] ?? '',
            'opt_min'      => $item['opt_min'] ?? '',
            'opt_max'      => $item['opt_max'] ?? '',
            'opt_step'     => $item['opt_step'] ?? '',
            'html_content' => $item['default_content'] ?? '',
            'html_css'     => $item['default_css'] ?? '',
        ];
    }
}

/**
 * Schema di default (form demo iniziale).
 */
if (!function_exists('fone_get_default_schema')) {
    function fone_get_default_schema() {
        $library = fone_get_field_library();

        $find = function($slug) use ($library) {
            foreach ($library as $cat) {
                foreach ($cat['fields'] as $f) {
                    if ($f['slug'] === $slug) return $f;
                }
            }
            return null;
        };

        $avatar    = $find('avatar');
        $first     = $find('first_name');
        $last      = $find('last_name');
        $email     = $find('email');
        $password  = $find('password');

        $fields = [];
        $step   = 1;

        // Step 1 — Foto profilo + nome + cognome
        if ($avatar) { $f = fone_library_item_to_field($avatar); $f['step']=$step; $fields[] = $f; }
        if ($first)  { $f = fone_library_item_to_field($first);  $f['step']=$step; $f['width']='half'; $fields[] = $f; }
        if ($last)   { $f = fone_library_item_to_field($last);   $f['step']=$step; $f['width']='half'; $fields[] = $f; }

        // Step 2 — Email + Password + conferma
        $step = 2;
        if ($email) {
            $f = fone_library_item_to_field($email);
            $f['step']=$step; $f['width']='full';
            $f['label']='Indirizzo email';
            $f['placeholder']='nome@esempio.it';
            $f['required']=1;
            $fields[] = $f;
        }
        if ($password) {
            $f = fone_library_item_to_field($password);
            $f['step']=$step; $f['width']='half';
            $f['label']='Password'; $f['required']=1;
            $fields[] = $f;

            // Conferma password
            $fc = $f;
            $fc['id']    = 'fone_' . substr(md5('password_confirm'), 0, 8);
            $fc['slug']  = 'password_confirm';
            $fc['label'] = 'Conferma password';
            $fc['width'] = 'half';
            $fields[] = $fc;
        }

        // Submit finale
        $fields[] = [
            'id'          => 'fone_submit',
            'type'        => 'submit',
            'slug'        => 'submit',
            'label'       => 'Invia',
            'placeholder' => '',
            'help'        => '',
            'required'    => 0,
            'step'        => $step,
            'width'       => 'full',
            'options'     => '',
            'max_chars'   => '',
            'autocomp'    => 'off',
            'meta_key'    => '',
        ];

        return $fields;
    }
}

/**
 * Layout di default per step (una colonna).
 * Viene salvato nelle settings come array: step_number => '1col'|'2col'
 */
if (!function_exists('fone_get_step_layouts')) {
    function fone_get_step_layouts() {
        $layouts = get_option('fone_step_layouts', []);
        if (!is_array($layouts)) {
            $layouts = [];
        }
        return $layouts;
    }
}
