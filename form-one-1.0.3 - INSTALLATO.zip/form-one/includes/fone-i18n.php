<?php
/**
 * Form One — Stringhe UI (IT / EN)
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('fone_get_all_strings')) {
    function fone_get_all_strings() {
        return [

            'it' => [
                // Generali
                'plugin_title'         => 'Form One',
                'builder_title'        => 'Form One — Builder',
                'builder_subtitle'     => 'Costruisci form di registrazione multi-step con drag & drop.',
                'custom_css_title'     => 'CSS Personalizzato',
                'custom_css_subtitle'  => 'Personalizza l\'aspetto del form. Ogni blocco è commentato.',
                'entries_title'        => 'Invii ricevuti',
                'entries_empty'        => 'Nessun invio ricevuto per questo form.',
                'entry_time'           => 'Data',
                'entry_page'           => 'Pagina',
                'entry_values'         => 'Dati',
                'export_csv'           => 'Esporta CSV',
                'delete_all'           => 'Elimina tutti gli invii',
                'delete_confirm'       => 'Eliminare davvero tutti gli invii di questo form? L\'operazione è irreversibile.',
                'delete_form_confirm'  => 'Eliminare questo form e tutti i suoi invii? L\'operazione è irreversibile.',

                // Tabs builder
                'tab_fields'           => 'Campi',
                'tab_form'             => 'Impostazioni',
                'tab_design'           => 'Design',
                'tab_publish'          => 'Pubblica',
                'collapse_to_fields'   => 'Torna ai campi',

                // Layout builder
                'field_library'        => 'Libreria Campi',
                'library_search'       => 'Cerca campo…',
                'form_canvas'          => 'Canvas del Form',
                'field_settings'       => 'Impostazioni Campo',
                'live_preview'         => 'Anteprima Live',
                'responsive_preview'   => 'Anteprima responsive del form nel frontend.',
                'desktop'              => 'Desktop',
                'tablet'               => 'Tablet',
                'mobile'               => 'Mobile',

                // Azioni globali
                'language'             => 'Lingua',
                'english'              => 'Inglese',
                'italian'              => 'Italiano',
                'save_form'            => 'Salva Modifiche',
                'saved'                => 'Modifiche salvate con successo.',
                'save_css'             => 'Salva CSS',
                'css_saved'            => 'CSS salvato correttamente.',
                'reset_css'            => 'Ripristina CSS predefinito',
                'reset_css_confirm'    => 'Sovrascrivere il CSS attuale con quello predefinito?',

                // Liste form
                'all_forms'            => 'Tutti i Form',
                'new_form'             => 'Crea Nuovo Form',
                'form_name'            => 'Nome del form',
                'form_name_placeholder'=> 'es. Form di Registrazione',
                'edit_form'            => 'Modifica',
                'delete_form'          => 'Elimina',
                'view_entries'         => 'Invii',
                'forms_empty'          => 'Nessun form creato. Crea il tuo primo form!',
                'back_to_forms'        => '← Tutti i Form',
                'form_created'         => 'Form creato con successo.',
                'form_deleted'         => 'Form eliminato.',
                'form_id_label'        => 'Shortcode:',
                'registration_badge'   => '✓ Registrazione',

                // Libreria campi — categorie
                'cat_identity'         => 'Identità di base',
                'cat_security'         => 'Accesso e sicurezza',
                'cat_demographics'     => 'Anagrafica',
                'cat_public_profile'   => 'Profilo pubblico',
                'cat_contacts'         => 'Contatti',
                'cat_professional'     => 'Dati professionali',
                'cat_business'         => 'Dati aziendali',
                'cat_operational'      => 'Dati operativi',
                'cat_structure'        => 'Struttura',
                'cat_uploads'          => 'Upload e documenti',
                'cat_surveys'          => 'Survey e feedback',

                // Azioni campo
                'add_field'            => 'Aggiungi campo',
                'no_fields'            => 'Nessun campo. Trascina o clicca un campo dalla libreria a sinistra.',
                'drag_here'            => 'Trascina qui i campi dalla libreria',
                'select_field'         => 'Clicca un campo per modificarne le impostazioni.',
                'move_up'              => 'Sposta su',
                'move_down'            => 'Sposta giù',
                'duplicate_field'      => 'Duplica campo',
                'remove_field'         => 'Rimuovi campo',

                // Impostazioni campo
                'field_type'           => 'Tipo campo',
                'field_id'             => 'ID campo',
                'label'                => 'Etichetta',
                'placeholder'          => 'Testo segnaposto',
                'help_text'            => 'Testo di aiuto',
                'required'             => 'Campo obbligatorio',
                'step'                 => 'Step',
                'step_n'               => 'Step %d',
                'add_step'             => '+ Aggiungi step',
                'remove_step'          => 'Rimuovi step',
                'width'                => 'Larghezza',
                'third'                => 'Un terzo',
                'half'                 => 'Metà larghezza',
                'two_thirds'           => 'Due terzi',
                'full'                 => 'Larghezza piena',
                'options'              => 'Opzioni (una per riga)',
                'max_chars'            => 'Numero massimo di caratteri',
                'meta_key'             => 'Chiave meta (avanzato)',
                'meta_key_help'        => 'Chiave user_meta WordPress opzionale per salvare il valore.',
                'accept_types'         => 'Tipi di file accettati',
                'accept_types_help'    => 'Separati da virgola, es. image/jpeg,image/png',
                'max_size_mb'          => 'Dimensione massima (MB)',

                // Step layout
                'step_layout'          => 'Layout dello step',
                'step_layout_help'     => '1 colonna o 2 colonne (le 2 colonne valgono solo su desktop).',
                'one_column'           => '1 Colonna',
                'two_columns'          => '2 Colonne',
                'two_columns_desktop'  => '2 colonne (solo desktop)',

                // Impostazioni form
                'form_title'           => 'Titolo del form (opzionale)',
                'form_subtitle'        => 'Sottotitolo del form (opzionale)',
                'admin_email'          => 'Email di notifica admin',
                'success_message'      => 'Messaggio di completamento',
                'show_donate_frontend' => 'Mostra pulsante di supporto sotto il form',
                'donate_url'           => 'URL del pulsante di supporto',

                // Sezione registrazione
                'registration_section' => '👤 Registrazione Utente WordPress',
                'enable_registration'  => 'Usa questo form per registrare nuovi utenti WordPress',
                'enable_registration_help' => 'All\'invio verrà creato un nuovo account WordPress con i dati del form. Solo un form alla volta può avere questa funzione attiva.',
                'registration_conflict'=> '⚠️ Un altro form è già impostato come form di registrazione. Disattivalo prima di abilitare questo.',
                'registration_role'    => 'Ruolo assegnato al nuovo utente',
                'registration_autologin' => 'Esegui il login automatico dopo la registrazione',
                'registration_send_wp_email' => 'Invia l\'email di benvenuto WordPress al nuovo utente',
                'registration_redirect'=> 'URL di reindirizzamento dopo la registrazione (opzionale)',
                'registration_redirect_help' => 'Lascia vuoto per mostrare il messaggio di completamento.',
                'registration_fields_hint' => 'Campi richiesti per la registrazione:',

                // Design
                'accent_color'         => 'Colore principale',
                'border_radius'        => 'Arrotondamento angoli (px)',
                'reveal_animation'     => 'Animazione di entrata degli step',
                'reveal_from_top'      => 'Dall\'alto (predefinito)',
                'reveal_fade'          => 'Dissolvenza',
                'reveal_slide_right'   => 'Scivolata da sinistra',
                'reveal_scale'         => 'Zoom morbido',

                // Pubblica
                'publish_title'        => 'Pubblica il Form',
                'publish_text'         => 'Incolla questo shortcode in qualsiasi pagina, articolo o widget testo.',
                'copy_shortcode'       => 'Copia shortcode',
                'copied'               => 'Copiato!',
                'new_page'             => 'Crea Nuova Pagina',
                'all_pages'            => 'Tutte le Pagine',
                'donate_now'           => 'Supporta il progetto',

                // Frontend
                'continue'             => 'Continua →',
                'submit'               => 'Registrati',
                'submit_generic'       => 'Invia',
                'trust_text'           => 'I tuoi dati sono al sicuro. Niente spam.',
                'loading'              => 'Invio in corso…',
                'upload_photo'         => 'Carica foto profilo',
                'take_photo'           => 'Scatta una foto',
                'change_photo'         => 'Cambia foto',
                'remove_photo'         => 'Rimuovi foto',
                'photo_uploaded'       => 'Foto caricata con successo.',
                'photo_preview'        => 'Anteprima foto profilo',

                // Errori
                'error_required'       => 'Questo campo è obbligatorio.',
                'error_email'          => 'Inserisci un indirizzo email valido.',
                'error_phone'          => 'Inserisci un numero di telefono valido.',
                'error_url'            => 'Inserisci un URL valido.',
                'error_password_match' => 'Le password non coincidono.',
                'error_password_weak'  => 'La password è troppo debole (minimo 8 caratteri).',
                'error_file_type'      => 'Tipo di file non consentito.',
                'error_file_size'      => 'Il file supera la dimensione massima consentita.',
                'error_max_chars'      => 'Hai superato il numero massimo di caratteri.',
                'rate_limit_error'     => 'Troppi tentativi. Attendi qualche minuto e riprova.',
                'global_error'         => 'Correggi gli errori evidenziati per procedere.',
                'spam_detected'        => 'Richiesta non valida (possibile spam).',
                'invalid_token'        => 'Token di sicurezza non valido. Ricarica la pagina.',

                // Account (shortcode fone_account)
                'account_title'        => 'Il tuo account',
                'account_not_logged'   => 'Devi accedere per visualizzare questa pagina.',
            ],

            'en' => [
                // General
                'plugin_title'         => 'Form One',
                'builder_title'        => 'Form One — Builder',
                'builder_subtitle'     => 'Build multi-step registration forms with drag & drop.',
                'custom_css_title'     => 'Custom CSS',
                'custom_css_subtitle'  => 'Customize the form\'s appearance. Every block is commented.',
                'entries_title'        => 'Form Submissions',
                'entries_empty'        => 'No submissions received for this form yet.',
                'entry_time'           => 'Date',
                'entry_page'           => 'Page',
                'entry_values'         => 'Data',
                'export_csv'           => 'Export CSV',
                'delete_all'           => 'Delete All Submissions',
                'delete_confirm'       => 'Permanently delete all submissions for this form? This cannot be undone.',
                'delete_form_confirm'  => 'Delete this form and all its submissions? This cannot be undone.',

                // Builder tabs
                'tab_fields'           => 'Fields',
                'tab_form'             => 'Settings',
                'tab_design'           => 'Design',
                'tab_publish'          => 'Publish',
                'collapse_to_fields'   => 'Back to Fields',

                // Builder layout
                'field_library'        => 'Field Library',
                'library_search'       => 'Search fields…',
                'form_canvas'          => 'Form Canvas',
                'field_settings'       => 'Field Settings',
                'live_preview'         => 'Live Preview',
                'responsive_preview'   => 'Responsive preview of the form as seen by visitors.',
                'desktop'              => 'Desktop',
                'tablet'               => 'Tablet',
                'mobile'               => 'Mobile',

                // Global actions
                'language'             => 'Language',
                'english'              => 'English',
                'italian'              => 'Italian',
                'save_form'            => 'Save Changes',
                'saved'                => 'Changes saved successfully.',
                'save_css'             => 'Save CSS',
                'css_saved'            => 'CSS saved successfully.',
                'reset_css'            => 'Reset to Default CSS',
                'reset_css_confirm'    => 'Overwrite current CSS with the default template?',

                // Form list
                'all_forms'            => 'All Forms',
                'new_form'             => 'Create New Form',
                'form_name'            => 'Form name',
                'form_name_placeholder'=> 'e.g. Registration Form',
                'edit_form'            => 'Edit',
                'delete_form'          => 'Delete',
                'view_entries'         => 'Submissions',
                'forms_empty'          => 'No forms yet. Create your first form!',
                'back_to_forms'        => '← All Forms',
                'form_created'         => 'Form created successfully.',
                'form_deleted'         => 'Form deleted.',
                'form_id_label'        => 'Shortcode:',
                'registration_badge'   => '✓ Registration',

                // Field library categories
                'cat_identity'         => 'Basic Identity',
                'cat_security'         => 'Access & Security',
                'cat_demographics'     => 'Demographics',
                'cat_public_profile'   => 'Public Profile',
                'cat_contacts'         => 'Contacts',
                'cat_professional'     => 'Professional',
                'cat_business'         => 'Business',
                'cat_operational'      => 'Operational',
                'cat_structure'        => 'Structure',
                'cat_uploads'          => 'Uploads & Documents',
                'cat_surveys'          => 'Survey & Feedback',

                // Field actions
                'add_field'            => 'Add field',
                'no_fields'            => 'No fields yet. Drag or click a field from the library on the left.',
                'drag_here'            => 'Drag fields here from the library',
                'select_field'         => 'Click a field to edit its settings.',
                'move_up'              => 'Move up',
                'move_down'            => 'Move down',
                'duplicate_field'      => 'Duplicate field',
                'remove_field'         => 'Remove field',

                // Field settings
                'field_type'           => 'Field type',
                'field_id'             => 'Field ID',
                'label'                => 'Label',
                'placeholder'          => 'Placeholder text',
                'help_text'            => 'Help text',
                'required'             => 'Required field',
                'step'                 => 'Step',
                'step_n'               => 'Step %d',
                'add_step'             => '+ Add step',
                'remove_step'          => 'Remove step',
                'width'                => 'Width',
                'third'                => 'One third',
                'half'                 => 'Half width',
                'two_thirds'           => 'Two thirds',
                'full'                 => 'Full width',
                'options'              => 'Options (one per line)',
                'max_chars'            => 'Maximum characters',
                'meta_key'             => 'Meta key (advanced)',
                'meta_key_help'        => 'Optional user_meta key where the value will be stored.',
                'accept_types'         => 'Allowed file types',
                'accept_types_help'    => 'Comma-separated, e.g. image/jpeg,image/png',
                'max_size_mb'          => 'Max file size (MB)',

                // Step layout
                'step_layout'          => 'Step layout',
                'step_layout_help'     => '1 column or 2 columns (2 columns applies to desktop only).',
                'one_column'           => '1 Column',
                'two_columns'          => '2 Columns',
                'two_columns_desktop'  => '2 columns (desktop only)',

                // Form settings
                'form_title'           => 'Form title (optional)',
                'form_subtitle'        => 'Form subtitle (optional)',
                'admin_email'          => 'Admin notification email',
                'success_message'      => 'Completion message',
                'show_donate_frontend' => 'Show a support button below the form',
                'donate_url'           => 'Support button URL',

                // Registration section
                'registration_section' => '👤 WordPress User Registration',
                'enable_registration'  => 'Use this form to register new WordPress users',
                'enable_registration_help' => 'On submission, a new WordPress account will be created. Only one form can have this feature active at a time.',
                'registration_conflict'=> '⚠️ Another form is already set as the registration form. Disable it first.',
                'registration_role'    => 'Role assigned to new users',
                'registration_autologin' => 'Automatically log in after registration',
                'registration_send_wp_email' => 'Send WordPress welcome email to the new user',
                'registration_redirect'=> 'Redirect URL after registration (optional)',
                'registration_redirect_help' => 'Leave blank to show the completion message.',
                'registration_fields_hint' => 'Fields required for registration:',

                // Design
                'accent_color'         => 'Primary color',
                'border_radius'        => 'Corner radius (px)',
                'reveal_animation'     => 'Step reveal animation',
                'reveal_from_top'      => 'From top (default)',
                'reveal_fade'          => 'Fade in',
                'reveal_slide_right'   => 'Slide from left',
                'reveal_scale'         => 'Soft zoom',

                // Publish
                'publish_title'        => 'Publish Your Form',
                'publish_text'         => 'Paste this shortcode into any page, post or text widget.',
                'copy_shortcode'       => 'Copy shortcode',
                'copied'               => 'Copied!',
                'new_page'             => 'Create New Page',
                'all_pages'            => 'All Pages',
                'donate_now'           => 'Support the project',

                // Frontend
                'continue'             => 'Continue →',
                'submit'               => 'Create Account',
                'submit_generic'       => 'Submit',
                'trust_text'           => 'Your data is safe. No spam, ever.',
                'loading'              => 'Submitting…',
                'upload_photo'         => 'Upload profile photo',
                'take_photo'           => 'Take a photo',
                'change_photo'         => 'Change photo',
                'remove_photo'         => 'Remove photo',
                'photo_uploaded'       => 'Photo uploaded successfully.',
                'photo_preview'        => 'Profile photo preview',

                // Errors
                'error_required'       => 'This field is required.',
                'error_email'          => 'Please enter a valid email address.',
                'error_phone'          => 'Please enter a valid phone number.',
                'error_url'            => 'Please enter a valid URL.',
                'error_password_match' => 'Passwords do not match.',
                'error_password_weak'  => 'Password is too weak (minimum 8 characters).',
                'error_file_type'      => 'File type not allowed.',
                'error_file_size'      => 'File exceeds the maximum allowed size.',
                'error_max_chars'      => 'Character limit exceeded.',
                'rate_limit_error'     => 'Too many attempts. Please wait a few minutes and try again.',
                'global_error'         => 'Please correct the highlighted errors.',
                'spam_detected'        => 'Invalid request detected.',
                'invalid_token'        => 'Security token invalid. Please reload the page.',

                // Account
                'account_title'        => 'Your Account',
                'account_not_logged'   => 'You must be logged in to view this page.',
            ],
        ];
    }
}

if (!function_exists('fone_t')) {
    function fone_t($key, $form_id = 0) {
        $settings = ($form_id && function_exists('fone_get_settings'))
            ? fone_get_settings($form_id)
            : (function_exists('fone_get_settings') ? fone_get_settings() : ['lang' => 'it']);
        $lang    = !empty($settings['lang']) ? $settings['lang'] : 'it';
        $strings = fone_get_all_strings();
        return $strings[$lang][$key] ?? $strings['it'][$key] ?? $key;
    }
}
