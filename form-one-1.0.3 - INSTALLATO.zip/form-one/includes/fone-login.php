<?php
/**
 * Form One — Login system completo
 *
 * Architettura:
 * - Tutte le opzioni del form di login sono salvate in option 'fone_login_settings'.
 * - Lo shortcode [fone_login] legge le opzioni e si auto-personalizza.
 * - Pagina admin "Form di Login" permette di personalizzare titolo, sottotitolo,
 *   colori, microcopy, campi extra (consenso/checkbox), redirect post-login.
 * - L'autenticazione passa da un handler 'init' (priorità 1) che intercetta
 *   il POST prima del rendering e setta i cookie correttamente.
 * - Il debug login viene scritto solo con WP_DEBUG attivo, in
 *   uploads/form-one-logs/ tramite fone_write_debug_log() (logger centralizzato).
 */
if (!defined('ABSPATH')) { exit; }

add_shortcode('fone_login',     'fone_render_login_shortcode');
add_shortcode('user_login_gip', 'fone_render_login_shortcode'); // legacy

/* ---------------------------------------------------------------
   DEFAULTS + GETTER/SETTER OPZIONI
--------------------------------------------------------------- */

if (!function_exists('fone_login_default_settings')) {
    function fone_login_default_settings() {
        return [
            // Testi
            'title'                => 'Accedi al tuo account',
            'subtitle'             => 'Inserisci le tue credenziali per continuare.',
            'label_user'           => 'Email o Username',
            'label_pass'           => 'Password',
            'label_remember'       => 'Ricordami',
            'btn_login'            => 'Accedi',
            'btn_loading'          => 'Accesso…',
            'msg_success'          => 'Accesso effettuato con successo!',
            'msg_error_invalid'    => 'Email o password non corretti. Riprova.',
            'msg_error_empty'      => 'Inserisci email/username e password.',
            'msg_error_nonce'      => 'Sessione scaduta. Ricarica la pagina e riprova.',
            'msg_error_ratelimit'  => 'Troppi tentativi. Attendi qualche minuto e riprova.',
            'lostpass_label'       => 'Password dimenticata?',
            'profile_link_label'   => 'Area personale',
            'show_lostpass'        => 1,
            'show_profile_link'    => 1,
            'show_remember'        => 1,
            // Stile
            'accent_color'         => '#2563eb',
            'bg_color'             => '#ffffff',
            'text_color'           => '#0a0a0f',
            'border_radius'        => 10,
            'btn_text_color'       => '#ffffff',
            'show_box_shadow'      => 1,
            // Comportamento
            'redirect_after_login' => '',
            'logged_greeting'      => 'Ciao, {name}!',
            // Campi extra: array di {type:'checkbox|text|hidden', slug, label, required, default}
            'extra_fields'         => [],
        ];
    }
}

if (!function_exists('fone_login_get_settings')) {
    function fone_login_get_settings() {
        $saved = get_option('fone_login_settings', []);
        if (!is_array($saved)) $saved = [];
        return wp_parse_args($saved, fone_login_default_settings());
    }
}

if (!function_exists('fone_login_save_settings')) {
    function fone_login_save_settings($new) {
        if (!is_array($new)) return false;
        $defaults = fone_login_default_settings();
        $clean = [];

        foreach (['title','subtitle','label_user','label_pass','label_remember',
                  'btn_login','btn_loading','msg_success','msg_error_invalid',
                  'msg_error_empty','msg_error_nonce','msg_error_ratelimit',
                  'lostpass_label','profile_link_label','logged_greeting'] as $k) {
            $clean[$k] = isset($new[$k]) ? sanitize_text_field(wp_unslash($new[$k])) : $defaults[$k];
        }
        foreach (['show_lostpass','show_profile_link','show_remember','show_box_shadow'] as $k) {
            $clean[$k] = !empty($new[$k]) ? 1 : 0;
        }
        foreach (['accent_color','bg_color','text_color','btn_text_color'] as $k) {
            $color = isset($new[$k]) ? sanitize_hex_color(wp_unslash($new[$k])) : null;
            $clean[$k] = $color ?: $defaults[$k];
        }
        $clean['border_radius'] = isset($new['border_radius']) ? max(0, min(40, (int) $new['border_radius'])) : $defaults['border_radius'];

        // Redirect: solo URL stesso dominio
        $redir = isset($new['redirect_after_login']) ? trim(wp_unslash($new['redirect_after_login'])) : '';
        if ($redir) {
            $redir = esc_url_raw($redir);
            $home_host  = wp_parse_url(home_url(), PHP_URL_HOST);
            $redir_host = wp_parse_url($redir, PHP_URL_HOST);
            if ($redir_host && $redir_host !== $home_host) $redir = '';
        }
        $clean['redirect_after_login'] = $redir;

        // Campi extra
        $extra = [];
        if (!empty($new['extra_fields']) && is_array($new['extra_fields'])) {
            foreach ($new['extra_fields'] as $f) {
                if (!is_array($f)) continue;
                $type = isset($f['type']) ? sanitize_key($f['type']) : 'checkbox';
                if (!in_array($type, ['checkbox','text','hidden'], true)) $type = 'checkbox';
                $slug = isset($f['slug']) ? sanitize_key($f['slug']) : '';
                $label = isset($f['label']) ? sanitize_text_field($f['label']) : '';
                $required = !empty($f['required']) ? 1 : 0;
                $default = isset($f['default']) ? sanitize_text_field($f['default']) : '';
                if (!$slug || !$label) continue;
                $extra[] = compact('type','slug','label','required','default');
            }
        }
        $clean['extra_fields'] = $extra;

        update_option('fone_login_settings', $clean, false);
        return true;
    }
}

/* ---------------------------------------------------------------
   FLASH + LOG (logger centralizzato)
--------------------------------------------------------------- */

if (!function_exists('fone_login_log')) {
    function fone_login_log($msg) {
        if (function_exists('fone_write_debug_log')) {
            fone_write_debug_log('login', $msg);
        }
    }
}

if (!function_exists('fone_login_set_flash')) {
    function fone_login_set_flash($message) {
        $key = 'fone_login_err_' . md5(
            (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '') .
            (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '')
        );
        set_transient($key, sanitize_text_field($message), 60);
    }
}

if (!function_exists('fone_login_get_flash')) {
    function fone_login_get_flash() {
        $key = 'fone_login_err_' . md5(
            (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '') .
            (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '')
        );
        $msg = get_transient($key);
        if ($msg) delete_transient($key);
        return $msg ?: '';
    }
}

/* ---------------------------------------------------------------
   HANDLER LOGIN su 'init' priorità 1 (prima del rendering)
--------------------------------------------------------------- */

add_action('init', 'fone_login_intercept_submit', 1);

if (!function_exists('fone_login_intercept_submit')) {
    function fone_login_intercept_submit() {
        if (empty($_POST['fone_login_submit']) || empty($_POST['fone_login_nonce'])) return;
        if (is_admin() && !defined('DOING_AJAX')) return;

        $opts = fone_login_get_settings();

        $nonce_ok = wp_verify_nonce(
            sanitize_text_field(wp_unslash($_POST['fone_login_nonce'])),
            'fone_login_action'
        );
        if (!$nonce_ok) {
            fone_login_set_flash($opts['msg_error_nonce']);
            return;
        }

        $raw_user = wp_unslash($_POST['fone_login_user'] ?? '');
        $password = (string) wp_unslash($_POST['fone_login_pass'] ?? '');
        $remember = !empty($_POST['fone_login_remember']);

        if ($raw_user === '' || $password === '') {
            fone_login_set_flash($opts['msg_error_empty']);
            return;
        }

        if (function_exists('fone_check_context_rate_limit')) {
            $ok = fone_check_context_rate_limit(
                'login_shortcode', 8, 10 * MINUTE_IN_SECONDS, 10 * MINUTE_IN_SECONDS,
                strtolower($raw_user)
            );
            if (!$ok) {
                fone_login_set_flash($opts['msg_error_ratelimit']);
                return;
            }
        }

        // Validazione campi extra obbligatori
        foreach ($opts['extra_fields'] as $ef) {
            if (!empty($ef['required'])) {
                $field_name = 'fone_login_extra_' . sanitize_key($ef['slug']);
                if (empty($_POST[$field_name])) {
                    fone_login_set_flash(sprintf(
                        __('Il campo "%s" è obbligatorio.', 'form-one'),
                        $ef['label']
                    ));
                    return;
                }
            }
        }

        // Trova utente
        $user = null;
        if (is_email($raw_user)) {
            $user = get_user_by('email', sanitize_email($raw_user));
        }
        if (!$user) {
            $user = get_user_by('login', sanitize_user($raw_user, true));
        }
        if (!$user) {
            $user = get_user_by('slug', sanitize_title($raw_user));
        }
        if (!$user) {
            fone_login_set_flash($opts['msg_error_invalid']);
            return;
        }

        if (!wp_check_password($password, $user->user_pass, $user->ID)) {
            fone_login_set_flash($opts['msg_error_invalid']);
            return;
        }

        wp_clear_auth_cookie();
        wp_set_current_user($user->ID, $user->user_login);
        wp_set_auth_cookie($user->ID, $remember, is_ssl());
        do_action('wp_login', $user->user_login, $user);

        // Salvo eventuali campi extra come user meta
        foreach ($opts['extra_fields'] as $ef) {
            $field_name = 'fone_login_extra_' . sanitize_key($ef['slug']);
            if (isset($_POST[$field_name])) {
                $val = is_array($_POST[$field_name])
                    ? array_map('sanitize_text_field', wp_unslash($_POST[$field_name]))
                    : sanitize_text_field(wp_unslash($_POST[$field_name]));
                update_user_meta($user->ID, 'fone_login_' . sanitize_key($ef['slug']), $val);
            }
        }

        // Redirect
        $redirect_to = '';
        if (!empty($_POST['fone_login_redirect'])) {
            $redirect_to = esc_url_raw(wp_unslash($_POST['fone_login_redirect']));
        }
        if (!$redirect_to && !empty($opts['redirect_after_login'])) {
            $redirect_to = $opts['redirect_after_login'];
        }
        if (!$redirect_to) {
            $redirect_to = function_exists('fone_default_profile_url')
                ? fone_default_profile_url()
                : home_url('/account-form-one/');
        }
        if (function_exists('fone_sanitize_local_url')) {
            $redirect_to = fone_sanitize_local_url($redirect_to, home_url('/'));
        }

        wp_safe_redirect($redirect_to);
        exit;
    }
}

/* ---------------------------------------------------------------
   SHORTCODE [fone_login]
--------------------------------------------------------------- */

if (!function_exists('fone_render_login_shortcode')) {
    function fone_render_login_shortcode($atts) {
        if (function_exists('fone_enqueue_front_assets')) {
            fone_enqueue_front_assets(true);
        }
        $atts = shortcode_atts(['redirect' => ''], $atts, 'fone_login');
        $opts = fone_login_get_settings();

        $profile_url_raw = function_exists('fone_default_profile_url')
            ? fone_default_profile_url() : home_url('/account-form-one/');
        $profile_url = function_exists('fone_sanitize_local_url')
            ? fone_sanitize_local_url($profile_url_raw, home_url('/'))
            : esc_url_raw($profile_url_raw);

        $redirect_to = !empty($atts['redirect']) ? $atts['redirect']
            : (!empty($opts['redirect_after_login']) ? $opts['redirect_after_login'] : $profile_url);
        if (function_exists('fone_sanitize_local_url')) {
            $redirect_to = fone_sanitize_local_url($redirect_to, $profile_url);
        }

        $inline_style = sprintf(
            '--fone-accent:%s;--fone-radius:%dpx;--fone-bg:%s;--fone-text:%s;--fone-btn-text:%s;',
            esc_attr($opts['accent_color']),
            (int) $opts['border_radius'],
            esc_attr($opts['bg_color']),
            esc_attr($opts['text_color']),
            esc_attr($opts['btn_text_color'])
        );
        $box_shadow_class = !empty($opts['show_box_shadow']) ? ' fone-login-shadow' : '';

        // Già loggato
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            $display_name = $user->display_name ?: $user->user_login;
            $logout_url = wp_logout_url(get_permalink());
            $greeting = str_replace('{name}', '<strong>' . esc_html($display_name) . '</strong>', esc_html($opts['logged_greeting']));
            ob_start(); ?>
            <div class="fone-wrap fone-login-wrap<?php echo $box_shadow_class; ?>" style="<?php echo esc_attr($inline_style); ?>">
                <div class="fone-success-box fone-success-rich">
                    <div class="fone-success-icon-wrap"><span class="fone-success-icon-big">👋</span></div>
                    <div class="fone-success-body">
                        <p class="fone-success-title"><?php echo wp_kses($greeting, ['strong' => []]); ?></p>
                        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px;">
                            <a href="<?php echo esc_url($profile_url); ?>" class="fone-profile-btn"><?php esc_html_e('Il mio profilo', 'form-one'); ?></a>
                            <a href="<?php echo esc_url($logout_url); ?>" style="padding:9px 16px;border:1.5px solid #e2e8f0;color:#334155;border-radius:var(--fone-radius);text-decoration:none;font-weight:600;font-size:14px;"><?php esc_html_e('Esci', 'form-one'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php return ob_get_clean();
        }

        $login_error = fone_login_get_flash();
        ob_start(); ?>
        <style>
        @media (max-width:600px) { .fone-login-wrap { margin-top:55px !important; } }
        .fone-login-wrap.fone-login-shadow { box-shadow: 0 4px 24px rgba(0,0,0,.06); }
        .fone-login-wrap { background: var(--fone-bg, #fff); color: var(--fone-text, #0a0a0f); padding: 28px; border-radius: calc(var(--fone-radius, 10px) + 4px); }
        .fone-login-wrap h2.fone-login-title { margin: 0 0 6px; font-size: 22px; font-weight: 700; color: var(--fone-text, #0a0a0f); }
        .fone-login-wrap p.fone-login-subtitle { margin: 0 0 22px; font-size: 14px; color: #64748b; }
        .fone-login-wrap .fone-submit-btn { background: var(--fone-accent, #2563eb); color: var(--fone-btn-text, #fff); }
        </style>
        <div class="fone-wrap fone-login-wrap<?php echo $box_shadow_class; ?>" style="<?php echo esc_attr($inline_style); ?>">
            <?php if (!empty($opts['title'])) : ?>
                <h2 class="fone-login-title"><?php echo esc_html($opts['title']); ?></h2>
            <?php endif; ?>
            <?php if (!empty($opts['subtitle'])) : ?>
                <p class="fone-login-subtitle"><?php echo esc_html($opts['subtitle']); ?></p>
            <?php endif; ?>

            <?php if ($login_error) : ?>
                <div class="fone-global-error" role="alert" style="margin-bottom:16px;padding:12px 14px;background:#fee2e2;border:1px solid #fca5a5;border-radius:8px;color:#991b1b;font-size:14px;">
                    <?php echo esc_html($login_error); ?>
                </div>
            <?php endif; ?>

            <form method="post" class="fone-front-form" novalidate>
                <?php wp_nonce_field('fone_login_action', 'fone_login_nonce'); ?>
                <input type="hidden" name="fone_login_submit" value="1">
                <input type="hidden" name="fone_login_redirect" value="<?php echo esc_attr($redirect_to); ?>">

                <div class="fone-step-grid is-one-col" style="gap:14px;">
                    <div class="fone-field fone-width-full">
                        <label for="fone_login_user"><?php echo esc_html($opts['label_user']); ?> <span class="fone-required">*</span></label>
                        <input type="text" id="fone_login_user" name="fone_login_user"
                            value="<?php echo esc_attr(wp_unslash($_POST['fone_login_user'] ?? '')); ?>"
                            autocomplete="username" required>
                    </div>
                    <div class="fone-field fone-width-full">
                        <label for="fone_login_pass"><?php echo esc_html($opts['label_pass']); ?> <span class="fone-required">*</span></label>
                        <div class="fone-password-wrap">
                            <input type="password" id="fone_login_pass" name="fone_login_pass" class="fone-password-input" autocomplete="current-password" required>
                            <button type="button" class="fone-password-toggle" data-fone-password-toggle="1" aria-controls="fone_login_pass" aria-label="Mostra password" aria-pressed="false">
                                <span class="fone-password-eye" aria-hidden="true">👁</span>
                            </button>
                        </div>
                    </div>

                    <?php // Campi extra ?>
                    <?php foreach ($opts['extra_fields'] as $ef) :
                        $name = 'fone_login_extra_' . sanitize_key($ef['slug']);
                        if ($ef['type'] === 'hidden') : ?>
                            <input type="hidden" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($ef['default']); ?>">
                        <?php elseif ($ef['type'] === 'checkbox') : ?>
                            <div class="fone-field fone-width-full" style="display:flex;align-items:center;gap:8px;">
                                <input type="checkbox" id="<?php echo esc_attr($name); ?>" name="<?php echo esc_attr($name); ?>" value="1" style="width:auto;" <?php echo !empty($ef['default']) ? 'checked' : ''; ?> <?php echo !empty($ef['required']) ? 'required' : ''; ?>>
                                <label for="<?php echo esc_attr($name); ?>" style="margin:0;font-weight:400;font-size:14px;color:#475569;"><?php echo esc_html($ef['label']); ?> <?php if (!empty($ef['required'])) : ?><span class="fone-required">*</span><?php endif; ?></label>
                            </div>
                        <?php elseif ($ef['type'] === 'text') : ?>
                            <div class="fone-field fone-width-full">
                                <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($ef['label']); ?> <?php if (!empty($ef['required'])) : ?><span class="fone-required">*</span><?php endif; ?></label>
                                <input type="text" id="<?php echo esc_attr($name); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($ef['default']); ?>" <?php echo !empty($ef['required']) ? 'required' : ''; ?>>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>

                    <?php if (!empty($opts['show_remember'])) : ?>
                    <div class="fone-field fone-width-full" style="display:flex;align-items:center;gap:8px;">
                        <input type="checkbox" id="fone_login_remember" name="fone_login_remember" value="1" style="width:auto;">
                        <label for="fone_login_remember" style="margin:0;font-weight:400;font-size:14px;color:#475569;"><?php echo esc_html($opts['label_remember']); ?></label>
                    </div>
                    <?php endif; ?>
                </div>

                <button type="submit" class="fone-submit-btn" style="margin-top:14px;" data-loading="<?php echo esc_attr($opts['btn_loading']); ?>"><?php echo esc_html($opts['btn_login']); ?></button>

                <?php if (!empty($opts['show_lostpass']) || !empty($opts['show_profile_link'])) : ?>
                <p style="margin:10px 0 0;text-align:center;font-size:13px;color:#64748b;">
                    <?php if (!empty($opts['show_lostpass'])) : ?>
                        <a href="<?php echo esc_url(wp_lostpassword_url(get_permalink())); ?>" style="color:var(--fone-accent);text-decoration:none;"><?php echo esc_html($opts['lostpass_label']); ?></a>
                    <?php endif; ?>
                    <?php if (!empty($opts['show_lostpass']) && !empty($opts['show_profile_link'])) : ?>
                        &nbsp;·&nbsp;
                    <?php endif; ?>
                    <?php if (!empty($opts['show_profile_link'])) : ?>
                        <a href="<?php echo esc_url($profile_url); ?>" style="color:var(--fone-accent);text-decoration:none;"><?php echo esc_html($opts['profile_link_label']); ?></a>
                    <?php endif; ?>
                </p>
                <?php endif; ?>
            </form>
        </div>
        <?php return ob_get_clean();
    }
}

/* ===============================================================
   PAGINA ADMIN — Form di Login
=============================================================== */

if (!function_exists('fone_login_settings_page')) {
    function fone_login_settings_page() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');

        if (!empty($_POST['fone_login_save']) && check_admin_referer('fone_login_save_nonce', 'fone_login_nonce_field')) {
            $payload = isset($_POST['fone_login']) && is_array($_POST['fone_login']) ? wp_unslash($_POST['fone_login']) : [];
            if (isset($payload['extra_fields_json'])) {
                $decoded = json_decode($payload['extra_fields_json'], true);
                $payload['extra_fields'] = is_array($decoded) ? $decoded : [];
            }
            fone_login_save_settings($payload);
            echo '<div class="notice notice-success is-dismissible"><p>✅ Impostazioni Form di Login salvate.</p></div>';
        }

        $opts = fone_login_get_settings();
        $extra_json = wp_json_encode($opts['extra_fields'] ?: []);
        ?>
        <div class="wrap" style="max-width:1280px;">
            <h1>🔐 Form di Login</h1>
            <p style="font-size:14px;color:#52525b;line-height:1.6;max-width:780px;">
                Personalizza il form di login del tuo sito. Lo shortcode <code>[fone_login]</code> userà queste impostazioni in qualsiasi pagina lo inserisci.
            </p>

            <form method="post" id="fone-login-form-settings">
                <?php wp_nonce_field('fone_login_save_nonce', 'fone_login_nonce_field'); ?>
                <input type="hidden" name="fone_login_save" value="1">
                <input type="hidden" name="fone_login[extra_fields_json]" id="fone_login_extra_fields_json" value="<?php echo esc_attr($extra_json); ?>">

                <div style="display:grid;grid-template-columns:1fr 380px;gap:24px;margin-top:18px;">
                    <div>
                        <nav class="nav-tab-wrapper" style="margin-bottom:0;">
                            <a href="#tab-testi" class="nav-tab nav-tab-active" data-tab="testi">📝 Testi</a>
                            <a href="#tab-stile" class="nav-tab" data-tab="stile">🎨 Stile</a>
                            <a href="#tab-comportamento" class="nav-tab" data-tab="comportamento">⚙️ Comportamento</a>
                            <a href="#tab-extra" class="nav-tab" data-tab="extra">➕ Campi Extra</a>
                        </nav>

                        <div class="fone-tab-panel" data-panel="testi" style="background:#fff;border:1px solid #e4e4e7;border-top:none;padding:22px 24px;">
                            <h2 style="margin:0 0 14px;font-size:16px;">Testi visibili nel form</h2>
                            <p><label><strong>Titolo</strong><br><input type="text" name="fone_login[title]" value="<?php echo esc_attr($opts['title']); ?>" class="regular-text fone-live" data-target="title" style="width:100%;max-width:520px;"></label></p>
                            <p><label><strong>Sottotitolo</strong><br><input type="text" name="fone_login[subtitle]" value="<?php echo esc_attr($opts['subtitle']); ?>" class="regular-text fone-live" data-target="subtitle" style="width:100%;max-width:520px;"></label></p>

                            <h3 style="margin:18px 0 8px;font-size:14px;color:#52525b;">Etichette campi</h3>
                            <p><label>Email/Username: <input type="text" name="fone_login[label_user]" value="<?php echo esc_attr($opts['label_user']); ?>" class="fone-live" data-target="label_user"></label></p>
                            <p><label>Password: <input type="text" name="fone_login[label_pass]" value="<?php echo esc_attr($opts['label_pass']); ?>" class="fone-live" data-target="label_pass"></label></p>
                            <p><label>Ricordami: <input type="text" name="fone_login[label_remember]" value="<?php echo esc_attr($opts['label_remember']); ?>" class="fone-live" data-target="label_remember"></label></p>

                            <h3 style="margin:18px 0 8px;font-size:14px;color:#52525b;">Pulsanti</h3>
                            <p><label>Testo pulsante: <input type="text" name="fone_login[btn_login]" value="<?php echo esc_attr($opts['btn_login']); ?>" class="fone-live" data-target="btn_login"></label></p>
                            <p><label>Testo "in caricamento": <input type="text" name="fone_login[btn_loading]" value="<?php echo esc_attr($opts['btn_loading']); ?>"></label></p>

                            <h3 style="margin:18px 0 8px;font-size:14px;color:#52525b;">Link sotto al form</h3>
                            <p><label><input type="checkbox" name="fone_login[show_lostpass]" value="1" <?php checked(!empty($opts['show_lostpass'])); ?>> Mostra "Password dimenticata?"</label> &nbsp;<input type="text" name="fone_login[lostpass_label]" value="<?php echo esc_attr($opts['lostpass_label']); ?>"></p>
                            <p><label><input type="checkbox" name="fone_login[show_profile_link]" value="1" <?php checked(!empty($opts['show_profile_link'])); ?>> Mostra link "Area personale"</label> &nbsp;<input type="text" name="fone_login[profile_link_label]" value="<?php echo esc_attr($opts['profile_link_label']); ?>"></p>
                            <p><label><input type="checkbox" name="fone_login[show_remember]" value="1" <?php checked(!empty($opts['show_remember'])); ?>> Mostra checkbox "Ricordami"</label></p>

                            <h3 style="margin:18px 0 8px;font-size:14px;color:#52525b;">Messaggi</h3>
                            <p><label>Errore credenziali sbagliate: <input type="text" name="fone_login[msg_error_invalid]" value="<?php echo esc_attr($opts['msg_error_invalid']); ?>" style="width:420px;"></label></p>
                            <p><label>Errore campi vuoti: <input type="text" name="fone_login[msg_error_empty]" value="<?php echo esc_attr($opts['msg_error_empty']); ?>" style="width:420px;"></label></p>
                            <p><label>Errore sessione scaduta: <input type="text" name="fone_login[msg_error_nonce]" value="<?php echo esc_attr($opts['msg_error_nonce']); ?>" style="width:420px;"></label></p>
                            <p><label>Errore rate limit: <input type="text" name="fone_login[msg_error_ratelimit]" value="<?php echo esc_attr($opts['msg_error_ratelimit']); ?>" style="width:420px;"></label></p>
                            <p><label>Saluto se già loggato: <input type="text" name="fone_login[logged_greeting]" value="<?php echo esc_attr($opts['logged_greeting']); ?>" style="width:300px;"></label> &nbsp; <small><code>{name}</code> = nome utente</small></p>
                        </div>

                        <div class="fone-tab-panel" data-panel="stile" style="display:none;background:#fff;border:1px solid #e4e4e7;border-top:none;padding:22px 24px;">
                            <h2 style="margin:0 0 14px;font-size:16px;">Stile del form</h2>
                            <p><label>Colore principale (accent): <input type="color" name="fone_login[accent_color]" value="<?php echo esc_attr($opts['accent_color']); ?>" class="fone-live" data-target="accent_color"></label></p>
                            <p><label>Sfondo card: <input type="color" name="fone_login[bg_color]" value="<?php echo esc_attr($opts['bg_color']); ?>" class="fone-live" data-target="bg_color"></label></p>
                            <p><label>Colore testo: <input type="color" name="fone_login[text_color]" value="<?php echo esc_attr($opts['text_color']); ?>" class="fone-live" data-target="text_color"></label></p>
                            <p><label>Colore testo pulsante: <input type="color" name="fone_login[btn_text_color]" value="<?php echo esc_attr($opts['btn_text_color']); ?>" class="fone-live" data-target="btn_text_color"></label></p>
                            <p><label>Border radius (px): <input type="number" name="fone_login[border_radius]" value="<?php echo (int) $opts['border_radius']; ?>" min="0" max="40" class="fone-live" data-target="border_radius"></label></p>
                            <p><label><input type="checkbox" name="fone_login[show_box_shadow]" value="1" <?php checked(!empty($opts['show_box_shadow'])); ?>> Mostra ombra box</label></p>
                        </div>

                        <div class="fone-tab-panel" data-panel="comportamento" style="display:none;background:#fff;border:1px solid #e4e4e7;border-top:none;padding:22px 24px;">
                            <h2 style="margin:0 0 14px;font-size:16px;">Comportamento dopo il login</h2>
                            <p style="max-width:680px;color:#52525b;">Specifica dove inviare l'utente dopo il login. Lascia vuoto per usare la pagina account predefinita.</p>
                            <p><label>URL di redirect: <input type="url" name="fone_login[redirect_after_login]" value="<?php echo esc_attr($opts['redirect_after_login']); ?>" placeholder="<?php echo esc_attr(home_url('/dashboard/')); ?>" style="width:480px;"></label></p>
                            <p style="font-size:13px;color:#71717A;">⚠️ Per sicurezza accettiamo solo URL dello stesso dominio.</p>
                        </div>

                        <div class="fone-tab-panel" data-panel="extra" style="display:none;background:#fff;border:1px solid #e4e4e7;border-top:none;padding:22px 24px;">
                            <h2 style="margin:0 0 14px;font-size:16px;">Campi extra</h2>
                            <p style="max-width:680px;color:#52525b;">Aggiungi campi opzionali al form di login. Tipici: una checkbox tipo "Ho letto i termini", un campo "Codice cliente" obbligatorio, ecc.</p>
                            <div id="fone-extra-fields-list"></div>
                            <button type="button" class="button button-secondary" id="fone-add-extra">+ Aggiungi campo extra</button>
                        </div>
                    </div>

                    <div>
                        <h3 style="margin:0 0 8px;font-size:14px;color:#52525b;">👁 Anteprima</h3>
                        <div id="fone-login-preview" style="background:#f4f4f5;border:1px dashed #d4d4d8;padding:24px;border-radius:8px;position:sticky;top:32px;">
                            <div id="fone-preview-card" style="background:<?php echo esc_attr($opts['bg_color']); ?>;color:<?php echo esc_attr($opts['text_color']); ?>;padding:28px;border-radius:<?php echo (int)$opts['border_radius']+4; ?>px;<?php echo !empty($opts['show_box_shadow']) ? 'box-shadow:0 4px 24px rgba(0,0,0,.08);' : ''; ?>">
                                <h2 data-prev="title" style="margin:0 0 6px;font-size:22px;font-weight:700;color:<?php echo esc_attr($opts['text_color']); ?>;"><?php echo esc_html($opts['title']); ?></h2>
                                <p data-prev="subtitle" style="margin:0 0 18px;font-size:13px;color:#64748b;"><?php echo esc_html($opts['subtitle']); ?></p>
                                <label data-prev="label_user" style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;"><?php echo esc_html($opts['label_user']); ?> *</label>
                                <input type="text" disabled style="width:100%;padding:10px;border:1px solid #e4e4e7;border-radius:6px;margin-bottom:10px;background:#fafafa;">
                                <label data-prev="label_pass" style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;"><?php echo esc_html($opts['label_pass']); ?> *</label>
                                <input type="password" disabled style="width:100%;padding:10px;border:1px solid #e4e4e7;border-radius:6px;margin-bottom:14px;background:#fafafa;">
                                <button type="button" disabled data-prev="btn_login" id="fone-preview-btn" style="width:100%;padding:11px;background:<?php echo esc_attr($opts['accent_color']); ?>;color:<?php echo esc_attr($opts['btn_text_color']); ?>;border:none;border-radius:8px;font-weight:700;font-size:14px;cursor:not-allowed;"><?php echo esc_html($opts['btn_login']); ?></button>
                            </div>
                            <p style="margin-top:12px;text-align:center;font-size:12px;color:#71717A;">Anteprima statica. Per vedere il form vero, inserisci <code>[fone_login]</code> in una pagina.</p>
                        </div>
                    </div>
                </div>

                <p style="margin-top:24px;">
                    <button type="submit" class="button button-primary button-large">💾 Salva impostazioni</button>
                </p>
            </form>
        </div>

        <script>
        (function(){
            var tabs = document.querySelectorAll('.nav-tab[data-tab]');
            var panels = document.querySelectorAll('.fone-tab-panel[data-panel]');
            tabs.forEach(function(t){
                t.addEventListener('click', function(e){
                    e.preventDefault();
                    tabs.forEach(function(x){ x.classList.remove('nav-tab-active'); });
                    t.classList.add('nav-tab-active');
                    var name = t.getAttribute('data-tab');
                    panels.forEach(function(p){ p.style.display = (p.getAttribute('data-panel') === name) ? 'block' : 'none'; });
                });
            });

            // Anteprima live
            document.querySelectorAll('.fone-live').forEach(function(input){
                input.addEventListener('input', function(){
                    var key = input.getAttribute('data-target');
                    var val = input.value;
                    var prev = document.querySelector('[data-prev="' + key + '"]');
                    if (prev && key.indexOf('label_') !== 0) {
                        prev.textContent = val;
                    }
                    if (key.indexOf('label_') === 0) {
                        var lbl = document.querySelector('[data-prev="' + key + '"]');
                        if (lbl) lbl.textContent = val + ' *';
                    }
                    var card = document.getElementById('fone-preview-card');
                    var btn  = document.getElementById('fone-preview-btn');
                    if (key === 'accent_color' && btn) btn.style.background = val;
                    if (key === 'btn_text_color' && btn) btn.style.color = val;
                    if (key === 'bg_color' && card) card.style.background = val;
                    if (key === 'text_color' && card) {
                        card.style.color = val;
                        card.querySelectorAll('h2, label').forEach(function(el){ el.style.color = val; });
                    }
                    if (key === 'border_radius' && card) card.style.borderRadius = (parseInt(val,10)+4) + 'px';
                });
            });

            // Campi extra
            var jsonInput = document.getElementById('fone_login_extra_fields_json');
            var listEl = document.getElementById('fone-extra-fields-list');
            var fields = [];
            try { fields = JSON.parse(jsonInput.value || '[]'); } catch(e) { fields = []; }
            if (!Array.isArray(fields)) fields = [];

            function renderExtra(){
                listEl.innerHTML = '';
                fields.forEach(function(f, i){
                    var box = document.createElement('div');
                    box.style.cssText = 'background:#fafafa;border:1px solid #e4e4e7;border-radius:8px;padding:14px;margin-bottom:10px;';
                    box.innerHTML =
                        '<div style="display:grid;grid-template-columns:140px 200px 1fr auto;gap:10px;align-items:end;">' +
                          '<label style="font-size:12px;">Tipo<br><select data-i="'+i+'" data-k="type" style="width:100%;"><option value="checkbox"' + (f.type==='checkbox'?' selected':'') + '>Checkbox</option><option value="text"' + (f.type==='text'?' selected':'') + '>Testo</option><option value="hidden"' + (f.type==='hidden'?' selected':'') + '>Nascosto</option></select></label>' +
                          '<label style="font-size:12px;">Slug (interno)<br><input type="text" data-i="'+i+'" data-k="slug" value="'+(f.slug||'').replace(/"/g,'&quot;')+'" style="width:100%;"></label>' +
                          '<label style="font-size:12px;">Etichetta<br><input type="text" data-i="'+i+'" data-k="label" value="'+(f.label||'').replace(/"/g,'&quot;')+'" style="width:100%;"></label>' +
                          '<button type="button" class="button" data-rm="'+i+'" style="color:#b91c1c;">Rimuovi</button>' +
                        '</div>' +
                        '<div style="margin-top:8px;font-size:12px;">' +
                          '<label><input type="checkbox" data-i="'+i+'" data-k="required"' + (f.required?' checked':'') + '> Obbligatorio</label> &nbsp; ' +
                          '<label>Default: <input type="text" data-i="'+i+'" data-k="default" value="'+(f.default||'').replace(/"/g,'&quot;')+'"></label>' +
                        '</div>';
                    listEl.appendChild(box);
                });

                listEl.querySelectorAll('[data-i]').forEach(function(el){
                    el.addEventListener('change', updateField);
                    el.addEventListener('input', updateField);
                });
                listEl.querySelectorAll('[data-rm]').forEach(function(el){
                    el.addEventListener('click', function(){
                        fields.splice(parseInt(el.getAttribute('data-rm'),10), 1);
                        renderExtra(); sync();
                    });
                });
            }

            function updateField(e){
                var el = e.target;
                var i = parseInt(el.getAttribute('data-i'),10);
                var k = el.getAttribute('data-k');
                if (!fields[i]) return;
                if (k === 'required') fields[i][k] = el.checked ? 1 : 0;
                else fields[i][k] = el.value;
                sync();
            }

            function sync(){ jsonInput.value = JSON.stringify(fields); }

            document.getElementById('fone-add-extra').addEventListener('click', function(){
                fields.push({type:'checkbox', slug:'', label:'', required:0, default:''});
                renderExtra(); sync();
            });

            renderExtra();
        })();
        </script>
        <?php
    }
}
