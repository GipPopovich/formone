<?php
/**
 * Form One — Frontend render
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   SCHEMA HELPERS
--------------------------------------------------------------- */

if (!function_exists('fone_current_url')) {
    /**
     * Helper robusto per ottenere l'URL della pagina corrente.
     * Usato per redirect post-submit. Cascata di fallback:
     *   1. permalink della pagina corrente (più affidabile)
     *   2. referer HTTP (la pagina da cui arriva il POST)
     *   3. URI corrente (REQUEST_URI)
     *   4. home_url (ultima spiaggia)
     */
    function fone_current_url() {
        $url = '';
        $perma = get_permalink();
        if ($perma) {
            $url = $perma;
        } elseif (($ref = wp_get_referer())) {
            $url = $ref;
        } elseif (!empty($_SERVER['REQUEST_URI'])) {
            $url = home_url(esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'])));
        } else {
            $url = home_url('/');
        }
        // Rimuovo eventuali parametri fone_* esistenti per non duplicarli
        $url = remove_query_arg(['fone_done', 'fone_success', 'fone_flash', 'fone_flash_2', 'fone_done_2', 'fone_success_2'], $url);
        return $url;
    }
}

if (!function_exists('fone_get_schema_array')) {
    function fone_get_schema_array() {
        $raw = get_option('fone_form_schema', '');
        $arr = json_decode($raw, true);
        if (!is_array($arr) || empty($arr)) {
            $arr = fone_get_default_schema();
        }
        return $arr;
    }
}

if (!function_exists('fone_resolve_width')) {
    function fone_resolve_width($field) {
        // Whitelist delle larghezze ammesse
        $allowed = ['third', 'half', 'two-thirds', 'full'];
        if (!empty($field['width']) && in_array($field['width'], $allowed, true)) {
            return $field['width'];
        }
        $type = !empty($field['type']) ? $field['type'] : 'text';
        if (in_array($type, ['textarea', 'html', 'html_admin', 'submit', 'radio', 'checkbox', 'avatar', 'paypal_button'], true)) {
            return 'full';
        }
        return 'half';
    }
}

if (!function_exists('fone_parse_field_options')) {
    function fone_parse_field_options($field) {
        if (empty($field['options'])) {
            return [];
        }
        $lines = preg_split('/\r\n|\r|\n/', (string) $field['options']);
        $lines = array_map('trim', $lines);
        $lines = array_filter($lines);
        return array_values($lines);
    }
}

if (!function_exists('fone_sanitize_admin_html_css')) {
    function fone_sanitize_admin_html_css($css) {
        $css = (string) $css;
        $css = wp_strip_all_tags($css);
        $css = preg_replace('/<\/?style[^>]*>/i', '', $css);
        $css = preg_replace('/<\/?script[^>]*>/i', '', $css);
        $css = preg_replace('/expression\s*\(/i', '', $css);
        $css = preg_replace('/javascript\s*:/i', '', $css);
        return trim($css);
    }
}

/* ---------------------------------------------------------------
   SINGLE FIELD RENDERER
--------------------------------------------------------------- */

if (!function_exists('fone_render_field')) {
    function fone_render_field($field, $values, $errors, $is_registration = false) {
        $type        = !empty($field['type'])        ? $field['type']        : 'text';
        $id          = !empty($field['id'])          ? $field['id']          : 'fone_' . wp_generate_uuid4();
        $slug        = !empty($field['slug'])        ? $field['slug']        : $id;
        $label       = !empty($field['label'])       ? $field['label']       : '';
        $placeholder = !empty($field['placeholder']) ? $field['placeholder'] : '';
        $help        = !empty($field['help'])        ? $field['help']        : '';
        $required    = !empty($field['required']);
        $max_chars   = !empty($field['max_chars'])   ? (int) $field['max_chars'] : 0;
        $autocomp    = !empty($field['autocomp'])    ? $field['autocomp']    : 'off';
        $accept      = !empty($field['accept_types']) ? $field['accept_types'] : ($type === 'file' ? 'application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/rtf,text/plain,text/csv,image/jpeg,image/png,image/webp,image/gif,image/avif,image/heic,video/mp4,video/webm,video/quicktime,audio/mpeg,audio/wav,audio/ogg,audio/mp4,application/zip' : 'image/jpeg,image/png,image/webp');
        $max_size    = !empty($field['max_size_mb']) ? (int) $field['max_size_mb'] : ($type === 'file' ? 20 : 5);
        $width       = fone_resolve_width($field);
        $options     = fone_parse_field_options($field);
        $value       = isset($values[$id]) ? $values[$id] : '';
        $has_error   = isset($errors[$id]);

        $classes = 'fone-field fone-width-' . $width . ' fone-type-' . $type . ' fone-slug-' . sanitize_html_class($slug);
        if ($has_error) {
            $classes .= ' has-error';
        }

        $cond_attrs = '';
        if (!empty($field['conditional_enabled'])) {
            $cond = [
                'field'    => sanitize_text_field($field['conditional_field'] ?? ''),
                'operator' => sanitize_key($field['conditional_operator'] ?? 'is'),
                'value'    => sanitize_text_field($field['conditional_value'] ?? ''),
                'action'   => sanitize_key($field['conditional_action'] ?? 'show'),
            ];
            if ($cond['field'] !== '') {
                $cond_attrs = ' data-fone-conditional="' . esc_attr(wp_json_encode($cond)) . '"';
            }
        }

        ob_start();

        /* ---- HTML block ---- */
        if ($type === 'html') {
            echo '<div class="' . esc_attr($classes) . '"' . $cond_attrs . '><div class="fone-html-block">' . wp_kses_post($label) . '</div></div>';
            return ob_get_clean();
        }

        /* ---- HTML Admin block: HTML + CSS inseriti dal backend ---- */
        if ($type === 'html_admin') {
            $html_content = isset($field['html_content']) && $field['html_content'] !== '' ? $field['html_content'] : $label;
            $html_css     = isset($field['html_css']) ? fone_sanitize_admin_html_css($field['html_css']) : '';
            echo '<div class="' . esc_attr($classes) . '"' . $cond_attrs . '>';
            if ($html_css !== '') {
                echo '<style id="fone-html-admin-style-' . esc_attr(sanitize_html_class($id)) . '">' . $html_css . '</style>';
            }
            echo '<div class="fone-html-admin-block">' . wp_kses_post($html_content) . '</div>';
            echo '</div>';
            return ob_get_clean();
        }

        /* ---- Campi strutturali / nascosti ---- */
        if ($type === 'hidden') {
            $hidden_value = isset($values[$id]) && !is_array($values[$id]) ? $values[$id] : ($field['default_value'] ?? '');
            echo '<input type="hidden" id="' . esc_attr($id) . '" name="' . esc_attr($id) . '" value="' . esc_attr($hidden_value) . '">';
            return ob_get_clean();
        }

        if ($type === 'divider') {
            echo '<div class="' . esc_attr($classes) . '"' . $cond_attrs . '><div class="fone-section-divider"><strong>' . esc_html($label ? $label : __('Nuova sezione', 'form-one')) . '</strong>';
            if ($help !== '') {
                echo '<small>' . esc_html($help) . '</small>';
            }
            echo '</div></div>';
            return ob_get_clean();
        }

        /* ---- PayPal button DISMESSO: ignoro silenziosamente campi residui ---- */
        if ($type === 'paypal_button') {
            return '';
        }

        /* ---- Submit button ---- */
        if ($type === 'submit') {
            $submit_fallback = $is_registration ? fone_t('submit') : fone_t('submit_generic');
            echo '<div class="' . esc_attr($classes) . '"' . $cond_attrs . '><button type="submit" class="fone-submit-btn" data-loading="' . esc_attr(fone_t('loading')) . '"><i class="fa-solid fa-paper-plane" aria-hidden="true"></i> ' . esc_html($label ? $label : $submit_fallback) . '</button></div>';
            return ob_get_clean();
        }

        ?>
        <div class="<?php echo esc_attr($classes); ?>"<?php echo $cond_attrs; ?>>
            <?php if ($label !== '' && !in_array($type, ['avatar','consent'], true)) : ?>
                <label for="<?php echo esc_attr($id); ?>">
                    <?php echo esc_html($label); ?>
                    <?php if ($required) : ?><span class="fone-required" aria-hidden="true">*</span><?php endif; ?>
                </label>
            <?php endif; ?>

            <?php if ($type === 'consent') : ?>
                <?php $checked = !empty($value); ?>
                <label class="fone-choice-row fone-consent-row" for="<?php echo esc_attr($id); ?>">
                    <input
                        id="<?php echo esc_attr($id); ?>"
                        type="checkbox"
                        name="<?php echo esc_attr($id); ?>"
                        value="1"
                        <?php checked($checked, true); ?>
                        <?php echo $required ? 'required' : ''; ?>
                        <?php echo $has_error ? 'aria-invalid="true"' : ''; ?>
                    >
                    <span><?php echo esc_html(!empty($field['default_value']) ? $field['default_value'] : ($label ?: __('Acconsento al trattamento dei dati.', 'form-one'))); ?><?php if ($required) : ?> <span class="fone-required">*</span><?php endif; ?></span>
                </label>

            <?php elseif ($type === 'file') : ?>
                <?php
                // Mostra il file già caricato se presente (es. in area personale)
                $existing_url      = isset($values[$id . '__url'])      ? $values[$id . '__url']      : '';
                $existing_filename = isset($values[$id . '__filename']) ? $values[$id . '__filename'] : '';
                if ($existing_url) :
                    $existing_filename = $existing_filename ?: wp_basename($existing_url);
                ?>
                <div class="fone-file-existing" style="display:flex;align-items:center;gap:10px;padding:10px 12px;margin-bottom:8px;background:#f1f5f9;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;color:#334155;">
                    <span aria-hidden="true">📎</span>
                    <a href="<?php echo esc_url($existing_url); ?>" target="_blank" rel="noopener" style="color:#1e293b;font-weight:600;text-decoration:underline;">
                        <?php echo esc_html($existing_filename); ?>
                    </a>
                    <span class="fone-file-existing-hint" style="margin-left:auto;color:#64748b;font-size:12px;">
                        <?php esc_html_e('Carica un nuovo file per sostituirlo', 'form-one'); ?>
                    </span>
                </div>
                <?php endif; ?>
                <input
                    id="<?php echo esc_attr($id); ?>"
                    name="<?php echo esc_attr($id); ?>"
                    type="file"
                    accept="<?php echo esc_attr($accept); ?>"
                    data-fone-file="1"
                    data-max-size="<?php echo esc_attr($max_size); ?>"
                    <?php echo ($required && !$existing_url) ? 'required' : ''; ?>
                    <?php echo $has_error ? 'aria-invalid="true"' : ''; ?>
                >
                <small class="fone-help"><?php echo esc_html(sprintf(__('Max %d MB', 'form-one'), $max_size)); ?></small>

            <?php elseif ($type === 'range') : ?>
                <?php
                $rmin = isset($field['opt_min']) && $field['opt_min'] !== '' ? $field['opt_min'] : 0;
                $rmax = isset($field['opt_max']) && $field['opt_max'] !== '' ? $field['opt_max'] : 100;
                $rstep = !empty($field['opt_step']) ? $field['opt_step'] : 1;
                $rval = $value !== '' ? $value : (!empty($field['default_value']) ? $field['default_value'] : round(((float)$rmin + (float)$rmax) / 2));
                ?>
                <input
                    id="<?php echo esc_attr($id); ?>"
                    name="<?php echo esc_attr($id); ?>"
                    type="range"
                    min="<?php echo esc_attr($rmin); ?>"
                    max="<?php echo esc_attr($rmax); ?>"
                    step="<?php echo esc_attr($rstep); ?>"
                    value="<?php echo esc_attr($rval); ?>"
                    data-fone-range="1"
                    <?php echo $required ? 'required' : ''; ?>
                >
                <output class="fone-range-output" for="<?php echo esc_attr($id); ?>"><?php echo esc_html($rval); ?></output>

            <?php elseif ($type === 'rating' || $type === 'nps') : ?>
                <?php
                $scale_min = isset($field['opt_min']) && $field['opt_min'] !== '' ? (int) $field['opt_min'] : ($type === 'nps' ? 0 : 1);
                $scale_max = isset($field['opt_max']) && $field['opt_max'] !== '' ? (int) $field['opt_max'] : ($type === 'nps' ? 10 : 5);
                if ($scale_max < $scale_min) { $scale_max = $scale_min; }
                $scale_max = min($scale_max, $scale_min + 14);
                ?>
                <div class="fone-choice-group fone-scale-group fone-scale-<?php echo esc_attr($type); ?>" role="radiogroup">
                    <?php for ($n = $scale_min; $n <= $scale_max; $n++) : ?>
                        <?php $rid = $id . '_' . $n; ?>
                        <label class="fone-choice-row fone-scale-choice" for="<?php echo esc_attr($rid); ?>">
                            <input id="<?php echo esc_attr($rid); ?>" type="radio" name="<?php echo esc_attr($id); ?>" value="<?php echo esc_attr($n); ?>" <?php checked((string)$value, (string)$n); ?> <?php echo $required ? 'required' : ''; ?>>
                            <span><?php echo $type === 'rating' ? '⭐ ' : ''; ?><?php echo esc_html($n); ?></span>
                        </label>
                    <?php endfor; ?>
                </div>

            <?php elseif ($type === 'time') : ?>
                <input
                    id="<?php echo esc_attr($id); ?>"
                    name="<?php echo esc_attr($id); ?>"
                    type="time"
                    value="<?php echo esc_attr(is_array($value) ? '' : $value); ?>"
                    <?php if (!empty($field['opt_min'])) echo ' min="' . esc_attr($field['opt_min']) . '"'; ?>
                    <?php if (!empty($field['opt_max'])) echo ' max="' . esc_attr($field['opt_max']) . '"'; ?>
                    <?php echo $required ? 'required' : ''; ?>
                >

            <?php elseif ($type === 'color') : ?>
                <input
                    id="<?php echo esc_attr($id); ?>"
                    name="<?php echo esc_attr($id); ?>"
                    type="color"
                    value="<?php echo esc_attr($value !== '' && !is_array($value) ? $value : (!empty($field['default_value']) ? $field['default_value'] : '#374151')); ?>"
                    <?php echo $required ? 'required' : ''; ?>
                >

            <?php elseif ($type === 'avatar') : ?>
                <?php
                // Avatar / foto profilo autore — input file con preview
                $existing_id = !empty($value) && is_numeric($value) ? (int) $value : 0;
                $existing_url = $existing_id ? wp_get_attachment_url($existing_id) : '';
                ?>
                <div class="fone-avatar-slot" data-fone-avatar="<?php echo esc_attr($id); ?>">
                    <?php if ($label !== '') : ?>
                        <div class="fone-avatar-label">
                            <?php echo esc_html($label); ?>
                            <?php if ($required) : ?><span class="fone-required">*</span><?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class="fone-avatar-preview">
                        <?php if ($existing_url) : ?>
                            <img src="<?php echo esc_url($existing_url); ?>" alt="<?php echo esc_attr(fone_t('photo_preview')); ?>">
                        <?php else : ?>
                            <div class="fone-avatar-placeholder"><i class="fa-solid fa-camera" aria-hidden="true"></i></div>
                        <?php endif; ?>
                    </div>

                    <div class="fone-avatar-buttons">
                        <label class="fone-avatar-btn fone-avatar-upload-btn">
                            <span><?php echo esc_html(fone_t('upload_photo')); ?></span>
                            <input
                                type="file"
                                id="<?php echo esc_attr($id); ?>"
                                name="<?php echo esc_attr($id); ?>"
                                accept="<?php echo esc_attr($accept); ?>"
                                data-max-size="<?php echo esc_attr($max_size); ?>"
                                class="fone-avatar-input"
                                <?php echo $required ? 'required' : ''; ?>
                            >
                        </label>
                        <label class="fone-avatar-btn fone-avatar-capture-btn">
                            <span><?php echo esc_html(fone_t('take_photo')); ?></span>
                            <input
                                type="file"
                                name="<?php echo esc_attr($id); ?>_capture"
                                accept="<?php echo esc_attr($accept); ?>"
                                capture="user"
                                class="fone-avatar-input"
                            >
                        </label>
                    </div>
                </div>

            <?php elseif (in_array($type, ['tel', 'phone', 'whatsapp'], true)) : ?>
                <?php
                // Selettore prefisso internazionale cliccabile. Il valore finale
                // inviato via $_POST è la concatenazione: prefisso + numero.
                // Il campo sotto è "number only" via pattern + JS.
                $prefix_default = !empty($field['default_prefix']) ? $field['default_prefix'] : '+39';
                $prefixes = [
                    '+39'  => '🇮🇹 Italia (+39)',
                    '+1'   => '🇺🇸 USA/Canada (+1)',
                    '+44'  => '🇬🇧 UK (+44)',
                    '+33'  => '🇫🇷 Francia (+33)',
                    '+49'  => '🇩🇪 Germania (+49)',
                    '+34'  => '🇪🇸 Spagna (+34)',
                    '+41'  => '🇨🇭 Svizzera (+41)',
                    '+43'  => '🇦🇹 Austria (+43)',
                    '+32'  => '🇧🇪 Belgio (+32)',
                    '+31'  => '🇳🇱 Olanda (+31)',
                    '+351' => '🇵🇹 Portogallo (+351)',
                    '+30'  => '🇬🇷 Grecia (+30)',
                    '+46'  => '🇸🇪 Svezia (+46)',
                    '+47'  => '🇳🇴 Norvegia (+47)',
                    '+45'  => '🇩🇰 Danimarca (+45)',
                    '+358' => '🇫🇮 Finlandia (+358)',
                    '+48'  => '🇵🇱 Polonia (+48)',
                    '+420' => '🇨🇿 R. Ceca (+420)',
                    '+36'  => '🇭🇺 Ungheria (+36)',
                    '+40'  => '🇷🇴 Romania (+40)',
                    '+7'   => '🇷🇺 Russia (+7)',
                    '+380' => '🇺🇦 Ucraina (+380)',
                    '+90'  => '🇹🇷 Turchia (+90)',
                    '+86'  => '🇨🇳 Cina (+86)',
                    '+81'  => '🇯🇵 Giappone (+81)',
                    '+82'  => '🇰🇷 Corea del Sud (+82)',
                    '+91'  => '🇮🇳 India (+91)',
                    '+61'  => '🇦🇺 Australia (+61)',
                    '+55'  => '🇧🇷 Brasile (+55)',
                    '+54'  => '🇦🇷 Argentina (+54)',
                    '+52'  => '🇲🇽 Messico (+52)',
                ];

                // Parse valore esistente per ricostruire prefisso+numero
                $cur_prefix = $prefix_default;
                $cur_number = '';
                if (!empty($value) && is_string($value)) {
                    foreach (array_keys($prefixes) as $p) {
                        if (strpos($value, $p) === 0) {
                            $cur_prefix = $p;
                            $cur_number = trim(substr($value, strlen($p)));
                            break;
                        }
                    }
                    if ($cur_number === '' && $cur_prefix === $prefix_default) {
                        $cur_number = $value; // nessun prefisso trovato
                    }
                }

                $wrap_class = 'fone-phone-wrap' . ($type === 'whatsapp' ? ' is-whatsapp' : '');
                ?>
                <div class="<?php echo esc_attr($wrap_class); ?>" data-fone-phone="1">
                    <select
                        name="<?php echo esc_attr($id); ?>_prefix"
                        class="fone-phone-prefix"
                        aria-label="<?php esc_attr_e('Prefisso internazionale', 'form-one'); ?>"
                    >
                        <?php foreach ($prefixes as $code => $label) : ?>
                            <option value="<?php echo esc_attr($code); ?>" <?php selected($cur_prefix, $code); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input
                        id="<?php echo esc_attr($id); ?>"
                        name="<?php echo esc_attr($id); ?>"
                        type="tel"
                        inputmode="numeric"
                        pattern="[0-9 ]*"
                        value="<?php echo esc_attr($cur_number); ?>"
                        placeholder="<?php echo esc_attr($placeholder ?: '333 1234567'); ?>"
                        autocomplete="<?php echo esc_attr($autocomp); ?>"
                        class="fone-phone-number"
                        data-fone-numeric="1"
                        <?php echo $required ? 'required' : ''; ?>
                        <?php echo $has_error ? 'aria-invalid="true"' : ''; ?>
                    >
                </div>

            <?php elseif (in_array($type, ['text', 'name', 'email', 'number', 'url', 'password'], true)) : ?>
                <?php
                $input_type = $type === 'name' ? 'text' : $type;

                // Attributi extra numerici
                $extra_attrs = '';
                if ($type === 'number') {
                    if (isset($field['opt_min']) && $field['opt_min'] !== '')  $extra_attrs .= ' min="' . esc_attr($field['opt_min']) . '"';
                    if (isset($field['opt_max']) && $field['opt_max'] !== '')  $extra_attrs .= ' max="' . esc_attr($field['opt_max']) . '"';
                    if (!empty($field['opt_step']))                             $extra_attrs .= ' step="' . esc_attr($field['opt_step']) . '"';
                }

                // Attributi pattern testo
                if (in_array($type, ['text','name'], true)) {
                    if (!empty($field['opt_max_length']))  $extra_attrs .= ' maxlength="' . esc_attr((int) $field['opt_max_length']) . '"';
                    if (!empty($field['opt_min_length']))  $extra_attrs .= ' minlength="' . esc_attr((int) $field['opt_min_length']) . '"';
                }

                // Data-attribs per JS trasformazioni live
                $data_attrs = '';
                if (!empty($field['opt_lowercase']))        $data_attrs .= ' data-fone-lowercase="1"';
                if (!empty($field['opt_capitalize']))       $data_attrs .= ' data-fone-capitalize="1"';
                if (!empty($field['opt_letters_only']))     $data_attrs .= ' data-fone-letters-only="1"';
                if (!empty($field['opt_alphanum_only']))    $data_attrs .= ' data-fone-alphanum="1"';
                if (!empty($field['opt_no_spaces']))        $data_attrs .= ' data-fone-no-spaces="1"';
                ?>
                <?php if ($type === 'password') : ?>
                    <div class="fone-password-wrap">
                        <input
                            id="<?php echo esc_attr($id); ?>"
                            name="<?php echo esc_attr($id); ?>"
                            type="password"
                            class="fone-password-input"
                            value="<?php echo esc_attr(is_array($value) ? '' : $value); ?>"
                            placeholder="<?php echo esc_attr($placeholder); ?>"
                            autocomplete="<?php echo esc_attr($autocomp); ?>"
                            <?php echo $extra_attrs; ?>
                            <?php echo $data_attrs; ?>
                            <?php echo $required ? 'required' : ''; ?>
                            <?php echo $has_error ? 'aria-invalid="true"' : ''; ?>
                        >
                        <button
                            type="button"
                            class="fone-password-toggle"
                            data-fone-password-toggle="1"
                            aria-controls="<?php echo esc_attr($id); ?>"
                            aria-label="<?php echo esc_attr__('Mostra password', 'form-one'); ?>"
                            aria-pressed="false"
                        >
                            <span class="fone-password-eye" aria-hidden="true"><i class="fa-solid fa-eye"></i></span>
                        </button>
                    </div>
                <?php else : ?>
                    <input
                        id="<?php echo esc_attr($id); ?>"
                        name="<?php echo esc_attr($id); ?>"
                        type="<?php echo esc_attr($input_type); ?>"
                        value="<?php echo esc_attr(is_array($value) ? '' : $value); ?>"
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        autocomplete="<?php echo esc_attr($autocomp); ?>"
                        <?php echo $extra_attrs; ?>
                        <?php echo $data_attrs; ?>
                        <?php echo $required ? 'required' : ''; ?>
                        <?php echo $has_error ? 'aria-invalid="true"' : ''; ?>
                    >
                <?php endif; ?>

                <?php if ($type === 'password' && !empty($field['opt_show_strength'])) : ?>
                    <div class="fone-pw-strength" data-fone-pw-for="<?php echo esc_attr($id); ?>">
                        <div class="fone-pw-strength-bar"><div class="fone-pw-strength-fill"></div></div>
                        <div class="fone-pw-strength-label">—</div>
                    </div>
                <?php endif; ?>

                <?php if ($type === 'email' && !empty($field['opt_require_confirm'])) : ?>
                    <input
                        type="email"
                        name="<?php echo esc_attr($id); ?>_confirm"
                        placeholder="<?php esc_attr_e('Conferma email', 'form-one'); ?>"
                        autocomplete="off"
                        style="margin-top:8px;"
                        <?php echo $required ? 'required' : ''; ?>
                    >
                <?php endif; ?>

            <?php elseif ($type === 'date') : ?>
                <input
                    id="<?php echo esc_attr($id); ?>"
                    name="<?php echo esc_attr($id); ?>"
                    type="date"
                    value="<?php echo esc_attr(is_array($value) ? '' : $value); ?>"
                    autocomplete="<?php echo esc_attr($autocomp); ?>"
                    <?php
                    if (!empty($field['opt_future_only'])) echo ' min="' . esc_attr(date('Y-m-d')) . '"';
                    if (!empty($field['opt_past_only']))   echo ' max="' . esc_attr(date('Y-m-d')) . '"';
                    if (!empty($field['opt_min_age']))     echo ' max="' . esc_attr(date('Y-m-d', strtotime('-' . (int)$field['opt_min_age'] . ' years'))) . '"';
                    if (!empty($field['opt_max_age']))     echo ' min="' . esc_attr(date('Y-m-d', strtotime('-' . (int)$field['opt_max_age'] . ' years'))) . '"';
                    ?>
                    <?php echo $required ? 'required' : ''; ?>
                >

            <?php elseif ($type === 'textarea') : ?>
                <div class="fone-textarea-wrap">
                    <textarea
                        id="<?php echo esc_attr($id); ?>"
                        name="<?php echo esc_attr($id); ?>"
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        <?php echo $required ? 'required' : ''; ?>
                        <?php echo $max_chars > 0 ? 'maxlength="' . esc_attr($max_chars) . '" data-maxchars="' . esc_attr($max_chars) . '"' : ''; ?>
                        <?php echo $has_error ? 'aria-invalid="true"' : ''; ?>
                    ><?php echo esc_textarea(is_array($value) ? '' : $value); ?></textarea>
                    <?php if ($max_chars > 0) : ?>
                        <span class="fone-char-count" data-for="<?php echo esc_attr($id); ?>">0 / <?php echo esc_html($max_chars); ?></span>
                    <?php endif; ?>
                </div>

            <?php elseif ($type === 'select') : ?>
                <select id="<?php echo esc_attr($id); ?>" name="<?php echo esc_attr($id); ?>" autocomplete="<?php echo esc_attr($autocomp); ?>" <?php echo $required ? 'required' : ''; ?>>
                    <option value=""><?php echo esc_html($placeholder ? $placeholder : '— ' . fone_t('step') . ' —'); ?></option>
                    <?php foreach ($options as $option) : ?>
                        <option value="<?php echo esc_attr($option); ?>" <?php selected($value, $option); ?>><?php echo esc_html($option); ?></option>
                    <?php endforeach; ?>
                </select>

            <?php elseif ($type === 'radio') : ?>
                <div class="fone-choice-group" role="radiogroup">
                    <?php foreach ($options as $index => $option) : ?>
                        <?php $rid = $id . '_' . $index; ?>
                        <label class="fone-choice-row" for="<?php echo esc_attr($rid); ?>">
                            <input id="<?php echo esc_attr($rid); ?>" type="radio" name="<?php echo esc_attr($id); ?>" value="<?php echo esc_attr($option); ?>" <?php checked($value, $option); ?> <?php echo $required ? 'required' : ''; ?>>
                            <span><?php echo esc_html($option); ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>

            <?php elseif ($type === 'checkbox') : ?>
                <div class="fone-choice-group">
                    <?php foreach ($options as $index => $option) : ?>
                        <?php
                        $cid     = $id . '_' . $index;
                        $checked = is_array($value) && in_array($option, $value, true);
                        ?>
                        <label class="fone-choice-row" for="<?php echo esc_attr($cid); ?>">
                            <input id="<?php echo esc_attr($cid); ?>" type="checkbox" name="<?php echo esc_attr($id); ?>[]" value="<?php echo esc_attr($option); ?>" <?php checked($checked, true); ?>>
                            <span><?php echo esc_html($option); ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>

            <?php endif; ?>

            <?php if ($has_error) : ?>
                <span class="fone-field-error" role="alert"><?php echo esc_html($errors[$id]); ?></span>
            <?php endif; ?>

            <?php if ($help !== '') : ?>
                <small class="fone-help"><?php echo esc_html($help); ?></small>
            <?php endif; ?>
        </div>
        <?php

        return ob_get_clean();
    }
}

/* ---------------------------------------------------------------
   SHORTCODE — MAIN RENDER
--------------------------------------------------------------- */

if (!function_exists('fone_render_form_shortcode')) {
    function fone_render_form_shortcode($atts = []) {
        if (function_exists('fone_enqueue_front_assets')) {
            fone_enqueue_front_assets(true);
        }
        // Supporta [form_one id="3"] oppure legacy [form_one] (prende il primo form)
        $atts    = shortcode_atts(['id' => 0, 'preview' => 0], $atts, 'form_one');
        $form_id = (int) $atts['id'];
        $fone_preview = !empty($atts['preview']) && $atts['preview'] !== '0';


        $form = null;
        if ($form_id) {
            $form = fone_get_form($form_id);
        }
        if (!$form) {
            // Fallback: primo form disponibile
            $all = fone_get_all_forms();
            $form = $all ? $all[0] : null;
        }

        if (!$form) {
            return '<!-- Form One: nessun form trovato -->';
        }

        $schema   = $form['schema'];
        $settings = $form['settings'];
        $layouts  = $form['layouts'];
        $form_id  = $form['id'];

        // Se la registrazione è attiva e l'utente è già loggato, mostra avviso
        // ECCEZIONE: se siamo nel post-redirect di un submit appena fatto
        // (parametro fone_done_X=1 per QUESTO form), saltiamo questo blocco
        // così l'utente vede il messaggio di benvenuto al posto di "Sei già loggato"
        $done_qkey_check = 'fone_done_' . (int) $form['id'];
        $just_registered = isset($_GET[$done_qkey_check]) && $_GET[$done_qkey_check] === '1';
        if (!$fone_preview && !$just_registered && !empty($settings['enable_registration']) && is_user_logged_in()) {

            $current_user = wp_get_current_user();
            $display_name = $current_user->display_name ?: $current_user->user_login;
            $account_url_raw = !empty($settings['registration_redirect']) ? $settings['registration_redirect'] : '';
            $account_url  = ($account_url_raw && function_exists('fone_sanitize_local_url')) ? fone_sanitize_local_url($account_url_raw, '') : esc_url_raw($account_url_raw);
            ob_start();
            ?>
            <div class="fone-wrap fone-already-logged">
                <div class="fone-success-box" style="flex-direction:column;align-items:flex-start;gap:10px;">
                    <p style="margin:0;font-size:16px;font-weight:600;">
                        <i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> <?php echo wp_kses(sprintf(__('Sei già loggato come %s.', 'form-one'), '<strong>' . esc_html($display_name) . '</strong>'), ['strong' => []]); ?>
                    </p>
                    <?php if ($account_url) : ?>
                        <a href="<?php echo esc_url($account_url); ?>" style="color:#065f46;text-decoration:underline;font-size:14px;">
                            <?php esc_html_e('Vai alla tua area personale →', 'form-one'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        /* ---- PRG: Post → Redirect → Get -------------------------
         * Dopo un submit con errori facciamo redirect alla stessa URL
         * e passiamo errori+valori via transient (chiave in query string).
         * Questo evita che un F5 / back-forward mostri errori stantii.
         * --------------------------------------------------------- */
        $result  = ['success' => false, 'errors' => [], 'values' => []];
        $values  = [];
        $errors  = [];
        $success_payload = [];

        // Chiavi per-form: ogni form ha il suo flash/done separato nella query string
        // es. fone_flash_3=xxx  fone_done_3=1  (dove 3 è il form_id)
        $flash_qkey = 'fone_flash_' . $form_id;
        $done_qkey  = 'fone_done_'  . $form_id;
        $success_qkey = 'fone_success_' . $form_id;

        // 1) C'è un transient da un POST precedente con errori (per questo form)?
        $flash_key = (!$fone_preview && isset($_GET[$flash_qkey])) ? sanitize_key($_GET[$flash_qkey]) : '';

        if ($flash_key) {
            $flash = get_transient('fone_flash_' . $flash_key);
            if (is_array($flash)) {
                $errors = !empty($flash['errors']) ? $flash['errors'] : [];
                $values = !empty($flash['values']) ? $flash['values'] : [];
            }
            delete_transient('fone_flash_' . $flash_key);
        }

        // 2) È un nuovo submit POST per QUESTO form?
        $is_this_form_submit = !empty($_POST['fone_form_submit'])
            && isset($_POST['fone_form_id'])
            && (int) $_POST['fone_form_id'] === $form_id;

        if (!$fone_preview && empty($flash_key) && $is_this_form_submit) {

            $result = fone_handle_submission($schema, $form_id);

            if (!empty($result['success'])) {
                // Successo: redirect con flag per-form + payload temporaneo per azioni post-submit (es. WhatsApp).
                $success_key = wp_generate_uuid4();
                set_transient('fone_success_' . $success_key, [
                    'values' => $result['values'],
                    'schema' => $schema,
                    'form_id' => $form_id,
                ], 5 * MINUTE_IN_SECONDS);

                $reg_redirect_raw = !empty($settings['registration_redirect']) ? $settings['registration_redirect'] : '';
                $reg_redirect    = ($reg_redirect_raw && function_exists('fone_sanitize_local_url')) ? fone_sanitize_local_url($reg_redirect_raw, '') : esc_url_raw($reg_redirect_raw);
                $is_registration = !empty($settings['enable_registration']);

                $success_args = [$done_qkey => '1', $success_qkey => $success_key];
                if ($is_registration && !empty($settings['auto_redirect_profile']) && $reg_redirect) {
                    wp_safe_redirect(add_query_arg($success_args, esc_url_raw($reg_redirect)));
                } else {
                    // Helper robusto: prova permalink corrente, poi referer, poi
                    // URL della richiesta corrente. Evita fallback a home_url
                    // che farebbe perdere il messaggio successo se la pagina è strana.
                    $current_url = function_exists('fone_current_url') ? fone_current_url() : (get_permalink() ?: (wp_get_referer() ?: home_url('/')));
                    $redirect = add_query_arg($success_args, $current_url);
                    wp_safe_redirect($redirect);
                }
                exit;
            }

            if (!empty($result['errors'])) {
                // Errori: salvo in transient con chiave per-form
                $key = wp_generate_uuid4();
                set_transient('fone_flash_' . $key, [
                    'errors' => $result['errors'],
                    'values' => $result['values'],
                ], 5 * MINUTE_IN_SECONDS);
                $current_url = function_exists('fone_current_url') ? fone_current_url() : (get_permalink() ?: (wp_get_referer() ?: home_url('/')));
                $redirect = add_query_arg($flash_qkey, $key, $current_url);
                wp_safe_redirect($redirect);
                exit;
            }
        }

        // 3) Ritorno da redirect successo (solo per questo form)
        if (!$fone_preview && isset($_GET[$done_qkey]) && $_GET[$done_qkey] === '1') {

            $result['success'] = true;
            $success_key = isset($_GET[$success_qkey]) ? sanitize_key(wp_unslash($_GET[$success_qkey])) : '';
            if ($success_key) {
                $success_payload = get_transient('fone_success_' . $success_key);
                if (is_array($success_payload)) {
                    $values = !empty($success_payload['values']) && is_array($success_payload['values']) ? $success_payload['values'] : [];
                }
                delete_transient('fone_success_' . $success_key);
            }
        }

        // Raggruppa per step — senza limite massimo
        $groups = [];
        foreach ($schema as $field) {
            $step = !empty($field['step']) ? (int) $field['step'] : 1;
            $step = max(1, $step);
            if (!isset($groups[$step])) {
                $groups[$step] = [];
            }
            $groups[$step][] = $field;
        }
        ksort($groups, SORT_NUMERIC);

        $non_empty_steps = [];
        foreach ($groups as $sn => $f) {
            if (!empty($f)) {
                $non_empty_steps[] = (int) $sn;
            }
        }

        // Inline CSS
        $accent = !empty($settings['accent_color'])   ? $settings['accent_color']   : '#374151';
        $radius = isset($settings['border_radius'])   ? (int) $settings['border_radius'] : 10;
        $reveal = !empty($settings['reveal_animation']) ? $settings['reveal_animation'] : 'from-top';
        $first_yes_enabled = !empty($settings['first_yes_enabled']);
        $first_yes_presets = [
            'quote'       => ['Richiedi un preventivo', 'Partiamo da una domanda semplice: ti guideremo passo dopo passo.'],
            'consulting'  => ['Inizia la consulenza', 'Raccontaci il punto di partenza, senza compilare tutto subito.'],
            'contact'     => ['Voglio essere ricontattato', 'Ti chiediamo solo le informazioni utili per risponderti bene.'],
            'lead_magnet' => ['Ricevi la risorsa', 'Un passaggio alla volta, senza account e senza complicazioni.'],
            'signup'      => ['Inizia iscrizione', 'Completiamo l\'iscrizione con un percorso guidato.'],
        ];
        $first_yes_preset = !empty($settings['first_yes_preset']) ? sanitize_key($settings['first_yes_preset']) : 'custom';
        $preset_values    = isset($first_yes_presets[$first_yes_preset]) ? $first_yes_presets[$first_yes_preset] : ['', ''];
        $first_yes_label   = !empty($settings['first_yes_button_label']) ? $settings['first_yes_button_label'] : (!empty($preset_values[0]) ? $preset_values[0] : fone_t('continue'));
        $first_yes_hint    = !empty($settings['first_yes_hint']) ? $settings['first_yes_hint'] : (!empty($preset_values[1]) ? $preset_values[1] : '');
        $resume_enabled    = !empty($settings['resume_later_enabled']);
        $resume_ttl_days   = isset($settings['resume_later_ttl_days']) ? max(1, min(30, (int) $settings['resume_later_ttl_days'])) : 7;

        $inline_style = '--fone-accent:' . esc_attr($accent) . ';--fone-radius:' . esc_attr($radius) . 'px;';

        // Capisco se questo è un form di login (per il bypass JS)
        $is_login_attr = '0';
        if (function_exists('fone_submission_is_login_form')) {
            $is_login_attr = fone_submission_is_login_form($form_id, $schema, $settings) ? '1' : '0';
        } elseif (!empty($settings['enable_login'])) {
            $is_login_attr = '1';
        }

        // DIAGNOSTICA: registro nel log cosa stiamo renderizzando
        if (function_exists('fone_login_log')) {
            fone_login_log('[RENDER] form_id=' . $form_id .
                ' is_login_attr=' . $is_login_attr .
                ' enable_login=' . (!empty($settings['enable_login']) ? '1' : '0') .
                ' enable_registration=' . (!empty($settings['enable_registration']) ? '1' : '0'));
        }
        $wrap_classes = 'fone-wrap' . ($fone_preview ? ' fone-preview-mode' : '');
        ob_start();
        ?>
        <div class="<?php echo esc_attr($wrap_classes); ?>" style="
<?php echo esc_attr($inline_style); ?>" data-fone-form-id="<?php echo (int) $form_id; ?>" data-fone-reveal="<?php echo esc_attr($reveal); ?>" data-fone-first-yes="<?php echo $first_yes_enabled ? '1' : '0'; ?>" data-fone-resume="<?php echo $resume_enabled ? '1' : '0'; ?>" data-fone-resume-ttl="<?php echo (int) $resume_ttl_days; ?>" data-fone-is-login="<?php echo esc_attr($is_login_attr); ?>">

            <?php
            // Feature gate PRO: il titolo del form è una funzione premium
            $_is_pro = function_exists('fone_is_premium') ? fone_is_premium() : false;
            $_show_title = $_is_pro && !empty($settings['form_title']);
            ?>
            <?php if ($_show_title || !empty($settings['form_subtitle'])) : ?>
                <div class="fone-form-header">
                    <?php if ($_show_title) : ?>
                        <h2 class="fone-form-title"><?php echo esc_html($settings['form_title']); ?></h2>
                    <?php endif; ?>
                    <?php if (!empty($settings['form_subtitle'])) : ?>
                        <p class="fone-form-subtitle"><?php echo esc_html($settings['form_subtitle']); ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($result['success'])) : ?>
                <?php
                $is_reg   = !empty($settings['enable_registration']);
                $is_login_form = function_exists('fone_submission_is_login_form') ? fone_submission_is_login_form($form_id, $schema, $settings) : !empty($settings['enable_login']);
                $profile_url_raw = !empty($settings['profile_url']) ? $settings['profile_url'] : (function_exists('fone_default_profile_url') ? fone_default_profile_url() : home_url('/account-form-one/'));
                $profile_url   = function_exists('fone_sanitize_local_url') ? fone_sanitize_local_url($profile_url_raw, home_url('/')) : esc_url_raw($profile_url_raw);
                $do_redirect   = !empty($settings['auto_redirect_profile']) && ($is_reg || $is_login_form);
                $redirect_delay = (int)($settings['auto_redirect_delay'] ?? 8);
                $current_user  = wp_get_current_user();
                $display_name  = is_user_logged_in() ? ($current_user->display_name ?: $current_user->user_login) : '';
                $uniq_success  = 'fone-success-' . $form_id;
                ?>
                <div class="fone-success-box fone-success-rich" role="alert" id="<?php echo esc_attr($uniq_success); ?>">
                    <div class="fone-success-icon-wrap">
                        <?php if ($is_reg) : ?>
                            <span class="fone-success-icon-big"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></span>
                        <?php elseif ($is_login_form) : ?>
                            <span class="fone-success-icon-big"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i></span>
                        <?php else : ?>
                            <span class="fone-success-icon-big"><i class="fa-solid fa-check" aria-hidden="true"></i></span>
                        <?php endif; ?>
                    </div>
                    <div class="fone-success-body">
                    <?php if ($is_reg) : ?>
                        <p class="fone-success-title">
                            <?php echo $display_name
                                ? wp_kses(sprintf(__('Benvenuto, %s! Registrazione completata.', 'form-one'), '<strong>' . esc_html($display_name) . '</strong>'), ['strong' => []])
                                : esc_html__('Registrazione completata con successo!', 'form-one'); ?>
                        </p>
                        <p class="fone-success-sub"><?php esc_html_e('Il tuo account è stato creato. Ti abbiamo inviato una email di conferma.', 'form-one'); ?></p>
                    <?php elseif ($is_login_form) : ?>
                        <p class="fone-success-title">
                            <?php echo $display_name
                                ? wp_kses(sprintf(__('Bentornato, %s!', 'form-one'), '<strong>' . esc_html($display_name) . '</strong>'), ['strong' => []])
                                : esc_html__('Accesso effettuato con successo!', 'form-one'); ?>
                        </p>
                        <p class="fone-success-sub"><?php esc_html_e('Sei ora connesso al tuo account.', 'form-one'); ?></p>
                    <?php else : ?>
                        <p class="fone-success-title"><?php echo esc_html(!empty($settings['success_message']) ? $settings['success_message'] : __('Modulo inviato con successo!', 'form-one')); ?></p>
                    <?php endif; ?>

                    <?php if (function_exists('fone_render_success_whatsapp_button')) : ?>
                        <?php echo fone_render_success_whatsapp_button($settings, $schema, $values, $form_id); ?>
                    <?php endif; ?>

                    <?php if (($is_reg || $is_login_form || is_user_logged_in()) && $profile_url) : ?>
                        <?php if (!$is_reg && !$is_login_form && is_user_logged_in()) : ?>
                            <p class="fone-success-sub"><?php esc_html_e('Sei già registrato: puoi vedere o aggiornare i tuoi dati dall\'area personale.', 'form-one'); ?></p>
                        <?php endif; ?>
                        <a href="<?php echo esc_url($profile_url); ?>" class="fone-profile-btn">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            <?php esc_html_e('Vai alla tua area personale', 'form-one'); ?>
                        </a>
                        <?php if ($do_redirect) : ?>
                        <p class="fone-redirect-countdown" data-url="<?php echo esc_attr($profile_url); ?>" data-seconds="<?php echo (int)$redirect_delay; ?>">
                            <?php printf(esc_html__('Reindirizzamento automatico tra %d secondi…', 'form-one'), $redirect_delay); ?>
                        </p>
                        <script>
                        (function(){
                            var el = document.querySelector('#<?php echo esc_js($uniq_success); ?> .fone-redirect-countdown');
                            if (!el) return;
                            var url = el.dataset.url;
                            var s = parseInt(el.dataset.seconds, 10);
                            var iv = setInterval(function(){
                                s--;
                                if (s <= 0) { clearInterval(iv); window.location.href = url; return; }
                                el.textContent = '<?php echo esc_js(__('Reindirizzamento automatico tra', 'form-one')); ?> ' + s + ' <?php echo esc_js(__('secondi…', 'form-one')); ?>';
                            }, 1000);
                        })();
                        </script>
                        <?php endif; ?>
                    <?php endif; ?>
                    </div>
                </div>
            <?php else : ?>

                <?php
                // Calcolo $error_step prima del banner così è disponibile nel messaggio
                $error_step = null;
                if (!empty($errors)) {
                    foreach ($schema as $f) {
                        $fid = $f['id'] ?? '';
                        if ($fid && isset($errors[$fid])) {
                            $error_step = (int) ($f['step'] ?? 1);
                            break;
                        }
                    }
                }
                ?>

                <?php if (!empty($errors['global'])) : ?>
                    <div class="fone-global-error" role="alert"><?php echo esc_html($errors['global']); ?></div>
                <?php elseif (!empty($errors)) :
                    // Costruisco il messaggio con il numero di step e i campi interessati
                    $err_count = 0;
                    $err_first_label = '';
                    foreach ($schema as $f) {
                        $fid = $f['id'] ?? '';
                        if ($fid && isset($errors[$fid])) {
                            $err_count++;
                            if ($err_first_label === '') {
                                $err_first_label = $f['label'] ?? $fid;
                            }
                        }
                    }
                    $step_txt = $error_step ? ' (Step ' . (int) $error_step . ')' : '';
                    $detail_msg = fone_t('global_error') . $step_txt;
                    if ($err_count > 0) {
                        $detail_msg .= ' — ' . $err_count . ($err_count === 1 ? ' campo da correggere' : ' campi da correggere');
                    }
                    ?>
                    <div class="fone-global-error" role="alert" id="fone-error-banner"><?php echo esc_html($detail_msg); ?></div>
                    <script>
                        (function(){
                            // Scroll automatico al primo campo in errore
                            document.addEventListener('DOMContentLoaded', function(){
                                var target = document.querySelector('.fone-field.has-error');
                                if (target) {
                                    setTimeout(function(){
                                        target.scrollIntoView({behavior:'smooth', block:'center'});
                                        var input = target.querySelector('input,select,textarea');
                                        if (input) try { input.focus({preventScroll:true}); } catch(e) {}
                                    }, 120);
                                }
                            });
                        })();
                    </script>
                <?php endif; ?>

                <form method="post" class="fone-front-form" enctype="multipart/form-data" novalidate>
                    <?php wp_nonce_field('fone_submit_form_' . $form_id, 'fone_form_nonce'); ?>
                    <input type="hidden" name="fone_form_submit" value="1">
                    <input type="hidden" name="fone_form_id" value="<?php echo (int) $form_id; ?>">
                    <input type="text" name="fone_honey" value="" class="fone-honeypot" tabindex="-1" autocomplete="off" aria-hidden="true">

                    <?php
                    $step_count = count($non_empty_steps);

                    foreach ($non_empty_steps as $index => $step_number) :
                        $fields    = $groups[$step_number];
                        $is_first  = ($index === 0);
                        $is_last   = ($index === $step_count - 1);

                        // Logica visibilità:
                        // - Se non ci sono errori: mostra solo il primo step (comportamento normale)
                        // - Se ci sono errori: mostra solo lo step con l'errore
                        if ($fone_preview) {
                            $is_hidden = false;
                        } elseif (!empty($errors) && $error_step !== null) {
                            $is_hidden = ($step_number !== $error_step);
                        } else {
                            $is_hidden = !$is_first;
                        }


                        // Layout per-step (1col o 2col)
                        $layout    = isset($layouts[$step_number]) ? $layouts[$step_number] : '1col';
                        $grid_cls  = 'fone-step-grid ' . ($layout === '2col' ? 'is-two-col' : 'is-one-col');
                        $is_registration_form = !empty($settings['enable_registration']);
                        ?>
                        <div class="fone-step-card fone-step-<?php echo esc_attr($step_number); ?><?php echo $is_hidden ? ' is-hidden' : ''; ?>"
                             data-fone-step="<?php echo esc_attr($step_number); ?>"
                             <?php echo $is_hidden ? 'aria-hidden="true"' : ''; ?>>


                            <?php if ($fone_preview && $step_count > 1) : ?>
                                <div class="fone-step-preview-label"><?php echo esc_html(sprintf(__('Step %d', 'form-one'), (int) $step_number)); ?></div>
                            <?php endif; ?>

                            <?php
                            $has_submit_in_step = false;
                            foreach ($fields as $f_check) {
                                if (($f_check['type'] ?? '') === 'submit') { $has_submit_in_step = true; break; }
                            }
                            ?>
                            <div class="<?php echo esc_attr($grid_cls); ?>">
                                <?php foreach ($fields as $field) : ?>
                                    <?php echo fone_render_field($field, $values, $errors, $is_registration_form); ?>
                                <?php endforeach; ?>

                                <?php if ($is_last && !$has_submit_in_step) : ?>
                                    <?php
                                    $fallback_submit_label = $is_login_form
                                        ? __('Accedi', 'form-one')
                                        : ($is_registration_form ? fone_t('submit') : fone_t('submit_generic'));
                                    ?>
                                    <div class="fone-field fone-field-submit fone-width-full fone-submit-fallback">
                                        <button type="submit" class="fone-submit-btn" data-loading="<?php echo esc_attr(fone_t('loading')); ?>"><i class="fa-solid fa-paper-plane" aria-hidden="true"></i> <?php echo esc_html($fallback_submit_label); ?></button>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if ($is_first && $step_count > 1) : ?>
                                <p class="fone-trust-text"><?php echo esc_html(fone_t('trust_text')); ?></p>
                            <?php endif; ?>

                            <?php if ($is_first && $first_yes_enabled && $first_yes_hint !== '') : ?>
                                <p class="fone-first-yes-hint"><?php echo esc_html($first_yes_hint); ?></p>
                            <?php endif; ?>

                            <?php if (!$is_last) :
                                // Mostra "Continua" solo se nello step NON c'è già un submit
                                $has_submit = false;
                                foreach ($fields as $f) {
                                    if (($f['type'] ?? '') === 'submit') { $has_submit = true; break; }
                                }
                                if (!$has_submit) : ?>
                                    <button type="button" class="fone-continue-btn" data-fone-next="<?php echo esc_attr($step_number + 1); ?>">
                                        <?php echo esc_html(($is_first && $first_yes_enabled) ? $first_yes_label : fone_t('continue')); ?>
                                    </button>
                                <?php endif;
                            endif; ?>
                        </div>
                    <?php endforeach; ?>
                </form>

            <?php endif; ?>

            <?php if (!empty($settings['show_donate_frontend']) && !empty($settings['donate_url'])) : ?>
                <div class="fone-donate-wrap">
                    <a class="fone-donate-btn" href="<?php echo esc_url($settings['donate_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(fone_t('donate_now')); ?></a>
                </div>
            <?php endif; ?>
        </div>
        <?php

        return ob_get_clean();
    }
}
