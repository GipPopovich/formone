<?php
/**
 * Form One — Pagina account / profilo utente
 *
 * Shortcode: [fone_account]
 *
 * Mostra i dati dell'utente loggato (quelli inseriti nel form di registrazione)
 * e permette di modificarli tutti tranne email e username.
 *
 * Funzionamento:
 * - Se non loggato → mostra messaggio con link al form
 * - Se loggato     → mostra form di modifica profilo
 * - Salvataggio via POST con nonce
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   HELPER: trova la pagina del form di registrazione
--------------------------------------------------------------- */

if (!function_exists('fone_find_registration_page_url')) {
    function fone_find_registration_page_url($fallback = '') {
        $fallback = $fallback ?: get_permalink();
        $reg_form = function_exists('fone_get_registration_form') ? fone_get_registration_form() : null;
        $reg_id   = $reg_form ? (int) ($reg_form['id'] ?? 0) : 0;

        $pages = get_pages(['post_status' => 'publish']);

        if ($reg_id) {
            $pattern = '/\[form_one\b[^\]]*\bid\s*=\s*["\']?' . preg_quote((string) $reg_id, '/') . '["\']?[^\]]*\]/i';
            foreach ($pages as $page) {
                if (preg_match($pattern, (string) $page->post_content)) {
                    return get_permalink($page->ID);
                }
            }
        }

        foreach ($pages as $page) {
            if (!has_shortcode($page->post_content, 'form_one')) {
                continue;
            }
            if (preg_match('/(registr|iscriz|signup|sign-up|account|utente|user)/i', sanitize_title($page->post_title . ' ' . $page->post_name))) {
                return get_permalink($page->ID);
            }
        }

        foreach ($pages as $page) {
            if (has_shortcode($page->post_content, 'form_one')) {
                return get_permalink($page->ID);
            }
        }

        return $fallback;
    }
}

/* ---------------------------------------------------------------
   SHORTCODE [fone_account]
--------------------------------------------------------------- */


if (!function_exists('fone_render_account_shortcode')) {
    function fone_render_account_shortcode() {
        if (function_exists('fone_enqueue_front_assets')) {
            fone_enqueue_front_assets(true);
        }

        $settings = fone_get_settings();

        // Utente non loggato
        if (!is_user_logged_in()) {
            $form_url = function_exists('fone_find_registration_page_url') ? fone_find_registration_page_url(get_permalink()) : get_permalink();
            ob_start();
            ?>
            <div class="fone-wrap fone-account-wrap">
                <div class="fone-global-error" style="text-align:center;padding:24px;">
                    <p style="margin:0 0 12px;font-size:16px;font-weight:600;"><?php esc_html_e('Devi essere registrato per accedere a questa pagina.', 'form-one'); ?></p>
                    <a href="<?php echo esc_url($form_url); ?>" style="color:#991b1b;text-decoration:underline;"><?php esc_html_e('Vai al form di registrazione →', 'form-one'); ?></a>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        $user_id   = get_current_user_id();
        $user      = get_userdata($user_id);
        // Usa lo schema del form di registrazione attivo
        $reg_form  = fone_get_registration_form();
        $schema    = $reg_form ? $reg_form['schema'] : fone_get_schema_array();
        $save_msg  = '';
        $save_errors = [];

        // ----------------------------------------------------------------
        // Gestione salvataggio
        // ----------------------------------------------------------------
        if (!empty($_POST['fone_account_save']) && !empty($_POST['fone_account_nonce'])) {
            $nonce = sanitize_text_field(wp_unslash($_POST['fone_account_nonce']));
            if (!wp_verify_nonce($nonce, 'fone_account_save_' . $user_id)) {
                $save_errors[] = __('Sessione scaduta. Ricarica la pagina e riprova.', 'form-one');
            } else {
                $update_data = ['ID' => $user_id];
                $meta_updates = [];

                foreach ($schema as $field) {
                    $fid      = $field['id'] ?? '';
                    $type     = $field['type'] ?? '';
                    $wp_field = $field['wp_field'] ?? '';
                    $slug     = $field['slug'] ?? '';

                    if (!$fid || in_array($type, ['html', 'submit', 'paypal_button'], true)) {
                        continue;
                    }

                    // Email e username NON modificabili
                    $slug     = $field['slug'] ?? '';
                    $is_email_field    = ($type === 'email' || $wp_field === 'user_email' || $slug === 'email' || $slug === 'login_email');
                    $is_username_field = ($wp_field === 'user_login' || $slug === 'username');
                    if ($is_email_field || $is_username_field) {
                        continue;
                    }

                    // Avatar: gestione upload
                    if ($type === 'avatar') {
                        $file_key = $fid;
                        if (empty($_FILES[$file_key]['tmp_name']) && !empty($_FILES[$fid . '_capture']['tmp_name'])) {
                            $file_key = $fid . '_capture';
                        }
                        $has_tmp  = !empty($_FILES[$file_key]['tmp_name']);
                        $has_size = !empty($_FILES[$file_key]['size']) && (int) $_FILES[$file_key]['size'] > 0;
                        $err_code = isset($_FILES[$file_key]['error']) ? (int) $_FILES[$file_key]['error'] : UPLOAD_ERR_NO_FILE;

                        if ($has_tmp && $has_size && $err_code === UPLOAD_ERR_OK) {
                            if (!function_exists('wp_handle_upload')) {
                                require_once ABSPATH . 'wp-admin/includes/file.php';
                            }
                            if (!function_exists('media_handle_upload')) {
                                require_once ABSPATH . 'wp-admin/includes/media.php';
                            }
                            if (!function_exists('wp_generate_attachment_metadata')) {
                                require_once ABSPATH . 'wp-admin/includes/image.php';
                            }
                            $up = fone_handle_avatar_upload($file_key, null, 12 * 1024 * 1024);
                            if (!empty($up['ok'])) {
                                fone_assign_avatar_to_user($user_id, $up['attachment_id']);
                            } else {
                                $save_errors[] = ($field['label'] ?? $fid) . ': ' . ($up['error'] ?? __('Errore upload foto.', 'form-one'));
                            }
                        }
                        continue;
                    }

                    // File generico: gestione upload se l'utente ha caricato
                    // un nuovo file dall'area personale; altrimenti preserva
                    // l'attachment_id già salvato.
                    if ($type === 'file') {
                        $has_tmp  = !empty($_FILES[$fid]['tmp_name']);
                        $has_size = !empty($_FILES[$fid]['size']) && (int) $_FILES[$fid]['size'] > 0;
                        $err_code = isset($_FILES[$fid]['error']) ? (int) $_FILES[$fid]['error'] : UPLOAD_ERR_NO_FILE;

                        if ($has_tmp && $has_size && $err_code === UPLOAD_ERR_OK) {
                            $accept_types = !empty($field['accept_types']) ? $field['accept_types'] : '';
                            $accept_arr   = $accept_types ? array_filter(array_map('trim', explode(',', $accept_types))) : null;
                            $max_mb       = !empty($field['max_size_mb']) ? (int) $field['max_size_mb'] : 20;
                            $max_bytes    = max(1, $max_mb) * 1024 * 1024;

                            if (function_exists('fone_handle_file_upload')) {
                                $up = fone_handle_file_upload($fid, $accept_arr, $max_bytes);
                                if (!empty($up['ok']) && !empty($up['attachment_id'])) {
                                    $meta_updates[$fid] = (int) $up['attachment_id'];
                                } else {
                                    $save_errors[] = ($field['label'] ?? $fid) . ': ' . ($up['error'] ?? __('Errore upload file.', 'form-one'));
                                }
                            }
                        }
                        // Se non c'è upload nuovo, il vecchio attachment_id rimane
                        // perché non lo sovrascriviamo né eliminiamo da user_meta.
                        continue;
                    }

                    // Password: aggiornamento speciale
                    if ($type === 'password' || $wp_field === 'user_pass') {
                        $raw_pw = isset($_POST[$fid]) ? wp_strip_all_tags(wp_unslash($_POST[$fid])) : '';
                        if ($raw_pw !== '' && mb_strlen($raw_pw) >= 8) {
                            $update_data['user_pass'] = $raw_pw;
                        }
                        continue;
                    }

                    // Campi WP standard
                    if (!empty($wp_field) && $wp_field !== 'custom_meta') {
                        $raw = isset($_POST[$fid]) ? wp_unslash($_POST[$fid]) : '';
                        if ($wp_field === 'first_name')   $update_data['first_name']   = sanitize_text_field($raw);
                        if ($wp_field === 'last_name')    $update_data['last_name']    = sanitize_text_field($raw);
                        if ($wp_field === 'display_name') $update_data['display_name'] = sanitize_text_field($raw);
                        if ($wp_field === 'user_url')     $update_data['user_url']     = esc_url_raw($raw);
                        if ($wp_field === 'description')  $update_data['description']  = sanitize_textarea_field($raw);
                        continue;
                    }

                    // Meta utente custom — mai scrivere chiavi sensibili come wp_capabilities/user_level.
                    $safe_meta_key = sanitize_key($fid);
                    if (function_exists('fone_is_protected_user_meta_key') && fone_is_protected_user_meta_key($safe_meta_key)) {
                        continue;
                    }

                    if ($type === 'checkbox') {
                        $raw = isset($_POST[$fid]) ? wp_unslash($_POST[$fid]) : [];
                        if (!is_array($raw)) $raw = [];
                        $meta_updates[$safe_meta_key] = array_map('sanitize_text_field', $raw);
                    } else {
                        $raw = isset($_POST[$fid]) ? wp_unslash($_POST[$fid]) : '';
                        $meta_updates[$safe_meta_key] = sanitize_text_field($raw);
                    }
                }

                if (empty($save_errors)) {
                    $result = wp_update_user($update_data);
                    if (is_wp_error($result)) {
                        $save_errors[] = $result->get_error_message();
                    } else {
                        foreach ($meta_updates as $key => $val) {
                            $key = sanitize_key($key);
                            if (function_exists('fone_is_protected_user_meta_key') && fone_is_protected_user_meta_key($key)) {
                                continue;
                            }
                            update_user_meta($user_id, $key, $val);
                        }
                        // Aggiorna display_name se first+last sono stati cambiati
                        if (isset($update_data['first_name']) || isset($update_data['last_name'])) {
                            $fn = get_user_meta($user_id, 'first_name', true);
                            $ln = get_user_meta($user_id, 'last_name', true);
                            if ($fn || $ln) {
                                wp_update_user(['ID' => $user_id, 'display_name' => trim($fn . ' ' . $ln)]);
                            }
                        }
                        $save_msg = __('✅ Profilo aggiornato con successo!', 'form-one');
                        // Ricarico i dati aggiornati
                        $user = get_userdata($user_id);
                    }
                }
            }
        }

        // ----------------------------------------------------------------
        // Leggo i valori correnti dell'utente per pre-compilare il form
        // ----------------------------------------------------------------
        $current_values = fone_account_get_user_values($user_id, $schema);

        // ----------------------------------------------------------------
        // Render
        // ----------------------------------------------------------------
        ob_start();
        ?>
        <div class="fone-wrap fone-account-wrap" style="<?php echo esc_attr('--fone-accent:' . ($settings['accent_color'] ?? '#2563eb') . ';--fone-radius:' . ((int)($settings['border_radius'] ?? 10)) . 'px;'); ?>">

            <?php if (isset($_GET['fone_done']) && $_GET['fone_done'] === '1') : ?>
                <div class="fone-success-box" role="alert" style="margin-bottom:20px;">
                    <span class="fone-success-icon">✓</span>
                    <div>
                        <p style="margin:0 0 4px;font-weight:700;font-size:16px;">
                            🎉 <?php echo wp_kses(
                                sprintf(__('Benvenuto, %s!', 'form-one'), '<strong>' . esc_html($user->display_name ?: $user->user_login) . '</strong>'),
                                ['strong' => []]
                            ); ?>
                        </p>
                        <p style="margin:0;font-size:14px;color:#065f46;">
                            <?php esc_html_e('Il tuo account è stato creato. Qui puoi modificare i tuoi dati in qualsiasi momento.', 'form-one'); ?>
                        </p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Header profilo -->
            <?php
            $acct_profile_url = function_exists('fone_default_profile_url') ? fone_default_profile_url() : home_url('/account-form-one/');
            $reg_form_acct = fone_get_registration_form();
            if ($reg_form_acct && !empty($reg_form_acct['settings']['profile_url'])) {
                $acct_profile_url = function_exists('fone_sanitize_local_url')
                    ? fone_sanitize_local_url($reg_form_acct['settings']['profile_url'], $acct_profile_url)
                    : esc_url_raw($reg_form_acct['settings']['profile_url']);
            }
            ?>
            <div class="fone-account-header" style="display:flex;align-items:center;gap:18px;margin-bottom:24px;padding-bottom:20px;border-bottom:1px solid #e2e8f0;">
                <?php
                $avatar_html = get_avatar($user_id, 72, '', '', ['class' => 'fone-account-avatar']);
                echo $avatar_html; // phpcs:ignore
                $logout_url = wp_logout_url(home_url('/'));
                ?>
                <div style="flex:1;min-width:0;">
                    <h2 style="margin:0 0 4px;font-size:20px;font-weight:700;color:#0f172a;"><?php echo esc_html($user->display_name ?: $user->user_login); ?></h2>
                    <p style="margin:0;font-size:13px;color:#64748b;"><?php echo esc_html($user->user_email); ?> &middot; <?php echo esc_html(ucfirst($user->roles[0] ?? 'subscriber')); ?></p>
                </div>
                <a href="<?php echo esc_url($logout_url); ?>" class="fone-account-logout" style="display:inline-flex;align-items:center;gap:7px;padding:9px 15px;border:1.5px solid #e2e8f0;border-radius:var(--fone-radius);color:#334155;background:#fff;text-decoration:none;font-weight:700;font-size:13px;white-space:nowrap;">
                    <span aria-hidden="true">↪</span> <?php esc_html_e('Esci', 'form-one'); ?>
                </a>
            </div>


            <?php if ($save_msg) : ?>
                <div class="fone-success-box" style="margin-bottom:18px;" role="alert">
                    <span class="fone-success-icon">✓</span>
                    <p><?php echo esc_html($save_msg); ?></p>
                </div>
            <?php endif; ?>

            <?php if (!empty($save_errors)) : ?>
                <div class="fone-global-error" role="alert" style="margin-bottom:18px;">
                    <?php foreach ($save_errors as $err) : ?>
                        <div><?php echo esc_html($err); ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- Dati non modificabili -->
            <div class="fone-account-readonly" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px 18px;margin-bottom:20px;">
                <p style="margin:0 0 8px;font-size:12px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.04em;"><?php esc_html_e('Dati non modificabili', 'form-one'); ?></p>
                <div style="display:flex;gap:24px;flex-wrap:wrap;">
                    <div>
                        <span style="font-size:12px;color:#64748b;"><?php esc_html_e('Username', 'form-one'); ?></span>
                        <p style="margin:2px 0 0;font-weight:600;color:#0f172a;"><?php echo esc_html($user->user_login); ?></p>
                    </div>
                    <div>
                        <span style="font-size:12px;color:#64748b;"><?php esc_html_e('Email', 'form-one'); ?></span>
                        <p style="margin:2px 0 0;font-weight:600;color:#0f172a;"><?php echo esc_html($user->user_email); ?></p>
                    </div>
                    <div>
                        <span style="font-size:12px;color:#64748b;"><?php esc_html_e('Registrato il', 'form-one'); ?></span>
                        <p style="margin:2px 0 0;font-weight:600;color:#0f172a;"><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($user->user_registered))); ?></p>
                    </div>
                </div>
            </div>

            <!-- Form modifica -->
            <form method="post" enctype="multipart/form-data" class="fone-front-form fone-account-form" novalidate>
                <?php wp_nonce_field('fone_account_save_' . $user_id, 'fone_account_nonce'); ?>
                <input type="hidden" name="fone_account_save" value="1">

                <div class="fone-step-grid is-two-col" style="margin-bottom:20px;">
                <?php
                foreach ($schema as $field) :
                    $fid      = $field['id'] ?? '';
                    $type     = $field['type'] ?? '';
                    $wp_field = $field['wp_field'] ?? '';
                    $slug     = $field['slug'] ?? '';

                    if (!$fid || in_array($type, ['html', 'submit', 'paypal_button'], true)) {
                        continue;
                    }

                    // Email e username: non editabili (già mostrati nel blocco readonly)
                    $is_email_field    = ($type === 'email' || $wp_field === 'user_email' || $slug === 'email' || $slug === 'login_email');
                    $is_username_field = ($wp_field === 'user_login' || $slug === 'username');
                    if ($is_email_field || $is_username_field) {
                        continue;
                    }

                    // Avatar in account: mostra bottone "Cambia foto" invece del drag&drop
                    if ($type === 'avatar') {
                        $att_id_cur  = !empty($current_values[$fid]) ? (int)$current_values[$fid] : 0;
                        $current_img = $att_id_cur ? wp_get_attachment_image_url($att_id_cur, 'thumbnail') : get_avatar_url($user_id, ['size'=>80]);
                        $accept_cur  = !empty($field['accept_types']) ? $field['accept_types'] : 'image/jpeg,image/png,image/webp';
                        ?>
                        <div class="fone-field fone-width-full fone-type-avatar fone-account-avatar-field">
                            <div class="fone-account-avatar-row">
                                <?php if ($current_img) : ?>
                                    <img id="fone-acct-avatar-preview-<?php echo esc_attr($fid); ?>"
                                         src="<?php echo esc_url($current_img); ?>"
                                         alt="" class="fone-account-avatar-img">
                                <?php endif; ?>
                                <div class="fone-account-avatar-btns">
                                    <label class="fone-btn fone-btn-ghost fone-btn-sm fone-change-photo-btn" style="cursor:pointer;">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
                                        <?php esc_html_e('Cambia foto', 'form-one'); ?>
                                        <input type="file" id="<?php echo esc_attr($fid); ?>"
                                               name="<?php echo esc_attr($fid); ?>"
                                               accept="<?php echo esc_attr($accept_cur); ?>"
                                               data-max-size="12"
                                               class="fone-avatar-input"
                                               style="display:none;"
                                               data-preview="fone-acct-avatar-preview-<?php echo esc_attr($fid); ?>">
                                    </label>
                                </div>
                            </div>
                        </div>
                        <?php
                        continue;
                    }

                    // Usa il valore corrente dell'utente
                    $field_with_value = $field;
                    echo fone_render_field($field_with_value, $current_values, []);
                endforeach;
                ?>
                </div>

                <button type="submit" class="fone-submit-btn" style="width:auto;padding:12px 28px;">
                    <?php esc_html_e('Salva modifiche', 'form-one'); ?>
                </button>
            </form>
        </div>
        <?php

        return ob_get_clean();
    }
}

/* ---------------------------------------------------------------
   HELPER: legge i valori attuali dell'utente per pre-compilare il form
--------------------------------------------------------------- */

if (!function_exists('fone_account_get_user_values')) {
    function fone_account_get_user_values($user_id, $schema) {
        $user   = get_userdata($user_id);
        $values = [];

        $wp_map = [
            'first_name'   => $user->first_name,
            'last_name'    => $user->last_name,
            'display_name' => $user->display_name,
            'user_url'     => $user->user_url,
            'description'  => get_user_meta($user_id, 'description', true),
        ];

        foreach ($schema as $field) {
            $fid      = $field['id'] ?? '';
            $type     = $field['type'] ?? '';
            $wp_field = $field['wp_field'] ?? '';

            if (!$fid) continue;

            // Avatar: legge l'attachment associato.
            // Compatibile con tutte le 3 chiavi che il sistema può aver scritto:
            // fone_avatar_id (nostra), wp_user_avatar (compat con plugin terzi),
            // _fone_avatar_attachment_id (legacy)
            if ($type === 'avatar') {
                $att_id = (int) get_user_meta($user_id, 'fone_avatar_id', true);
                if (!$att_id) $att_id = (int) get_user_meta($user_id, 'wp_user_avatar', true);
                if (!$att_id) $att_id = (int) get_user_meta($user_id, '_fone_avatar_attachment_id', true);

                $values[$fid] = $att_id > 0 ? $att_id : '';
                if ($att_id > 0) {
                    $url = wp_get_attachment_url($att_id);
                    if ($url) $values[$fid . '__url'] = $url;
                }
                continue;
            }

            // File generico: salva solo l'attachment_id come meta.
            // Recuperiamo il file caricato in registrazione e popoliamo URL/nome
            // per mostrarli in area personale come link cliccabile.
            if ($type === 'file') {
                $att_id = (int) get_user_meta($user_id, $fid, true);
                $values[$fid] = $att_id > 0 ? $att_id : '';
                if ($att_id > 0) {
                    $url      = wp_get_attachment_url($att_id);
                    $filename = $url ? wp_basename($url) : '';
                    if ($url)      $values[$fid . '__url']      = $url;
                    if ($filename) $values[$fid . '__filename'] = $filename;
                }
                continue;
            }

            // Campi mappati su WP standard
            if (!empty($wp_field) && isset($wp_map[$wp_field])) {
                $values[$fid] = $wp_map[$wp_field];
                continue;
            }

            // Meta custom salvati al momento della registrazione
            $meta = get_user_meta($user_id, $fid, true);
            if ($meta !== '') {
                $values[$fid] = $meta;
            }
        }

        return $values;
    }
}
